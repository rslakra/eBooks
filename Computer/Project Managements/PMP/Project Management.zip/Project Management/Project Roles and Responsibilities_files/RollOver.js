//==================================================================================
//==================================================================================
//=====================PAREMETERS:
arr1 = new Array("Home", "About TenStep", "Partner with us", "TenStep USA offices", "TenStep Worldwide", "Our clients", "Contact us");
arrUrl1 = new Array("http://www.tenstep.com", "http://www.TenStep.com/open/miscpages/90.0AboutTenStepInc.htm", "http://www.TenStep.com/open/miscpages/91.0PartnershipsandNetworking.htm", "http://www.tenstep.com/open/miscpages/90.3TenStepGlobalNetwork.htm", "http://www.tenstep.com/open/miscpages/90.3TenStepGlobalNetwork.htm#TenStep_Worldwide", "http://www.tenstep.com/open/miscpages/90.4.1LookWhoisUsingTenStep.htm", "http://www.tenstep.com/open/miscpages/90.11ContactTenStep.htm");
arr1_1 = new Array( "" );
arrUrl1_1 = new Array( "" );
arr1_2 = new Array( "" );
arrUrl1_2 = new Array( "" );
arr1_3 = new Array( "" );
arrUrl1_3 = new Array( "" );
arr1_4 = new Array( "" );
arrUrl1_4 = new Array( "" );
arr1_5 = new Array( "" );
arrUrl1_5 = new Array( "" );
arr1_6 = new Array( "" );
arrUrl1_6 = new Array( "" );
arr1_7 = new Array( "" );
arrUrl1_7 = new Array( "" );
//--
arr2 = new Array("All Available Classes", "US Class Schedule", "Non-US Class Schedule");
arrUrl2 = new Array("http://www.tenstep.com/open/miscpages/90.6TrainingClasses.htm", "https://www.mcssl.com/app/adtrack.asp?MerchantID=101473&AdID=309180", "http://www.tenstep.com/open/miscpages/90.3.1TenStepWorldwideUpcomingEvents.htm");
arr2_1 = new Array( "" );
arrUrl2_1 = new Array( "" );
arr2_2 = new Array( "" );
arrUrl2_2 = new Array( "" );
arr2_3 = new Array( "" );
arrUrl2_3 = new Array( "" );
//--
arr3 = new Array("");
arrUrl3 = new Array("");
//--
arr4 = new Array( "TenStep PM Process", "TenStep PMBOK Format", "Product licenses");
arrUrl4 = new Array("http://www.tenstep.com/open/0.0.0TenStepHomepage.htm", "http://www.tensteppb.com/0.0.0TenStepPBHomepage.htm", "http://www.tenstep.com/open/miscpages/93.0TenStepLicenses.htm");
arr4_1 = new Array( "");
arrUrl4_1 = new Array( "" );
arr4_2 = new Array( "" );
arrUrl4_2 = new Array( "" );
arr4_3 = new Array( "" );
arrUrl4_3 = new Array( "" );
//--
arr5 = new Array("LifecycleStep Process", "LifecycleStep licenses");
arrUrl5 = new Array("http://www.lifecyclestep.com/open/0.0.0LifecycleStepHomepage.htm", "http://www.lifecyclestep.com/open/miscpages/498.2Licenses.htm");
arr5_1 = new Array( "" );
arrUrl5_1 = new Array( "" );
arr5_2 = new Array( "" );
arrUrl5_2 = new Array( "" );
//--
arr6 = new Array("PMOStep Framework", "PortfolioStep Framework", "SupportStep Framework");
arrUrl6 = new Array("http://www.pmostep.com/0.0.0PMOStepHomepage.htm", "http://www.portfoliostep.com/0.0.0PortfolioStepHomepage.htm", "http://www.supportstep.com/100.0.0SupportStepHomepage.htm");
arr6_1 = new Array( "" );
arrUrl6_1 = new Array( "" );
arr6_2 = new Array( "" );
arrUrl6_2 = new Array( "" );
arr6_3 = new Array( "" );
arrUrl6_3 = new Array( "" );
//--
arr7 = new Array("");
arrUrl7 = new Array("");
//--
arr8 = new Array("");
arrUrl8 = new Array("");
//--
arr9 = new Array("");
arrUrl9 = new Array("");
//=====================END PAREMETERS
//==================================================================================
//==================================================================================

function rollOver( idx, depth )
{
    var wid = 130    
    arrX = eval( "arr" + idx );
    if(  arrX.length > 1  ) //Only those nodes with children
    {     
        if( depth == 1 ) //If this is the parent categoy, i need to move it down, if not, it has to be in the same top position from the top
        { 
            var top = 30
            var objAnchorCategory = document.getElementById("Parent"+ idx)
            MyDiv = document.getElementById("divParent")        
        }
        if( depth == 2 )
        { 
            var top= 0 
            //alert( idx ) //"son"+ idx.substring( 0, idx.lastIndexOf('_') ) );
            //alert( idx.substring( idx.lastIndexOf('_') +1 ) );
            var objAnchorCategory = document.getElementById("son"+ idx.substring( idx.lastIndexOf('_') +1 )  )
            MyDiv = document.getElementById("divSon")
        }
        //if( depth == 3 )
        { 
        //    alert( "3-" + "son"+ idx.substring( 0, idx.lastIndexOf('_') ) );
        //    var top= 0 
        //    var objAnchorCategory = document.getElementById("son"+ idx.substring( 0, idx.lastIndexOf('_') )  )
        //    MyDiv = document.getElementById("divSubSon")
        }
        IE=document.all;
        NS=document.layers;
                
        MyDiv.innerHTML = "";
        //MyDiv.onmouseover = " alert( 'outTable' )";
        var MyTable = MyDiv.appendChild(document.createElement('Table'));
        MyTable.cellspacing="0"
        MyTable.cellpadding="0"
        MyTable.id = 'Tabla1'
        //var tbody = MyTable.getElementsByTagName("TBODY")[0]; 
        
        //MyTable.onmouseout = " alert( MyDiv.innerHTML )";
        
        
    //=============Adding the elements of the menu===================
    // this line takes the variables from the top of the page according to the parameter 'idx', this parameter could go from 1 to n Now the page contains 9 categories About...Tenstep Store
        arrTmp = eval( "arr" + idx )
        arrUrlTmp = eval( "arrUrl" + idx )
        for( h = 0; h < arrTmp.length; h++ )
	    {	
	        var MyTR = MyTable.appendChild(document.createElement('TR'));
	        var MyTD = MyTR.appendChild(document.createElement('TD'));
	        MyTD.appendChild(document.createTextNode( arrTmp[h] ) )
	        MyTD.id = "son" + (h*1 + 1)
	        //MyTD.id = "son" + idx
	        MyTD.style.width = wid

	        //Look and feel can be found in CascadeMenu.css under class 'tableClass'
            if( depth == 1 )
            {	     
                MyTD.className = 'tableClass'   
	            MyTD.onmouseover = "rollOver('" + idx + "_" + ((h*1)+1) + "'," + ( (depth*1) + 1 ) + "); changeColor(this)";
	            MyTD.onmouseout = "this.className = 'tableClass'";
            }
            else
            {                
                MyTD.className = 'tableSelectedClass'
                //MyTD.onmouseover = "rollOver('" + idx + "'," + ( 1 ) + "); changeColor(this)";
            }
            
            if( arrUrlTmp[h] != "" )
            {
                MyTD.onclick = "location.href = '" + arrUrlTmp[h] + "'";
            }
	    }
        //=============END - Adding the elements of the menu===================
        MyDiv.appendChild( MyTable );
        //Position and mouse style        
        //top = top *3
        if( depth == 1 )
        {
            MyDiv.style.left = getLeft(objAnchorCategory);
            MyDiv.style.top = getTop(objAnchorCategory) + top;
        }
        else //if( depth == 2 )
        {
            MyDiv.style.left = getLeft(objAnchorCategory) + wid ;
            MyDiv.style.top = getTop(objAnchorCategory)
        }
        //if( depth == 3 )
        {
            //MyDiv.style.left = getLeft(objAnchorCategory) + wid ;
        }
        MyDiv.style.cursor = "HAND";    
        MyDiv.innerHTML = MyDiv.innerHTML 
    } //    if( arrTmp.length )
    
            var tbody = document.getElementById('Tabla1').getElementsByTagName("TBODY")[0]; 
        tbody.onmouseout = " alert( 'outTable' )";
}
//==================================================================================
//==================================================================================
function clearParent(p1, p2)
{
    MyDiv = document.getElementById("divParent")
    MyDiv.innerHTML = '';
}
function clearMenu(p1, p2)
{
    MyDiv = document.getElementById("divSon")
    MyDiv.innerHTML = '';
    MyDiv = document.getElementById("divParent")
    MyDiv.innerHTML = '';
}
function clearSubMenu(p1, p2)
{
    MyDiv = document.getElementById("divSon")
    MyDiv.innerHTML = '';
}
function changeColor( obj )
{
    obj.className = 'tableSelectedClass'
}
//==================================================================================
//==================================================================================
//======================Functions to get the position of the parent category, this is the top table (about, training, consulting, etc. )
function getLeft(MyObject)
{
    if (MyObject.offsetParent)
        return (MyObject.offsetLeft + getLeft(MyObject.offsetParent));
    else 
        return (MyObject.offsetLeft);
} 
//============
function getTop(MyObject)
{
    if (MyObject.offsetParent)
        return (MyObject.offsetTop + getTop(MyObject.offsetParent));
    else
        return (MyObject.offsetTop);
}
//============
function mouseEventHandler(mEvent)
{
	// Internet Explorer
	if (mEvent.srcElement)
	{
		if (mEvent.srcElement.id )
		{
		    if ( mEvent.srcElement.id.indexOf('son') > -1 || mEvent.srcElement.id.indexOf('Parent') > -1 || mEvent.srcElement.parentNode.id.indexOf('Parent') > -1 )
            {
            //alert( "Menu Stays" )
            }
            else
            {
            clearMenu()
            }
        }
        else
        {
            if( mEvent.srcElement.parentNode.id.indexOf('Parent') > -1 )
            {
            //alert( "Menu Stays" )
            }
            else
            {
            clearMenu()
            }
        }
	}
	// Netscape and Firefox
	else if (mEvent.target)
	{
		if (mEvent.target.id )
		{
		    if ( mEvent.target.id.indexOf('son') > -1 || mEvent.target.id.indexOf('Parent') > -1 || mEvent.target.parentNode.id.indexOf('Parent') > -1 )
            {
            //alert( "Menu Stays" )
            }
            else
            {
            clearMenu()
            }
        }
        else
        {
            if( mEvent.target.parentNode.id.indexOf('Parent') > -1 )
            {
            //alert( "Menu Stays" )
            }
            else
            {
            clearMenu()
            }
        }	
	}
}
//=====================Functions==================================================================
//================================================================================================