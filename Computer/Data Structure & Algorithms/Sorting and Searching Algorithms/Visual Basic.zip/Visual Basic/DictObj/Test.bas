Attribute VB_Name = "Test"
Option Explicit


' error constants
Public Const errKeyNotFound As Long = &H1
Public Const errDuplicateKey As Long = &H2

Public Sub Raise(errno As Long, loc As String)
    Dim msg As String

    ' express error as text
    Select Case errno
    Case errKeyNotFound
        msg = "Key not found"
    Case errDuplicateKey
        msg = "Duplicate key"
    End Select

    Err.Raise errno + vbObjectError + &H200, App.EXEName & "." & loc, msg & "."
End Sub

Public Sub Test()
    Dim i As Long
    Dim rec() As Variant
    Dim key() As Variant
    Dim start As Single
    Dim time(3) As Single
    Dim ln(3) As String
    Dim r As Variant
     
    Select Case FDemo.Method
    Case 0
        Hash.Init FDemo.Size
    Case 1
        Bin.Init
    Case 2
        Rbt.Init
    End Select
    
    ReDim rec(1 To FDemo.ItemCount)
    ReDim key(1 To FDemo.ItemCount)

    ' create keys
    For i = 1 To FDemo.ItemCount
        key(i) = Rnd * FDemo.ItemCount
    Next i

    start = Timer
    For i = 1 To FDemo.ItemCount
        Select Case FDemo.Method
        Case 0
            Hash.Insert key(i), rec(i)
        Case 1
            Bin.Insert key(i), rec(i)
        Case 2
            Rbt.Insert key(i), rec(i)
        End Select
    Next i
    time(0) = Timer - start
 
    start = Timer
    For i = 1 To FDemo.ItemCount
        Select Case FDemo.Method
        Case 0
            r = Hash.Find(key(i))
        Case 1
            r = Bin.Find(key(i))
        Case 2
            r = Rbt.Find(key(i))
        End Select
  
        If r <> rec(i) Then MsgBox "fail at " & i
    Next i
    time(1) = Timer - start

    start = Timer
    For i = 1 To FDemo.ItemCount
        Select Case FDemo.Method
        Case 0
            Hash.Delete key(i)
        Case 1
            Bin.Delete key(i)
        Case 2
            Rbt.Delete key(i)
        End Select
    Next i
    time(2) = Timer - start

    ln(0) = vbCrLf & "Insert: " & vbTab & FormatNumber(time(0), 2) & " secs"
    ln(1) = vbCrLf & "Search: " & vbTab & FormatNumber(time(1), 2) & " secs"
    ln(2) = vbCrLf & "Delete: " & vbTab & FormatNumber(time(2), 2) & " secs"
    MsgBox "Execution Time" & ln(0) & ln(1) & ln(2)

    Select Case FDemo.Method
    Case 0
        Hash.Term
    Case 1
        Bin.Term
    Case 2
        Rbt.Term
    End Select
End Sub

