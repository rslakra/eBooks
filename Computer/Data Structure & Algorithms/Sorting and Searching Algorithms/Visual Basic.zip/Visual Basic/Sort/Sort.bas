Attribute VB_Name = "Sort"
Option Explicit

Public Sub InsertSort(ByRef A() As Variant, ByVal Lb As Long, ByVal Ub As Long)
    Dim t As Variant
    Dim i As Long
    Dim j As Long

    ' sort A[Lb..Ub]
    For i = Lb + 1 To Ub
        t = A(i)

        ' shift elements down until insertion point found
        For j = i - 1 To Lb Step -1
            If A(j) <= t Then Exit For
            A(j + 1) = A(j)
        Next j

        ' insert
        A(j + 1) = t
    Next i
End Sub

Public Sub ShellSort(ByRef A() As Variant, ByVal Lb As Long, ByVal Ub As Long)
    Dim n As Long
    Dim h As Long
    Dim i As Long
    Dim j As Long
    Dim t As Variant

    ' sort array[lb..ub]

    ' compute largest increment
    n = Ub - Lb + 1
    h = 1
    If (n < 14) Then
        h = 1
    Else
        Do While h < n
            h = 3 * h + 1
        Loop
        h = h \ 3
        h = h \ 3
    End If

    Do While h > 0
        ' sort by insertion in increments of h
        For i = Lb + h To Ub
            t = A(i)
            For j = i - h To Lb Step -h
                If A(j) <= t Then Exit For
                A(j + h) = A(j)
            Next j
            A(j + h) = t
        Next i
        h = h \ 3
    Loop
End Sub

Private Function Partition(ByRef A() As Variant, ByVal Lb As Long, ByVal Ub As Long) _
        As Long
    Dim t As Variant
    Dim pivot As Variant
    Dim i As Long
    Dim j As Long
    Dim p As Long

    ' partition array[lb..ub]

    ' select pivot and exchange with 1st element
    p = Lb + (Ub - Lb) \ 2
    pivot = A(p)
    A(p) = A(Lb)

    ' sort Lb+1 .. Ub based on pivot
    i = Lb + 1
    j = Ub
    Do
        Do While i < j
            If pivot <= A(i) Then Exit Do
            i = i + 1
        Loop
        Do While j >= i
            If A(j) <= pivot Then Exit Do
            j = j - 1
        Loop
        If i >= j Then Exit Do
        t = A(i)
        A(i) = A(j)
        A(j) = t
        j = j - 1
        i = i + 1
    Loop

    ' pivot belongs in a(j)
    A(Lb) = A(j)
    A(j) = pivot
    Partition = j
End Function

Public Sub QuickSort(ByRef A() As Variant, ByVal Lb As Long, ByVal Ub As Long)
    Dim m As Long

    ' sort array A(lb..ub)

    Do While Lb < Ub
        ' quickly sort short lists
        If (Ub - Lb <= 12) Then
            Call InsertSort(A, Lb, Ub)
            Exit Sub
        End If

        ' partition into two segments
        m = Partition(A, Lb, Ub)

        ' sort the smallest partition to minimize stack requirements
        If m - Lb <= Ub - m Then
            Call QuickSort(A, Lb, m - 1)
            Lb = m + 1
        Else
            Call QuickSort(A, m + 1, Ub)
            Ub = m - 1
        End If
    Loop
End Sub

Public Sub QSort(ByRef A() As Variant, ByVal Lb As Long, ByVal Ub As Long)
    Dim lbStack(32) As Long
    Dim ubStack(32) As Long
    Dim sp As Long              ' stack pointer
    Dim lbx As Long             ' current lower-bound
    Dim ubx As Long             ' current upper-bound
    Dim m As Long
    Dim p As Long               ' index to pivot
    Dim i As Long
    Dim j As Long
    Dim t As Variant            ' temp used for exchanges

    lbStack(0) = Lb
    ubStack(0) = Ub
    sp = 0
    Do While sp >= 0
        lbx = lbStack(sp)
        ubx = ubStack(sp)

        Do While (lbx < ubx)

            ' select pivot and exchange with 1st element
            p = lbx + (ubx - lbx) \ 2

            ' exchange lbx, p
            t = A(lbx)
            A(lbx) = A(p)
            A(p) = t

            ' partition into two segments
            i = lbx + 1
            j = ubx
            Do
                Do While i < j
                    If A(lbx) <= A(i) Then Exit Do
                    i = i + 1
                Loop

                Do While j >= i
                    If A(j) <= A(lbx) Then Exit Do
                    j = j - 1
                Loop

                If i >= j Then Exit Do

                ' exchange i, j
                t = A(i)
                A(i) = A(j)
                A(j) = t

                j = j - 1
                i = i + 1
            Loop

            ' pivot belongs in A[j]
            ' exchange lbx, j
            t = A(lbx)
            A(lbx) = A(j)
            A(j) = t

            m = j

            ' keep processing smallest segment, and stack largest
            If m - lbx <= ubx - m Then
                If m + 1 < ubx Then
                    lbStack(sp) = m + 1
                    ubStack(sp) = ubx
                    sp = sp + 1
                End If
                ubx = m - 1
            Else
                If m - 1 > lbx Then
                    lbStack(sp) = lbx
                    ubStack(sp) = m - 1
                    sp = sp + 1
                End If
                lbx = m + 1
            End If
        Loop
        sp = sp - 1
    Loop
End Sub


