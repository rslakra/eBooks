Attribute VB_Name = "SortTest"
Option Explicit

Public Sub Test()
    Dim A() As Variant
    Dim i As Long
    Dim start As Single
    
    ReDim A(1 To FDemo.ItemCount)
    ' build array
    For i = 1 To FDemo.ItemCount
        A(i) = Rnd
    Next i
    
    ' sort array
    start = Timer
    Select Case FDemo.Method
    Case 0
        Sort.InsertSort A, 1, FDemo.ItemCount
    Case 1
        Sort.ShellSort A, 1, FDemo.ItemCount
    Case 2
        Sort.QuickSort A, 1, FDemo.ItemCount
    Case 3
        Sort.QSort A, 1, FDemo.ItemCount
    End Select
    MsgBox "Elapsed time: " & FormatNumber(Timer - start, 2) & " seconds"
End Sub

