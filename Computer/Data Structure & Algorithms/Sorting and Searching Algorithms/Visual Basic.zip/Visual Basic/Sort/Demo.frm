VERSION 5.00
Begin VB.Form FDemo 
   Caption         =   "Sort Demo"
   ClientHeight    =   2205
   ClientLeft      =   4170
   ClientTop       =   2190
   ClientWidth     =   3585
   LinkTopic       =   "Form1"
   ScaleHeight     =   2205
   ScaleWidth      =   3585
   Begin VB.CommandButton cmdSort 
      Caption         =   "Sort"
      Height          =   495
      Left            =   2040
      TabIndex        =   3
      Top             =   480
      Width           =   1215
   End
   Begin VB.TextBox txtCount 
      Height          =   285
      Left            =   360
      TabIndex        =   1
      Top             =   1320
      Width           =   1215
   End
   Begin VB.ComboBox cmbMethod 
      Height          =   315
      Left            =   360
      Style           =   2  'Dropdown List
      TabIndex        =   0
      Top             =   480
      Width           =   1215
   End
   Begin VB.Label lblMethod 
      Caption         =   "Method:"
      Height          =   255
      Left            =   360
      TabIndex        =   4
      Top             =   240
      Width           =   1215
   End
   Begin VB.Label lblCount 
      Caption         =   "Count:"
      Height          =   255
      Left            =   360
      TabIndex        =   2
      Top             =   1080
      Width           =   1215
   End
End
Attribute VB_Name = "FDemo"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Public Method As Long
Public ItemCount As Long

Private Sub cmbMethod_Click()
    Method = cmbMethod.ListIndex
End Sub

Private Sub cmdSort_Click()
    Test
End Sub

Private Sub Form_Load()
    cmbMethod.AddItem "Insertion"
    cmbMethod.AddItem "Shell"
    cmbMethod.AddItem "QuickSort"
    cmbMethod.AddItem "QSort"
    Method = 0
    cmbMethod.ListIndex = Method
    ItemCount = 1000
    txtCount.Text = ItemCount
End Sub


Private Sub txtCount_Validate(Cancel As Boolean)
    If IsNumeric(txtCount.Text) Then
        ItemCount = txtCount.Text
    Else
        MsgBox "Count must be numeric"
        Cancel = True
    End If
End Sub
