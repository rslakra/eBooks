Attribute VB_Name = "Test"
Option Explicit

' error constants
Public Const errKeyNotFound As Long = &H1
Public Const errDuplicateKey As Long = &H2

Private Hash As CHash
Private Bin As CBin
Private Rbt As CRbt
Private Collect As CCollect
     
Public Sub Raise(errno As Long, loc As String)
    Dim msg As String

    ' express error as text
    Select Case errno
    Case errKeyNotFound
        msg = "Key not found"
    Case errDuplicateKey
        msg = "Duplicate key"
    End Select

    Err.Raise errno + vbObjectError + &H200, App.EXEName & "." & loc, msg & "."
End Sub

Public Sub Test()
    Dim i As Long
    Dim rec() As Variant
    Dim key() As Variant
    Dim start As Single
    Dim time(3) As Single
    Dim ln(3) As String
    Dim r As Variant
    Dim initialAlloc As Long
    Dim growthFactor As Single

    initialAlloc = FDemo.ItemCount / 10
    If initialAlloc < 10 Then initialAlloc = 10
    growthFactor = 1.5
    
    Select Case FDemo.Method
    Case 0
        Set Hash = New CHash
        Hash.Init FDemo.Size, initialAlloc, growthFactor
    Case 1
        Set Bin = New CBin
        Bin.Init initialAlloc, growthFactor
    Case 2
        Set Rbt = New CRbt
        Rbt.Init initialAlloc, growthFactor
    Case 3
        Set Collect = New CCollect
    End Select

    ReDim rec(1 To FDemo.ItemCount)
    ReDim key(1 To FDemo.ItemCount)

    ' create keys and records
    For i = 1 To FDemo.ItemCount
        key(i) = Rnd * FDemo.ItemCount
        rec(i) = Rnd * FDemo.ItemCount
    Next i

    start = Timer
    For i = 1 To FDemo.ItemCount
        Select Case FDemo.Method
        Case 0
            Hash.Insert key(i), rec(i)
        Case 1
            Bin.Insert key(i), rec(i)
        Case 2
            Rbt.Insert key(i), rec(i)
        Case 3
            Collect.Insert key(i), rec(i)
        End Select
    Next i
    time(0) = Timer - start
    
    start = Timer
    For i = 1 To FDemo.ItemCount
        Select Case FDemo.Method
        Case 0
            r = Hash.Find(key(i))
        Case 1
            r = Bin.Find(key(i))
        Case 2
            r = Rbt.Find(key(i))
        Case 3
            r = Collect.Find(key(i))
        End Select
        If r <> rec(i) Then MsgBox "fail at " & i
    Next i
    time(1) = Timer - start

    start = Timer
    For i = 1 To FDemo.ItemCount
        Select Case FDemo.Method
        Case 0
            Hash.Delete key(i)
        Case 1
            Bin.Delete key(i)
        Case 2
            Rbt.Delete key(i)
        Case 3
            Collect.Delete key(i)
        End Select
    Next i
    time(2) = Timer - start
    
    ln(0) = vbCrLf & "Insert: " & vbTab & FormatNumber(time(0), 2) & " secs"
    ln(1) = vbCrLf & "Search: " & vbTab & FormatNumber(time(1), 2) & " secs"
    ln(2) = vbCrLf & "Delete: " & vbTab & FormatNumber(time(2), 2) & " secs"
    MsgBox "Execution Time" & ln(0) & ln(1) & ln(2)
    
    ' free memory
    Select Case FDemo.Method
    Case 0
        Set Hash = Nothing
    Case 1
        Set Bin = Nothing
    Case 2
        Set Rbt = Nothing
    Case 3
        Set Collect = Nothing
    End Select
End Sub

