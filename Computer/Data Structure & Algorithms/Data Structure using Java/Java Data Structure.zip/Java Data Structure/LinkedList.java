package miscellaneous.datastructure;

class Node {
    Object data;
    Node next;

    public Node() {
	data = null;
	next = null;
    }

    public Node(Object newData, Node childNode) {
	data = newData;
	next = childNode;
    }

    public Object getData() {
	return data;
    }

    public void setData(Object newData) {
	data = newData;
    }

    public Node getNext() {
	return next;
    }

    public void setNext(Node newNext) {
	next = newNext;
    }

    public boolean hasNext() {
	return (next != null) ? true : false;
    }

    public String toString() {
	return "" + data;
    }
}



public class LinkedList {
    static int RANDOM_NUMBER = 100;

    Node head;
    int noOfNodes;

    public LinkedList() {
	head = null;
	noOfNodes = 0;
    }

    public boolean isEmpty() {
	return head == null;
    }

    public int size() {
	return noOfNodes;
    }

    public void insert(Object object) {
	head = new Node(object, head);
	noOfNodes++;
    }

    public Object remove() {
	if (isEmpty())
	    return null;
	Node tmp = head;
	head = tmp.getNext();
	noOfNodes--;
	return tmp.getData();
    }

    public void insertEnd(Object obj) {
	if (isEmpty())
	    insert(obj);
	else {
	    Node t = head;
	    while (t.getNext() != null)
		t = t.getNext();
	    Node tmp =
		new Node(obj, t.getNext());
	    t.setNext(tmp);
	    noOfNodes++;
	}
    }

    public Object removeEnd() {
	if (isEmpty())
	    return null;
	if (head.getNext() == null)
	    return remove();
	Node t = head;
	while (t.getNext().getNext() != null)
	    t = t.getNext();
	Object obj = t.getNext().getData();
	t.setNext(t.getNext().getNext());
	noOfNodes--;
	return obj;
    }

    /**
     * goes through the list until it either reaches the element requested,
     * or the end of the list
     */
    public Object peek(int n) {
	Node t = head;
	for (int i = 0; i < n && t != null; i++)
	    t = t.getNext();
	return t.getData();
    }


    public static int getRandomNumber() {
	int randomNumber = (int) (Math.random() * RANDOM_NUMBER);
	System.out.println("Generated Random Number : " + randomNumber);
	return randomNumber;
    }

    /**
     * Starting Point
     */
    public static void main(String[] args) {
	LinkedList linkedList = new LinkedList();
	Integer j = null;
	int i;
	System.out.println("starting...");
	for (i = 0; i < 5; i++) {
	    j = new Integer( getRandomNumber());
	    linkedList.insert(j);
	    System.out.println("Insert: " + j);
	}
	System.out.println();
	for (; i < 10; i++) {
	    j = new Integer( getRandomNumber());
	    linkedList.insertEnd(j);
	    System.out.println("Insert at End: " + j);
	}
	System.out.println();
	for (i = 0; i < linkedList.size(); i++)
	    System.out.println("Peek " + i + ": " + linkedList.peek(i));

	System.out.println();
	for (i = 0; i < 5; i++)
	    System.out.println("Remove: " + ( (Integer) linkedList.remove()));
	System.out.println();
	while (!linkedList.isEmpty())
	    System.out.println("Remove From End: " +
			       ( (Integer) linkedList.removeEnd()));
	System.out.println("Done ;-)");
    }
}
