/*
*  Copyright 2001 Sun Microsystems, Inc. All rights reserved.
*  Use is subject to license terms.
*/

/*
 * JDOException.java
 *
 * Created on March 8, 2000, 8:29 AM
 */

package javax.jdo;

/** This is the root of all JDO Exceptions.  It contains an optional detail
 * message, an optional nested exception array and an optional failed object.
 * @author Craig Russell
 * @version 0.9
 */
public class JDOException extends java.lang.RuntimeException {
  
  /** This exception was generated because of an exception in the runtime library.
   * @serial the nested Exception array
   */
  Exception[] nested;
  
  /** This exception may be the result of incorrect parameters supplied
   * to an API.  This is the object from which the user can determine
   * the cause of the problem.
   * @serial the failed Object
   */
  Object failed;

  /**
   * Constructs a new <code>JDOException</code> without detail message.
   */
  public JDOException() {
  }
  

  /**
   * Constructs a new <code>JDOException</code> with the specified detail message.
   * @param msg the detail message.
   */
  public JDOException(String msg) {
    super(msg);
  }

  /** Constructs a new <code>JDOException</code> with the specified detail message
   * and nested exceptions.
   * @param msg the detail message.
   * @param nested the nested <code>Exception[]</code>.
   */
  public JDOException(String msg, Exception[] nested) {
    super(msg);
    this.nested = nested;
  }
  
  /** Constructs a new <code>JDOException</code> with the specified detail message
   * and failed object.
   * @param msg the detail message.
   * @param failed the failed object.
   */
  public JDOException(String msg, Object failed) {
    super(msg);
    this.failed = failed;
  }
  
  /** Constructs a new <code>JDOException</code> with the specified detail message,
   * nested exceptions, and failed object.
   * @param msg the detail message.
   * @param nested the nested <code>Exception[]</code>.
   * @param failed the failed object.
   */
  public JDOException(String msg, Exception[] nested, Object failed) {
    super(msg);
    this.nested = nested;
    this.failed = failed;
  }
  
  /** The exception may include a failed object.
   * @return the failed object.
   */
  public Object getFailedObject() {
    return failed;
  }
  
  /** The exception may have been caused by multiple exceptions in the runtime.
   * If multiple objects caused the problem, each failed object will have
   * its own Exception.
   * @return the nested Exception array.
   */
  public Exception[] getNestedExceptions() {
    return nested;
  }
  
  /** The String representation includes the name of the class,
   * the descriptive comment (if any),
   * the String representation of the failed Object (if any),
   * and the String representation of the nested Exceptions (if any).
   * @return the String.
   */
  public String toString() {
    int len = nested==null?0:nested.length;
    // calculate approximate size of the String to return
    StringBuffer sb = new StringBuffer (10 + 100 * len);
    sb.append (super.toString());
    // include failed object information
    if (failed != null) {
      sb.append ("\nFailedObject: " + failed.toString());
    }
    // include nested exception information
    if (len > 0) {
      sb.append ("\nNestedExceptions:\n");
      Exception exception = nested[0];
      sb.append (exception==null?"null":exception.toString());
      for (int i=1; i<len; ++i) {
        sb.append ("\n");
        exception = nested[i];
      sb.append (exception==null?"null":exception.toString());
      }
    }
    return sb.toString();
  }    
}

