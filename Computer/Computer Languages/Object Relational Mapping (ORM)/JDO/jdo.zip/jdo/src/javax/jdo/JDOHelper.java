/*
*  Copyright 2001 Sun Microsystems, Inc. All rights reserved.
*  Use is subject to license terms.
*/

/*
 * JDOHelper.java
 *
 * Created on April 24, 2000, 9:09 AM
 */
 
package javax.jdo;

import java.lang.reflect.Constructor;
import java.util.HashMap;

/** 
 *
 * @author  Craig Russell
 * @version 0.9
 */

/**
 * This class can be used by a JDO-aware application to call the JDO behavior
 * of PersistenceCapable instances without declaring them to be PersistenceCapable.
 *
 * <P>Every class whose instances can be managed by a JDO PersistenceManager must 
 * implement the PersistenceCapable interface.
 *
 * <P>This helper class defines static methods that allow a JDO-aware 
 * application to examine the runtime state of instances.  For example,
 * an application can discover whether the instance is persistent, transactional,
 * dirty, new, or deleted; and to get its associated
 * PersistenceManager if it has one.
 *
 */
public class JDOHelper extends Object {
      
    /** Return the associated PersistenceManager if there is one.
     * Transactional and persistent instances return the associated
     * PersistenceManager.  
     *
     * <P>Transient non-transactional instances and instances of classes 
     * that do not implement PersistenceCapable return null.
     * @see PersistenceCapable#jdoGetPersistenceManager()
     * @param pc the PersistenceCapable instance.
     * @return the PersistenceManager associated with this instance.
     */
     public static PersistenceManager getPersistenceManager(Object pc) {
        return pc instanceof PersistenceCapable?((PersistenceCapable)pc).jdoGetPersistenceManager():null;
      }
    
    /** Explicitly mark this instance and this field dirty.
     * Normally, PersistenceCapable classes are able to detect changes made
     * to their fields.  However, if a reference to an array is given to a
     * method outside the class, and the array is modified, then the
     * persistent instance is not aware of the change.  This API allows the
     * application to notify the instance that a change was made to a field.
     *
     * <P>Transient instances and instances of classes 
     * that do not implement PersistenceCapable ignore this method.
     * @see PersistenceCapable#jdoMakeDirty(String fieldName)
     * @param pc the PersistenceCapable instance.
     * @param fieldName the name of the field to be marked dirty.
     */
    public static void makeDirty(Object pc, String fieldName) {
     if (pc instanceof PersistenceCapable) 
      ((PersistenceCapable)pc).jdoMakeDirty(fieldName);
    }
    
    /** Return a copy of the JDO identity associated with this instance.
     *
     * <P>Persistent instances of PersistenceCapable classes have a JDO identity
     * managed by the PersistenceManager.  This method returns a copy of the
     * ObjectId that represents the JDO identity.  
     * 
     * <P>Transient instances and instances of classes 
     * that do not implement PersistenceCapable return null.
     *
     * <P>The ObjectId may be serialized
     * and later restored, and used with a PersistenceManager from the same JDO
     * implementation to locate a persistent instance with the same data store
     * identity.
     *
     * <P>If the JDO identity is managed by the application, then the ObjectId may
     * be used with a PersistenceManager from any JDO implementation that supports
     * the PersistenceCapable class.
     *
     * <P>If the JDO identity is not managed by the application or the data store,
     * then the ObjectId returned is only valid within the current transaction.
     *<P>
     * @see PersistenceManager#getObjectId(Object pc)
     * @see PersistenceCapable#jdoGetObjectId()
     * @see PersistenceManager#getObjectById(Object oid, boolean validate)
     * @param pc the PersistenceCapable instance.
     * @return a copy of the ObjectId of this instance as of the beginning of the transaction.
     */
    public static Object getObjectId(Object pc) {
      return pc instanceof PersistenceCapable?((PersistenceCapable)pc).jdoGetObjectId():null;
    }
    
    /** Return a copy of the JDO identity associated with this instance.
     *
     * @see PersistenceCapable#jdoGetTransactionalObjectId()
     * @see PersistenceManager#getObjectById(Object oid, boolean validate)
     * @param pc the PersistenceCapable instance.
     * @return a copy of the ObjectId of this instance as modified in this transaction.
     */
    public static Object getTransactionalObjectId(Object pc) {
      return pc instanceof PersistenceCapable?((PersistenceCapable)pc).jdoGetObjectId():null;
    }
    
    /** Tests whether this object is dirty.
     *
     * Instances that have been modified, deleted, or newly 
     * made persistent in the current transaction return true.
     *
     *<P>Transient instances and instances of classes 
     * that do not implement PersistenceCapable return false.
     *<P>
     * @see StateManager#makeDirty(Object pc, String fieldName)
     * @see PersistenceCapable#jdoIsDirty()
     * @param pc the PersistenceCapable instance.
     * @return true if this instance has been modified in the current transaction.
     */
    public static boolean isDirty(Object pc) {
      return pc instanceof PersistenceCapable?((PersistenceCapable)pc).jdoIsDirty():false;
    }

    /** Tests whether this object is transactional.
     *
     * Instances whose state is associated with the current transaction 
     * return true. 
     *
     *<P>Transient instances and instances of classes 
     * that do not implement PersistenceCapable return false.
     * @see PersistenceCapable#jdoIsTransactional()
     * @param pc the PersistenceCapable instance.
     * @return true if this instance is transactional.
     */
    public static boolean isTransactional(Object pc) {
      return pc instanceof PersistenceCapable?((PersistenceCapable)pc).jdoIsTransactional():false;
    }

    /** Tests whether this object is persistent.
     *
     * Instances that represent persistent objects in the data store 
     * return true. 
     *
     *<P>Transient instances and instances of classes 
     * that do not implement PersistenceCapable return false.
     *<P>
     * @see PersistenceManager#makePersistent(Object pc)
     * @see PersistenceCapable#jdoIsPersistent()
     * @param pc the PersistenceCapable instance.
     * @return true if this instance is persistent.
     */
    public static boolean isPersistent(Object pc) {
      return pc instanceof PersistenceCapable?((PersistenceCapable)pc).jdoIsPersistent():false;
    }

    /** Tests whether this object has been newly made persistent.
     *
     * Instances that have been made persistent in the current transaction 
     * return true.
     *
     *<P>Transient instances and instances of classes 
     * that do not implement PersistenceCapable return false.
     *<P>
     * @see PersistenceManager#makePersistent(Object pc)
     * @see PersistenceCapable#jdoIsNew()
     * @param pc the PersistenceCapable instance.
     * @return true if this instance was made persistent
     * in the current transaction.
     */
    public static boolean isNew(Object pc) {
      return pc instanceof PersistenceCapable?((PersistenceCapable)pc).jdoIsNew():false;
    }

    /** Tests whether this object has been deleted.
     *
     * Instances that have been deleted in the current transaction return true.
     *
     *<P>Transient instances and instances of classes 
     * that do not implement PersistenceCapable return false.
     *<P>
     * @see PersistenceManager#deletePersistent(Object pc)
     * @see PersistenceCapable#jdoIsDeleted()
     * @param pc the PersistenceCapable instance.
     * @return true if this instance was deleted
     * in the current transaction.
     */
    public static boolean isDeleted(Object pc) {
      return pc instanceof PersistenceCapable?((PersistenceCapable)pc).jdoIsDeleted():false;
    }
    
}
