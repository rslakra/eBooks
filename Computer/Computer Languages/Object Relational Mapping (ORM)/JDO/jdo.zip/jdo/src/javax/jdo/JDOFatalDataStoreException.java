/*
*  Copyright 2001 Sun Microsystems, Inc. All rights reserved.
*  Use is subject to license terms.
*/

/*
 * JDOFatalDataStoreException.java
 *
 * Created on March 8, 2000, 8:36 AM
 */

package javax.jdo;

/** This class represents data store exceptions that cannot be retried.
 *
 * @author  Craig Russell
 * @version 0.9
 */
public class JDOFatalDataStoreException extends JDOFatalException {

  /**
   * Constructs a new <code>JDOFatalDataStoreException</code> without detail message.
   */
  public JDOFatalDataStoreException() {
  }
  

  /**
   * Constructs a new <code>JDOFatalDataStoreException</code> with the specified detail message.
   * @param msg the detail message.
   */
  public JDOFatalDataStoreException(String msg) {
    super(msg);
  }

  /**
   * Constructs a new <code>JDOFatalDataStoreException</code> with the specified detail message and nested exceptions.
   * @param msg the detail message.
   * @param nested the nested <code>Exception[]</code>.
   */
  public JDOFatalDataStoreException(String msg, Exception[] nested) {
    super(msg, nested);
  }
}

