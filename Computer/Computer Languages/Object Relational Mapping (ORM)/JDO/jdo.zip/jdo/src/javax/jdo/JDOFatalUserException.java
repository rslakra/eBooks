/*
*  Copyright 2001 Sun Microsystems, Inc. All rights reserved.
*  Use is subject to license terms.
*/

/*
 * JDOUserException.java
 *
 * Created on March 8, 2000, 8:33 AM
 */

package javax.jdo;

/** This class represents user errors that cannot be retried.  
 *
 * @author  Craig Russell
 * @version 0.9
 */
public class JDOFatalUserException extends JDOFatalException {

  /**
   * Constructs a new <code>JDOFatalUserException</code> without detail message.
   */
  public JDOFatalUserException() {
  }
  

  /**
   * Constructs a new <code>JDOFatalUserException</code> with the specified detail message.
   * @param msg the detail message.
   */
  public JDOFatalUserException(String msg) {
    super(msg);
  }

  /**
   * Constructs a new <code>JDOFatalUserException</code> with the specified detail message
   * and nested exceptions.
   * @param msg the detail message.
   * @param nested the nested <code>Exception[]</code>.
   */
  public JDOFatalUserException(String msg, Exception[] nested) {
    super(msg, nested);
  }
  
  /** Constructs a new <code>JDOFatalUserException</code> with the specified detail message
   * and failed object.
   * @param msg the detail message.
   * @param failed the failed object.
   */
  public JDOFatalUserException(String msg, Object failed) {
    super(msg, failed);
  }
  
  /** Constructs a new <code>JDOFatalUserException</code> with the specified detail message,
   * nested exceptions, and failed object.
   * @param msg the detail message.
   * @param nested the nested <code>Exception[]</code>.
   * @param failed the failed object.
   */
  public JDOFatalUserException(String msg, Exception[] nested, Object failed) {
    super(msg, nested, failed);
  }
}

