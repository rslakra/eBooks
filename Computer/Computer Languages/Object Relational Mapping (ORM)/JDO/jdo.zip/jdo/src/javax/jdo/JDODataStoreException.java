/*
*  Copyright 2001 Sun Microsystems, Inc. All rights reserved.
*  Use is subject to license terms.
*/

/*
 * JDODataStoreException.java
 *
 * Created on March 8, 2000, 8:37 AM
 */

package javax.jdo;

/** This class represents data store exceptions that can be retried..
 *
 * @author  Craig Russell
 * @version 0.9
 */
public class JDODataStoreException extends JDOCanRetryException {

  /**
   * Constructs a new <code>JDODataStoreException</code> without detail message.
   */
  public JDODataStoreException() {
  }
  

  /**
   * Constructs a new <code>JDODataStoreException</code> with the specified detail message.
   * @param msg the detail message.
   */
  public JDODataStoreException(String msg) {
    super(msg);
  }

  /**
   * Constructs a new <code>JDODataStoreException</code> with the specified 
   * detail message and nested exceptions.
   * @param msg the detail message.
   * @param nested the nested <code>Exception[]</code>.
   */
  public JDODataStoreException(String msg, Exception[] nested) {
    super(msg, nested);
  }

  /** Constructs a new <code>JDODataStoreException</code> with the specified detail message
   * and failed object.
   * @param msg the detail message.
   * @param failed the failed object.
   */
  public JDODataStoreException(String msg, Object failed) {
    super(msg, failed);
  }
 
  /** Constructs a new <code>JDODataStoreException</code> with the specified detail message,
   * nested exceptions, and failed object.
   * @param msg the detail message.
   * @param nested the nested <code>Exception[]</code>.
   * @param failed the failed object.
   */
  public JDODataStoreException(String msg, Exception[] nested, Object failed) {
    super(msg, nested, failed);
  }

}

