/*
*  Copyright 2001 Sun Microsystems, Inc. All rights reserved.
*  Use is subject to license terms.
*/

/*
 * JDOUserException.java
 *
 * Created on March 8, 2000, 8:33 AM
 */

package javax.jdo;

/** This class represents user errors that can possibly be retried.
 *
 * @author  Craig Russell
 * @version 0.9
 */
public class JDOUserException extends JDOCanRetryException {

  /**
   * Constructs a new <code>JDOUserException</code> without detail message.
   */
  public JDOUserException() {
  }
  

  /**
   * Constructs a new <code>JDOUserException</code> with the specified detail message.
   * @param msg the detail message.
   */
  public JDOUserException(String msg) {
    super(msg);
  }

  /**
   * Constructs a new <code>JDOUserException</code> with the specified detail message
   * and nested exceptions.
   * @param msg the detail message.
   * @param nested the nested <code>Exception[]</code>.
   */
  public JDOUserException(String msg, Exception[] nested) {
    super(msg, nested);
  }
  
  /** Constructs a new <code>JDOUserException</code> with the specified detail message
   * and failed object.
   * @param msg the detail message.
   * @param failed the failed object.
   */
  public JDOUserException(String msg, Object failed) {
    super(msg, failed);
  }
  
  /** Constructs a new <code>JDOUserException</code> with the specified detail message,
   * nested exceptions, and failed object.
   * @param msg the detail message.
   * @param nested the nested <code>Exception[]</code>.
   * @param failed the failed object.
   */
  public JDOUserException(String msg, Exception[] nested, Object failed) {
    super(msg, nested, failed);
  }
}

