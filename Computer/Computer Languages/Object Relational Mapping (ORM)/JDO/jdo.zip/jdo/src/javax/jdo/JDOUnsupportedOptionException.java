/*
*  Copyright 2001 Sun Microsystems, Inc. All rights reserved.
*  Use is subject to license terms.
*/

/*
 * JDOUnsupportedOptionException.java
 *
 * Created on March 8, 2000, 8:34 AM
 */

package javax.jdo;

/** This class represents exceptions caused by the use of optional features
 * not supported by the JDO implementation.
 *
 * @author  Craig Russell
 * @version 0.9
 */
public class JDOUnsupportedOptionException extends JDOUserException {

  /**
   * Constructs a new <code>JDOUnsupportedOptionException</code> without detail message.
   */
  public JDOUnsupportedOptionException() {
  }
  

  /**
   * Constructs a new <code>JDOUnsupportedOptionException</code> with the specified detail message.
   * @param msg the detail message.
   */
  public JDOUnsupportedOptionException(String msg) {
    super(msg);
  }

  /**
   * Constructs a new <code>JDOUnsupportedOptionException</code> with the specified detail message and nested exceptions.
   * @param msg the detail message.
   * @param nested the nested <code>Exception[]</code>.
   */
  public JDOUnsupportedOptionException(String msg, Exception[] nested) {
    super(msg, nested);
  }
}

