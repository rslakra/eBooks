/*
*  Copyright 2001 Sun Microsystems, Inc. All rights reserved.
*  Use is subject to license terms.
*/

package javax.jdo;
import java.io.Serializable;
import java.util.Collection;
import java.util.Map;

/** The Query interface allows applications to obtain persistent instances
 * from the data store.
 *
 * The {@link PersistenceManager} is the factory for Query instances.  There
 * may be many Query instances associated with a PersistenceManager.  Multiple
 * queries might be executed simultaneously by different threads, but the
 * implementation might choose to execute them serially.  In either case, the
 * implementation must be thread safe.
 *
 * <P>There are three required elements in a Query: the class of the results,
 * the candidate collection of instances, and the filter.
 *
 * <P>There are optional elements: parameter declarations, variable
 * declarations, import statements, and an ordering specification.
 * <P>The query namespace is modeled after methods in Java:
 * <ul>
 * <li>setClass corresponds to the class definition
 * <li>declareParameters corresponds to formal parameters of a method
 * <li>declareVariables corresponds to local variables of a method
 * <li>setFilter and setOrdering correspond to the method body
 * </ul>
 * <P>There are two namespaces in queries. Type names have their own
 * namespace that is separate from the namespace for fields, variables
 * and parameters.
 * <P>The method setClass introduces the name of the candidate class in
 * the type namespace. The method declareImports introduces the names of
 * the imported class or interface types in the type namespace. Imported
 * type names must be unique. When used (e.g. in a parameter declaration,
 * cast expression, etc.) a type name must be the name of the candidate
 * class, the name of a class or interface imported by method
 * declareImports, or denote a class or interface from the same
 * package as the candidate class.
 * <P>The method setClass introduces the names of the candidate class fields.
 * <P>The method declareParameters introduces the names of the
 * parameters. A name introduced by declareParameters hides the name
 * of a candidate class field if equal. Parameter names must be unique.
 * <P>The method declareVariables introduces the names of the variables.
 * A name introduced by declareVariables hides the name of a candidate
 * class field if equal. Variable names must be unique and must not
 * conflict with parameter names.
 * <P>A hidden field may be accessed using the 'this' qualifier:
 * this.fieldName.
 * <P>The Query interface provides methods which execute the query
 * based on the parameters given. They return a Collection which the
 * user can iterate to get results. For future extension, the signature
 * of the execute methods specifies that they return an Object which
 * must be cast to Collection by the user.
 * <P>Any parameters passed to the execute methods are used only for
 * this execution, and are not remembered for future execution.
 * @author Craig Russell
 * @version 0.9
 */

public interface Query extends java.io.Serializable 
{
   /** Set the class of the candidate instances of the query.
    * <P>The class specifies the class
    * of the candidates of the query.  Elements of the candidate collection
    * that are of the specified class are filtered before being
    * put into the result Collection.
    *
    * @param cls the Class of the candidate instances.
    */
void setClass(Class cls);
    
    /** Set the candidate Extent to query.
     * @param pcs the Candidate Extent.
     */
    void setCandidates(Extent pcs);
    
    /** Set the candidate Collection to query.
     * @param pcs the Candidate collection.
     */
    void setCandidates(Collection pcs);
    
    /** Set the filter for the query.
     *
     * <P>AThe filter specification is a String containing a boolean
     * expression that is to be evaluated for each of the instances
     * in the candidate collection. If the filter is not specified,
     * then it defaults to "true", which has the effect of filtering
     * the input Collection only for class type.
     * <P>An element of the candidate collection is returned in the result if:
     * <ul><li>it is assignment compatible to the candidate Class of the Query; and
     * <li>for all variables there exists a value for which the filter
     * expression evaluates to true.
     * </ul>
     * <P>The user may denote uniqueness in the filter expression by
     * explicitly declaring an expression (for example, e1 != e2).
     * <P>Rules for constructing valid expressions follow the Java
     * language, except for these differences:
     * <ul>
     * <li>Equality and ordering comparisons between primitives and instances
     * of wrapper classes are valid.
     * <li>Equality and ordering comparisons of Date fields and Date
     * parameters are valid.
     * <li>White space (non-printing characters space, tab, carriage
     * return, and line feed) is a separator and is otherwise ignored.
     * <li>The assignment operators =, +=, etc. and pre- and post-increment
     * and -decrement are not supported. Therefore, there are no side
     * effects from evaluation of any expressions.
     * <li>Methods, including object construction, are not supported, except
     * for Collection.contains(Object o), Collection.isEmpty(),
     * String.startsWith (String s), and String.endsWith (String e).
     * Implementations might choose to support non-mutating method
     * calls as non-standard extensions.
     * <li>Navigation through a null-valued field, which would throw
     * NullPointerException, is treated as if the filter expression
     * returned false for the evaluation of the current set of variable
     * values. Other values for variables might still qualify the candidate
     * instance for inclusion in the result set.
     * <li>Navigation through multi-valued fields (Collection types) is
     * specified using a variable declaration and the
     * Collection.contains(Object o) method.
     * </ul>
     * <P>Identifiers in the expression are considered to be in the name
     * space of the specified class, with the addition of declared imports,
     * parameters and variables. As in the Java language, this is a reserved
     * word which means the element of the collection being evaluated.
     * <P>Navigation through single-valued fields is specified by the Java
     * language syntax of field_name.field_name....field_name.
     * <P>A JDO implementation is allowed to reorder the filter expression
     * for optimization purposes.
     * @param filter the query filter.
     */
    void setFilter(String filter);
    
    /** Set the import statements to be used to identify the fully qualified name of
     * variables or parameters.  Parameters and unbound variables might 
     * come from a different class from the candidate class, and the names 
     * need to be declared in an import statement to eliminate ambiguity. 
     * Import statements are specified as a String with semicolon-separated 
     * statements. 
     * <P>The String parameter to this method follows the syntax of the  
     * import statement of the Java language.
     * @param imports import statements separated by semicolons.
     */
    void declareImports(String imports);
    
    /** Declare the list of parameters query execution.
     *
     * The parameter declaration is a String containing one or more query 
     * parameter declarations separated with commas. Each parameter named 
     * in the parameter declaration must be bound to a value when 
     * the query is executed.
     * <P>The String parameter to this method follows the syntax for formal 
     * parameters in the Java language. 
     * @param parameters the list of parameters separated by commas.
     */
    void declareParameters(String parameters);
    
    /** Declare the unbound variables to be used in the query. Variables 
     * might be used in the filter, and these variables must be declared 
     * with their type. The unbound variable declaration is a String 
     * containing one or more unbound variable declarations separated 
     * with semicolons. It follows the syntax for local variables in 
     * the Java language.
     * @param variables the variables separated by semicolons.
     */
    void declareVariables(String variables);
    
    /** Set the ordering specification for the result Collection.  The
     * ordering specification is a String containing one or more ordering
     * declarations separated by commas.
     *
     * <P>Each ordering declaration is the name of the field on which
     * to order the results followed by one of the following words:
     * "ascending" or "descending".
     *
     *<P>The field must be declared in the candidate class or must be
     * a navigation expression starting with a field in the candidate class.
     *
     *<P>Valid field types are primitive types except boolean; wrapper types 
     * except Boolean; BigDecimal; BigInteger; String; and Date.
     * @param ordering the ordering specification.
     */
    void setOrdering(String ordering);
    
    /** Set the ignoreCache option.  The default value for this option was
     * set by the PersistenceManagerFactory or the PersistenceManager used 
     * to create this Query.
     *
     * The ignoreCache option setting specifies whether the query should execute
     * entirely in the back end, instead of in the cache.  If this flag is set
     * to true, an implementation might be able to optimize the query
     * execution by ignoring changed values in the cache.  For optimistic
     * transactions, this can dramatically improve query response times.
     * @param ignoreCache the setting of the ignoreCache option.
     */
    void setIgnoreCache(boolean ignoreCache);   
    
    /** Get the ignoreCache option setting.
     * @return the ignoreCache option setting.
     * @see #setIgnoreCache
     */
    boolean getIgnoreCache();
    
    /** Verify the elements of the query and provide a hint to the query to
     * prepare and optimize an execution plan.
     */
    void compile();
    
    /** Execute the query and return the filtered Collection.
     * @return the filtered Collection.
     * @see #executeWithArray(Object[] parameters)
     */
    Object execute();
    
    /** Execute the query and return the filtered Collection.
     * @return the filtered Collection.
     * @see #executeWithArray(Object[] parameters)
     * @param p1 the value of the first parameter declared.
     */
    Object execute(Object p1);
    
    /** Execute the query and return the filtered Collection.
     * @return the filtered Collection.
     * @see #executeWithArray(Object[] parameters)
     * @param p1 the value of the first parameter declared.
     * @param p2 the value of the second parameter declared.
     */
    Object execute(Object p1, Object p2);
    
    /** Execute the query and return the filtered Collection.
     * @return the filtered Collection.
     * @see #executeWithArray(Object[] parameters)
     * @param p1 the value of the first parameter declared.
     * @param p2 the value of the second parameter declared.
     * @param p3 the value of the third parameter declared.
     */
    Object execute(Object p1, Object p2, Object p3);
    
    /** Execute the query and return the filtered Collection.  The query
     * is executed with the parameters set by the Map values.  Each Map entry
     * consists of a key which is the name of the parameter in the 
     * declareParameters method, and a value which is the value used in 
     * the execute method.  The keys in the Map and the declared parameters 
     * must exactly match or a JDOUserException is thrown.
     * @return the filtered Collection.
     * @see #executeWithArray(Object[] parameters)
     * @param parameters the Map containing all of the parameters.
     */
    Object executeWithMap (Map parameters);
    
    /** Execute the query and return the filtered Collection.
     *
     * <P>The execution of the query obtains the values of the parameters and
     * matches them against the declared parameters in order.  The names
     * of the declared parameters are ignored.  The type of
     * the declared parameters must match the type of the passed parameters,
     * except that the passed parameters might need to be unwrapped to get
     * their primitive values.
     *
     * <P>The filter, import, declared parameters, declared variables, and
     * ordering statements are verified for consistency.
     *
     * <P>Each element in the candidate Collection is examined to see that it
     * is assignment compatible to the Class of the query.  It is then evaluated
     * by the boolean expression of the filter.  The element passes the filter
     * if there exist unique values for all variables for which the filter
     * expression evaluates to true.
     * @return the filtered Collection.
     * @param parameters the Object array with all of the parameters.
     */
    Object executeWithArray (Object[] parameters);
    
    /** Get the PersistenceManager associated with this Query.
     *
     * <P>If this Query was restored from a serialized form, it has no 
     * PersistenceManager, and this method returns null.
     * @return the PersistenceManager associated with this Query.
     */
    PersistenceManager getPersistenceManager();
  
    /** Close a query result and release any resources associated with it.  The
     * parameter is the return from execute(...) and might have iterators open on it.
     * Iterators associated with the query result are invalidated: they return false
     * to hasNext() and throw NoSuchElementException to next().
     * @param queryResult the result of execute(...) on this Query instance.
     */    
    void close (Object queryResult);
    
    /** Close all query results associated with this Query instance, and release all
     * resources associated with them.  The query results might have iterators open
     * on them.  Iterators associated with the query results are invalidated:
     * they return false to hasNext() and throw NoSuchElementException to next().
     */    
    void closeAll ();
}

