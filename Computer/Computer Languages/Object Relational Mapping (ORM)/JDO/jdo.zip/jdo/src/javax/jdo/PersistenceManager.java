/*
*  Copyright 2001 Sun Microsystems, Inc. All rights reserved.
*  Use is subject to license terms.
*/

/*
 * PersistenceManager.java
 *
 * Created on February 25, 2000
 */
 
package javax.jdo;
import java.util.Collection;
import java.util.Map;
import java.util.Properties;
import java.lang.Class;

/** PersistenceManager is the primary interface for JDO-aware application
 * components.  It is the factory for Query and Transaction instances,
 * and contains methods to manage the life cycle of PersistenceCapable
 * instances.
 *
 * <P>A PersistenceManager is obtained from the
 * {@link PersistenceManagerFactory}
 * (recommended) or by construction.
 * @author Craig Russell
 * @version 0.9
 */

public interface PersistenceManager 
{

  /** A PersistenceManager instance can be used until it is closed.
   * @return true if this PersistenceManager has been closed
   * @see #close()
   */
  boolean isClosed ();
    
    /** Close this PersistenceManager so that no further requests may be 
     * made on it.  A PersistenceManager instance can be used 
     * only until it is closed.
     *
     * <P>Closing a PersistenceManager might release it to the pool of available
     * PersistenceManagers, or might be garbage collected, at the option of
     * the JDO implementation.  Before being used again to satisfy a
     * getPersistenceManager request, the default values for options will
     * be restored to their values as specified in the PersistenceManagerFactory.
     *
     * <P>This method closes the PersistenceManager.
     */
    void close ();

    /** Return the Transaction instance associated with a PersistenceManager.
     * There is one Transaction instance associated with each PersistenceManager
     * instance.  The Transaction instance supports options as well as
     * transaction completion requests.
     * @return the Transaction associated with this
     * PersistenceManager.
     */
    Transaction currentTransaction();

    /** Mark an instance as no longer needed in the cache.
     * Eviction is normally done automatically by the PersistenceManager
     * at transaction completion.  This method allows the application to
     * explicitly provide a hint to the PersistenceManager that the instance
     * is no longer needed in the cache.
     * @param pc the instance to evict from the cache.
     */
    void evict (Object pc);
    
    /** Mark an array of instances as no longer needed in the cache.
     * @see #evict(Object pc)
     * @param pcs the array of instances to evict from the cache.
     */
    void evictAll (Object[] pcs);
    
    /** Mark a Collection of instances as no longer needed in the cache.
     * @see #evict(Object pc)
     * @param pcs the Collection of instance to evict from the cache.
     */
    void evictAll (Collection pcs);
    
    /** Mark all persistent-nontransactional instances as no longer needed 
     * in the cache.  It transitions
     * all persistent-nontransactional instances to hollow.  Transactional
     * instances are subject to eviction based on the RetainValues setting.
     * @see #evict(Object pc)
     */
    void evictAll ();
    
    /** Refresh the state of the instance from the data store.
     *
     * <P>In an optimistic transaction, the state of instances in the cache
     * might not match the state in the data store.  This method is used to
     * reload the state of the instance from the data store so that a subsequent
     * commit is more likely to succeed.
     * <P>Outside a transaction, this method will refresh nontransactional state.
     * @param pc the instance to refresh.
     */
    void refresh (Object pc);
    
    /** Refresh the state of an array of instances from the data store.
     *
     * @see #refresh(Object pc)
     * @param pcs the array of instances to refresh.
     */
    void refreshAll (Object[] pcs);
    
    /** Refresh the state of a Collection of instances from the data store.
     *
     * @see #refresh(Object pc)
     * @param pcs the Collection of instances to refresh.
     */
    void refreshAll (Collection pcs);
    
    /** Refresh the state of all applicable instances from the data store.
     * <P>If called with an active transaction, all transactional instances
     * will be refreshed.  If called outside an active transaction, all
     * nontransactional instances will be refreshed.
     * @see #refresh(Object pc)
     */
    void refreshAll ();
    
    /** Create a new Query with no elements.
     * @return the new Query.
     */
    Query newQuery ();
    
    /** Create a new Query using elements from another Query.  The other Query
     * must have been created by the same JDO implementation.  It might be active
     * in a different PersistenceManager or might have been serialized and
     * restored.
     * <P>All of the settings of the other Query are copied to this Query,
     * except for the candidate Collection or Extent.
     * @return the new Query
     * @param compiled another Query from the same JDO implementation
     */
    Query newQuery (Object compiled);
    
    /** Create a new Query using the specified language.
     * @param language the language of the query parameter
     * @param query the query, which is of a form determined by the language
     * @return the new Query
     */    
    Query newQuery (String language, Object query);
    
    /** Create a new Query specifying the Class of the candidate instances.
     * @param cls the Class of the candidate instances
     * @return the new Query
     */
    Query newQuery (Class cls);
    
    /** Create a new Query with the Class of the candidate instances and 
     * candidate Extent.
     * @param cls the Class of results
     * @param cln the Extent of candidate instances
     * @return the new Query
     */
    Query newQuery (Class cls, Extent cln);
    
    /** Create a new Query with the Class of the candidate instances and 
     * candidate Collection.
     * @param cls the Class of results
     * @param cln the Collection of candidate instances
     * @return the new Query
     */
    Query newQuery (Class cls, Collection cln);
    
    /** Create a new Query with the Class of the candidate instances and Filter.
     * @param cls the Class of results
     * @param filter the filter for candidate instances
     * @return the new Query
     */
    Query newQuery (Class cls, String filter);
    
    /** Create a new Query with the Class of the candidate instances, 
     * candidate Collection, and filter.
     * @param cls the Class of candidate instances
     * @param cln the Collection of candidate instances
     * @param filter the filter for candidate instances
     * @return the new Query
     */
    Query newQuery (Class cls, Collection cln, String filter);
    
    /** Create a new Query with the Class of the candidate instances,
     * candidate Extent, and filter.
     * @param cls the Class of results
     * @param cln the Extent of candidate instances
     * @param filter the filter for candidate instances
     * @return the new Query
     */
    Query newQuery (Class cls, Extent cln, String filter);
    
    /** The PersistenceManager manages a collection of instances in the data
     * store based on the class of the instances.  This method returns a
     * Extent of instances in the data store that might be iterated or
     * given to a Query.  The Extent itself might not reference any 
     * instances, but only hold the class name and an
     * indicator whether subclasses are included in the Extent.
     * <P>Note that the Extent might be very large.
     * @param persistenceCapableClass Class of instances
     * @param subclasses whether to include instances of subclasses
     * @return an Extent of the specified Class
     * @see Query
     */
    Extent getExtent (Class persistenceCapableClass, boolean subclasses);

    /** Create a new instance of a Second Class Object which tracks changes made
     * to itself and notifies its owning instance.  The types supported include
     * java.util.Date and java.util.Locale.  Implementations might also support
     * java.sql.Date, java.sql.Time, and java.sql.Timestamp.  The effect of 
     * this method on the owner is to mark the field dirty, which might
     * cause a state change in the owner.
     * @param type the Class of the instance to be instantiated
     * @param owner the First Class Object instance to notify on changes
     * @param fieldName the name of the field in the owner
     * @return the new instance
     */
    Object newSCOInstance (Class type,Object owner,String fieldName);
    
    /** Create a new instance of a Collection which tracks changes made
     * to itself and notifies its owning instance.  The types supported must
     * include java.util.Collection, java.util.Set, and java.util.HashSet.
     * The effect of 
     * this method on the owner is to mark the field dirty, which might
     * cause a state change in the owner.
     * Implementations may also support other types.
     * If the initialContents parameter is null, the Collection has an 
     * initial capacity as specified by the initialSize parameter, and a load 
     * factor as specified by the loadFactor parameter. Defaults as specified 
     * in the Java language specification are taken where possible for null 
     * values of initialCapacity and loadFactor. Otherwise, implementation 
     * defaults are taken. 
     * If the initialContents parameter is not null, the initial contents 
     * of the Collection are copied from the initialContents parameter using 
     * shallow copy semantics, and the initialCapacity and loadFactor are 
     * determined by the constructor semantics of the Java language 
     * specification for the specified Collection type. 
     * @see #newSCOInstance
     * @param initialContents the Collection containing the elements to be
     * copied into the new Colleciton; may be null.
     * @param type the Class or Interface of the instance to be instantiated;
     * must not be null.
     * @param owner the First Class Object instance to notify on changes;
     * must not be null.
     * @param fieldName the name of the field in the owner; must not be null.
     * @param elementType the element type assignment compatible with all
     * added elements; must not be null (use Object if instances of any class
     * are acceptable).
     * @param allowNulls whether nulls are permitted as elements.
     * @param initialCapacity the initial size of the Collection; must be
     * non-negative or null.
     * @param loadFactor loadFactor for the Collection type, if that type uses
     * a load factor.  If so, loadFactor must be greater than 0 or null.
     * @return the new instance
     * @throws IllegalArgumentException if any of the restrictions noted in
     * the parameters is not met.
     */
    Collection newCollectionInstance (Class type, Object owner, String fieldName,
      Class elementType, boolean allowNulls, Integer initialCapacity, Float loadFactor,
      Collection initialContents) throws IllegalArgumentException;
    
    /** Create a new instance of a Map which tracks changes made
     * to itself and notifies its owning instance.  The effect of 
     * this method on the owner is to mark the field dirty, which might
     * cause a state change in the owner.
     * If the initialContents parameter is null, the Map has an 
     * initial capacity as specified by the initialSize parameter, and a load 
     * factor as specified by the loadFactor parameter. Defaults as specified 
     * in the Java language specification are taken where possible for null 
     * values of initialCapacity and loadFactor. Otherwise, implementation 
     * defaults are taken. 
     * If the initialContents parameter is not null, the initial contents 
     * of the Map are copied from the initialContents parameter using 
     * shallow copy semantics, and the initialCapacity and loadFactor are 
     * determined by the constructor semantics of the Java language 
     * specification for the specified Map type. 
     * @see #newSCOInstance
     * @param allowNulls whether nulls are allowed as keys or values
     * @param type the Class or Interface of the instance to be instantiated;
     * must not be null
     * @param owner the First Class Object instance to notify on changes; must
     * not be null
     * @param fieldName the name of the field in the owner; must not be null
     * @param keyType the type of the key; must not be null
     * @param valueType the type of the value; must not be null
     * @param initialCapacity the initial capacity for the new Map; must be
     * non-negative or null.
     * @param loadFactor the load factor for the new Map; must be positive
     * or null
     * @param initialContents the initial contents of the new Map; may be null
     * @return the new instance
     * @throws IllegalArgumentException if any of the restrictions noted in
     * the parameters is not met.
     */
    Map newMapInstance (Class type, Object owner, String fieldName,
      Class keyType, Class valueType, boolean allowNulls, 
      Integer initialCapacity, Float loadFactor, 
      Map initialContents) throws IllegalArgumentException;
    
    /** This method locates a persistent instance in the cache of instances
     * managed by this PersistenceManager.  The getObjectById method attempts 
     * to find an instance in the cache with the specified JDO identity. 
     * The oid parameter object might have been returned by an earlier call 
     * to getObjectId or getTransactionalObjectId, or might have been 
     * constructed by the application. 
     * <P>If the PersistenceManager is unable to resolve the oid parameter 
     * to an ObjectId instance, then it throws a JDOUserException.
     * <P>If the validate flag is false, and there is already an instance in the
     * cache with the same jdo identity as the oid parameter, then this method
     * returns it. There is no change made to the state of the returned
     * instance.
     * <P>If there is not an instance already in the cache with the same JDO
     * identity as the oid parameter, then this method creates an instance
     * with the specified JDO identity and returns it. If there is no
     * transaction in progress, the returned instance will be hollow or
     * persistent-nontransactional, at the choice of the implementation.
     * <P>If there is a transaction in progress, the returned instance will
     * be hollow, persistent-nontransactional, or persistent-clean, at the
     * choice of the implementation.
     * <P>It is an implementation decision whether to access the data store,
     * if required to determine the exact class. This will be the case of
     * inheritance, where multiple PersistenceCapable classes share the
     * same Object Id class.
     * <P>If the validate flag is false, and the instance does not exist in
     * the data store, then this method might not fail. It is an
     * implementation choice whether to fail immediately with a
     * JDODatastoreException.But a subsequent access of the fields of the
     * instance will throw a JDODatastoreException if the instance does not
     * exist at that time. Further, if a relationship is established to this
     * instance, then the transaction in which the association was made will
     * fail.
     * <P>If the validate flag is true, and there is already a transactional
     * instance in the cache with the same jdo identity as the oid parameter,
     * then this method returns it. There is no change made to the state of
     * the returned instance.
     * <P>If there is an instance already in the cache with the same jdo
     * identity as the oid parameter, but the instance is not transactional,
     * then it must be verified in the data store. If the instance does not
     * exist in the datastore, then a JDODatastoreException is thrown.
     * <P>If there is not an instance already in the cache with the same JDO
     * identity as the oid parameter, then this method creates an instance
     * with the specified jdo identity, verifies that it exists in the data
     * store, and returns it. If there is no transaction in progress, the
     * returned instance will be hollow or persistent-nontransactional,
     * at the choice of the implementation.
     * <P>If there is a data store transaction in progress, the returned
     * instance will be persistent-clean.
     * If there is an optimistic transaction in progress, the returned
     * instance will be persistent-nontransactional.
     * @see #getObjectId(Object pc)
     * @see #getTransactionalObjectId(Object pc)
     * @return the PersistenceCapable instance with the specified
     * ObjectId
     * @param oid an ObjectId
     * @param validate if the existence of the instance is to be validated
     */
    Object getObjectById (Object oid, boolean validate);
    
    /** The ObjectId returned by this method represents the JDO identity of
     * the instance.  The ObjectId is a copy (clone) of the internal state
     * of the instance, and changing it does not affect the JDO identity of
     * the instance.  
     * <P>The getObjectId method returns an ObjectId instance that represents
     * the object identity of the specified JDO instance. The identity is
     * guaranteed to be unique only in the context of the JDO
     * PersistenceManager that created the identity, and only for two types
     * of JDO Identity: those that are managed by the application, and
     * those that are managed by the data store.
     * <P>If the object identity is being changed in the transaction, by the
     * application modifying one or more of the application key fields,
     * then this method returns the identity as of the beginning of the
     * transaction. The value returned by getObjectId will be different
     * following afterCompletion processing for successful transactions.
     * <P>Within a transaction, the ObjectId returned will compare equal to
     * the ObjectId returned by only one among all JDO instances associated
     * with the PersistenceManager regardless of the type of ObjectId.
     * <P>The ObjectId does not necessarily contain any internal state of the
     * instance, nor is it necessarily an instance of the class used to
     * manage identity internally. Therefore, if the application makes a
     * change to the ObjectId instance returned by this method, there is
     * no effect on the instance from which the ObjectId was obtained.
     * <P>The getObjectById method can be used between instances of
     * PersistenceManager of different JDO vendors only for instances of
     * persistence capable classes using application-managed (primary key)
     * JDO identity. If it is used for instances of classes using datastore
     * identity, the method might succeed, but there are no guarantees that
     * the parameter and return instances are related in any way.
     * @see #getTransactionalObjectId(Object pc)
     * @see #getObjectById(Object oid, boolean validate)
     * @param pc the PersistenceCapable instance
     * @return the ObjectId of the instance
     */
    Object getObjectId (Object pc);
    
    /** The ObjectId returned by this method represents the JDO identity of
     * the instance.  The ObjectId is a copy (clone) of the internal state
     * of the instance, and changing it does not affect the JDO identity of
     * the instance.
     * <P>If the object identity is being changed in the transaction, by the
     * application modifying one or more of the application key fields,
     * then this method returns the current identity in the transaction.
     * <P>If there is no transaction in progress, or if none of the key fields
     * is being modified, then this method will return the same value as
     * getObjectId.
     * @see #getObjectId(Object pc)
     * @see #getObjectById(Object oid, boolean validate)
     * @param pc a PersistenceCapable instance
     * @return the ObjectId of the instance
     */
    Object getTransactionalObjectId (Object pc);
    
    /** Make the transient instance persistent in this PersistenceManager.
     * This method must be called in an active transaction.
     * The PersistenceManager assigns an ObjectId to the instance and
     * transitions it to persistent-new.
     * The instance will be managed in the Extent associated with its Class.
     * The instance will be put into the data store at commit.
     * The closure of instances of PersistenceCapable classes
     * reachable from persistent
     * fields will be made persistent at commit.  [This is known as 
     * persistence by reachability.]
     * @param pc a transient instance of a Class that implements
     * PersistenceCapable
     */
    void makePersistent (Object pc);
    
    /** Make an array of instances persistent.
     * @param pcs an array of transient instances
     * @see #makePersistent(Object pc)
     */
    void makePersistentAll (Object[] pcs);
    
    /** Make a Collection of instances persistent.
     * @param pcs a Collection of transient instances
     * @see #makePersistent(Object pc)
     */
    void makePersistentAll (Collection pcs);
    
    /** Delete the persistent instance from the data store.
     * This method must be called in an active transaction.
     * The data store object will be removed at commit.
     * Unlike makePersistent, which makes the closure of the instance persistent,
     * the closure of the instance is not deleted from the data store.
     * This method has no effect if the instance is already deleted in the
     * current transaction.
     * This method throws JDOUserException if the instance is transient or 
     * is managed by another PersistenceManager.
     *
     * @param pc a persistent instance
     */
    void deletePersistent (Object pc);
    
    /** Delete an array of instances from the data store.
     * @param pcs a Collection of persistent instances
     * @see #deletePersistent(Object pc)
     */
    void deletePersistentAll (Object[] pcs);
    
    /** Delete a Collection of instances from the data store.
     * @param pcs a Collection of persistent instances
     * @see #deletePersistent(Object pc)
     */
    void deletePersistentAll (Collection pcs);
    
    /** Make an instance transient, removing it from management by this
     * PersistenceManager.
     *
     * <P>The instance loses its JDO identity and it is no longer associated
     * with any PersistenceManager.  The state of fields is preserved unchanged.
     * @param pc the instance to make transient.
     */
    void makeTransient (Object pc);
    
    /** Make an array of instances transient, removing them from management by this
     * PersistenceManager.
     *
     * <P>The instances lose their JDO identity and they are no longer associated
     * with any PersistenceManager.  The state of fields is preserved unchanged.
     * @param pcs the instances to make transient.
     */
    void makeTransientAll (Object[] pcs);
    
    /** Make a Collection of instances transient, removing them from management by this
     * PersistenceManager.
     *
     * <P>The instances lose their JDO identity and they are no longer associated
     * with any PersistenceManager.  The state of fields is preserved unchanged.
     * @param pcs the instances to make transient.
     */ 
    void makeTransientAll (Collection pcs);
    
    /** Make an instance subject to transactional boundaries.
     *
     * <P>Transient instances normally do not observe transaction boundaries.
     * This method makes transient instances sensitive to transaction completion.
     * If an instance is modified in a transaction, and the transaction rolls back,
     * the state of the instance is restored to the state before the first change
     * in the transaction.
     *
     * <P>For persistent instances read in optimistic transactions, this method
     * allows the application to make the state of the instance part of the
     * transactional state.  At transaction commit, the state of the instance in
     * cache is compared to the state of the instance in the data store.  If they
     * are not the same, then an exception is thrown.
     * @param pc the instance to make transactional.
     */
    void makeTransactional (Object pc);

    /** Make an array of instances subject to transactional boundaries.
     * @param pcs the array of instances to make transactional.
     * @see #makeTransactional(Object pc)
     */
    void makeTransactionalAll (Object[] pcs);

    /** Make a Collection of instances subject to transactional boundaries.
     * @param pcs the Collection of instances to make transactional.
     * @see #makeTransactional(Object pc)
     */
    void makeTransactionalAll (Collection pcs);
    
    /** Make an instance non-transactional after commit.
     *
     * <P>Normally, at transaction completion, instances are evicted from the
     * cache.  This method allows an application to identify an instance as
     * not being evicted from the cache at transaction completion.  Instead,
     * the instance remains in the cache with nontransactional state.
     *
     * @param pc the instance to make nontransactional.
     */
    void makeNontransactional (Object pc);
    
    /** Make an array of instances non-transactional after commit.
     *
     * @param pcs the array of instances to make nontransactional.
     * @see #makeNontransactional(Object pc)
     */
    void makeNontransactionalAll (Object[] pcs);
    
    /** Make a Collection of instances non-transactional after commit.
     *
     * @param pcs the Collection of instances to make nontransactional.
     * @see #makeNontransactional(Object pc)
     */
    void makeNontransactionalAll (Collection pcs);
           
    /** The application can manage the PersistenceManager instances
     * more easily by having an application object associated with each
     * PersistenceManager instance.
     * @param o the user instance to be remembered by the PersistenceManager
     * @see #getUserObject
     */
    void setUserObject (Object o);
    
    /** The application can manage the PersistenceManager instances
     * more easily by having an application object associated with each
     * PersistenceManager instance.
     * @return the user object associated with this PersistenceManager
     * @see #setUserObject
     */
    Object getUserObject ();
     
    /** This method returns the PersistenceManagerFactory used to create
     * this PersistenceManager.  
     * @return the PersistenceManagerFactory that created
     * this PersistenceManager
     */
    PersistenceManagerFactory getPersistenceManagerFactory();

    /** Return the Class that implements the JDO Identity for the
     * specified PersistenceCapable Class.  The application can use the
     * returned Class to construct a JDO Identity instance for
     * application identity PersistenceCapable classes.  This JDO Identity
     * instance can then be used to get an instance of the
     * PersistenceCapable class for use in the application.
     *
     * <P>In order for the application to construct an instance of the ObjectId class
     * it needs to know the class being used by the JDO implementation.
     * @param cls the PersistenceCapable Class
     * @return the Class of the ObjectId of the parameter
     * @see #getObjectById
     */
    Class getObjectIdClass(Class cls);
  
  /** Set the Multithreaded flag for this PersistenceManager.  Applications
   * that use multiple threads to invoke methods or access fields from 
   * instances managed by this PersistenceManager must set this flag to true.
   * Instances managed by this PersistenceManager include persistent or
   * transactional instances of PersistenceCapable classes, as well as 
   * helper instances such as Query, Transaction, or Extent.
   *
   * @param flag the Multithreaded setting.
   */
  void setMultithreaded (boolean flag);
  
  /** Get the current Multithreaded flag for this PersistenceManager.  
   * @see #setMultithreaded
   * @return the Multithreaded setting.
   */
  boolean getMultithreaded();
    
    /** Set the ignoreCache parameter for queries.
     *
     * <P>IgnoreCache set to true specifies that for all Query instances created by this
     * PersistenceManager, the default is the cache should be ignored for queries.
     * @param flag the ignoreCache setting.
     */
    void setIgnoreCache(boolean flag);
  
    /** Get the ignoreCache setting for queries.
     *
     * <P>IgnoreCache set to true specifies that for all Query instances created by this
     * PersistenceManager, the default is the cache should be ignored for queries.
     * @return the ignoreCache setting.
     */
   boolean getIgnoreCache();
    }
