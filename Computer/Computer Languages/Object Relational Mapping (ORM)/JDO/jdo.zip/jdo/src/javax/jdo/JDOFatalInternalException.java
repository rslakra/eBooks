/*
*  Copyright 2001 Sun Microsystems, Inc. All rights reserved.
*  Use is subject to license terms.
*/

/*
 * JDOFatalInternalException.java
 *
 * Created on March 8, 2000, 8:35 AM
 */

package javax.jdo;

/** This class represents errors in the implementation for which no user
 * error handling is possible.  The error should be reported to the JDO
 * vendor for corrective action.
 *
 * @author  Craig Russell
 * @version 0.9
 */
public class JDOFatalInternalException extends JDOFatalException {

  /**
   * Constructs a new <code>JDOFatalInternalException</code> without detail message.
   */
  public JDOFatalInternalException() {
  }
  

  /**
   * Constructs a new <code>JDOFatalInternalException</code> with the specified detail message.
   * @param msg the detail message.
   */
  public JDOFatalInternalException(String msg) {
    super(msg);
  }

  /**
   * Constructs a new <code>JDOFatalInternalException</code> with the specified detail message and nested exceptions.
   * @param msg the detail message.
   * @param nested the nested <code>Exception[]</code>.
   */
  public JDOFatalInternalException(String msg, Exception[] nested) {
    super(msg, nested);
  }
}

