/*
*  Copyright 2001 Sun Microsystems, Inc. All rights reserved.
*  Use is subject to license terms.
*/

/*
 * PersistenceManagerFactory.java
 *
 * Created on February 25, 2000
 */
 
package javax.jdo;

import java.util.Properties;
import java.util.Collection;
import java.util.List;

/** The PersistenceManagerFactory is the interface to use to obtain
 * PersistenceManager instances.  All PersistenceManager instances obtained
 * from the same PersistenceManagerFactory will have the same default
 * properties.
 *
 * <P>PersistenceManagerFactory instances may be configured and
 * serialized for later use.  They may be stored via JNDI and looked up
 * and used later.  Any properties configured will be saved and restored.
 *
 * <P>Once the first PersistenceManager is obtained from the 
 * PersistenceManagerFactory, the factory can no longer be configured.
 * <P>If the ConnectionFactory property is set (non-null) then 
 * all other Connection properties including ConnectionFactoryName are ignored;
 * otherwise, if ConnectionFactoryName is set (non-null) then
 * all other Connection properties are ignored.
 * Similarly, if the ConnectionFactory2 property is set (non-null) then 
 * ConnectionFactory2Name is ignored.
 * <P>Operational state (PersistenceManager pooling, connection pooling,
 * operational parameters) must not be serialized.
 *
 * @author Craig Russell
 * @version 0.9
 */

public interface PersistenceManagerFactory extends java.io.Serializable
{
  
  /** Get an instance of PersistenceManager from this factory.  The instance has
   * default values for options.
   *
   * <P>After the first use of getPersistenceManager, no "set" methods will
   * succeed.
   *
   * @return a PersistenceManager instance with default options.
   */
  PersistenceManager getPersistenceManager();

    /** Get an instance of PersistenceManager from this factory.  The instance has
     * default values for options.  The parameters userid and password are used
     * when obtaining datastore connections from the connection pool.
     *
     * <P>After the first use of getPersistenceManager, no "set" methods will
     * succeed.
     *
     * @return a PersistenceManager instance with default options.
     * @param userid the userid for the connection
     * @param password the password for the connection
     */
  PersistenceManager getPersistenceManager(String userid, String password);

  /** Set the user name for the data store connection.
   * @param userName the user name for the data store connection.
   */
  void setConnectionUserName(String userName);

  /** Get the user name for the data store connection.
   * @return the user name for the data store connection.
   */
  String getConnectionUserName ();
  
  /** Set the password for the data store connection.
   * @param password the password for the data store connection.
   */
  void setConnectionPassword (String password);
  
  /** Set the URL for the data store connection.
   * @param URL the URL for the data store connection.
   */
  void setConnectionURL (String URL);

  /** Get the URL for the data store connection.
   * @return the URL for the data store connection.
   */
  String getConnectionURL ();
  
  /** Set the driver name for the data store connection.
   * @param driverName the driver name for the data store connection.
   */
  void setConnectionDriverName  (String driverName);

  /** Get the driver name for the data store connection.
   * @return the driver name for the data store connection.
   */
  String getConnectionDriverName ();
    
  /** Set the name for the data store connection factory.
   * @param connectionFactoryName the name of the data store connection factory.
   */
  void setConnectionFactoryName (String connectionFactoryName);

  /** Get the name for the data store connection factory.
   * @return the name of the data store connection factory.
   */
  String getConnectionFactoryName ();
  
  /** Set the data store connection factory.  JDO implementations
   * will support specific connection factories.  The connection
   * factory interfaces are not part of the JDO specification.
   * @param connectionFactory the data store connection factory.
   */
  void setConnectionFactory (Object connectionFactory);
  
  /** Get the data store connection factory.
   * @return the data store connection factory.
   */
  Object getConnectionFactory ();
  
  /** Set the name for the second data store connection factory.  This is
   * needed for managed environments to get nontransactional connections for
   * optimistic transactions.
   * @param connectionFactoryName the name of the data store connection factory.
   */
  void setConnectionFactory2Name (String connectionFactoryName);

  /** Get the name for the second data store connection factory.  This is
   * needed for managed environments to get nontransactional connections for
   * optimistic transactions.
   * @return the name of the data store connection factory.
   */
  String getConnectionFactory2Name ();
  
  /** Set the second data store connection factory.  This is
   * needed for managed environments to get nontransactional connections for
   * optimistic transactions.  JDO implementations
   * will support specific connection factories.  The connection
   * factory interfaces are not part of the JDO specification.
   * @param connectionFactory the data store connection factory.
   */
  void setConnectionFactory2 (Object connectionFactory);
  
  /** Get the second data store connection factory.  This is
   * needed for managed environments to get nontransactional connections for
   * optimistic transactions.
   * @return the data store connection factory.
   */
  Object getConnectionFactory2 ();
  
  /** Set the default Multithreaded setting for all PersistenceManager instances
   * obtained from this factory.
   *
   * @param flag the default Multithreaded setting.
   */
  void setMultithreaded (boolean flag);
  
  /** Get the default Multithreaded setting for all PersistenceManager instances
   * obtained from this factory.  
   *
   * @return the default Multithreaded setting.
   */
  boolean getMultithreaded();
    
  /** Set the default Optimistic setting for all PersistenceManager instances
   * obtained from this factory.  
   *
   * @param flag the default Optimistic setting.
   */
  void setOptimistic (boolean flag);
  
  /** Get the default Optimistic setting for all PersistenceManager instances
   * obtained from this factory.  
   *
   * @return the default Optimistic setting.
   */
  boolean getOptimistic();
    
  /** Set the default RetainValues setting for all PersistenceManager instances
   * obtained from this factory.
   *
   * @param flag the default RetainValues setting.
   */
  void setRetainValues (boolean flag);
  
  /** Get the default RetainValues setting for all PersistenceManager instances
   * obtained from this factory.
   *
   * @return the default RetainValues setting.
   */
  boolean getRetainValues ();
    
  /** Set the default NontransactionalRead setting for all PersistenceManager instances
   * obtained from this factory.  
   *
   * @param flag the default NontransactionalRead setting.
   */
  void setNontransactionalRead (boolean flag);
  
  /** Get the default NontransactionalRead setting for all PersistenceManager instances
   * obtained from this factory.
   *
   * @return the default NontransactionalRead setting.
   */
  boolean getNontransactionalRead ();
    
  /** Set the default NontransactionalWrite setting for all PersistenceManager instances
   * obtained from this factory.  
   *
   * @param flag the default NontransactionalWrite setting.
   */
  void setNontransactionalWrite (boolean flag);
  
  /** Get the default NontransactionalWrite setting for all PersistenceManager instances
   * obtained from this factory.
   *
   * @return the default NontransactionalWrite setting.
   */
  boolean getNontransactionalWrite ();
    
  /** Set the default IgnoreCache setting for all PersistenceManager instances
   * obtained from this factory.
   *
   * @param flag the default IgnoreCache setting.
   */
  void setIgnoreCache (boolean flag);
  
  /** Get the default IgnoreCache setting for all PersistenceManager instances
   * obtained from this factory.
   *
   * @return the default IngoreCache setting.
   */
  boolean getIgnoreCache ();
  
    /** Get the MaxPool setting for the PersistenceManager 
    * pool for this factory.
   * @return the MaxPool setting.
    */
    public int getMaxPool();
    
    /** Set the MaxPool setting for the PersistenceManager 
    * pool for this factory.
   * @param maxPool the MaxPool setting.
     */
    public void setMaxPool(int maxPool);
    
    /** Get the MinPool setting for the PersistenceManager 
    * pool for this factory.
    * @return the MinPool setting.
    */
    public int getMinPool();
    
    /** Set the MinPool setting for the PersistenceManager 
    * pool for this factory.
    * @param minPool the MinPool setting.
    */
    public void setMinPool(int minPool);
    
    /** Get the MsWait setting for the PersistenceManager 
    * pool for this factory.
    * @return the MsWait setting.
    */
    public int getMsWait();
    
    /** Set the MsWait setting for the PersistenceManager 
    * pool for this factory.
    * @param msWait the MsWait setting.
    */
    public void setMsWait(int msWait);
    
   /** Return non-configurable properties of this PersistenceManagerFactory.
   * Properties with keys VendorName and VersionNumber are required.  Other
   * keys are optional.
   * @return the non-configurable properties of this
   * PersistenceManagerFactory.
   */
  Properties getProperties();
  
    /** The application can determine from the results of this
     * method which optional features, and which query languages 
     * are supported by the JDO implementation.
     * <P>Each supported JDO optional feature is represented by a
     * String with one of the following values:
     *
     * <P>javax.jdo.option.TransientTransactional
     * <P>javax.jdo.option.NontransactionalRead
     * <P>javax.jdo.option.NontransactionalWrite
     * <P>javax.jdo.option.RetainValues
     * <P>javax.jdo.option.Optimistic
     * <P>javax.jdo.option.ApplicationIdentity
     * <P>javax.jdo.option.DatastoreIdentity
     * <P>javax.jdo.option.NonDatastoreIdentity
     * <P>javax.jdo.option.ArrayList
     * <P>javax.jdo.option.HashMap
     * <P>javax.jdo.option.Hashtable
     * <P>javax.jdo.option.LinkedList
     * <P>javax.jdo.option.TreeMap
     * <P>javax.jdo.option.TreeSet
     * <P>javax.jdo.option.Vector
     * <P>javax.jdo.option.Map
     * <P>javax.jdo.option.List
     * <P>javax.jdo.option.Array  
     * <P>javax.jdo.option.NullCollection  
     *
     *<P>The standard JDO query language is represented by a String:
     *<P>javax.jdo.query.JDOQL   
     * @return the List of String representing the supported Options
     */    
    Collection supportedOptions();
   
}
