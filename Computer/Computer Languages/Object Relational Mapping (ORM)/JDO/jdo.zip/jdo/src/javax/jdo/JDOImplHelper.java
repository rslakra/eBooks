/*
*  Copyright 2001 Sun Microsystems, Inc. All rights reserved.
*  Use is subject to license terms.
*/

/*
 * JDOImplHelper.java
 *
 * Created on February 2, 2001, 3:53 PM
 */

package javax.jdo;

import java.util.HashMap;

/** This class is a helper class for JDO implementations.  It contains methods
 * to register metadata for persistence-capable classes and to perform common
 * operations needed by implementations, not by end users.
 * <P>JDOImplHelper allows construction of instances of persistence-capable
 * classes without using reflection.
 * <P>Persistence-capable classes register themselves via a static method 
 * at class load time.
 * There is no security restriction on this access.  JDO implementations
 * get access to the functions provided by this class only if they are
 * authorized by the security manager.  To avoid having every call go through
 * the security manager, only the call to get an instance is checked.  Once an 
 * implementation
 * has an instance, any of the methods can be invoked without security checks.
 * @author clr
 * @version 0.9
 *
 */
public class JDOImplHelper extends java.lang.Object {
    
    /** This HashMap contains a static mapping of PersistenceCapable class to
     * metadata for the class used for constructing new instances.
     *
     * It is synchronized only when new keys are being added.
     */    
    private static HashMap hashMap = new HashMap ();

    /** The singleton JDOImplHelper instance.
     */    
    private static JDOImplHelper jdoImplHelper = new JDOImplHelper();

    /** Creates new JDOImplHelper */
    private JDOImplHelper() {
    }
    
    /** Get an instance of JDOImplHelper.  This method
     * checks that the caller is authorized for
     * JDOPermission("getMetadata"), and if not, throws IllegalAccessException.
     * @throws IllegalAccessException
     * @return an instance of JDOImplHelper.
     */    
    public static JDOImplHelper getInstance() 
        throws IllegalAccessException {        
        SecurityManager sec = System.getSecurityManager();
        if (sec != null) { 
            // throws exception if caller is not authorized
            sec.checkPermission (new JDOPermission("getMetadata"));
        }
        return jdoImplHelper;
    }
    
    /** Get the field names for a PersistenceCapable class.  The order 
     * of fields is the natural ordering of the String class (without
     * considering localization).
     * @param pcClass the PersistenceCapable class.
     * @return the field names for the class.
     */    
    public String[] getFieldNames (Class pcClass) {
        Meta meta = getMeta (pcClass);
        if (meta == null) {
            throw new JDOFatalUserException ("PersistenceCapableMetadata");
        }
        return meta.getFieldNames();
    }

    /** Get the field types for a PersistenceCapable class.  The order
     * of fields is the same as for field names.
     * @param pcClass the PersistenceCapable class.
     * @return the field types for the class.
     */    
    public Class[] getFieldTypes (Class pcClass) {
        Meta meta = getMeta (pcClass);
        if (meta == null) {
            throw new JDOFatalUserException ("PersistenceCapableMetadata");
        }
        return meta.getFieldTypes();
    }
            
    /** Get the field flags for a PersistenceCapable class.  The order
     * of fields is the same as for field names.
     * @param pcClass the PersistenceCapable class.
     * @return the field types for the class.
     */    
    public byte[] getFieldFlags (Class pcClass) {
        Meta meta = getMeta (pcClass);
        if (meta == null) {
            throw new JDOFatalUserException ("PersistenceCapableMetadata");
        }
        return meta.getFieldFlags();
    }
            
    /** Get the persistence-capable superclass for a PersistenceCapable class.
     * @param pcClass the PersistenceCapable class.
     * @return the field types for the class.
     */    
    public Class getPersistenceCapableSuperclass (Class pcClass) {
        Meta meta = getMeta (pcClass);
        if (meta == null) {
            throw new JDOFatalUserException ("PersistenceCapableMetadata");
        }
        return meta.getPersistenceCapableSuperclass();
    }
            
    
    /** Create a new instance of the class and assign its jdoStateManager.
     * The new instance has its jdoFlags set to LOAD_REQUIRED.
     * @see PersistenceCapable#jdoNewInstance(StateManager sm)
     * @param pcClass the PersistenceCapable class.
     * @param sm the StateManager which will own the new instance.
     * @return the new instance, or null if the class is not registered.
     */    
    public PersistenceCapable newInstance (Class pcClass, StateManager sm) {
        Meta meta = getMeta (pcClass);
        if (meta == null) {
            throw new JDOFatalInternalException ("PersistenceCapableMetadata");
        } else {
        PersistenceCapable pcInstance = meta.getPC();
        return pcInstance == null?null:pcInstance.jdoNewInstance(sm);
        }
    }
    
    /** Create a new instance of the class and assign its jdoStateManager and 
     * key values from the ObjectId.  If the oid parameter is null, no key 
     * values are copied.
     * The new instance has its jdoFlags set to LOAD_REQUIRED.
     * @see PersistenceCapable#jdoNewInstance(StateManager sm, Object oid)
     * @param pcClass the PersistenceCapable class.
     * @param sm the StateManager which will own the new instance.
     * @return the new instance, or null if the class is not registered.
     * @param oid the ObjectId instance from which to copy key field values.
 */    
    public PersistenceCapable newInstance 
            (Class pcClass, StateManager sm, Object oid) {
        Meta meta = getMeta (pcClass);
        if (meta == null) {
            throw new JDOFatalInternalException ("PersistenceCapableMetadata");
        } else {
        PersistenceCapable pcInstance = meta.getPC();
        return pcInstance == null?null:pcInstance.jdoNewInstance(sm, oid);
        }
    }
    
    /** Create a new instance of the ObjectId class of this PersistenceCapable
     * class.
     * @param pcClass the PersistenceCapable class.
     * @return the new ObjectId instance, or null if the class is not registered.
     */    
    public Object newObjectIdInstance (Class pcClass) {
        Meta meta = getMeta (pcClass);
        if (meta == null) {
            throw new JDOFatalUserException ("PersistenceCapableMetadata");
        } else {
        PersistenceCapable pcInstance = meta.getPC();
        return pcInstance == null?null:pcInstance.jdoNewObjectIdInstance();
        }
    }
    
    /** Copy fields from an outside source to the key fields in the ObjectId.
     * This method is generated in the PersistenceCapable class to generate
     * a call to the field manager for each key field in the ObjectId.  
     * <P>For example, an ObjectId class that has three key fields (int id, 
     * String name, and Float salary) would have the method generated:
     * <P>void copyKeyFieldsToObjectId (Object oid, ObjectIdFieldManager fm) {
     * <P>    oid.id = fm.fetchIntField (0);
     * <P>    oid.name = fm.fetchStringField (1);
     * <P>    oid.salary = fm.fetchObjectField (2);
     * <P>}
     * <P>The implementation is responsible for implementing the 
     * ObjectIdFieldManager to produce the values for the key fields.
     * @param pcClass the PersistenceCapable Class.
     * @param oid the ObjectId target of the copy.
     * @param fm the field manager that supplies the field values.
 */    
    public void copyKeyFieldsToObjectId 
    (Class pcClass, PersistenceCapable.ObjectIdFieldManager fm, Object oid) {
        Meta meta = getMeta (pcClass);
        if (meta == null) {
            throw new JDOFatalUserException ("PersistenceCapableMetadata");
        } else {
            PersistenceCapable pcInstance = meta.getPC();
            if (pcInstance != null) pcInstance.jdoCopyKeyFieldsToObjectId(fm, oid);
        }
    }

    /** Copy fields from the PersistenceCapable instance to the Object Id instance.
     * @param pc the PersistenceCapable source of the key fields
     * @param oid the ObjectId target of the key fields
     */    
    public void copyKeyFieldsToObjectId 
    (PersistenceCapable pc, Object oid) {
        Class pcClass = pc.getClass();
        Meta meta = getMeta (pcClass);
        if (meta == null) {
            throw new JDOFatalUserException ("PersistenceCapableMetadata");
        } else {
            PersistenceCapable pcInstance = meta.getPC();
            if (pcInstance != null) pcInstance.jdoCopyKeyFieldsToObjectId(pc, oid);
        }
    }

            
    /** Register metadata by class.  The registration will be done in the
     * class named JDOImplHelper loaded by the same class loader as the 
     * PersistenceCapable class performing the registration.
     *
     * @param pcClass the PersistenceCapable class
     * used as the key for lookup.
     * @param fieldNames an array of String field names.
     * @param fieldTypes an array of Class field types
     * @param pc the PersistenceCapable class.
     */    
    public static void registerClass (Class pcClass, 
            String[] fieldNames, Class[] fieldTypes, 
            byte[] fieldFlags, Class persistenceCapableSuperclass,
            PersistenceCapable pc) {
        if (pcClass == null | pc == null) 
            throw new NullPointerException();
        Meta meta = new Meta (fieldNames, fieldTypes, 
            fieldFlags, persistenceCapableSuperclass, pc);
        synchronized (hashMap) {
            hashMap.put (pcClass, meta);
        }
    } 
        
    /** Look up the metadata for a PC class.
     * @param pcClass the Class.
     * @return the Meta for the Class.
     */    
    private static Meta getMeta (Class pcClass) {
        return (Meta) hashMap.get (pcClass);
    }
    
    /** This is a helper class to manage metadata per persistence-capable
     * class.  The information is used at runtime to provide field names and
     * field types to the JDO Model.
     *
     * This is the value of the HashMap which
     * relates the PersistenceCapable Class
     * as a key to the metadata.
     */    
    static class Meta {
        
    /** Construct an instance of Meta.
     * @param fieldNames An array of String
     * @param fieldTypes An array of Class
     * @param pc An instance of the PersistenceCapable class
     */        
    Meta (String[] fieldNames, Class[] fieldTypes, byte[] fieldFlags,
            Class persistenceCapableSuperclass, PersistenceCapable pc) {
        this.fieldNames = fieldNames;
        this.fieldTypes = fieldTypes;
        this.fieldFlags = fieldFlags;
        this.persistenceCapableSuperclass = persistenceCapableSuperclass;
        this.pc = pc;
    }
    
    /** This is an array of field names used
     * for the Model at runtime.  The field
     * is passed by the static class initialization.
     */        
    String fieldNames[];
    
    /** Get the field names from the metadata.
     * @return the array of field names.
     */    
    String[] getFieldNames() {
        return fieldNames;
    }
    
    /** This is an array of field types used
     * for the Model at runtime.  The field
     * is passed by the static class initialization.
     */        
    Class fieldTypes[];
    
    /** Get the field types from the metadata.
     * @return the array of field types.
     */    
    Class[] getFieldTypes() {
        return fieldTypes;
    }
    
    /** This is an array of field flags used
     * for the Model at runtime.  The field
     * is passed by the static class initialization.
     */        
    byte fieldFlags[];
    
    /** Get the field types from the metadata.
     * @return the array of field types.
     */    
    byte[] getFieldFlags() {
        return fieldFlags;
    }

    /** This is the Class instance of the PersistenceCapable superclass.
     */
    Class persistenceCapableSuperclass;
    
    Class getPersistenceCapableSuperclass() {
        return persistenceCapableSuperclass;
    }
    /** This is an instance of PersistenceCapable,
     * used at runtime to create new instances.
     */        
    PersistenceCapable pc;
    
    /** Get an instance of the PersistenceCapable class.
     * @return an instance of the PC Class.
     */    
    PersistenceCapable getPC() {
        return pc;
    }
    
    }
}
