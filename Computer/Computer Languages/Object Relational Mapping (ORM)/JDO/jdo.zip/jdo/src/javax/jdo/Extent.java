/*
*  Copyright 2001 Sun Microsystems, Inc. All rights reserved.
*  Use is subject to license terms.
*/

/*
 * Extent.java
 *
 * Created on December 8, 2000, 3:06 PM
 */

package javax.jdo;

import java.util.Iterator;

/** Instances of the Extent class represent the entire collection
 * of instances in the data store of the candidate class
 * possibly including its subclasses.
 * <P>The Extent instance has two possible uses:
 * <ol>
 * <li>to iterate all instances in of a particular class 
 * <li>to execute a Query in the data store over all instances
 * of a particular class
 * </ol>
 * @author clr
 * @version 0.9
 */
public interface Extent {
        
    /** Returns an iterator over all the instances in the Extent.
     * @return an iterator over all instances in the Extent
     */
        Iterator iterator();

    /** Returns whether this Extent was defined to contain subclasses.
     * @return true if this Extent was defined to contain instances
     * that are of a subclass type
     */    
    boolean hasSubclasses();

    /** An Extent contains all instances of a particular Class in the data
     * store; this method returns the Class of the instances
      * @return the Class of instances of this Extent
      */
    Class getCandidateClass();

    /** An Extent is managed by a PersistenceManager; this method gives access
     * to the owning PersistenceManager.
     * @return the owning PersistenceManager
     */
    PersistenceManager getPersistenceManager();
    
    /** Close all Iterators associated with this Extent instance.  Iterators closed
     * by this method will return false to hasNext() and will throw
     * NoSuchElementException on next().  The Extent instance can still be used
     * as a parameter of Query.setExtent, and to get an Iterator.
     */    
    void closeAll ();
    
    /** Close an Iterator associated with this Extent instance.  Iterators closed
     * by this method will return false to hasNext() and will throw
     * NoSuchElementException on next().  The Extent instance can still be used
     * as a parameter of Query.setExtent, and to get an Iterator.
     * @param it an iterator obtained by the method iterator() on this Extent instance.
     */    
    void close (Iterator it);
}

