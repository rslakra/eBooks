/*
*  Copyright 2001 Sun Microsystems, Inc. All rights reserved.
*  Use is subject to license terms.
*/

/*
 * StateManager.java
 *
 * Created on September 1, 2000, 2:29 PM
 */

package javax.jdo;

/**
 *
 * @author  clr
 * @version 0.9
 */
public interface StateManager {
    
    /** The owning StateManager uses this method to supply the 
     * value of the flags to the PersistenceCapable instance.
     * @param pc the calling PersistenceCapable instance
     * @return the value of jdoFlags to be stored in the PersistenceCapable instance
     */
    byte replacingFlags(Object pc);

    /** Replace the current value of jdoStateManager.
     * <P>
     * This method is called by the PersistenceCapable whenever
     * jdoReplaceStateManager is called and there is already
     * an owning StateManager.  This is a security precaution
     * to ensure that the owning StateManager is the only
     * source of any change to its reference in the PersistenceCapable.
     * @return the new value for the jdoStateManager
     * @param pc the calling PersistenceCapable instance
     * @param sm the proposed new value for the jdoStateManager
     */ 
    StateManager replacingStateManager (Object pc, StateManager sm);
    
    /** Tests whether this object is dirty.
     *
     * Instances that have been modified, deleted, or newly 
     * made persistent in the current transaction return true.
     *
     *<P>Transient nontransactional instances return false.
     *<P>
     * @see PersistenceCapable#jdoMakeDirty(String fieldName)
     * @param pc the calling PersistenceCapable instance
     * @return true if this instance has been modified in the current transaction.
     */
    boolean isDirty(Object pc);

    /** Tests whether this object is transactional.
     *
     * Instances that respect transaction boundaries return true.  These instances
     * include transient instances made transactional as a result of being the
     * target of a makeTransactional method call; newly made persistent or deleted
     * persistent instances; persistent instances read in data store
     * transactions; and persistent instances modified in optimistic transactions.
     *
     *<P>Transient nontransactional instances return false.
     *<P>
     * @param pc the calling PersistenceCapable instance
     * @return true if this instance is transactional.
     */
    boolean isTransactional(Object pc);

    /** Tests whether this object is persistent.
     *
     * Instances whose state is stored in the data store return true.
     *
     *<P>Transient instances return false.
     *<P>
     * @see PersistenceManager#makePersistent(Object pc)
     * @param pc the calling PersistenceCapable instance
     * @return true if this instance is persistent.
     */
    boolean isPersistent(Object pc);

    /** Tests whether this object has been newly made persistent.
     *
     * Instances that have been made persistent in the current transaction 
     * return true.
     *
     *<P>Transient instances return false.
     *<P>
     * @see PersistenceManager#makePersistent(Object pc)
     * @param pc the calling PersistenceCapable instance
     * @return true if this instance was made persistent
     * in the current transaction.
     */
    boolean isNew(Object pc);

    /** Tests whether this object has been deleted.
     *
     * Instances that have been deleted in the current transaction return true.
     *
     *<P>Transient instances return false.
     *<P>
     * @see PersistenceManager#deletePersistent(Object pc)
     * @param pc the calling PersistenceCapable instance
     * @return true if this instance was deleted
     * in the current transaction.
     */
    boolean isDeleted(Object pc);
    
    /** Return the PersistenceManager that owns this instance.
     * @param pc the calling PersistenceCapable instance
     * @return the PersistenceManager that owns this instance
     */
    PersistenceManager getPersistenceManager (Object pc);
    
    /** Mark the associated PersistenceCapable field dirty.
     * <P> The StateManager will make a copy of the field
     * so it can be restored if needed later, and then mark
     * the field as modified in the current transaction.
     * @param pc the calling PersistenceCapable instance
     * @param fieldName the name of the field
     */    
    void makeDirty (Object pc, String fieldName);
    
    /** Return the object representing the JDO identity 
     * of the calling instance.  If the JDO identity is being changed in
     * the current transaction, this method returns the identity as of
     * the beginning of the transaction.
     * @param pc the calling PersistenceCapable instance
     * @return the object representing the JDO identity of the calling instance
     */    
    Object getObjectId (Object pc);

    /** Return the object representing the JDO identity 
     * of the calling instance.  If the JDO identity is being changed in
     * the current transaction, this method returns the current identity as
     * changed in the transaction.
     * @param pc the calling PersistenceCapable instance
     * @return the object representing the JDO identity of the calling instance
     */    
    Object getTransactionalObjectId (Object pc);

    /** Return true if the field is cached in the calling
     * instance.
     * @param pc the calling PersistenceCapable instance
     * @param field the field number
     * @return whether the field is cached in the calling instance
     */    
    boolean isLoaded (Object pc, int field);
    
    /** Guarantee that the serializable transactional and persistent fields
     * are loaded into the instance.  This method is called by the generated
     * jdoPreSerialize method prior to serialization of the
     * instance.
     * @param pc the calling PersistenceCapable instance
     */    
    void preSerialize (Object pc);
    
    /** Return the value for the field.
     * @param pc the calling PersistenceCapable instance
     * @param field the field number 
     * @param currentValue the current value of the field
     * @return the new value for the field
     */    
    boolean getBooleanField (Object pc, int field, boolean currentValue);
    
    /** Return the value for the field.
     * @param pc the calling PersistenceCapable instance
     * @param field the field number 
     * @param currentValue the current value of the field
     * @return the new value for the field
     */    
    char getCharField (Object pc, int field, char currentValue);
    
    /** Return the value for the field.
     * @param pc the calling PersistenceCapable instance
     * @param field the field number 
     * @param currentValue the current value of the field
     * @return the new value for the field
     */    
    byte getByteField (Object pc, int field, byte currentValue);
    
    /** Return the value for the field.
     * @param pc the calling PersistenceCapable instance
     * @param field the field number 
     * @param currentValue the current value of the field
     * @return the new value for the field
     */    
    short getShortField (Object pc, int field, short currentValue);
    
    /** Return the value for the field.
     * @param pc the calling PersistenceCapable instance
     * @param field the field number 
     * @param currentValue the current value of the field
     * @return the new value for the field
     */    
    int getIntField (Object pc, int field, int currentValue);
    
    /** Return the value for the field.
     * @param pc the calling PersistenceCapable instance
     * @param field the field number 
     * @param currentValue the current value of the field
     * @return the new value for the field
     */    
    long getLongField (Object pc, int field, long currentValue);
    
    /** Return the value for the field.
     * @param pc the calling PersistenceCapable instance
     * @param field the field number 
     * @param currentValue the current value of the field
     * @return the new value for the field
     */    
    float getFloatField (Object pc, int field, float currentValue);
    
    /** Return the value for the field.
     * @param pc the calling PersistenceCapable instance
     * @param field the field number 
     * @param currentValue the current value of the field
     * @return the new value for the field
     */    
    double getDoubleField (Object pc, int field, double currentValue);
    
    /** Return the value for the field.
     * @param pc the calling PersistenceCapable instance
     * @param field the field number 
     * @param currentValue the current value of the field
     * @return the new value for the field
     */    
    String getStringField (Object pc, int field, String currentValue);
    
    /** Return the value for the field.
     * @param pc the calling PersistenceCapable instance
     * @param field the field number 
     * @param currentValue the current value of the field
     * @return the new value for the field
     */    
    Object getObjectField (Object pc, int field, Object currentValue);

    /** Mark the field as modified by the user, and return the new value for the field.
     * @param pc the calling PersistenceCapable instance
     * @param field the field number
     * @param currentValue the current value of the field
     * @param newValue the proposed new value of the field
     * @return the new value for the field
     */    
    boolean setBooleanField (Object pc, int field, boolean currentValue, boolean newValue);

    /** Mark the field as modified by the user, and return the new value for the field.
     * @param pc the calling PersistenceCapable instance
     * @param field the field number 
     * @param currentValue the current value of the field
     * @param newValue the proposed new value of the field
     * @return the new value for the field
     */    
    char setCharField (Object pc, int field, char currentValue, char newValue);

    /** Mark the field as modified by the user, and return the new value for the field.
     * @param pc the calling PersistenceCapable instance
     * @param field the field number 
     * @param currentValue the current value of the field
     * @param newValue the proposed new value of the field
     * @return the new value for the field
     */    
    byte setByteField (Object pc, int field, byte currentValue, byte newValue);

    /** Mark the field as modified by the user, and return the new value for the field.
     * @param pc the calling PersistenceCapable instance
     * @param field the field number 
     * @param currentValue the current value of the field
     * @param newValue the proposed new value of the field
     * @return the new value for the field
     */    
    short setShortField (Object pc, int field, short currentValue, short newValue);

    /** Mark the field as modified by the user, and return the new value for the field.
     * @param pc the calling PersistenceCapable instance
     * @param field the field number 
     * @param currentValue the current value of the field
     * @param newValue the proposed new value of the field
     * @return the new value for the field
     */    
    int setIntField (Object pc, int field, int currentValue, int newValue);

    /** Mark the field as modified by the user, and return the new value for the field.
     * @param pc the calling PersistenceCapable instance
     * @param field the field number 
     * @param currentValue the current value of the field
     * @param newValue the proposed new value of the field
     * @return the new value for the field
     */    
    long setLongField (Object pc, int field, long currentValue, long newValue);

    /** Mark the field as modified by the user, and return the new value for the field.
     * @param pc the calling PersistenceCapable instance
     * @param field the field number 
     * @param currentValue the current value of the field
     * @param newValue the proposed new value of the field
     * @return the new value for the field
     */    
    float setFloatField (Object pc, int field, float currentValue, float newValue);

    /** Mark the field as modified by the user, and return the new value for the field.
     * @param pc the calling PersistenceCapable instance
     * @param field the field number 
     * @param currentValue the current value of the field
     * @param newValue the proposed new value of the field
     * @return the new value for the field
     */    
    double setDoubleField (Object pc, int field, double currentValue, double newValue);

    /** Mark the field as modified by the user, and return the new value for the field.
     * @param pc the calling PersistenceCapable instance
     * @param field the field number 
     * @param currentValue the current value of the field
     * @param newValue the proposed new value of the field
     * @return the new value for the field
     */    
    String setStringField (Object pc, int field, String currentValue, String newValue);

    /** Mark the field as modified by the user, and return the new value for the field.
     * @param pc the calling PersistenceCapable instance
     * @param field the field number 
     * @param currentValue the current value of the field
     * @param newValue the proposed new value of the field
     * @return the new value for the field
     */    
    Object setObjectField (Object pc, int field, Object currentValue, Object newValue);

    /** The value of the field requested to be provided to the StateManager
     * @param pc the calling PersistenceCapable instance
     * @param field the field number 
     * @param currentValue the current value of the field
     */    
    void providedBooleanField (Object pc, int field, boolean currentValue);

    /** The value of the field requested to be provided to the StateManager
     * @param pc the calling PersistenceCapable instance
     * @param field the field number 
     * @param currentValue the current value of the field
     */    
    void providedCharField (Object pc, int field, char currentValue);

    /** The value of the field requested to be provided to the StateManager
     * @param pc the calling PersistenceCapable instance
     * @param field the field number 
     * @param currentValue the current value of the field
     */    
    void providedByteField (Object pc, int field, byte currentValue);

    /** The value of the field requested to be provided to the StateManager
     * @param pc the calling PersistenceCapable instance
     * @param field the field number 
     * @param currentValue the current value of the field
     */    
    void providedShortField (Object pc, int field, short currentValue);

    /** The value of the field requested to be provided to the StateManager
     * @param pc the calling PersistenceCapable instance
     * @param field the field number 
     * @param currentValue the current value of the field
     */    
    void providedIntField (Object pc, int field, int currentValue);

    /** The value of the field requested to be provided to the StateManager
     * @param pc the calling PersistenceCapable instance
     * @param field the field number 
     * @param currentValue the current value of the field
     */    
    void providedLongField (Object pc, int field, long currentValue);

    /** The value of the field requested to be provided to the StateManager
     * @param pc the calling PersistenceCapable instance
     * @param field the field number 
     * @param currentValue the current value of the field
     */    
    void providedFloatField (Object pc, int field, float currentValue);

    /** The value of the field requested to be provided to the StateManager
     * @param pc the calling PersistenceCapable instance
     * @param field the field number 
     * @param currentValue the current value of the field
     */    
    void providedDoubleField (Object pc, int field, double currentValue);

    /** The value of the field requested to be provided to the StateManager
     * @param pc the calling PersistenceCapable instance
     * @param field the field number 
     * @param currentValue the current value of the field
     */    
    void providedStringField (Object pc, int field, String currentValue);

    /** The value of the field requested to be provided to the StateManager
     * @param pc the calling PersistenceCapable instance
     * @param field the field number 
     * @param currentValue the current value of the field
     */    
    void providedObjectField (Object pc, int field, Object currentValue);

    /** The replacing value of the field in the calling instance
     * @param pc the calling PersistenceCapable instance
     * @param field the field number
     * @return the new value for the field
     */    
    boolean replacingBooleanField (Object pc, int field);

    /** The replacing value of the field in the calling instance
     * @param pc the calling PersistenceCapable instance
     * @param field the field number 
     * @return the new value for the field
     */    
    char replacingCharField (Object pc, int field);

    /** The replacing value of the field in the calling instance
     * @param pc the calling PersistenceCapable instance
     * @param field the field number 
     * @return the new value for the field
     */    
    byte replacingByteField (Object pc, int field);

    /** The replacing value of the field in the calling instance
     * @param pc the calling PersistenceCapable instance
     * @param field the field number 
     * @return the new value for the field
     */    
    short replacingShortField (Object pc, int field);

    /** The replacing value of the field in the calling instance
     * @param pc the calling PersistenceCapable instance
     * @param field the field number 
     * @return the new value for the field
     */    
    int replacingIntField (Object pc, int field);

    /** The replacing value of the field in the calling instance
     * @param pc the calling PersistenceCapable instance
     * @param field the field number 
     * @return the new value for the field
     */    
    long replacingLongField (Object pc, int field);

    /** The replacing value of the field in the calling instance
     * @param pc the calling PersistenceCapable instance
     * @param field the field number 
     * @return the new value for the field
     */    
    float replacingFloatField (Object pc, int field);

    /** The replacing value of the field in the calling instance
     * @param pc the calling PersistenceCapable instance
     * @param field the field number 
     * @return the new value for the field
     */    
    double replacingDoubleField (Object pc, int field);

    /** The replacing value of the field in the calling instance
     * @param pc the calling PersistenceCapable instance
     * @param field the field number 
     * @return the new value for the field
     */    
    String replacingStringField (Object pc, int field);

    /** The replacing value of the field in the calling instance
     * @param pc the calling PersistenceCapable instance
     * @param field the field number 
     * @return the new value for the field
     */    
    Object replacingObjectField (Object pc, int field);

}

