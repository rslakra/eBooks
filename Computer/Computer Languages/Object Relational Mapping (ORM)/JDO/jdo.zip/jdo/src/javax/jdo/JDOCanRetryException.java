/*
*  Copyright 2001 Sun Microsystems, Inc. All rights reserved.
*  Use is subject to license terms.
*/

/*
 * JDOCanRetryException.java
 *
 * Created on March 8, 2000, 8:32 AM
 */

package javax.jdo;

/** This is the base class for exceptions that can be retried.
 *
 * @author  Craig Russell
 * @version 0.9
 */
public class JDOCanRetryException extends JDOException {

  /**
   * Constructs a new <code>JDOCanRetryException</code> without detail message.
   */
  public JDOCanRetryException() {
  }
  

  /**
   * Constructs a new <code>JDOCanRetryException</code> with the specified detail message.
   * @param msg the detail message.
   */
  public JDOCanRetryException(String msg) {
    super(msg);
  }

  /**
   * Constructs a new <code>JDOCanRetryException</code> with the specified detail message and nested exceptions.
   * @param msg the detail message.
   * @param nested the nested <code>Exception[]</code>.
   */
  public JDOCanRetryException(String msg, Exception[] nested) {
    super(msg, nested);
  }
  
  /** Constructs a new <code>JDOCanRetryException</code> with the specified detail message
   * and failed object.
   * @param msg the detail message.
   * @param failed the failed object.
   */
  public JDOCanRetryException(String msg, Object failed) {
    super(msg, failed);
  }
  
  /** Constructs a new <code>JDOCanRetryException</code> with the specified detail message,
   * nested exceptions, and failed object.
   * @param msg the detail message.
   * @param nested the nested <code>Exception[]</code>.
   * @param failed the failed object.
   */
  public JDOCanRetryException(String msg, Exception[] nested, Object failed) {
    super(msg, nested, failed);
  }
}

