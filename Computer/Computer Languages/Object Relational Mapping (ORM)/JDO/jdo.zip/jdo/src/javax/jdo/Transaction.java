/*
*  Copyright 2001 Sun Microsystems, Inc. All rights reserved.
*  Use is subject to license terms.
*/

/*
 * Transaction.java
 *
 * Created on February 25, 2000
 */
 
package javax.jdo;
import javax.transaction.Synchronization;

/** The JDO Transaction interface provides for initiation and completion 
 * of transactions under user control.
 * It is a sub-interface of the {@link PersistenceManager}
 * that deals with options and transaction demarcation. 
 * <P>Transaction options include whether optimistic concurrency
 * control should be used for the current transaction, whether instances
 * may hold values in the cache outside transactions, and whether
 * values should be retained in the cache after transaction completion.  These
 * options are valid for both managed and non-managed transactions.
 *
 * <P>Transaction completion methods have the same semantics as javax.transaction
 * UserTransaction, and are valid only in the non-managed, non-distributed
 * transaction environment.
 * <P>For operation in the distributed environment, Transaction is declared
 * to implement javax.transaction.Synchronization.  This allows for
 * flushing the cache to the data store during externally managed
 * transaction completion.
 * @author Craig Russell
 * @version 0.9
 */

public interface Transaction
{
    /** Begin a transaction.  The type of transaction is determined by the
     * setting of the Optimistic flag.
     * @see #setOptimistic
     * @see #getOptimistic
     * @throws JDOUserException if transactions are managed by a container
     * in the managed environment, or if the transaction is already active.
     */
    void begin();
    
    /** Commit the current transaction.
     * @throws JDOUserException if transactions are managed by a container
     * in the managed environment, or if the transaction is not active.
     */
    void commit();
    
    /** Roll back the current transaction.
     * @throws JDOUserException if transactions are managed by a container
     * in the managed environment, or if the transaction is not active.
     */
    void rollback();

    /** Returns whether there is a transaction currently active.
     * @return true if the transaction is active.
     */
    boolean isActive();
    
    /** If true, allow persistent instances to be read without
     * a transaction active.
     * If an implementation does not support this option, a 
     * JDOUnsupportedOptionException is thrown.
     * @param nontransactionalRead the value of the nontransactionalRead property
     */
    void setNontransactionalRead (boolean nontransactionalRead);
    
    /** If true, allows persistent instances to be read without
     * a transaction active.
     * @return the value of the nontransactionalRead property
     */
    boolean getNontransactionalRead ();
    
    /** If true, allow persistent instances to be written without
     * a transaction active.
     * If an implementation does not support this option, a 
     * JDOUnsupportedOptionException is thrown.
     * @param nontransactionalWrite the value of the nontransactionalRead property
     */
    void setNontransactionalWrite (boolean nontransactionalWrite);
    
    /** If true, allows persistent instances to be written without
     * a transaction active.
     * @return the value of the nontransactionalWrite property
     */
    boolean getNontransactionalWrite ();
    
    /** If true, at commit instances retain their values and the instances
     * transition to persistent-nontransactional.
     * If an implementation does not support this option, a 
     * JDOUnsupportedOptionException is thrown.
     * @param retainValues the value of the retainValues property
     */
    void setRetainValues(boolean retainValues);
    
    /** If true, at commit time instances retain their field values.
     * @return the value of the retainValues property
     */
    boolean getRetainValues();
    
    /** Optimistic transactions do not hold data store locks until commit time.
     * If an implementation does not support this option, a 
     * JDOUnsupportedOptionException is thrown.
     * @param optimistic the value of the Optimistic flag.
     */
    void setOptimistic(boolean optimistic);
    
    /** Optimistic transactions do not hold data store locks until commit time.
     * @return the value of the Optimistic property.
     */
    boolean getOptimistic();
    
    /** The user can specify a Synchronization instance to be notified on
     * transaction completions.  The beforeCompletion method is called prior
     * to flushing instances to the data store.
     *
     * <P>The afterCompletion method is called after performing state
     * transitions of persistent and transactional instances, following 
     * the data store commit or rollback operation.
     * <P>Only one Synchronization instance can be registered with the 
     * Transaction. If the application requires more than one instance to 
     * receive synchronization callbacks, then the single application instance 
     * is responsible for managing them, and forwarding callbacks to them.
     * @param sync the Synchronization instance to be notified; null for none
     */
    void setSynchronization(Synchronization sync);
    
    /** The user-specified Synchronization instance for this Transaction instance.    
     * @return the user-specified Synchronization instance.
     */
    Synchronization getSynchronization();

    /** The Tranansaction instance is always associated with exactly one
     * PersistenceManager.
     *
     * @return the PersistenceManager for this Transaction instance
     */
    PersistenceManager getPersistenceManager();
}
