/*
*  Copyright 2001 Sun Microsystems, Inc. All rights reserved.
*  Use is subject to license terms.
*/

package javax.jdo;

/**
 * The JDOPermission class is for operations that are reserved for JDO 
 * implementations and should not be called by other code.  A
 * JDOPermission is a <em>named permission</em> and has no
 * actions.  There are two names currently defined.
 * <P>
 * The following table
 * provides a summary description of what each named permission allows,
 * and discusses the risks of granting code the permission.
 * <P>
 *
 * <table border=1 cellpadding=5>
 * <tr>
 * <th>Permission Target Name</th>
 * <th>What the Permission Allows</th>
 * <th>Risks of Allowing this Permission</th>
 * </tr>
 *
 * <tr>
 *   <td>setStateManager</td>
 *   <td>This allows setting the StateManager for an instance of PersistenceCapable. 
 *   The StateMananger
 *   has unlimited access to get and set persistent and transactional fields of
 *   the PersistenceCapable instance.</td>
 *   <td>This is dangerous in that information (possibly confidential) 
 *   normally unavailable would be accessible to malicious code.</td>
 *</tr>
 *
 *<tr>
 *   <td>getMetadata</td>
 *   <td>This allows getting metadata for any PersistenceCapable class that has
 *   registered with JDOImplHelper.</td>
 *   <td>This is dangerous in that metadata information (possibly confidential) 
 *   normally unavailable would be accessible to malicious code.</td>
 * </tr>
 *
 * </table>
 *
 * @see java.security.Permission
 * @see java.security.BasicPermission
 * @see javax.jdo.JDOImplHelper
 * @see javax.jdo.PersistenceCapable
 */
public final
class JDOPermission extends java.security.BasicPermission {
    
    /** Construct a new instance of JDOPermission,
     * with default "getMetadata".
     */    
    public JDOPermission () {
        super ("getMetadata");
    }

    /**
     * Constructs a JDOPermission with the specified name.
     *
     * @param name the name of the JDOPermission
     */
    public JDOPermission(String name) {
	super(name);
    }

    /**
     * Constructs a JDOPermission with the specified name and actions.
     * The actions should be null; they are ignored. This
     * constructor exists for use by the <code>Policy</code> object
     * to instantiate new Permission objects.
     *
     * @param name the name of the JDOPermission
     * @param actions should be null.
     */
    public JDOPermission(String name, String actions) {
	super(name, actions);
    }

}


