//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by OpenDlg.rc
//
#define IDD_DIALOG                      101
#define IDC_FAVORITES                   1001
#define IDC_RECENT                      1002
#define IDC_WINDOWS                     1003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
