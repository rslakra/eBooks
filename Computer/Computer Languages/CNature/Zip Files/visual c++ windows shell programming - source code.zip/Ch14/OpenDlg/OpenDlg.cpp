/*****************************************************************
*
*  Project.....:  Dialog Customization
*  Application.:  OPENDLG.exe
*  Module......:  OPENDLG.cpp
*  Description.:  Application main module
*  Compiler....:  MS Visual C++
*  Written by..:  D. Esposito
*  Environment.:  Windows 9x/NT
*
******************************************************************/

/*---------------------------------------------------------------*/
//                        PRAGMA section
/*---------------------------------------------------------------*/
// Force the linker to add the following libraries.
#ifdef _MSC_VER

#pragma comment(lib, "kernel32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "comdlg32.lib")

#endif

/*---------------------------------------------------------------*/
//                        INCLUDE section
/*---------------------------------------------------------------*/
#include "OpenDlg.h"
#include <commctrl.h>
#include <commdlg.h>
#include <shellapi.h> 
#include <dlgs.h>
#include <shlobj.h>
#include "resource.h"

/*---------------------------------------------------------------*/
//                        GLOBAL section
/*---------------------------------------------------------------*/
// Data
HICON g_hIconLarge;
HICON g_hIconSmall;
HHOOK g_hHook;

// Functions
void OnInitDialog(HWND);
void OnOK(HWND);
void Goto(HWND, WORD);
void InitNewButtons(HWND);
void SetTooltips(HWND);
BOOL GetOpenFileNameEx(LPOPENFILENAME);
void ModifyStyle(HWND);

// Callbacks
BOOL CALLBACK APP_DlgProc(HWND, UINT, WPARAM, LPARAM);
UINT CALLBACK OpenDlgExProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK HookProc(int, WPARAM, LPARAM);

/*---------------------------------------------------------------*/
// Procedure....: WinMain()
// Description..: Entry point in any Windows program
// Input........: HINSTANCE, HINSTANCE, LPSTR, int
// Output.......: int
/*---------------------------------------------------------------*/
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevious, 
                     LPTSTR lpsz, int iCmd)
{
   // Save global data
   g_hIconLarge = static_cast<HICON>(
              LoadImage(hInstance, "APP_ICON", IMAGE_ICON,
              GetSystemMetrics(SM_CXICON), GetSystemMetrics(SM_CXICON), 0));
   g_hIconSmall = static_cast<HICON>(
              LoadImage(hInstance, "APP_ICON", IMAGE_ICON,
              GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CXSMICON), 0));

   // Enable common controls
   INITCOMMONCONTROLSEX iccex;
   iccex.dwSize = sizeof(INITCOMMONCONTROLSEX);
   iccex.dwICC = ICC_WIN95_CLASSES;
   InitCommonControlsEx(&iccex);

   // Run main dialog
   BOOL b = DialogBox(hInstance, "DLG_MAIN", NULL, APP_DlgProc);

   // Exit
   DestroyIcon(g_hIconLarge);
   DestroyIcon(g_hIconSmall);
   return b;
}


/*---------------------------------------------------------------*/
// Procedure....: APP_DlgProc()
// Description..: Responds to all messages sent to the dialog
// Input........: HWND, UINT, WPARAM, LPARAM
// Output.......: BOOL
/*---------------------------------------------------------------*/
BOOL CALLBACK APP_DlgProc(HWND hDlg, UINT uiMsg, WPARAM wParam, LPARAM lParam)
{
   switch(uiMsg)
   {
   case WM_INITDIALOG:
      OnInitDialog(hDlg);
      break;

   case WM_COMMAND:
      switch(wParam)
      {
      case IDOK:
         OnOK(hDlg);
         return FALSE;

      case IDCANCEL:
         EndDialog(hDlg, FALSE);
         return FALSE;
      }
      break;
   }

   return FALSE;
}


/*****************************************************************
*
*  Internals:
*    - OnOK()
*    - OnInitDialog()
*
******************************************************************/

/*---------------------------------------------------------------*/
// Procedure...: OnOK()
// Description.: Do something
// INPUT.......: HWND
// OUTPUT......: void
/*---------------------------------------------------------------*/
void OnOK(HWND hDlg)
{
	// Local data
	OPENFILENAME ofn;
	TCHAR szFile[MAX_PATH] = {0};
	
	ZeroMemory(&ofn, sizeof(OPENFILENAME));
	ofn.lStructSize = sizeof(OPENFILENAME);
	ofn.hwndOwner = hDlg;
	ofn.lpstrFile = szFile;
	ofn.nMaxFile = sizeof(szFile);
	ofn.lpstrFilter = "All files\0*.*\0";
	ofn.nFilterIndex = 1;
	ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY;

	if(GetOpenFileNameEx(&ofn))
		MessageBox(hDlg, ofn.lpstrFile, "Open", MB_OK | MB_ICONINFORMATION);
}


/*---------------------------------------------------------------*/
// Procedure...: OnInitDialog()
// Description.: Initialize the dialog
// INPUT.......: HWND
// OUTPUT......: void
/*---------------------------------------------------------------*/
void OnInitDialog(HWND hDlg)
{
   // Set the icons (T/F as to Large/Small icon)
   SendMessage(hDlg, WM_SETICON, FALSE, reinterpret_cast<LPARAM>(g_hIconSmall));
   SendMessage(hDlg, WM_SETICON, TRUE, reinterpret_cast<LPARAM>(g_hIconLarge));
}


void Goto(HWND hDlg, WORD wID)
{
   TCHAR szDir[MAX_PATH] = {0};
   LPITEMIDLIST pidl;

   // Retrieve the path to jump to
   if(wID == IDC_WINDOWS)
      GetWindowsDirectory(szDir, MAX_PATH);
   else
   {
      if(wID == IDC_FAVORITES)
         SHGetSpecialFolderLocation(hDlg, CSIDL_FAVORITES, &pidl);
      else
         if(wID == IDC_RECENT)
            SHGetSpecialFolderLocation(hDlg, CSIDL_RECENT, &pidl);

      SHGetPathFromIDList(pidl, szDir);
   }

   // Set a new path in the file name edit box
   HWND hdlgParent = GetParent(hDlg);
   SetDlgItemText(hdlgParent, edt1, szDir);
   SendMessage(hdlgParent, WM_COMMAND, IDOK, 0);
   SetDlgItemText(hdlgParent, edt1, "");
}


void InitNewButtons(HWND hDlg)
{
   SHFILEINFO sfi;
   LPITEMIDLIST pidl = NULL;

   // Assign an icon to the Favorites button
   SHGetSpecialFolderLocation(hDlg, CSIDL_FAVORITES, &pidl);
   SHGetFileInfo(reinterpret_cast<LPTSTR>(pidl),
                            0, &sfi, sizeof(SHFILEINFO), SHGFI_PIDL | SHGFI_ICON);
   SendDlgItemMessage(hDlg, IDC_FAVORITES, BM_SETIMAGE, IMAGE_ICON,
                                             reinterpret_cast<LPARAM>(sfi.hIcon));

   // Assign an icon to the Recent Documents button
   SHGetSpecialFolderLocation(hDlg, CSIDL_PERSONAL, &pidl);
   SHGetFileInfo(reinterpret_cast<LPTSTR>(pidl),
                            0, &sfi, sizeof(SHFILEINFO), SHGFI_PIDL | SHGFI_ICON);
   SendDlgItemMessage(hDlg, IDC_RECENT, BM_SETIMAGE, IMAGE_ICON,
                                             reinterpret_cast<LPARAM>(sfi.hIcon));

   // Assign an icon to the Windows button
   SendDlgItemMessage(hDlg, IDC_WINDOWS, BM_SETIMAGE, IMAGE_ICON,
                           reinterpret_cast<LPARAM>(LoadIcon(NULL, IDI_WINLOGO)));

   // Set tooltips for each button
   SetTooltips(hDlg);
}


void SetTooltips(HWND hDlg)
{
   // Creates a new tooltip control
   HWND hwndTT = CreateWindow(TOOLTIPS_CLASS, NULL, TTS_ALWAYSTIP, CW_USEDEFAULT,
                              CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, hDlg,
                              NULL, GetModuleHandle(NULL), NULL);

   // Define the required tools, one for each button
   // Look in Favorites
   TOOLINFO ti;
   ZeroMemory(&ti, sizeof(TOOLINFO));
   ti.cbSize = sizeof(TOOLINFO);
   ti.uFlags = TTF_IDISHWND | TTF_SUBCLASS;
   ti.hwnd = hDlg;
   ti.uId = reinterpret_cast<UINT>(GetDlgItem(hDlg, IDC_FAVORITES));
   ti.lpszText = __TEXT("Look in Favorites");
   SendMessage(hwndTT, TTM_ADDTOOL, 0, reinterpret_cast<LPARAM>(&ti));

   // Look in Recent Documents
   ZeroMemory(&ti, sizeof(TOOLINFO));
   ti.cbSize = sizeof(TOOLINFO);
   ti.uFlags = TTF_IDISHWND | TTF_SUBCLASS;
   ti.hwnd = hDlg;
   ti.uId = reinterpret_cast<UINT>(GetDlgItem(hDlg, IDC_RECENT));
   ti.lpszText = __TEXT("Look in Recent documents");
   SendMessage(hwndTT, TTM_ADDTOOL, 0, reinterpret_cast<LPARAM>(&ti));

   // Look in Windows
   ZeroMemory(&ti, sizeof(TOOLINFO));
   ti.cbSize = sizeof(TOOLINFO);
   ti.uFlags = TTF_IDISHWND | TTF_SUBCLASS;
   ti.hwnd = hDlg;
   ti.uId = reinterpret_cast<UINT>(GetDlgItem(hDlg, IDC_WINDOWS));
   ti.lpszText = __TEXT("Look in Windows");
   SendMessage(hwndTT, TTM_ADDTOOL, 0, reinterpret_cast<LPARAM>(&ti));
}


BOOL GetOpenFileNameEx(LPOPENFILENAME lpofn)
{
   // If the template is custom, revert to the standard dialog
   if(lpofn->lpTemplateName)
      return GetOpenFileName(lpofn);

   // Adjust the OPENFILENAME structure
   lpofn->hInstance = GetModuleHandle(NULL);
   lpofn->lpTemplateName = MAKEINTRESOURCE(IDD_DIALOG);
   lpofn->lpfnHook = OpenDlgExProc;
   lpofn->Flags |= OFN_EXPLORER | OFN_ENABLEHOOK | OFN_ENABLETEMPLATE;

   // Set a keyboard hook on the current thread
   g_hHook = SetWindowsHookEx(WH_KEYBOARD, HookProc, NULL, GetCurrentThreadId());

   BOOL b = GetOpenFileName(lpofn);

   // Remove the hook
   UnhookWindowsHookEx(g_hHook);
   return b;
}


UINT CALLBACK OpenDlgExProc(HWND hDlg, UINT uiMsg, WPARAM wParam, LPARAM lParam)
{
   LPOFNOTIFY pN = NULL;
   switch(uiMsg)
   {
   case WM_NOTIFY:
	  pN = reinterpret_cast<LPOFNOTIFY>(lParam);
      if(pN->hdr.code == CDN_INITDONE)
         InitNewButtons(hDlg);
      if(pN->hdr.code == CDN_FOLDERCHANGE)
         ModifyStyle(hDlg);
      break;

   case WM_COMMAND:
      switch(LOWORD(wParam))
      {
      case IDC_FAVORITES:
      case IDC_RECENT:
      case IDC_WINDOWS:
         Goto(hDlg, LOWORD(wParam));
         break;
      }
      break;
   }
   return 0;
}


void ModifyStyle(HWND hDlg)
{
   // Get the files' listview handle.
   HWND hwndDefView = GetDlgItem(GetParent(hDlg), lst2);
   HWND hwndListView = GetDlgItem(hwndDefView, 1);

   // Turn off the bit
   DWORD dwStyle = GetWindowLong(hwndListView, GWL_STYLE);
   dwStyle &= ~LVS_EDITLABELS;
   SetWindowLong(hwndListView, GWL_STYLE, dwStyle);
}


LRESULT CALLBACK HookProc(int iCode, WPARAM wParam, LPARAM lParam)
{
   // Eat the DELETE key...
   if(wParam == VK_DELETE)
      return 1;

   // ...otherwise feel free to proceed
   return CallNextHookEx(g_hHook, iCode, wParam, lParam);
}


/*  End of file: OpenDlg.cpp  */
