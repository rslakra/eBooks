/*****************************************************************
*
*  Project.....:  Metafile Viewer
*  Application.:  WMFVIEW.exe
*  Module......:  WMFVIEW.cpp
*  Description.:  Application main module
*  Compiler....:  MS Visual C++
*  Written by..:  D. Esposito
*  Environment.:  Windows 9x/NT
*
******************************************************************/

/*---------------------------------------------------------------*/
//                        PRAGMA section
/*---------------------------------------------------------------*/
// Force the linker to add the following libraries.
#ifdef _MSC_VER

#pragma comment(lib, "kernel32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "shlwapi.lib")
#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "comdlg32.lib")

#endif

/*---------------------------------------------------------------*/
//                        INCLUDE section
/*---------------------------------------------------------------*/
#include "WMFView.h"
#include <commctrl.h>
#include <commdlg.h>
#include <shellapi.h> 
#include <shlwapi.h>
#include "resource.h"

/*---------------------------------------------------------------*/
//                        GLOBAL section
/*---------------------------------------------------------------*/
// Structures
// Needed to handle 16-bit placeable metafiles
#pragma pack(push)
#pragma pack(2)
typedef struct
{
   DWORD       dwKey;
   WORD        hmf;
   SMALL_RECT  bbox;
   WORD        wInch;
   DWORD       dwReserved;
   WORD        wCheckSum;
} APMHEADER, *LPAPMHEADER;
#pragma pack(pop)

// Data
HICON g_hIconLarge;
HICON g_hIconSmall;
TCHAR g_szCurFile[MAX_PATH];

// Functions
void OnInitDialog(HWND, LPARAM);
void OnOK(HWND);
void DisplayMetaFile(HWND, LPTSTR);
HENHMETAFILE GetMetaFileHandle(LPTSTR);
void PrintMetaFile(LPTSTR);
void SaveMetaFile(LPTSTR);
void SaveToEMF(HENHMETAFILE, LPTSTR);
void SaveToWMF(HENHMETAFILE, LPTSTR);
void OnOpen(HWND);
void OnPrint(HWND);
void OnSave(HWND);
void RefreshUI(HWND, LPTSTR);
void ParseCommandLine(HWND, LPTSTR);
HWND AnotherInstanceRunning();
void HandleFileDrop(HWND, HDROP);

// Callbacks
BOOL CALLBACK APP_DlgProc(HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK CheckRunningApps(HWND, LPARAM);


/*---------------------------------------------------------------*/
// Procedure....: WinMain()
// Description..: Entry point in any Windows program
// Input........: HINSTANCE, HINSTANCE, LPSTR, int
// Output.......: int
/*---------------------------------------------------------------*/
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevious, 
                     LPTSTR lpsz, int iCmd)
{
   // Is there another running instance of this?
   HWND hwnd = AnotherInstanceRunning();
   if(IsWindow(hwnd))
   {
      // Bring the previous window to the top
      if(IsIconic(hwnd))
         ShowWindow(hwnd, SW_RESTORE);
      SetForegroundWindow(hwnd);

      // Parse "this" command line but send messages to the prev. window
      ParseCommandLine(hwnd, lpsz);

      // Now we can exit
      return 1;
   }

   // Save global data
   g_hIconLarge = static_cast<HICON>(
              LoadImage(hInstance, "APP_ICON", IMAGE_ICON,
              GetSystemMetrics(SM_CXICON), GetSystemMetrics(SM_CXICON), 0));
   g_hIconSmall = static_cast<HICON>(
              LoadImage(hInstance, "APP_ICON", IMAGE_ICON,
              GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CXSMICON), 0));
   lstrcpy(g_szCurFile, "");

   // Enable common controls
   INITCOMMONCONTROLSEX iccex;
   iccex.dwSize = sizeof(INITCOMMONCONTROLSEX);
   iccex.dwICC = ICC_WIN95_CLASSES;
   InitCommonControlsEx(&iccex);

   // Run main dialog
   BOOL b = DialogBoxParam(hInstance, "DLG_MAIN", NULL, APP_DlgProc, reinterpret_cast<LPARAM>(lpsz));

   // Exit
   DestroyIcon(g_hIconLarge);
   DestroyIcon(g_hIconSmall);
   return b;
}


/*---------------------------------------------------------------*/
// Procedure....: APP_DlgProc()
// Description..: Responds to all messages sent to the dialog
// Input........: HWND, UINT, WPARAM, LPARAM
// Output.......: BOOL
/*---------------------------------------------------------------*/
BOOL CALLBACK APP_DlgProc(HWND hDlg, UINT uiMsg, WPARAM wParam, LPARAM lParam)
{
   switch(uiMsg)
   {
   case WM_INITDIALOG:
      OnInitDialog(hDlg, lParam);
      break;

   case WM_DROPFILES:
      HandleFileDrop(hDlg, reinterpret_cast<HDROP>(wParam));
      break;

   case WM_EX_DISPLAYMETA:
      DisplayMetaFile(GetDlgItem(hDlg, IDC_METAFILE), reinterpret_cast<LPTSTR>(lParam));
      RefreshUI(hDlg, reinterpret_cast<LPTSTR>(lParam));
      break;

   case WM_EX_PRINTMETA:
      PrintMetaFile(reinterpret_cast<LPTSTR>(lParam));
      break;

   case WM_EX_SAVEMETA:
      SaveMetaFile(reinterpret_cast<LPTSTR>(lParam));
      break;

   case WM_COMMAND:
      switch(wParam)
      {
      case ID_FILE_OPEN:
         OnOpen(hDlg);
         return FALSE;

      case ID_FILE_PRINT:
         OnPrint(hDlg);
         return FALSE;

      case ID_FILE_SAVEAS:
         OnSave(hDlg);
         return FALSE;

      case ID_FILE_EXIT:
      case IDCANCEL:
         EndDialog(hDlg, FALSE);
         return FALSE;
      }
      break;
   }

   return FALSE;
}


/*****************************************************************
*
*  Internals:
*    - OnOK()
*    - OnInitDialog()
*
******************************************************************/

/*---------------------------------------------------------------*/
// Procedure...: OnOK()
// Description.: Do something
// INPUT.......: HWND
// OUTPUT......: void
/*---------------------------------------------------------------*/
void OnOK(HWND hDlg)
{
   return;
}


/*---------------------------------------------------------------*/
// Procedure...: OnInitDialog()
// Description.: Initialize the dialog
// INPUT.......: HWND
// OUTPUT......: void
/*---------------------------------------------------------------*/
void OnInitDialog(HWND hDlg, LPARAM lParam)
{
   // Set the icons (T/F as to Large/Small icon)
   SendMessage(hDlg, WM_SETICON, FALSE, reinterpret_cast<LPARAM>(g_hIconSmall));
   SendMessage(hDlg, WM_SETICON, TRUE, reinterpret_cast<LPARAM>(g_hIconLarge));

   if(lstrlen(reinterpret_cast<LPTSTR>(lParam)))
      ParseCommandLine(hDlg, reinterpret_cast<LPTSTR>(lParam));
}


void DisplayMetaFile(HWND hwndMeta, LPTSTR szFile)
{
   // Get the metafile handle
   HENHMETAFILE hemf = GetMetaFileHandle(szFile);
   if(hemf == NULL)
   {
      MessageBox(NULL, __TEXT("Unable to handle the file."), szFile, MB_OK | MB_ICONSTOP);
      return;
   }

   // Free the old file and display the new one
   HENHMETAFILE hemfOld = reinterpret_cast<HENHMETAFILE>(
                SendMessage(hwndMeta, STM_GETIMAGE, IMAGE_ENHMETAFILE, 0));
   if(hemfOld)
      DeleteEnhMetaFile(hemfOld);

   // hwndMeta is a Picture control
   SendMessage(hwndMeta, STM_SETIMAGE, IMAGE_ENHMETAFILE, reinterpret_cast<LPARAM>(hemf));
   lstrcpy(g_szCurFile, szFile);
}


HENHMETAFILE GetMetaFileHandle(LPTSTR szFile)
{
   DWORD dwSize = 0;
   LPBYTE pb = NULL;

   // Try to read it as an EMF
   HENHMETAFILE hEMF = GetEnhMetaFile(szFile);
   if(hEMF)
      return hEMF;

   // Try to read it as a WMF
   HMETAFILE hWMF = GetMetaFile(szFile);
   if(hWMF)
   {
      dwSize = GetMetaFileBitsEx(hWMF, 0, NULL);
      if(dwSize == 0)
      {
         DeleteMetaFile(hWMF);
         return NULL;
      }

      // Allocate enough memory
      pb = new BYTE[dwSize];
      if(pb == NULL)
      {
         DeleteMetaFile(hWMF);
         return NULL;
      }

      // Get the metafile bits
      dwSize = GetMetaFileBitsEx(hWMF, dwSize, pb);
      if(dwSize == 0)
      {
         delete [] pb;
         DeleteMetaFile(hWMF);
         return NULL;
      }

      // Convert to EMF
      hEMF = SetWinMetaFileBits(dwSize, pb, NULL, NULL);

      // Clean up
      DeleteMetaFile(hWMF);
      delete [] pb;
      return hEMF;
   }

   // Try to handle the input as a placeable metafile
   HANDLE hFile = CreateFile(szFile, GENERIC_READ, 0, NULL,
                               OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
   if(hFile == INVALID_HANDLE_VALUE)
      return NULL;

   // Read the file to a buffer
   dwSize = GetFileSize(hFile, NULL);
   pb = new BYTE[dwSize];
   ReadFile(hFile, pb, dwSize, &dwSize, NULL);
   CloseHandle(hFile);

   // Check to see if it is a placeable metafile
   if((reinterpret_cast<LPAPMHEADER>(pb))->dwKey != 0x9ac6cdd7l)
   {
      // Don't know how to handle this...
      delete [] pb;
      return NULL;
   }

   // Create an enhanced metafile from the bits
   hEMF = SetWinMetaFileBits(dwSize, &(pb[sizeof(APMHEADER)]), NULL, NULL);

   delete [] pb;
   return hEMF;
}


void PrintMetaFile(LPTSTR szFile)
{
   // Get an EMF handle
   HENHMETAFILE hEMF = GetMetaFileHandle(szFile);
   if(hEMF == NULL)
      return;

   // Get a printer DC
   PRINTDLG pdlg;
   ZeroMemory(&pdlg, sizeof(PRINTDLG));
   pdlg.lStructSize = sizeof(PRINTDLG);
   pdlg.Flags = PD_RETURNDC;

   HDC hDC = NULL;
   if(PrintDlg(&pdlg))
      hDC = pdlg.hDC;
   else
      return;

   // Prepare document printing
   DOCINFO di;
   ZeroMemory(&di, sizeof(DOCINFO));
   di.cbSize = sizeof(DOCINFO);
   di.lpszDocName = "Printing EMF";

   // Start printing
   StartDoc(hDC, &di);
   StartPage(hDC);

   // Scale to fit the entire printed page
   RECT rc;
   SetRect(&rc, 0, 0, GetDeviceCaps(hDC, HORZRES), GetDeviceCaps(hDC, VERTRES));
   PlayEnhMetaFile(hDC, hEMF, &rc);

   // Clean up
   EndPage(hDC);
   EndDoc(hDC);
   DeleteDC(hDC);
   DeleteEnhMetaFile(hEMF);
}


void SaveMetaFile(LPTSTR szFile)
{
   TCHAR szOutputFile[MAX_PATH] = {0};
   HENHMETAFILE hEMF = GetMetaFileHandle(szFile);
   if(hEMF == NULL)
      return;

   // Determine the output format
   lstrcpy(szOutputFile, szFile);
   strlwr(szFile);
   if(strstr(szFile, ".emf"))
   {
      PathRenameExtension(szOutputFile, ".wmf");
      SaveToWMF(hEMF, szOutputFile);
   }
   else if(strstr(szFile, ".wmf"))
   {
      PathRenameExtension(szOutputFile, ".emf");
      SaveToEMF(hEMF, szOutputFile);
   }

   DeleteEnhMetaFile(hEMF);
}


void SaveToEMF(HENHMETAFILE hEMF, LPTSTR szFile)
{
   // Get memory to store the EMF bits
   DWORD dwSize = GetEnhMetaFileBits(hEMF, 0, NULL);
   LPBYTE pb = new BYTE[dwSize];

   // Get the EMF bits
   GetEnhMetaFileBits(hEMF, dwSize, pb);

   // Save to file
   HANDLE hFile = CreateFile(szFile, GENERIC_WRITE,
                         0, NULL, CREATE_NEW, FILE_ATTRIBUTE_NORMAL, NULL);
   if(hFile == INVALID_HANDLE_VALUE)
   {
      UINT rc = MessageBox(GetFocus(), "File exists. Overwrite?",
                                       szFile, MB_ICONQUESTION | MB_YESNO);
      if(rc == IDYES)
         hFile = CreateFile(szFile, GENERIC_WRITE,
                      0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
      else
      {
         delete [] pb;
         return;
      }
   }

   DWORD dwBytes;
   WriteFile(hFile, pb, dwSize, &dwBytes, NULL);
   CloseHandle(hFile);
   delete [] pb;
}


void SaveToWMF(HENHMETAFILE hEMF, LPTSTR szFile)
{
   // Get memory to store the WMF bits
   HDC hDC = GetDC(NULL);
   DWORD dwSize = GetWinMetaFileBits(hEMF, 0, NULL, MM_ANISOTROPIC, hDC);
   LPBYTE pb = new BYTE[dwSize];

   // Get the WMF bits from the EMF handle
   GetWinMetaFileBits(hEMF, dwSize, pb, MM_ANISOTROPIC, hDC);
   ReleaseDC(NULL, hDC);

   // Save to file
   HANDLE hFile = CreateFile(szFile, GENERIC_WRITE,
                         0, NULL, CREATE_NEW, FILE_ATTRIBUTE_NORMAL, NULL);
   if(hFile == INVALID_HANDLE_VALUE)
   {
      UINT rc = MessageBox(GetFocus(), "File exists. Overwrite?",
                                         szFile, MB_ICONQUESTION|MB_YESNO);
      if(rc == IDYES)
         hFile = CreateFile(szFile, GENERIC_WRITE,
                      0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
      else
      {
         delete [] pb;
         return;
      }
   }

   DWORD dwBytes;
   WriteFile(hFile, pb, dwSize, &dwBytes, NULL);
   CloseHandle(hFile);
   delete [] pb;
}


void OnOpen(HWND hDlg)
{
	TCHAR szFile[MAX_PATH] = {0};

	OPENFILENAME ofn;
	ZeroMemory(&ofn, sizeof(OPENFILENAME));
	ofn.lStructSize = sizeof(OPENFILENAME);
	ofn.lpstrFilter = "Metafiles\0*.?mf\0WMF\0*.wmf\0Enhanced\0*.emf\0All Files\0*.*\0";
	ofn.nMaxFile = MAX_PATH;
	ofn.lpstrFile = szFile;
	if(!GetOpenFileName(&ofn))
		return;
	else
	{
		HWND hwndMeta = GetDlgItem(hDlg, IDC_METAFILE);
		DisplayMetaFile(hwndMeta, ofn.lpstrFile);
		RefreshUI(hDlg, ofn.lpstrFile);
	}
}


void OnPrint(HWND hDlg)
{
	if(lstrlen(g_szCurFile))
		PrintMetaFile(g_szCurFile);
	else
		Msg("There's no metafile currently opened.");
}


void OnSave(HWND hDlg)
{
	TCHAR s[1024] = {0};
	TCHAR szOutputFile[MAX_PATH] = {0};
	
	if(!lstrlen(g_szCurFile))
	{
		Msg("There's no metafile currently opened.");
		return;
	}

	// Ask for user's confirmation
	lstrcpy(szOutputFile, g_szCurFile);
	if(strstr(g_szCurFile, ".emf"))
		PathRenameExtension(szOutputFile, ".wmf");
	else if(strstr(g_szCurFile, ".wmf"))
		PathRenameExtension(szOutputFile, ".emf");

	wsprintf(s, "You're about to convert %s to %s.\nAre you really sure?",
		g_szCurFile, szOutputFile);
	UINT rc = MessageBox(hDlg, s, APPTITLE, MB_ICONQUESTION | MB_YESNO);

	// Proceed...
	if(rc == IDYES)
		SaveMetaFile(g_szCurFile);
}


void RefreshUI(HWND hWnd, LPTSTR szFile)
{
   TCHAR szCaption[MAX_PATH] = {0};

   // Refresh the caption bar
   wsprintf(szCaption, "%s - %s", APPTITLE, szFile);
   SetWindowText(hWnd, szCaption);
}


void ParseCommandLine(HWND hwnd, LPTSTR pszCmdLine)
{
   if(!lstrlen(pszCmdLine))
      return;

   // Get the first 2 (+ 1) chars from the command line (it's the switch)
   TCHAR pszSwitch[2] = {0};
   lstrcpyn(pszSwitch, pszCmdLine, 3);
   LPTSTR psz = pszCmdLine + lstrlen(pszSwitch) + 1;

   // Resolve any case by sending a custom message
   if(!lstrcmpi(pszSwitch, "/p"))
      SendMessage(hwnd, WM_EX_PRINTMETA, 0, reinterpret_cast<LPARAM>(psz));
   else if(!lstrcmpi(pszSwitch, "/s"))
      SendMessage(hwnd, WM_EX_SAVEMETA, 0, reinterpret_cast<LPARAM>(psz));
   else
      SendMessage(hwnd, WM_EX_DISPLAYMETA, 0, reinterpret_cast<LPARAM>(pszCmdLine));
}


HWND AnotherInstanceRunning()
{
   HWND hwndFound = NULL;
   EnumWindows(CheckRunningApps, reinterpret_cast<LPARAM>(&hwndFound));

   // hwndFound will get the handle of the matching window, if any
   return hwndFound;
}


BOOL CALLBACK CheckRunningApps(HWND hwnd, LPARAM lParam)
{
   TCHAR szClass[MAX_PATH] = {0};
   GetClassName(hwnd, szClass, MAX_PATH);
   if(!lstrcmpi(szClass, "#32770"))
   {
      TCHAR s[MAX_PATH] = {0};
      TCHAR szTitle[MAX_PATH] = {0};
      GetWindowText(hwnd, szTitle, MAX_PATH);

      lstrcpyn(s, szTitle, 1 + lstrlen(APPTITLE));
      if(!lstrcmpi(s, APPTITLE))
      {
         // Uses the buffer pointed by lParam to return the HWND
         HWND* lphwnd = reinterpret_cast<HWND*>(lParam);
         *lphwnd = hwnd;
         return FALSE;
      }
   }

   return TRUE;
}


void HandleFileDrop(HWND hDlg, HDROP hDrop)
{
   TCHAR szFileName[MAX_PATH] = {0};

   // Since we are an SDI app, it doesn't make sense to receive
   //  more than one file, so extract only the first
   DragQueryFile(hDrop, 0, szFileName, MAX_PATH);
   SendMessage(hDlg, WM_EX_DISPLAYMETA, 0, reinterpret_cast<LPARAM>(szFileName));
   DragFinish(hDrop);
}


/*  End of file: WMFView.cpp  */
