//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by WMFView.rc
//
#define IDR_MENU                        101
#define IDI_ENHMETA                     102
#define IDI_WINMETA                     103
#define IDC_METAFILE                    1000
#define ID_FILE_OPEN                    40001
#define ID_FILE_EXIT                    40002
#define ID_FILE_SAVEAS                  40003
#define ID_FILE_PRINT                   40004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
