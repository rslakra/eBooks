/*****************************************************************
*
*  Project.....:  Metafile Viewer
*  Application.:  WMFVIEW.exe
*  Module......:  WMFVIEW.h
*  Description.:  Application main header
*  Compiler....:  MS Visual C++ 
*  Written by..:  D. Esposito
*  Environment.:  Windows 9x/NT
*
*******************************/

// Prevent multiple inclusions
#define WIN32_LEAN_AND_MEAN
#define STRICT

#ifndef _APP_DEFS_
#define _APP_DEFS_

/*---------------------------------------------------------------*/
//                        INCLUDE section
/*---------------------------------------------------------------*/
#include <windows.h>
#include <windowsx.h>
#include "SPBUtils.h" 

const LPTSTR APPTITLE = "Metafile Viewer";
const int WM_EX_DISPLAYMETA = WM_APP + 1;
const int WM_EX_PRINTMETA   = WM_APP + 2;
const int WM_EX_SAVEMETA    = WM_APP + 3;

#endif   // _APP_DEFS_


/*  End of file: WMFView.h  */
