Set fs = CreateObject("Scripting.FileSystemObject")
Set dc = fs.Drives
For Each d in dc
   s = s & d.DriveLetter & " - " 
   If d.DriveType = Remote Then            
     n = d.ShareName
   ElseIf d.IsReady Then            
     n = d.VolumeName
     n = n + vbCrLf + "Free: " + FormatNumber(d.FreeSpace/1024, 0) + " KB"
     n = n + vbCrLf
   Else
     n = n + vbCrLf
   End If
   s = s & n & vbCrLf
Next

WScript.Echo s
