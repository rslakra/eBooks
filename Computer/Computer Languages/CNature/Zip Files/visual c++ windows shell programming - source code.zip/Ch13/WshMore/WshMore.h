/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Mon Nov 16 14:11:20 1998
 */
/* Compiler settings for C:\Windows\Desktop\WshMore\WshMore.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __WshMore_h__
#define __WshMore_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IWshFun_FWD_DEFINED__
#define __IWshFun_FWD_DEFINED__
typedef interface IWshFun IWshFun;
#endif 	/* __IWshFun_FWD_DEFINED__ */


#ifndef __WshFun_FWD_DEFINED__
#define __WshFun_FWD_DEFINED__

#ifdef __cplusplus
typedef class WshFun WshFun;
#else
typedef struct WshFun WshFun;
#endif /* __cplusplus */

#endif 	/* __WshFun_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IWshFun_INTERFACE_DEFINED__
#define __IWshFun_INTERFACE_DEFINED__

/* interface IWshFun */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IWshFun;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("E882458D-7D46-11D2-9DAF-00104B4C822A")
    IWshFun : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CopyText( 
            /* [in] */ BSTR bText) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE PasteText( 
            /* [retval][out] */ BSTR __RPC_FAR *pbRetVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE FormatDrive( 
            /* [in] */ int iDrive) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE BrowseForIcon( 
            /* [in] */ BSTR bFile,
            /* [retval][out] */ BSTR __RPC_FAR *pbRetVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE FindFirstKey( 
            /* [in] */ long hk,
            /* [in] */ BSTR bRegPath,
            /* [retval][out] */ BSTR __RPC_FAR *pbRetVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE FindNextKey( 
            /* [retval][out] */ BSTR __RPC_FAR *pbRetVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE FindFirstValue( 
            /* [in] */ long hk,
            /* [in] */ BSTR bRegPath,
            /* [retval][out] */ BSTR __RPC_FAR *pbRetVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE FindNextValue( 
            /* [retval][out] */ BSTR __RPC_FAR *pbRetVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE AddExecuteHook( 
            /* [in] */ BSTR bShortcut,
            /* [in] */ BSTR bExeFile) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IWshFunVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IWshFun __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IWshFun __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IWshFun __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IWshFun __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IWshFun __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IWshFun __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IWshFun __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CopyText )( 
            IWshFun __RPC_FAR * This,
            /* [in] */ BSTR bText);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *PasteText )( 
            IWshFun __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbRetVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *FormatDrive )( 
            IWshFun __RPC_FAR * This,
            /* [in] */ int iDrive);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *BrowseForIcon )( 
            IWshFun __RPC_FAR * This,
            /* [in] */ BSTR bFile,
            /* [retval][out] */ BSTR __RPC_FAR *pbRetVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *FindFirstKey )( 
            IWshFun __RPC_FAR * This,
            /* [in] */ long hk,
            /* [in] */ BSTR bRegPath,
            /* [retval][out] */ BSTR __RPC_FAR *pbRetVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *FindNextKey )( 
            IWshFun __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbRetVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *FindFirstValue )( 
            IWshFun __RPC_FAR * This,
            /* [in] */ long hk,
            /* [in] */ BSTR bRegPath,
            /* [retval][out] */ BSTR __RPC_FAR *pbRetVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *FindNextValue )( 
            IWshFun __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbRetVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *AddExecuteHook )( 
            IWshFun __RPC_FAR * This,
            /* [in] */ BSTR bShortcut,
            /* [in] */ BSTR bExeFile);
        
        END_INTERFACE
    } IWshFunVtbl;

    interface IWshFun
    {
        CONST_VTBL struct IWshFunVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IWshFun_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IWshFun_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IWshFun_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IWshFun_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IWshFun_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IWshFun_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IWshFun_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IWshFun_CopyText(This,bText)	\
    (This)->lpVtbl -> CopyText(This,bText)

#define IWshFun_PasteText(This,pbRetVal)	\
    (This)->lpVtbl -> PasteText(This,pbRetVal)

#define IWshFun_FormatDrive(This,iDrive)	\
    (This)->lpVtbl -> FormatDrive(This,iDrive)

#define IWshFun_BrowseForIcon(This,bFile,pbRetVal)	\
    (This)->lpVtbl -> BrowseForIcon(This,bFile,pbRetVal)

#define IWshFun_FindFirstKey(This,hk,bRegPath,pbRetVal)	\
    (This)->lpVtbl -> FindFirstKey(This,hk,bRegPath,pbRetVal)

#define IWshFun_FindNextKey(This,pbRetVal)	\
    (This)->lpVtbl -> FindNextKey(This,pbRetVal)

#define IWshFun_FindFirstValue(This,hk,bRegPath,pbRetVal)	\
    (This)->lpVtbl -> FindFirstValue(This,hk,bRegPath,pbRetVal)

#define IWshFun_FindNextValue(This,pbRetVal)	\
    (This)->lpVtbl -> FindNextValue(This,pbRetVal)

#define IWshFun_AddExecuteHook(This,bShortcut,bExeFile)	\
    (This)->lpVtbl -> AddExecuteHook(This,bShortcut,bExeFile)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IWshFun_CopyText_Proxy( 
    IWshFun __RPC_FAR * This,
    /* [in] */ BSTR bText);


void __RPC_STUB IWshFun_CopyText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IWshFun_PasteText_Proxy( 
    IWshFun __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pbRetVal);


void __RPC_STUB IWshFun_PasteText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IWshFun_FormatDrive_Proxy( 
    IWshFun __RPC_FAR * This,
    /* [in] */ int iDrive);


void __RPC_STUB IWshFun_FormatDrive_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IWshFun_BrowseForIcon_Proxy( 
    IWshFun __RPC_FAR * This,
    /* [in] */ BSTR bFile,
    /* [retval][out] */ BSTR __RPC_FAR *pbRetVal);


void __RPC_STUB IWshFun_BrowseForIcon_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IWshFun_FindFirstKey_Proxy( 
    IWshFun __RPC_FAR * This,
    /* [in] */ long hk,
    /* [in] */ BSTR bRegPath,
    /* [retval][out] */ BSTR __RPC_FAR *pbRetVal);


void __RPC_STUB IWshFun_FindFirstKey_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IWshFun_FindNextKey_Proxy( 
    IWshFun __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pbRetVal);


void __RPC_STUB IWshFun_FindNextKey_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IWshFun_FindFirstValue_Proxy( 
    IWshFun __RPC_FAR * This,
    /* [in] */ long hk,
    /* [in] */ BSTR bRegPath,
    /* [retval][out] */ BSTR __RPC_FAR *pbRetVal);


void __RPC_STUB IWshFun_FindFirstValue_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IWshFun_FindNextValue_Proxy( 
    IWshFun __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pbRetVal);


void __RPC_STUB IWshFun_FindNextValue_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IWshFun_AddExecuteHook_Proxy( 
    IWshFun __RPC_FAR * This,
    /* [in] */ BSTR bShortcut,
    /* [in] */ BSTR bExeFile);


void __RPC_STUB IWshFun_AddExecuteHook_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IWshFun_INTERFACE_DEFINED__ */



#ifndef __WSHMORELib_LIBRARY_DEFINED__
#define __WSHMORELib_LIBRARY_DEFINED__

/* library WSHMORELib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_WSHMORELib;

EXTERN_C const CLSID CLSID_WshFun;

#ifdef __cplusplus

class DECLSPEC_UUID("E882458E-7D46-11D2-9DAF-00104B4C822A")
WshFun;
#endif
#endif /* __WSHMORELib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
