
WshMoreps.dll: dlldata.obj WshMore_p.obj WshMore_i.obj
	link /dll /out:WshMoreps.dll /def:WshMoreps.def /entry:DllMain dlldata.obj WshMore_p.obj WshMore_i.obj \
		kernel32.lib rpcndr.lib rpcns4.lib rpcrt4.lib oleaut32.lib uuid.lib \

.c.obj:
	cl /c /Ox /DWIN32 /D_WIN32_WINNT=0x0400 /DREGISTER_PROXY_DLL \
		$<

clean:
	@del WshMoreps.dll
	@del WshMoreps.lib
	@del WshMoreps.exp
	@del dlldata.obj
	@del WshMore_p.obj
	@del WshMore_i.obj
