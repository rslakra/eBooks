// WshFun.h : Declaration of the CWshFun

#ifndef __WSHFUN_H_
#define __WSHFUN_H_

#include "resource.h"       // main symbols

const int MAXBUFSIZE = 32768;
const LPTSTR EXECUTEHOOK = __TEXT("c:\\showhook.ini");

/////////////////////////////////////////////////////////////////////////////
// CWshFun
class ATL_NO_VTABLE CWshFun : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CWshFun, &CLSID_WshFun>,
	public IDispatchImpl<IWshFun, &IID_IWshFun, &LIBID_WSHMORELib>
{
public:
	CWshFun()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_WSHFUN)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CWshFun)
	COM_INTERFACE_ENTRY(IWshFun)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// IWshFun
public:
	STDMETHOD(AddExecuteHook)(/*[in]*/ BSTR bShortcut, /*[in]*/ BSTR bExeFile);
	STDMETHOD(FindNextValue)(/*[out, retval]*/ BSTR* pbRetVal);
	STDMETHOD(FindFirstValue)(/*[in]*/ long hk, /*[in]*/ BSTR bRegPath, /*[out, retval]*/ BSTR* pbRetVal);
	STDMETHOD(FindNextKey)(/*[out, retval]*/ BSTR* pbRetVal);
	STDMETHOD(FindFirstKey)(/*[in]*/ long hk, /*[in]*/ BSTR bRegPath, /*[out, retval]*/ BSTR* pbRetVal);
	STDMETHOD(BrowseForIcon)(/*[in]*/ BSTR bFile, /*[out, retval]*/ BSTR* pbRetVal);
	STDMETHOD(FormatDrive)(/*[in]*/ int iDrive);
	STDMETHOD(PasteText)(/*[out, retval]*/ BSTR* pbRetVal);
	STDMETHOD(CopyText)(/*[in]*/ BSTR bText);
private:
	DWORD GetNthValue(long hk, BSTR bRegPath, int iIndex, BSTR* pbRetVal);
	DWORD GetNthKey(long hk, BSTR bRegPath, int iIndex, BSTR* pbRetVal);
};

#endif //__WSHFUN_H_
