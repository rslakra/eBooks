// WshFun.cpp : Implementation of CWshFun
#include "stdafx.h"
#include "WshMore.h"
#include "WshFun.h"
#include "shhelper.h"

extern "C" int WINAPI SHFormatDrive(long, long, long, long);

DWORD g_dwIndex = 0;
BSTR g_bRegPath;
LONG g_hk;

/////////////////////////////////////////////////////////////////////////////
// CWshFun

STDMETHODIMP CWshFun::CopyText(BSTR bText)
{
   USES_CONVERSION;
   TCHAR pszText[MAXBUFSIZE] = {0};
   lstrcpy(pszText, OLE2T(bText));

   HANDLE hData = GlobalAlloc(GHND, MAXBUFSIZE);
   LPTSTR psz = static_cast<LPTSTR>(GlobalLock(hData));
   lstrcpyn(psz, pszText, MAXBUFSIZE);
   GlobalUnlock(hData);

   OpenClipboard(NULL);
   SetClipboardData(CF_TEXT, hData);
   CloseClipboard();
   return S_OK;
}

STDMETHODIMP CWshFun::PasteText(BSTR *pbRetVal)
{
   USES_CONVERSION;

   // Get a memory handle from the clipboard
   OpenClipboard(NULL);
   HANDLE hData = GetClipboardData(CF_TEXT);
   CloseClipboard();

   // Extract the content
   LPTSTR psz = static_cast<LPTSTR>(GlobalLock(hData));
   TCHAR pszText[MAXBUFSIZE] = {0};
   lstrcpyn(pszText, psz, MAXBUFSIZE);
   GlobalUnlock(hData);

   // Returns a BSTR
   *pbRetVal = T2BSTR(pszText);
   return S_OK;
}

STDMETHODIMP CWshFun::FormatDrive(int iDrive)
{
   int irc = SHFormatDrive(0, iDrive, 0, 0);
   return (irc < 0 ? S_OK : E_FAIL);
}


STDMETHODIMP CWshFun::BrowseForIcon(BSTR bFile, BSTR *pbRetVal)
{
   USES_CONVERSION;
   TCHAR pszFile[MAX_PATH] = {0};
   lstrcpy(pszFile, OLE2T(bFile));

   HICON hIcon;
   int iIndex = SHBrowseForIcon(pszFile, &hIcon);
   if(iIndex >= 0)
   {
      TCHAR szBuf[MAX_PATH + 10] = {0};
      wsprintf(szBuf, __TEXT("%s,%d"), pszFile, iIndex);

      *pbRetVal = T2BSTR(szBuf);
      return S_OK;
   }
   return S_FALSE;
}

STDMETHODIMP CWshFun::FindFirstKey(long hk, BSTR bRegPath, BSTR *pbRetVal)
{
   g_dwIndex = 0;
   g_bRegPath = bRegPath;
   g_hk = hk;

   DWORD rc = GetNthKey(hk, bRegPath, g_dwIndex, pbRetVal);
   return (rc == ERROR_SUCCESS ? S_OK : S_FALSE);
}

STDMETHODIMP CWshFun::FindNextKey(BSTR *pbRetVal)
{
   g_dwIndex++;
   DWORD rc = GetNthKey(g_hk, g_bRegPath, g_dwIndex, pbRetVal);
   return (rc == ERROR_SUCCESS ? S_OK : S_FALSE);
}

STDMETHODIMP CWshFun::FindFirstValue(long hk, BSTR bRegPath, BSTR *pbRetVal)
{
   g_dwIndex = 0;
   g_bRegPath = bRegPath;
   g_hk = hk;

   DWORD rc = GetNthValue(hk, bRegPath, g_dwIndex, pbRetVal);
   return (rc == ERROR_SUCCESS ? S_OK : S_FALSE);
}

STDMETHODIMP CWshFun::FindNextValue(BSTR *pbRetVal)
{
   g_dwIndex++;
   DWORD rc = GetNthValue(g_hk, g_bRegPath, g_dwIndex, pbRetVal);
   return (rc == ERROR_SUCCESS ? S_OK : S_FALSE);
}

DWORD CWshFun::GetNthKey(long hk, BSTR bRegPath, int iIndex, BSTR *pbRetVal)
{
   USES_CONVERSION;
   TCHAR szRegPath[MAX_PATH] = {0};
   lstrcpy(szRegPath, OLE2T(bRegPath));

   HKEY hkey;
   RegOpenKeyEx(reinterpret_cast<HKEY>(hk), szRegPath, 0, KEY_ALL_ACCESS, &hkey);

   TCHAR szKey[MAX_PATH] = {0};
   DWORD dwSize = MAX_PATH;
   DWORD rc = SHEnumKeyEx(hkey, iIndex, szKey, &dwSize);
   if(rc == ERROR_SUCCESS)
      *pbRetVal = T2BSTR(szKey);
   RegCloseKey(hkey);
   return rc;
}


DWORD CWshFun::GetNthValue(long hk, BSTR bRegPath, int iIndex, BSTR *pbRetVal)
{
   USES_CONVERSION;
   TCHAR szRegPath[MAX_PATH] = {0};
   lstrcpy(szRegPath, OLE2T(bRegPath));

   HKEY hkey;
   RegOpenKeyEx(reinterpret_cast<HKEY>(hk), szRegPath, 0, KEY_ALL_ACCESS, &hkey);

   DWORD dwType = 0;
   TCHAR szKey[MAX_PATH] = {0};
   DWORD dwSize = MAX_PATH;
   DWORD rc = SHEnumValue(hkey, iIndex, szKey, &dwSize, &dwType, NULL, 0);
   if(rc == ERROR_SUCCESS)
      *pbRetVal = T2BSTR(szKey);
   RegCloseKey(hkey);
   return rc;
}

STDMETHODIMP CWshFun::AddExecuteHook(BSTR bShortcut, BSTR bExeFile)
{
   USES_CONVERSION;
   TCHAR szEntry[MAX_PATH] = {0};
   lstrcpy(szEntry, OLE2T(bShortcut));
   TCHAR szFile[MAX_PATH] = {0};
   lstrcpy(szFile, OLE2T(bExeFile));

   WritePrivateProfileString(__TEXT("goldlist"), szEntry, (lstrlen(szFile) ? szFile : NULL), EXECUTEHOOK);
   return S_OK;
}
