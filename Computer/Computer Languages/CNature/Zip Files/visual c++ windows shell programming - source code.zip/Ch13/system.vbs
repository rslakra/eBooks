' SYSTEM.VBS
' Reads version and registration information from the registry
'-------------------------------------------------------------

' Create the WshShell object
Set s = WScript.CreateObject("WScript.Shell")

' Registry Path constants
RP_SYSTEM = "HKLM\System\CurrentControlSet\Control\ProductOptions\"
RP_PRTYPE = "ProductType"
RP_NTVERS = "HKLM\Software\Microsoft\Windows NT\CurrentVersion\"
RP_WINVER = "HKLM\Software\Microsoft\Windows\CurrentVersion\"

' System name constants
WIN_NTWORK = "Windows NT Workstation"
WIN_NTSERV = "Windows NT Server"

' Read about the product type
On Error Resume Next      ' Because the key doesn't exist under Win9x
sProdType = ""
sProdType = s.RegRead(RP_SYSTEM & RP_PRTYPE)

' Determine the OS version
select case sProdType
   case "WinNT"
      sRegPathVer = RP_NTVERS
      sBuf0 = WIN_NTWORK
      sBuf1 = s.RegRead(RP_NTVERS & "CurrentVersion") + "."
      sBuf2 = s.RegRead(RP_NTVERS & "CurrentBuildNumber")
      sBuf3 = s.RegRead(RP_NTVERS & "CSDVersion")
   case "ServerNT", "LanManNT"
      sRegPathVer = RP_NTVERS
      sBuf0 = "Windows NT Server"
      sBuf1 = s.RegRead(RP_NTVERS & "CurrentVersion")
      sBuf2 = s.RegRead(RP_NTVERS & "CurrentBuildNumber")
      sBuf3 = s.RegRead(RP_NTVERS & "CSDVersion")
   case ""
      sRegPathVer = RP_WINVER
      sBuf0 = s.RegRead(RP_WINVER & "Version")
      sBuf2 = s.RegRead(RP_WINVER & "VersionNumber")
      sBuf3 = "-----------------------"
end select

' Read registration info
sBuf4 = s.RegRead(sRegPathVer & "RegisteredOwner")
sBuf5 = s.RegRead(sRegPathVer & "RegisteredOrganization")

' Display the result
WScript.Echo sBuf0 + "  " + sBuf1 + sBuf2 + vbCrLf + _
             sBuf3 + vbCrLf + vbCrLf + _
             sBuf4 + vbCrLf + _
             sBuf5

' Close
WScript.Quit
