/*****************************************************************
*
*  Project.....:  Program Executors
*  Application.:  EXECUTE.exe
*  Module......:  EXECUTE.cpp
*  Description.:  Application main module
*  Compiler....:  MS Visual C++
*  Written by..:  D. Esposito
*  Environment.:  Windows 9x/NT
*
******************************************************************/

/*---------------------------------------------------------------*/
//                        PRAGMA section
/*---------------------------------------------------------------*/
// Force the linker to add the following libraries.
#ifdef _MSC_VER

#pragma comment(lib, "kernel32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "comdlg32.lib")

#endif

/*---------------------------------------------------------------*/
//                        INCLUDE section
/*---------------------------------------------------------------*/
#include "Execute.h"
#include <commctrl.h>
#include <commdlg.h>
#include <shellapi.h>
#include <shlobj.h>
#include "resource.h"

/*---------------------------------------------------------------*/
//                        GLOBAL section
/*---------------------------------------------------------------*/
// Data
HICON g_hIconLarge;
HICON g_hIconSmall;

// Functions
void OnInitDialog(HWND);
void OnOK(HWND);

void OnBrowse(HWND);
void OnShellExecute(HWND);
void OnShellExecuteEx(HWND);
void OnFindExec(HWND);

HINSTANCE FindExecutableEx(LPCTSTR, LPCTSTR, LPTSTR);

// Callbacks
BOOL CALLBACK APP_DlgProc(HWND, UINT, WPARAM, LPARAM);


/*---------------------------------------------------------------*/
// Procedure....: WinMain()
// Description..: Entry point in any Windows program
// Input........: HINSTANCE, HINSTANCE, LPSTR, int
// Output.......: int
/*---------------------------------------------------------------*/
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevious, 
                     LPTSTR lpsz, int iCmd)
{
   // Save global data
   g_hIconLarge = static_cast<HICON>(
              LoadImage(hInstance, "APP_ICON", IMAGE_ICON,
              GetSystemMetrics(SM_CXICON), GetSystemMetrics(SM_CXICON), 0));
   g_hIconSmall = static_cast<HICON>(
              LoadImage(hInstance, "APP_ICON", IMAGE_ICON,
              GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CXSMICON), 0));

   // Enable common controls
   INITCOMMONCONTROLSEX iccex;
   iccex.dwSize = sizeof(INITCOMMONCONTROLSEX);
   iccex.dwICC = ICC_WIN95_CLASSES;
   InitCommonControlsEx(&iccex);

   // Run main dialog
   BOOL b = DialogBox(hInstance, "DLG_MAIN", NULL, APP_DlgProc);

   // Exit
   DestroyIcon(g_hIconLarge);
   DestroyIcon(g_hIconSmall);
   return b;
}


/*---------------------------------------------------------------*/
// Procedure....: APP_DlgProc()
// Description..: Responds to all messages sent to the dialog
// Input........: HWND, UINT, WPARAM, LPARAM
// Output.......: BOOL
/*---------------------------------------------------------------*/
BOOL CALLBACK APP_DlgProc(HWND hDlg, UINT uiMsg, WPARAM wParam, LPARAM lParam)
{
   switch(uiMsg)
   {
   case WM_INITDIALOG:
      OnInitDialog(hDlg);
      break;

   case WM_COMMAND:
      switch(wParam)
      {
      case IDC_FIND:
         OnFindExec(hDlg);
         return FALSE;

      case IDC_SHELLEX:
         OnShellExecuteEx(hDlg);
         return FALSE;

      case IDC_SHELL:
         OnShellExecute(hDlg);
         return FALSE;

      case IDC_BROWSE:
         OnBrowse(hDlg);
         return FALSE;

      case IDCANCEL:
         EndDialog(hDlg, FALSE);
         return FALSE;
      }
      break;
   }

   return FALSE;
}


/*****************************************************************
*
*  Internals:
*    - OnOK()
*    - OnInitDialog()
*
******************************************************************/

/*---------------------------------------------------------------*/
// Procedure...: OnOK()
// Description.: Do something
// INPUT.......: HWND
// OUTPUT......: void
/*---------------------------------------------------------------*/
void OnOK(HWND hDlg)
{
   return;
}


/*---------------------------------------------------------------*/
// Procedure...: OnInitDialog()
// Description.: Initialize the dialog
// INPUT.......: HWND
// OUTPUT......: void
/*---------------------------------------------------------------*/
void OnInitDialog(HWND hDlg)
{
   // Set the icons (T/F as to Large/Small icon)
   SendMessage(hDlg, WM_SETICON, FALSE, reinterpret_cast<LPARAM>(g_hIconSmall));
   SendMessage(hDlg, WM_SETICON, TRUE, reinterpret_cast<LPARAM>(g_hIconLarge));
}


void OnBrowse(HWND hDlg)
{
   TCHAR szFile[MAX_PATH] = {0};
   TCHAR szWinDir[MAX_PATH] = {0};
   GetWindowsDirectory(szWinDir, MAX_PATH);

   OPENFILENAME ofn;
   ZeroMemory(&ofn, sizeof(OPENFILENAME));
   ofn.lStructSize = sizeof(OPENFILENAME);
   ofn.lpstrFilter = __TEXT("All files\0*.*\0");
   ofn.nMaxFile = MAX_PATH;
   ofn.lpstrInitialDir = szWinDir;
   ofn.lpstrFile = szFile;
   if(!GetOpenFileName(&ofn))
      return;
   else
      SetDlgItemText(hDlg, IDC_FILENAME, ofn.lpstrFile);
}


void OnShellExecute(HWND hDlg)
{
   TCHAR sFile[MAX_PATH] = {0};
   TCHAR sOp[MAX_PATH] = {0};
   TCHAR sRC[MAX_PATH] = {0};

   GetDlgItemText(hDlg, IDC_FILENAME, sFile, MAX_PATH);
   GetDlgItemText(hDlg, IDC_OPERATION, sOp, MAX_PATH);
   HINSTANCE h = ShellExecute(NULL, sOp, sFile, NULL, NULL, SW_SHOW);

   wsprintf(sRC, __TEXT("%ld"), h);
   SetDlgItemText(hDlg, IDC_RETVAL, sRC);
   return;
}


void OnShellExecuteEx(HWND hDlg)
{
   TCHAR sFile[MAX_PATH] = {0};
   TCHAR sOp[MAX_PATH] = {0};
   TCHAR sRC[MAX_PATH] = {0};

   GetDlgItemText(hDlg, IDC_FILENAME, sFile, MAX_PATH);
   GetDlgItemText(hDlg, IDC_OPERATION, sOp, MAX_PATH);

   SHELLEXECUTEINFO sei;
   ZeroMemory(&sei, sizeof(SHELLEXECUTEINFO));
   sei.cbSize = sizeof(SHELLEXECUTEINFO);
   sei.lpFile = sFile;
   sei.nShow = SW_SHOW;
   sei.fMask = SEE_MASK_DOENVSUBST | SEE_MASK_INVOKEIDLIST;
   sei.lpVerb = sOp;
   DWORD rc = ShellExecuteEx(&sei);

   wsprintf(sRC, __TEXT("%ld"), rc);
   SetDlgItemText(hDlg, IDC_RETVAL, sRC);
   return;
}


void OnFindExec(HWND hDlg)
{
   TCHAR sFile[MAX_PATH] = {0};
   TCHAR sPrg[MAX_PATH] = {0};
   TCHAR sRC[MAX_PATH] = {0};

   GetDlgItemText(hDlg, IDC_FILENAME, sFile, MAX_PATH);
   HINSTANCE h = FindExecutableEx(sFile, NULL, sPrg);

   wsprintf(sRC, __TEXT("%ld"), h);
   SetDlgItemText(hDlg, IDC_RETVAL, sRC);
   SetDlgItemText(hDlg, IDC_EXE, sPrg);
   return;
}


HINSTANCE FindExecutableEx(LPCTSTR lpFile, LPCTSTR lpDirectory, LPTSTR lpResult)
{
   // These _MAX constants defined in stdlib.h
   TCHAR drive[_MAX_DRIVE];
   TCHAR dir[_MAX_DIR];
   TCHAR dir1[_MAX_DIR];
   TCHAR file[_MAX_FNAME];
   TCHAR ext[_MAX_EXT];

   HINSTANCE hi = FindExecutable(lpFile, lpDirectory, lpResult);
   lpResult[lstrlen(lpResult)] = 32;

   _splitpath(lpResult, drive, dir, file, ext);

   // Search for : in the directory name, and truncate the string
   LPTSTR p = strchr(dir, ':');
   if(p != NULL)
   {
      --p;
      dir[p - dir] = 0;

      // Now split what remains again to get file and extension
      _splitpath(dir, NULL, dir1, file, ext);
      p = strchr(ext, 32);
      ext[p - ext] = 0;
      _makepath(lpResult, drive, dir1, file, ext);
   }

   return hi;
}

/*  End of file: Execute.cpp  */
