//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Execute.rc
//
#define IDC_OPERATION                   1000
#define IDC_FILENAME                    1001
#define IDC_BROWSE                      1002
#define IDC_SHELLEX                     1003
#define IDC_SHELL                       1004
#define IDC_FIND                        1005
#define IDC_EXE                         1006
#define IDC_RETVAL                      1007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
