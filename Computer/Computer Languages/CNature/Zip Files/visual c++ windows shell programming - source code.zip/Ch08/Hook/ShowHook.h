// ShowHook.h : Declaration of the CShowHook

#ifndef __SHOWHOOK_H_
#define __SHOWHOOK_H_

#include "resource.h"       // main symbols
#include "comdef.h"
#include "IShellExecuteHookImpl.h"

/////////////////////////////////////////////////////////////////////////////
// CShowHook
class ATL_NO_VTABLE CShowHook : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CShowHook, &CLSID_ShowHook>,
    public IShellExecuteHookImpl,
    public IDispatchImpl<IShowHook, &IID_IShowHook, &LIBID_HOOKLib>
{
public:
	CShowHook()
	{
	}

STDMETHOD(Execute)(LPSHELLEXECUTEINFO lpsei);

DECLARE_REGISTRY_RESOURCEID(IDR_SHOWHOOK)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CShowHook)
	COM_INTERFACE_ENTRY(IShowHook)
	COM_INTERFACE_ENTRY(IDispatch)
    COM_INTERFACE_ENTRY(IShellExecuteHook)
END_COM_MAP()

// IShowHook
public:
};

#endif //__SHOWHOOK_H_
