// ShowHook.cpp : Implementation of CShowHook
#include "stdafx.h"
#include "Hook.h"
#include "ShowHook.h"

/////////////////////////////////////////////////////////////////////////////
// CShowHook

HRESULT CShowHook::Execute(LPSHELLEXECUTEINFO lpsei)
{
   // Trace the program/file opened
   TCHAR szTime[50] = {0};
   GetTimeFormat(LOCALE_SYSTEM_DEFAULT, 0, NULL, NULL, szTime, 50);

   TCHAR szText[1024] = {0};
   wsprintf(szText, __TEXT("%s: %s  at %s"),
                                     lpsei->lpVerb, lpsei->lpFile, szTime);

   FILE *f;
   f = fopen(__TEXT("c:\\ShowHook.txt"), __TEXT("a+t"));
   fseek(f, 0, SEEK_END);
   fprintf(f, __TEXT("%s: %s  at %s\n\r"),
                                     lpsei->lpVerb, lpsei->lpFile, szTime);
   fclose(f);

   // Check the shortcuts list and run programs
   TCHAR szFileName[MAX_PATH] = {0};
   GetPrivateProfileString(__TEXT("GoldList"), lpsei->lpFile,
                     "", szFileName, MAX_PATH, __TEXT("c:\\showhook.ini"));
   if(lstrlen(szFileName))
   {
      lpsei->hInstApp =
                 reinterpret_cast<HINSTANCE>(WinExec(szFileName, SW_SHOW));
      return S_OK;
   }

   // Prevent from doing anything if the name contains DEBUG
   strlwr(const_cast<LPTSTR>(lpsei->lpFile));
   if(strstr(lpsei->lpFile, __TEXT("debug")))
   {
      lpsei->hInstApp = reinterpret_cast<HINSTANCE>(42);
      return S_OK;
   }

   // Let it continue...
   return S_FALSE;
}
