/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Thu Nov 05 10:01:03 1998
 */
/* Compiler settings for C:\Windows\Desktop\Hook\Hook.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_IShowHook = {0xFC3CF1DA,0x7494,0x11D2,{0x9D,0xAF,0x00,0x10,0x4B,0x4C,0x82,0x2A}};


const IID LIBID_HOOKLib = {0xFC3CF1CE,0x7494,0x11D2,{0x9D,0xAF,0x00,0x10,0x4B,0x4C,0x82,0x2A}};


const CLSID CLSID_ShowHook = {0xFC3CF1DB,0x7494,0x11D2,{0x9D,0xAF,0x00,0x10,0x4B,0x4C,0x82,0x2A}};


#ifdef __cplusplus
}
#endif

