
Hookps.dll: dlldata.obj Hook_p.obj Hook_i.obj
	link /dll /out:Hookps.dll /def:Hookps.def /entry:DllMain dlldata.obj Hook_p.obj Hook_i.obj \
		kernel32.lib rpcndr.lib rpcns4.lib rpcrt4.lib oleaut32.lib uuid.lib \

.c.obj:
	cl /c /Ox /DWIN32 /D_WIN32_WINNT=0x0400 /DREGISTER_PROXY_DLL \
		$<

clean:
	@del Hookps.dll
	@del Hookps.lib
	@del Hookps.exp
	@del dlldata.obj
	@del Hook_p.obj
	@del Hook_i.obj
