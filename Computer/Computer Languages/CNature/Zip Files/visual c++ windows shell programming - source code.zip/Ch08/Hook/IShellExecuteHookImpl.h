// IShellExecuteHookImpl.h
//
//////////////////////////////////////////////////////////////////////
#include <AtlCom.h>
#include <ShlObj.h>


class ATL_NO_VTABLE IShellExecuteHookImpl : public IShellExecuteHook
{
public:

   // IUnknown
   STDMETHOD(QueryInterface)(REFIID riid, void** ppvObject) = 0;
   _ATL_DEBUG_ADDREF_RELEASE_IMPL(IShellExecuteHookImpl)

   // IShellExecuteHook
   STDMETHOD(Execute)(LPSHELLEXECUTEINFO lpsei)
   {
      return S_FALSE;
   }
};
