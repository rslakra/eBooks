/*****************************************************************
*
*  Project.....:  System Dialogs
*  Application.:  RUNXXX.exe
*  Module......:  RUNXXX.cpp
*  Description.:  Application main module
*  Compiler....:  MS Visual C++
*  Written by..:  D. Esposito
*  Environment.:  Windows 9x/NT
*
******************************************************************/

/*---------------------------------------------------------------*/
//                        PRAGMA section
/*---------------------------------------------------------------*/
// Force the linker to add the following libraries.
#ifdef _MSC_VER

#pragma comment(lib, "kernel32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "comctl32.lib")

#endif

/*---------------------------------------------------------------*/
//                        INCLUDE section
/*---------------------------------------------------------------*/
#include "RunXXX.h"
#include <commctrl.h>
#include <shellapi.h>
#include "resource.h"

/*---------------------------------------------------------------*/
//                        GLOBAL section
/*---------------------------------------------------------------*/
// Data
HICON g_hIconLarge;
HICON g_hIconSmall;

LPTSTR g_pszStrings [] = {
	"Add New Printer", "rundll32.exe sysdm.cpl,InstallDevice_Rundll printer",
	"Add New Hardware", "control.exe sysdm.cpl,Add New Hardware",
	"Add New Connection", "runDll32 RnaUI.dll,RnaWizard",
	"Add New Modem", "rundll32.exe sysdm.cpl,InstallDevice_Rundll modem",
	"Add New Monitor", "rundll32.exe sysdm.cpl,InstallDevice_Rundll monitor",
	"Internet Options", "rundll32 Inetcpl.cpl,LaunchInternetControlPanel",

	// Replace 'thefile.sys' with something on your system
	"Open As...", "rundll32 shell32.dll,OpenAs_RunDLL c:\\thefile.sys",

	// Replace 'DefaultISP' with something on your system
	"Connect to...", "rundll32 rnaui.dll,RnaDial DefaultISP",
	"Program Menu", "rundll32 appwiz.cpl,ConfigStartMenu"
};

// Functions
void OnInitDialog(HWND);
void OnOK(HWND);
void OnDisplay(HWND);
void RunDll(HWND, LPCTSTR, LPCTSTR, LPCTSTR);
void (__stdcall *pFunc)(HWND, HINSTANCE, LPTSTR, int);

// Callbacks
BOOL CALLBACK APP_DlgProc(HWND, UINT, WPARAM, LPARAM);


/*---------------------------------------------------------------*/
// Procedure....: WinMain()
// Description..: Entry point in any Windows program
// Input........: HINSTANCE, HINSTANCE, LPSTR, int
// Output.......: int
/*---------------------------------------------------------------*/
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevious, 
                     LPTSTR lpsz, int iCmd)
{
   // Save global data
   g_hIconLarge = static_cast<HICON>(
              LoadImage(hInstance, "APP_ICON", IMAGE_ICON,
              GetSystemMetrics(SM_CXICON), GetSystemMetrics(SM_CXICON), 0));
   g_hIconSmall = static_cast<HICON>(
              LoadImage(hInstance, "APP_ICON", IMAGE_ICON,
              GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CXSMICON), 0));

   // Enable common controls
   INITCOMMONCONTROLSEX iccex;
   iccex.dwSize = sizeof(INITCOMMONCONTROLSEX);
   iccex.dwICC = ICC_WIN95_CLASSES;
   InitCommonControlsEx(&iccex);

   // Run main dialog
   BOOL b = DialogBox(hInstance, "DLG_MAIN", NULL, APP_DlgProc);

   // Exit
   DestroyIcon(g_hIconLarge);
   DestroyIcon(g_hIconSmall);
   return b;
}


/*---------------------------------------------------------------*/
// Procedure....: APP_DlgProc()
// Description..: Responds to all messages sent to the dialog
// Input........: HWND, UINT, WPARAM, LPARAM
// Output.......: BOOL
/*---------------------------------------------------------------*/
BOOL CALLBACK APP_DlgProc(HWND hDlg, UINT uiMsg, WPARAM wParam, LPARAM lParam)
{
   switch(uiMsg)
   {
   case WM_INITDIALOG:
      OnInitDialog(hDlg);
      break;

   case WM_COMMAND:
      switch(wParam)
      {
      case IDOK:
         OnOK(hDlg);
         return FALSE;

      case IDC_DISPLAY:
         OnDisplay(hDlg);
         return FALSE;

      case IDCANCEL:
         EndDialog(hDlg, FALSE);
         return FALSE;
      }
      break;
   }

   return FALSE;
}


/*****************************************************************
*
*  Internals:
*    - OnOK()
*    - OnInitDialog()
*
******************************************************************/

/*---------------------------------------------------------------*/
// Procedure...: OnOK()
// Description.: Do something
// INPUT.......: HWND
// OUTPUT......: void
/*---------------------------------------------------------------*/
void OnOK(HWND hDlg)
{
   HWND hwndCbo = GetDlgItem(hDlg, IDC_COMBO);
   int i = ComboBox_GetCurSel(hwndCbo);
   WinExec(g_pszStrings[i * 2 + 1], SW_SHOW);
}


/*---------------------------------------------------------------*/
// Procedure...: OnInitDialog()
// Description.: Initialize the dialog
// INPUT.......: HWND
// OUTPUT......: void
/*---------------------------------------------------------------*/
void OnInitDialog(HWND hDlg)
{
   HWND hwndCbo = GetDlgItem(hDlg, IDC_COMBO);
   for(int i = 0 ; i < (sizeof(g_pszStrings) / 8) ; i++)
      ComboBox_AddString(hwndCbo, g_pszStrings[2 * i]);
   ComboBox_SetCurSel(hwndCbo, 0);
   
   // Set the icons (T/F as to Large/Small icon)
   SendMessage(hDlg, WM_SETICON, FALSE, reinterpret_cast<LPARAM>(g_hIconSmall));
   SendMessage(hDlg, WM_SETICON, TRUE, reinterpret_cast<LPARAM>(g_hIconLarge));
}

void OnDisplay(HWND hDlg)
{
   RunDll(hDlg, "shell32.dll", "Control_RunDLL", "desk.cpl");
}


void RunDll(HWND hwnd, LPCTSTR szDllName, LPCTSTR szFunc, LPCTSTR szCmdLine)
{
   HINSTANCE hLib = NULL;
   hLib = LoadLibrary(szDllName);
   if(hLib == NULL)
      return;

   pFunc = reinterpret_cast<void (__stdcall*)(HWND, HINSTANCE, LPTSTR, int)>(GetProcAddress(hLib, szFunc));
   if(!pFunc == NULL)
      pFunc(hwnd, hLib, const_cast<LPTSTR>(szCmdLine), SW_SHOW);
   FreeLibrary(hLib);
}


/*  End of file: RunXXX.cpp  */
