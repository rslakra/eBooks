//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PrnCmd.rc
//
#define IDC_PA_OPEN                     1000
#define IDC_PA_PROPERTIES               1001
#define IDC_PA_TESTPAGE                 1002
#define IDC_PRINTERNAME                 1003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
