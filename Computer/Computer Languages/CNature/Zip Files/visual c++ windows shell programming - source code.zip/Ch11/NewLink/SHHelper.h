////////////////////////////////////////////////////////////////
//
//   SHHelper.DLL
//   Shell Helper functions - Header
//   shhelper.h
//

#include <windows.h>
#include <windowsx.h>
#include <shellapi.h>
#include <shlobj.h>

extern "C" { INT APIENTRY SHBrowseForIcon(LPCSTR szFileName, HICON FAR* lphIcon); }
