//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by NewLink.rc
//
#define IDB_BITMAP                      101
#define IDC_TARGET                      1004
#define IDC_BROWSETARGET                1005
#define IDC_DESCRIPTION                 1006
#define IDC_LNKFILE                     1007
#define IDC_PATH                        1008
#define IDC_HOTKEY                      1009
#define IDC_CREATE                      1010
#define IDC_BROWSEICON                  1011
#define IDI_ICON                        1012
#define IDC_BROWSEPATH                  1013
#define IDC_CHOOSEICON                  1014
#define IDC_ICONPATH                    1015
#define IDC_ICONINDEX                   1016

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
