/*****************************************************************
*
*  Project.....:  Create Shortcut...
*  Application.:  NEWLINK.exe
*  Module......:  NEWLINK.cpp
*  Description.:  Application main module
*  Compiler....:  MS Visual C++
*  Written by..:  D. Esposito
*  Environment.:  Windows 9x/NT
*
******************************************************************/

/*---------------------------------------------------------------*/
//                        PRAGMA section
/*---------------------------------------------------------------*/
// Force the linker to add the following libraries.
#ifdef _MSC_VER

#pragma comment(lib, "kernel32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "ole32.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "comdlg32.lib")
#pragma comment(lib, "shhelper.lib")

#endif

/*---------------------------------------------------------------*/
//                        INCLUDE section
/*---------------------------------------------------------------*/
#include "NewLink.h"
#include <commctrl.h>
#include <commdlg.h>
#include <shellapi.h>
#include <shlobj.h> 
#include "resource.h"
#include "shhelper.h"

/*---------------------------------------------------------------*/
//                        GLOBAL section
/*---------------------------------------------------------------*/
// Data
HICON g_hIconLarge;
HICON g_hIconSmall;
LPTSTR g_szNewLinkName;

struct SHORTCUTSTRUCT
{
   LPTSTR pszTarget;
   LPTSTR pszDesc;
   WORD wHotKey;
   LPTSTR pszIconPath;
   WORD wIconIndex;
};

typedef SHORTCUTSTRUCT* LPSHORTCUTSTRUCT;

// Functions
void OnInitDialog(HWND);
void OnOK(HWND);
void OnBrowse(HWND, WPARAM);
void OnChooseIcon(HWND);
void DoCreateShortcut(HWND);

HRESULT SHCreateShortcutEx(LPCTSTR, LPSHORTCUTSTRUCT);

// Callbacks
BOOL CALLBACK APP_DlgProc(HWND, UINT, WPARAM, LPARAM);


/*---------------------------------------------------------------*/
// Procedure....: WinMain()
// Description..: Entry point in any Windows program
// Input........: HINSTANCE, HINSTANCE, LPSTR, int
// Output.......: int
/*---------------------------------------------------------------*/
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevious, 
                     LPTSTR lpsz, int iCmd)
{
   // Delete any temporary file created by the shell
   if(lstrlen(lpsz))
      DeleteFile(lpsz);

   // Save global data
   g_hIconLarge = static_cast<HICON>(
              LoadImage(hInstance, "APP_ICON", IMAGE_ICON,
              GetSystemMetrics(SM_CXICON), GetSystemMetrics(SM_CXICON), 0));
   g_hIconSmall = static_cast<HICON>(
              LoadImage(hInstance, "APP_ICON", IMAGE_ICON,
              GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CXSMICON), 0));
   lstrcpy(g_szNewLinkName, lpsz);

   // Enable common controls
   INITCOMMONCONTROLSEX iccex;
   iccex.dwSize = sizeof(INITCOMMONCONTROLSEX);
   iccex.dwICC = ICC_WIN95_CLASSES;
   InitCommonControlsEx(&iccex);

   CoInitialize(NULL);

   // Run main dialog
   BOOL b = DialogBox(hInstance, "DLG_MAIN", NULL, APP_DlgProc);

   CoUninitialize();

   // Exit
   DestroyIcon(g_hIconLarge);
   DestroyIcon(g_hIconSmall);
   return b;
}


/*---------------------------------------------------------------*/
// Procedure....: APP_DlgProc()
// Description..: Responds to all messages sent to the dialog
// Input........: HWND, UINT, WPARAM, LPARAM
// Output.......: BOOL
/*---------------------------------------------------------------*/
BOOL CALLBACK APP_DlgProc(HWND hDlg, UINT uiMsg, WPARAM wParam, LPARAM lParam)
{
   switch(uiMsg)
   {
   case WM_INITDIALOG:
      OnInitDialog(hDlg);
      break;

   case WM_COMMAND:
      switch(wParam)
      {
      case IDC_CREATE:
         DoCreateShortcut(hDlg);
         return FALSE;

      case IDC_BROWSEPATH:
         OnBrowse(hDlg, IDC_PATH);
         return FALSE;

      case IDC_CHOOSEICON:
         OnChooseIcon(hDlg);
         return FALSE;

      case IDC_BROWSETARGET:
         OnBrowse(hDlg, IDC_TARGET);
         return FALSE;

      case IDC_BROWSEICON:
         OnBrowse(hDlg, IDC_ICONPATH);
         return FALSE;

      case IDCANCEL:
         EndDialog(hDlg, FALSE);
         return FALSE;
      }
      break;
   }

   return FALSE;
}


/*****************************************************************
*
*  Internals:
*    - OnOK()
*    - OnInitDialog()
*
******************************************************************/

/*---------------------------------------------------------------*/
// Procedure...: OnOK()
// Description.: Do something
// INPUT.......: HWND
// OUTPUT......: void
/*---------------------------------------------------------------*/
void OnOK(HWND hDlg)
{
   return;
}


/*---------------------------------------------------------------*/
// Procedure...: OnInitDialog()
// Description.: Initialize the dialog
// INPUT.......: HWND
// OUTPUT......: void
/*---------------------------------------------------------------*/
void OnInitDialog(HWND hDlg)
{
   // Set the icons (T/F as to Large/Small icon)
   SendMessage(hDlg, WM_SETICON, FALSE, reinterpret_cast<LPARAM>(g_hIconSmall));
   SendMessage(hDlg, WM_SETICON, TRUE, reinterpret_cast<LPARAM>(g_hIconLarge));

   // Special folders available
   HWND hwndCbo = GetDlgItem(hDlg, IDC_PATH);
   int i = ComboBox_AddString(hwndCbo, "Desktop");
   ComboBox_SetItemData(hwndCbo, i, CSIDL_DESKTOP);
   i = ComboBox_AddString(hwndCbo, "Favorites");
   ComboBox_SetItemData(hwndCbo, i, CSIDL_FAVORITES);
   i = ComboBox_AddString(hwndCbo, "Programs");
   ComboBox_SetItemData(hwndCbo, i, CSIDL_PROGRAMS);
   i = ComboBox_AddString(hwndCbo, "My Documents");
   ComboBox_SetItemData(hwndCbo, i, CSIDL_PERSONAL);
   i = ComboBox_AddString(hwndCbo, "SendTo");
   ComboBox_SetItemData(hwndCbo, i, CSIDL_SENDTO);
   i = ComboBox_AddString(hwndCbo, "Start Menu");
   ComboBox_SetItemData(hwndCbo, i, CSIDL_STARTMENU);
   ComboBox_SetCurSel(hwndCbo, 0);

   // Initialize the hotkey control to prefix everything with Ctrl-Alt
   SendDlgItemMessage(hDlg, IDC_HOTKEY, HKM_SETRULES,
      HKCOMB_NONE | HKCOMB_S | HKCOMB_A | HKCOMB_C, HOTKEYF_CONTROL | HOTKEYF_ALT);

   SetDlgItemText(hDlg, IDC_TARGET, "C:\\");
   SetDlgItemText(hDlg, IDC_ICONINDEX, "0");

   // Handle any file name received through the command line
   if(lstrlen(g_szNewLinkName))
   {
      LPTSTR pszBuf = g_szNewLinkName;
      LPTSTR psz = strrchr(g_szNewLinkName, '\\');
      SetDlgItemText(hDlg, IDC_LNKFILE, ++psz);
      pszBuf[psz - pszBuf] = 0;
      SetDlgItemText(hDlg, IDC_PATH, pszBuf);
   }
   else
      SetDlgItemText(hDlg, IDC_LNKFILE, "NewLink");
}


void OnBrowse(HWND hDlg, WPARAM wItemType)
{
   // Browse for directory only...
   if(wItemType == IDC_PATH)
   {
      LPMALLOC pMalloc = NULL;
      TCHAR szDir[MAX_PATH] = {0};
      LPITEMIDLIST pidl = NULL;

      BROWSEINFO bi;
      ZeroMemory(&bi, sizeof(BROWSEINFO));
      bi.hwndOwner = hDlg;
      bi.lpszTitle = "Choose a folder:";

      pidl = SHBrowseForFolder(&bi);
      SHGetPathFromIDList(pidl, szDir);
      SetDlgItemText(hDlg, IDC_PATH, szDir);

      SHGetMalloc(&pMalloc);
      pMalloc->Free(pidl);
      pMalloc->Release();
      return;
   }

   // Browse for files...
   TCHAR szFile[MAX_PATH] = {0};
   OPENFILENAME ofn;
   ZeroMemory(&ofn, sizeof(OPENFILENAME));
   ofn.lStructSize = sizeof(OPENFILENAME);
   switch(wItemType)
   {
   case IDC_TARGET:
      ofn.lpstrFilter = "All files\0*.*\0";
      break;
   case IDC_ICONPATH:
      ofn.lpstrFilter = "Icons\0*.exe;*.dll;*.ico\0";
      break;	
   }

   TCHAR szWinDir[MAX_PATH] = {0};
   ofn.nMaxFile = MAX_PATH;
   GetWindowsDirectory(szWinDir, MAX_PATH);
   ofn.lpstrInitialDir = szWinDir;
   ofn.lpstrFile = szFile;
   if(!GetOpenFileName(&ofn))
      return;
	
   SetDlgItemText(hDlg, wItemType, ofn.lpstrFile);
	
   // Show the first icon by default
   HICON hIcon = ExtractIcon(GetModuleHandle(NULL), ofn.lpstrFile, 0);
   SendDlgItemMessage(hDlg, IDI_ICON, STM_SETICON, reinterpret_cast<WPARAM>(hIcon), 0);
}


void OnChooseIcon(HWND hDlg)
{
   TCHAR szFileName[MAX_PATH] = {0};
   GetDlgItemText(hDlg, IDC_ICONPATH, szFileName, MAX_PATH);

   HICON hIcon;
   int iIconIndex = SHBrowseForIcon(szFileName, &hIcon);
   if(iIconIndex >= 0)
   {
      SetDlgItemText(hDlg, IDC_ICONPATH, szFileName);
      SetDlgItemInt(hDlg, IDC_ICONINDEX, iIconIndex, TRUE);
      SendDlgItemMessage(hDlg, IDI_ICON, STM_SETICON, reinterpret_cast<WPARAM>(hIcon), 0);
   }
}


void DoCreateShortcut(HWND hDlg)
{
   TCHAR szTarget[MAX_PATH] = {0};
   TCHAR szDesc[MAX_PATH] = {0};

   // Get the hotkey
   SHORTCUTSTRUCT ss;
   ss.wHotKey = static_cast<WORD>(SendDlgItemMessage(hDlg, IDC_HOTKEY, HKM_GETHOTKEY, 0, 0));

   // Get target and description
   GetDlgItemText(hDlg, IDC_TARGET, szTarget, MAX_PATH);
   GetDlgItemText( hDlg, IDC_DESCRIPTION, szDesc, MAX_PATH );		
   ss.pszTarget = szTarget;
   ss.pszDesc = szDesc;

   // Get the icon
   TCHAR szIcon[MAX_PATH] = {0};
   GetDlgItemText(hDlg, IDC_ICONPATH, szIcon, MAX_PATH);
   ss.pszIconPath = szIcon;
   ss.wIconIndex = 0;

   // Determine shortcut file name
   // Get the target folder & final backslash
   HWND hwndCbo = GetDlgItem(hDlg, IDC_PATH);
   int i = ComboBox_GetCurSel(hwndCbo);
   DWORD nFolder = ComboBox_GetItemData(hwndCbo, i);

   TCHAR szPath[MAX_PATH]= {0};   
   if(nFolder)
      SHGetSpecialFolderPath(hDlg, szPath, nFolder, FALSE);
   else
      GetDlgItemText(hDlg, IDC_PATH, szPath, MAX_PATH);
   if(szPath[lstrlen(szPath) - 1] != '\\')
      lstrcat(szPath, "\\");

   TCHAR szLnkFile[MAX_PATH] = {0};
   GetDlgItemText(hDlg, IDC_LNKFILE, szLnkFile, MAX_PATH);
   lstrcat(szPath, szLnkFile);
   lstrcat(szPath, ".lnk");

   // Create...
   SHCreateShortcutEx(szPath, &ss);

// Where is this supposed to go, if anywhere?
// SetDlgItemText(hDlg, IDC_SHORTCUT, szPath);
} 


HRESULT SHCreateShortcutEx(LPCTSTR szLnkFile, LPSHORTCUTSTRUCT lpss)
{
   WCHAR wszLnkFile[MAX_PATH] = {0};
   IShellLink* pShellLink = NULL;
   IPersistFile* pPF = NULL;

   // Validate SHORTCUTSTRUCT pointer
   if(lpss == NULL)
      return E_FAIL;

   // Create the COM server assuming CoInitialize() has already been called
   HRESULT hr = CoCreateInstance(CLSID_ShellLink, NULL,
                                 CLSCTX_INPROC_SERVER, IID_IShellLink,
                                 reinterpret_cast<LPVOID*>(&pShellLink));
   if(FAILED(hr))
      return hr;

   // Set attributes
   pShellLink->SetPath(lpss->pszTarget);
   pShellLink->SetDescription(lpss->pszDesc);
   pShellLink->SetHotkey(lpss->wHotKey);
   pShellLink->SetIconLocation(lpss->pszIconPath, lpss->wIconIndex);

   // Get the IPersistFile interface to save
   hr = pShellLink->QueryInterface(IID_IPersistFile, reinterpret_cast<LPVOID*>(&pPF));
   if(FAILED(hr))
   {
      pShellLink->Release();
      return hr;
   }

   // Save to a LNK file (Unicode name)
   MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, szLnkFile, -1, wszLnkFile, MAX_PATH);
   hr = pPF->Save(wszLnkFile, TRUE);

   // Clean up
   pPF->Release();
   pShellLink->Release();
   return hr;
}

/*  End of file: NewLink.cpp  */
