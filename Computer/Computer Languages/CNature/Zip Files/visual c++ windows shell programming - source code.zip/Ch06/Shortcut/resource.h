//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Shortcut.rc
//
#define IDC_VIEW                        1000
#define IDC_SHORTCUT                    1001
#define IDC_BROWSE                      1002
#define IDC_RESOLVE                     1003
#define IDC_TARGET                      1004
#define IDC_BROWSETARGET                1005
#define IDC_DESCRIPTION                 1006
#define IDC_LNKFILE                     1007
#define IDC_SPECIAL                     1008
#define IDC_HOTKEY                      1009
#define IDC_CREATE                      1010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
