/*****************************************************************
*
*  Project.....:  Shortcut Manager
*  Application.:  SHORTCUT.exe
*  Module......:  SHORTCUT.cpp
*  Description.:  Application main module
*  Compiler....:  MS Visual C++
*  Written by..:  D. Esposito
*  Environment.:  Windows 9x/NT
*
******************************************************************/

/*---------------------------------------------------------------*/
//                        PRAGMA section
/*---------------------------------------------------------------*/
// Force the linker to add the following libraries.
#ifdef _MSC_VER

#pragma comment(lib, "kernel32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "comdlg32.lib")
#pragma comment(lib, "ole32.lib")

#endif

/*---------------------------------------------------------------*/
//                        INCLUDE section
/*---------------------------------------------------------------*/
#include "Shortcut.h"
#include <commctrl.h>
#include <commdlg.h>
#include <shellapi.h>
#include <shlobj.h>
#include "resource.h"

/*---------------------------------------------------------------*/
//                        GLOBAL section
/*---------------------------------------------------------------*/
// Data
HICON g_hIconLarge;
HICON g_hIconSmall;

struct SHORTCUTSTRUCT
{
   LPTSTR pszTarget;
   LPTSTR pszDesc;
   WORD wHotKey;
   LPTSTR pszIconPath;
   WORD wIconIndex;
};

typedef SHORTCUTSTRUCT* LPSHORTCUTSTRUCT;

// Functions
void OnInitDialog(HWND);
void OnOK(HWND);
void OnBrowse(HWND, WPARAM);
void DoCreateShortcut(HWND);
void DoResolveShortcut(HWND, LPTSTR);

HRESULT SHCreateShortcutEx(LPCTSTR, LPSHORTCUTSTRUCT);
HRESULT SHResolveShortcut(LPCTSTR, LPSHORTCUTSTRUCT);
void MakeReportView(HWND, LPTSTR*, int);
void AddStringToReportView(HWND, LPTSTR, int);
void HotkeyToString(WORD, LPTSTR);
void HandleFileDrop(HWND, HDROP);


// Callbacks
BOOL CALLBACK APP_DlgProc(HWND, UINT, WPARAM, LPARAM);


/*---------------------------------------------------------------*/
// Procedure....: WinMain()
// Description..: Entry point in any Windows program
// Input........: HINSTANCE, HINSTANCE, LPSTR, int
// Output.......: int
/*---------------------------------------------------------------*/
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevious, 
                     LPTSTR lpsz, int iCmd)
{
   // Save global data
   g_hIconLarge = static_cast<HICON>(
              LoadImage(hInstance, "APP_ICON", IMAGE_ICON,
              GetSystemMetrics(SM_CXICON), GetSystemMetrics(SM_CXICON), 0));
   g_hIconSmall = static_cast<HICON>(
              LoadImage(hInstance, "APP_ICON", IMAGE_ICON,
              GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CXSMICON), 0));

   // Enable common controls
   INITCOMMONCONTROLSEX iccex;
   iccex.dwSize = sizeof(INITCOMMONCONTROLSEX);
   iccex.dwICC = ICC_WIN95_CLASSES;
   InitCommonControlsEx(&iccex);

   CoInitialize(NULL);

   // Run main dialog
   BOOL b = DialogBox(hInstance, "DLG_MAIN", NULL, APP_DlgProc);

   CoUninitialize();

   // Exit
   DestroyIcon(g_hIconLarge);
   DestroyIcon(g_hIconSmall);
   return b;
}


/*---------------------------------------------------------------*/
// Procedure....: APP_DlgProc()
// Description..: Responds to all messages sent to the dialog
// Input........: HWND, UINT, WPARAM, LPARAM
// Output.......: BOOL
/*---------------------------------------------------------------*/
BOOL CALLBACK APP_DlgProc(HWND hDlg, UINT uiMsg, WPARAM wParam, LPARAM lParam)
{
   switch(uiMsg)
   {
   case WM_INITDIALOG:
      OnInitDialog(hDlg);
      break;

   case WM_DROPFILES:
      HandleFileDrop(hDlg, reinterpret_cast<HDROP>(wParam));
      break;

   case WM_COMMAND:
      switch(wParam)
      {
      case IDC_RESOLVE:
         DoResolveShortcut(hDlg, NULL);
         return FALSE;

      case IDC_CREATE:
         DoCreateShortcut(hDlg);
         return FALSE;

      case IDC_BROWSE:
         OnBrowse(hDlg, IDC_SHORTCUT);
         return FALSE;

      case IDC_BROWSETARGET:
         OnBrowse(hDlg, IDC_TARGET);
         return FALSE;

      case IDCANCEL:
         EndDialog(hDlg, FALSE);
         return FALSE;
      }
      break;
   }

   return FALSE;
}


/*****************************************************************
*
*  Internals:
*    - OnOK()
*    - OnInitDialog()
*
******************************************************************/

/*---------------------------------------------------------------*/
// Procedure...: OnOK()
// Description.: Do something
// INPUT.......: HWND
// OUTPUT......: void
/*---------------------------------------------------------------*/
void OnOK(HWND hDlg)
{
   return;
}


/*---------------------------------------------------------------*/
// Procedure...: OnInitDialog()
// Description.: Initialize the dialog
// INPUT.......: HWND
// OUTPUT......: void
/*---------------------------------------------------------------*/
void OnInitDialog(HWND hDlg)
{
   // Set the icons (T/F as to Large/Small icon)
   SendMessage(hDlg, WM_SETICON, FALSE, reinterpret_cast<LPARAM>(g_hIconSmall));
   SendMessage(hDlg, WM_SETICON, TRUE, reinterpret_cast<LPARAM>(g_hIconLarge));

   // Initialize the report view
   HWND hwndList = GetDlgItem(hDlg, IDC_VIEW);
   LPTSTR psz[] = {"Target",      reinterpret_cast<TCHAR*>(170),
                   "Description", reinterpret_cast<TCHAR*>(170),
                   "Hotkey",      reinterpret_cast<TCHAR*>(100)};
   MakeReportView(hwndList, psz, 3);

   // Special folders available
   HWND hwndCbo = GetDlgItem(hDlg, IDC_SPECIAL);
   int i = ComboBox_AddString(hwndCbo, "Desktop");
   ComboBox_SetItemData(hwndCbo, i, CSIDL_DESKTOP);
   i = ComboBox_AddString(hwndCbo, "Favorites");
   ComboBox_SetItemData(hwndCbo, i, CSIDL_FAVORITES);
   i = ComboBox_AddString(hwndCbo, "Programs");
   ComboBox_SetItemData(hwndCbo, i, CSIDL_PROGRAMS);
   i = ComboBox_AddString(hwndCbo, "My Documents");
   ComboBox_SetItemData(hwndCbo, i, CSIDL_PERSONAL);
   i = ComboBox_AddString(hwndCbo, "SendTo");
   ComboBox_SetItemData(hwndCbo, i, CSIDL_SENDTO);
   i = ComboBox_AddString(hwndCbo, "Start Menu");
   ComboBox_SetItemData(hwndCbo, i, CSIDL_STARTMENU);
   ComboBox_SetCurSel(hwndCbo, 0);

   // Initialize the hotkey control to prefix everything with Ctrl + Alt
   SendDlgItemMessage(hDlg, IDC_HOTKEY, HKM_SETRULES,
                      HKCOMB_NONE | HKCOMB_S | HKCOMB_A | HKCOMB_C,
                      HOTKEYF_CONTROL | HOTKEYF_ALT);

   SetDlgItemText(hDlg, IDC_TARGET, __TEXT("C:\\"));
}


HRESULT SHCreateShortcutEx(LPCTSTR szLnkFile, LPSHORTCUTSTRUCT lpss)
{
   WCHAR wszLnkFile[MAX_PATH] = {0};
   IShellLink* pShellLink = NULL;
   IPersistFile* pPF = NULL;

   // Validate SHORTCUTSTRUCT pointer
   if(lpss == NULL)
      return E_FAIL;

   // Create the COM server assuming CoInitialize() has already been called
   HRESULT hr = CoCreateInstance(CLSID_ShellLink, NULL,
                                 CLSCTX_INPROC_SERVER, IID_IShellLink,
                                 reinterpret_cast<LPVOID*>(&pShellLink));
   if(FAILED(hr))
      return hr;

   // Set attributes
   pShellLink->SetPath(lpss->pszTarget);
   pShellLink->SetDescription(lpss->pszDesc);
   pShellLink->SetHotkey(lpss->wHotKey);
   pShellLink->SetIconLocation(lpss->pszIconPath, lpss->wIconIndex);

   // Get the IPersistFile interface to save
   hr = pShellLink->QueryInterface(IID_IPersistFile, reinterpret_cast<LPVOID*>(&pPF));
   if(FAILED(hr))
   {
      pShellLink->Release();
      return hr;
   }

   // Save to a LNK file (Unicode name)
   MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, szLnkFile, -1, wszLnkFile, MAX_PATH);
   hr = pPF->Save(wszLnkFile, TRUE);

   // Clean up
   pPF->Release();
   pShellLink->Release();
   return hr;
}


HRESULT SHResolveShortcut(LPCTSTR szLnkFile, LPSHORTCUTSTRUCT lpss)
{
   WCHAR wszLnkFile[MAX_PATH] = {0};
   IShellLink* pShellLink = NULL;
   IPersistFile* pPF = NULL;

   // Create the appropriate COM server
   HRESULT hr = CoCreateInstance(CLSID_ShellLink, NULL,
                                 CLSCTX_INPROC_SERVER, IID_IShellLink,
                                 reinterpret_cast<LPVOID*>(&pShellLink));
   if(FAILED(hr))
      return hr;

   // Get the IPersistFile interface to load the LNK file
   hr = pShellLink->QueryInterface(IID_IPersistFile, reinterpret_cast<LPVOID*>(&pPF));
   if(FAILED(hr))
   {
      pShellLink->Release();
      return hr;
   }

   // Load the shortcut (Unicode name)
   MultiByteToWideChar(CP_ACP, 0, szLnkFile, -1, wszLnkFile, MAX_PATH);
   hr = pPF->Load(wszLnkFile, STGM_READ);
   if(FAILED(hr))
   {
      pPF->Release();
      pShellLink->Release();
      return hr;
   }

   // Resolve the link
   hr = pShellLink->Resolve(NULL, SLR_ANY_MATCH);
   if(FAILED(hr))
   {
      pPF->Release();
      pShellLink->Release();
      return hr;
   }

   // Extract the information to fill lpss
   if(lpss != NULL)
   {
      TCHAR szPath[MAX_PATH] = {0};
      TCHAR szDesc[MAX_PATH] = {0};
      TCHAR szIcon[MAX_PATH] = {0};
      WORD w = 0;
      WORD wIcon = 0;
      WIN32_FIND_DATA wfd;

      pShellLink->GetPath(szPath, MAX_PATH, &wfd, SLGP_SHORTPATH);
      pShellLink->GetDescription(szDesc, MAX_PATH);
      pShellLink->GetHotkey(&w);
      pShellLink->GetIconLocation(szIcon, MAX_PATH, reinterpret_cast<int*>(&wIcon));

      lpss->pszTarget = szPath;
      lpss->pszDesc = szDesc;
      lpss->pszIconPath = szIcon;
      lpss->wHotKey = w;
      lpss->wIconIndex = wIcon;
   }

   pPF->Release();
   pShellLink->Release();
   return hr;
}


void OnBrowse(HWND hDlg, WPARAM wID)
{
   TCHAR szFile[MAX_PATH] = {0};

   OPENFILENAME ofn;
   ZeroMemory(&ofn, sizeof(OPENFILENAME));
   ofn.lStructSize = sizeof(OPENFILENAME);
   if(wID == IDC_SHORTCUT)
   {
      ofn.lpstrFilter = __TEXT("Shortcuts\0*.lnk\0");
      ofn.Flags = OFN_NODEREFERENCELINKS;
   }
   else
      ofn.lpstrFilter = __TEXT("All files\0*.*\0");

   ofn.nMaxFile = MAX_PATH;
   ofn.lpstrInitialDir = __TEXT("c:\\");
   ofn.lpstrFile = szFile;
   if(!GetOpenFileName(&ofn))
      return;
   else
      SetDlgItemText(hDlg, wID, ofn.lpstrFile);
   return;
}


void MakeReportView(HWND hwndList, LPTSTR* psz, int iNumOfCols)
{
   RECT rc;

   DWORD dwStyle = GetWindowStyle(hwndList);
   SetWindowLong(hwndList, GWL_STYLE, dwStyle | LVS_REPORT);
   GetClientRect(hwndList, &rc);

   // Handle pairs of entries. Array size is assumed to be 2 * iNumOfCols
   for(int i = 0 ; i < 2 * iNumOfCols ; i = i + 2)
   {
      LV_COLUMN lvc;
      ZeroMemory(&lvc, sizeof(LV_COLUMN));
      lvc.mask = LVCF_TEXT | LVCF_WIDTH;
      lvc.pszText = psz[i];
      if(reinterpret_cast<int>(psz[i + 1]) == 0)
         lvc.cx = rc.right / iNumOfCols;
      else
         lvc.cx = reinterpret_cast<int>(psz[i + 1]);

      ListView_InsertColumn(hwndList, i, &lvc);
   }
   return;
}


void AddStringToReportView(HWND hwndList, LPTSTR psz, int iNumOfCols)
{
   LV_ITEM lvi;
   ZeroMemory(&lvi, sizeof(LV_ITEM));
   lvi.mask = LVIF_TEXT;
   lvi.pszText = psz;
   lvi.cchTextMax = lstrlen(psz);
   lvi.iItem = 0;
   ListView_InsertItem(hwndList, &lvi);

   // Other columns
   for(int i = 1 ; i < iNumOfCols ; i++)
   {
      psz += lstrlen(psz) + 1;
      ListView_SetItemText(hwndList, 0, i, psz);
   }
   return;
}


void HotkeyToString(WORD wHotKey, LPTSTR pszBuf)
{
   BYTE bKey = LOBYTE(wHotKey);
   BYTE bMod = HIBYTE(wHotKey);

   if(bMod & HOTKEYF_CONTROL)
      lstrcpy(pszBuf, __TEXT("Ctrl"));

   if(bMod & HOTKEYF_SHIFT)
      if(lstrlen(pszBuf))
         lstrcat(pszBuf, __TEXT(" + Shift"));
      else
         lstrcpy(pszBuf, __TEXT("Shift"));

   if(bMod & HOTKEYF_ALT)
      if(lstrlen(pszBuf))
         lstrcat(pszBuf, __TEXT(" + Alt"));
      else
         lstrcpy(pszBuf, __TEXT("Alt"));

   TCHAR s[2] = {0};
   wsprintf(s, __TEXT("%c"), bKey);
   if(lstrlen(pszBuf))
   {
      lstrcat(pszBuf, __TEXT(" + "));
      lstrcat(pszBuf, s);
   }
   else
      lstrcpy(pszBuf, s);
}


void DoCreateShortcut(HWND hDlg)
{
   SHORTCUTSTRUCT ss;
   ZeroMemory(&ss, sizeof(SHORTCUTSTRUCT));
   TCHAR szTarget[MAX_PATH] = {0};
   TCHAR szDesc[MAX_PATH] = {0};

   // Get the hotkey
   ss.wHotKey = static_cast<WORD>(SendDlgItemMessage(hDlg, IDC_HOTKEY, HKM_GETHOTKEY, 0, 0));

   // Get target and description
   GetDlgItemText(hDlg, IDC_TARGET, szTarget, MAX_PATH);
   GetDlgItemText(hDlg, IDC_DESCRIPTION, szDesc, MAX_PATH);
   ss.pszTarget = szTarget;
   ss.pszDesc = szDesc;

   // Determine the shortcut file name
   // Get the target folder & final backslash
   HWND hwndCbo = GetDlgItem(hDlg, IDC_SPECIAL);
   int i = ComboBox_GetCurSel(hwndCbo);
   DWORD nFolder = ComboBox_GetItemData(hwndCbo, i);

   TCHAR szPath[MAX_PATH] = {0};
   SHGetSpecialFolderPath(hDlg, szPath, nFolder, FALSE);
   if(szPath[lstrlen(szPath) - 1] != '\\')
      lstrcat(szPath, __TEXT("\\"));

   TCHAR szLnkFile[MAX_PATH] = {0};
   GetDlgItemText(hDlg, IDC_LNKFILE, szLnkFile, MAX_PATH);
   lstrcat(szPath, szLnkFile);
   lstrcat(szPath, __TEXT(".lnk"));

   // Create
   SHCreateShortcutEx(szPath, &ss);

   // Update UI
   SetDlgItemText(hDlg, IDC_SHORTCUT, szPath);
   return;
}


void DoResolveShortcut(HWND hDlg, LPTSTR pszFile)
{
   TCHAR szLnkFile[MAX_PATH] = {0};
   if(pszFile == NULL)
     GetDlgItemText(hDlg, IDC_SHORTCUT, szLnkFile, MAX_PATH);
   else
     lstrcpy(szLnkFile, pszFile);

   // Resolve the shortcut
   SHORTCUTSTRUCT ss;
   HRESULT hr = SHResolveShortcut(szLnkFile, &ss);
   if(FAILED(hr))
      return;

   //////////////////////////////////////////////
   // Update UI

   // Create the string for the listview
   TCHAR pszBuf[1024] = {0};
   LPTSTR psz = pszBuf;

   lstrcpy(psz, ss.pszTarget);
   lstrcat(psz, __TEXT("\0"));
   psz += lstrlen(psz) + 1;

   lstrcpy(psz, ss.pszDesc);
   lstrcat(psz, __TEXT("\0"));
   psz += lstrlen(psz) + 1;

   // Try to get the text version of the hotkey
   TCHAR szKey[30] = {0};
   HotkeyToString(ss.wHotKey, szKey);

   lstrcpy(psz, szKey);
   lstrcat(psz, __TEXT("\0"));

   // Add a new item to the report list view (3 columns)
   HWND hwndList = GetDlgItem(hDlg, IDC_VIEW);
   AddStringToReportView(hwndList, pszBuf, 3);
   return;
}


void HandleFileDrop(HWND hDlg, HDROP hDrop)
{
   // Check the window being dropped on
   POINT pt;
   DragQueryPoint(hDrop, &pt);
   ClientToScreen(hDlg, &pt);
   HWND hwndDrop = WindowFromPoint(pt);
   if(hwndDrop != GetDlgItem(hDlg, IDC_VIEW))
   {
      Msg(__TEXT("Sorry, you have to drop over the list view control!"));
      return;
   }

   // Now check the files
   int iNumOfFiles = DragQueryFile(hDrop, -1, NULL, 0);
   for(int i = 0 ; i < iNumOfFiles; i++)
   {
      TCHAR szFileName[MAX_PATH] = {0};
      DragQueryFile(hDrop, i, szFileName, MAX_PATH);
      DoResolveShortcut(hDlg, szFileName);
   }

   DragFinish(hDrop);
}

/*  End of file: Shortcut.cpp  */
