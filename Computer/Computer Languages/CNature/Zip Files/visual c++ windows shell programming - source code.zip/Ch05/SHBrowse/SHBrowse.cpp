/*****************************************************************
*
*  Project.....:  Demonstrating SHBrowseForFolder
*  Application.:  SHBROWSE.exe
*  Module......:  SHBROWSE.cpp
*  Description.:  Application main module
*  Compiler....:  MS Visual C++ 
*  Written by..:  D. Esposito
*  Environment.:  Windows 9x/NT
*
******************************************************************/

/*---------------------------------------------------------------*/
//                        PRAGMA section
/*---------------------------------------------------------------*/
// Force the linker to add the following libraries.
// In doing so we prevent the use of MFC classes.
#ifdef _MSC_VER

#pragma comment(lib, "kernel32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "comctl32.lib")

#endif

/*---------------------------------------------------------------*/
//                        INCLUDE section
/*---------------------------------------------------------------*/
#include "SHBrowse.h"
#include <commctrl.h>
#include <shellapi.h>
#include <shlobj.h>
#include "resource.h"

/*---------------------------------------------------------------*/
//                        GLOBAL section
/*---------------------------------------------------------------*/
// Data
HICON g_hIconLarge;
HICON g_hIconSmall;

// Functions
void OnInitDialog(HWND);
void OnOK(HWND);
HICON SHGetSystemIcon(int);
HRESULT SHPathToPIDL(LPCTSTR, LPITEMIDLIST*);

// Callbacks
BOOL CALLBACK APP_DlgProc(HWND, UINT, WPARAM, LPARAM);
int CALLBACK BrowseCallbackProc(HWND, UINT, LPARAM, LPARAM);

/*---------------------------------------------------------------*/
// Procedure....: WinMain()
// Description..: Entry point in any Windows program
// Input........: HINSTANCE, HINSTANCE, LPSTR, int
// Output.......: INT
/*---------------------------------------------------------------*/
int APIENTRY WinMain(
   HINSTANCE hInstance, HINSTANCE hPrevious, LPTSTR lpsz, int iCmd)
{
   // Save global data
   g_hIconLarge = static_cast<HICON>(LoadImage(hInstance, "APP_ICON", IMAGE_ICON,
      GetSystemMetrics(SM_CXICON), GetSystemMetrics(SM_CXICON), 0));
   g_hIconSmall = static_cast<HICON>(LoadImage(hInstance, "APP_ICON", IMAGE_ICON,
      GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CXSMICON), 0));

   // Enable common controls
   INITCOMMONCONTROLSEX iccex;
   iccex.dwSize = sizeof(INITCOMMONCONTROLSEX);
   iccex.dwICC = ICC_WIN95_CLASSES;
   InitCommonControlsEx(&iccex);

   // Run main dialog
   BOOL b = DialogBox(hInstance, "DLG_MAIN", NULL, APP_DlgProc);

   // Exit
   DestroyIcon(g_hIconLarge);
   DestroyIcon(g_hIconSmall);
   return b;
}


/*---------------------------------------------------------------*/
// Procedure....: APP_DlgProc()
// Description..: Responds to all messages sent to the dialog
// Input........: HWND, UINT, WPARAM, LPARAM
// Output.......: BOOL
/*---------------------------------------------------------------*/
BOOL CALLBACK APP_DlgProc(HWND hDlg, UINT uiMsg, WPARAM wParam, LPARAM lParam)
{
   switch(uiMsg)
   {
   case WM_INITDIALOG:
      OnInitDialog(hDlg);
      break;

   case WM_COMMAND:
      switch(wParam)
      {
      case IDOK:
         OnOK(hDlg);
         return FALSE;

      case IDCANCEL:
         EndDialog(hDlg, FALSE);
         return FALSE;
      }
      break;
   }

   return FALSE;
}


/*****************************************************************
*
*  Internals:
*    - OnOK()
*    - OnInitDialog()
*
******************************************************************/

/*---------------------------------------------------------------*/
// Procedure...: OnOK()
// Description.: Do something
// INPUT.......: HWND
// OUTPUT......: void
/*---------------------------------------------------------------*/
void OnOK(HWND hDlg)
{
   BROWSEINFO bi;
   TCHAR szTitle[MAX_PATH] = {0};
   TCHAR szPath[MAX_PATH] = {0};
   TCHAR szDisplay[MAX_PATH] = {0};
   LPITEMIDLIST pidl = NULL;
   LPMALLOC pMalloc = NULL;

   // Prepare the call
   ZeroMemory(&bi, sizeof(BROWSEINFO));
   bi.hwndOwner = hDlg;

   // Title and display name
   GetDlgItemText(hDlg, IDC_TITLE, szTitle, MAX_PATH);
   bi.lpszTitle = szTitle;
   bi.pszDisplayName = szDisplay;

   // Initial directory
   if(IsDlgButtonChecked(hDlg, IDC_USEPIDL))
   {
      HWND hwndCbo = GetDlgItem(hDlg, IDC_SPECIAL);
      int i = ComboBox_GetCurSel(hwndCbo);
      int nFolder = ComboBox_GetItemData(hwndCbo, i);

      SHGetSpecialFolderLocation(NULL, nFolder, &pidl);
      bi.pidlRoot = pidl;
   }
   else
   {
      // Convert a path name to a PIDL
      GetDlgItemText(hDlg, IDC_FOLDER, szPath, MAX_PATH);
      if(lstrlen(szPath) == 0)
         GetCurrentDirectory(MAX_PATH, szPath);
      SHPathToPIDL(szPath, &pidl);
      bi.pidlRoot = pidl;
   }

   // Collect the flags
   UINT uiFlags = 0;
   if(IsDlgButtonChecked(hDlg, IDC_NOBELOW))
      uiFlags |= BIF_DONTGOBELOWDOMAIN;
   if(IsDlgButtonChecked(hDlg, IDC_ONLYDIRS))
      uiFlags |= BIF_RETURNONLYFSDIRS;
   if(IsDlgButtonChecked(hDlg, IDC_INCLUDEFILES))
      uiFlags |= BIF_BROWSEINCLUDEFILES;
   if(IsDlgButtonChecked(hDlg, IDC_EDITBOX))
      uiFlags |= BIF_EDITBOX | BIF_VALIDATE;
   if(IsDlgButtonChecked(hDlg, IDC_STATUS))
      uiFlags |= BIF_STATUSTEXT;
   if(IsDlgButtonChecked(hDlg, IDC_COMPUTER))
      uiFlags |= BIF_BROWSEFORCOMPUTER;
   bi.ulFlags = uiFlags;

   // Set up the callback
   bi.lpfn = BrowseCallbackProc;
   bi.lParam = 0;

   // Call the function
   LPITEMIDLIST pidlFolder = SHBrowseForFolder(&bi);
   if(pidlFolder == NULL)
      return;

   // Display the results...
   // Show the display name
   SetDlgItemText(hDlg, IDC_DISPLAYNAME, bi.pszDisplayName);

   // Show the path name
   SHGetPathFromIDList(pidlFolder, szPath);
   SetDlgItemText(hDlg, IDC_PATHNAME, szPath);

   // Show the folder icon
   HICON hIcon = SHGetSystemIcon(bi.iImage);
   SendDlgItemMessage(hDlg, IDI_ICON, STM_SETICON, reinterpret_cast<WPARAM>(hIcon), 0);

   // Free
   SHGetMalloc(&pMalloc);
   pMalloc->Free(pidl);
   pMalloc->Free(pidlFolder);
   pMalloc->Release();
}


/*---------------------------------------------------------------*/
// Procedure...: OnInitDialog()
// Description.: Initialize the dialog
// INPUT.......: HWND
// OUTPUT......: void
/*---------------------------------------------------------------*/
void OnInitDialog(HWND hDlg)
{
   // Set the icons (T/F as to Large/Small icon)
   SendMessage(hDlg, WM_SETICON, FALSE, reinterpret_cast<LPARAM>(g_hIconSmall));
   SendMessage(hDlg, WM_SETICON, TRUE, reinterpret_cast<LPARAM>(g_hIconLarge));

   // Fill the combo box
   HWND hwndCbo = GetDlgItem(hDlg, IDC_SPECIAL);
   int i = ComboBox_AddString(hwndCbo, "Control Panel");
   ComboBox_SetItemData(hwndCbo, i, CSIDL_CONTROLS);
   i = ComboBox_AddString(hwndCbo, "Favorites");
   ComboBox_SetItemData(hwndCbo, i, CSIDL_FAVORITES);
   i = ComboBox_AddString(hwndCbo, "Printers");
   ComboBox_SetItemData(hwndCbo, i, CSIDL_PRINTERS);
   i = ComboBox_AddString(hwndCbo, "Fonts");
   ComboBox_SetItemData(hwndCbo, i, CSIDL_FONTS);
   i = ComboBox_AddString(hwndCbo, "SendTo");
   ComboBox_SetItemData(hwndCbo, i, CSIDL_SENDTO);
   ComboBox_SetCurSel(hwndCbo, 0);
}


int CALLBACK BrowseCallbackProc(HWND hwnd, UINT uMsg, LPARAM lParam, LPARAM dwData)
{
   switch(uMsg)
   {
   case BFFM_INITIALIZED:
      {
         // Remove the ? from the caption
         DWORD dwStyle = GetWindowLong(hwnd, GWL_EXSTYLE);
         SetWindowLong(hwnd, GWL_EXSTYLE, dwStyle & ~WS_EX_CONTEXTHELP);

         // Add a 3D border to the status text
         HWND hwndLabel = GetDlgItem(hwnd, 0x3743);

         // Check if it is a valid window
         if(IsWindow(hwndLabel))
         {
            // Now check if it is window of class 'static'
            TCHAR szClass[MAX_PATH] = {0};
            GetClassName(hwndLabel, szClass, MAX_PATH);
            if(lstrcmpi(szClass, __TEXT("static")))
               break;
         }
         else
            break;

         dwStyle = GetWindowLong(hwndLabel, GWL_EXSTYLE);
         SetWindowLong(hwndLabel, GWL_EXSTYLE, dwStyle | WS_EX_STATICEDGE);
         SetWindowPos(hwndLabel, NULL, 0, 0, 0, 0,
                                   SWP_NOSIZE | SWP_NOMOVE | SWP_DRAWFRAME);
      }
      break;

   case BFFM_SELCHANGED:
      {
         TCHAR szText[MAX_PATH] = {0};
         SHGetPathFromIDList(reinterpret_cast<LPITEMIDLIST>(lParam), szText);
         SendMessage(hwnd, BFFM_SETSTATUSTEXT, 0, reinterpret_cast<LPARAM>(szText));
      }
      break;

   case BFFM_VALIDATEFAILED:
      Msg("\"%s\" is a wrong path name.", reinterpret_cast<LPTSTR>(lParam));
      return 1;
   }

   return 0;
}


HICON SHGetSystemIcon(int iIconIndex)
{
   SHFILEINFO sfi;
   ZeroMemory(&sfi, sizeof(SHFILEINFO));

   // We aren't specifying a file name, since all we want is the handle...
   HIMAGELIST himl = reinterpret_cast<HIMAGELIST>(SHGetFileInfo(
      "*.*", 0, &sfi, sizeof(SHFILEINFO), SHGFI_ICON | SHGFI_SYSICONINDEX));

   HICON hIcon = ImageList_ExtractIcon(0, himl, iIconIndex);
   return hIcon;
}


HRESULT SHPathToPIDL(LPCTSTR szPath, LPITEMIDLIST* ppidl)
{
   LPSHELLFOLDER pShellFolder = NULL;
   OLECHAR wszPath[MAX_PATH] = {0};
   ULONG nCharsParsed = 0;

   // Get an IShellFolder interface pointer
   HRESULT hr = SHGetDesktopFolder(&pShellFolder);
   if(FAILED(hr))
      return hr;

   // Convert the path name to Unicode
   MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, szPath, -1, wszPath, MAX_PATH);

   // Call ParseDisplayName() to do the job
   hr = pShellFolder->ParseDisplayName(NULL, NULL, wszPath, &nCharsParsed, ppidl, NULL);

   // Clean up
   pShellFolder->Release();
   return hr;
}

/*  End of file: SHBrowse.c  */