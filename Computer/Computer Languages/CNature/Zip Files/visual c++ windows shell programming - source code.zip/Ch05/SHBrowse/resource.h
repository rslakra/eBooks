//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SHBrowse.rc
//
#define IDC_FOLDER                      1000
#define IDC_SPECIAL                     1001
#define IDC_USEPIDL                     1002
#define IDC_PATHNAME                    1003
#define IDC_DISPLAYNAME                 1004
#define IDC_NOBELOW                     1005
#define IDC_ONLYDIRS                    1006
#define IDC_INCLUDEFILES                1008
#define IDC_TITLE                       1009
#define IDC_EDITBOX                     1010
#define IDC_STATUS                      1011
#define IDI_ICON                        1012
#define IDC_COMPUTER                    1013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
