//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Pidl.rc
//
#define IDC_FOLDER                      1000
#define IDC_SPECIAL                     1001
#define IDC_PIDLCONTENT                 1002
#define IDC_SEARCHPATH                  1003
#define IDC_LISTVIEW                    1004
#define IDC_FOUND                       1006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
