#include "spbutils.h"


/*---------------------------------------------------*/
// Procedure....: Msg()
// Description..: Show a message box
/*---------------------------------------------------*/
void WINAPI Msg(char* szFormat, ...)
{
	va_list argptr;
	char szBuf[MAX_PATH];
	HWND hwndFocus = GetFocus();

	// init va_ functions
	va_start(argptr, szFormat);

	// format output string
	wvsprintf(szBuf, szFormat, argptr);

	// read title and show
	MessageBox(hwndFocus, szBuf, NULL, MB_ICONEXCLAMATION | MB_OK);

	// close va_ functions
	va_end(argptr);
	SetFocus(hwndFocus);
}


/*---------------------------------------------------*/
// Procedure....: SPB_SystemMessage()
// Description..: Formats a standard error message
/*---------------------------------------------------*/
void WINAPI SPB_SystemMessage(DWORD dwRC)
{
	LPVOID lpMsgBuf;
	DWORD rc;

	rc = FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER |
                          FORMAT_MESSAGE_FROM_SYSTEM |     
                          FORMAT_MESSAGE_IGNORE_INSERTS,    
                       NULL, dwRC,    
                       MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), 
                       reinterpret_cast<LPTSTR>(&lpMsgBuf), 0, NULL);

    Msg("%s:  %ld.\n\n\n%s:\n\n%s", "This is the error code", dwRC,
        "This is the system's explanation", (rc == 0 ? "<unknown>" : lpMsgBuf));
    LocalFree(lpMsgBuf);
} 





