/*****************************************************************
*
*  Project.....:  Shell Programming Book Utility Library
*  Application.:  SPBUTIL.dll
*  Module......:  SPBUtils.h
*  Description.:  Utility header
*  Compiler....:  MS Visual C++ 
*  Written by..:  D. Esposito
*  Environment.:  Windows 9x/NT
*
******************************************************************/

// Prevent multiple inclusions
#define WIN32_LEAN_AND_MEAN
#define STRICT

#ifndef _SPB_UTILS_
#define _SPB_UTILS_

#ifdef __cplusplus
extern "C" {
#endif

/*---------------------------------------------------------------*/
//                        INCLUDE section
/*---------------------------------------------------------------*/
#include <windows.h>
#include <windowsx.h>

/*---------------------------------------------------------------*/
//                        PROTOTYPE section
/*---------------------------------------------------------------*/
// Error Messages
#include <stdarg.h>

void WINAPI Msg(char* szFormat, ...);
void WINAPI SPB_SystemMessage(DWORD dwRC);

#ifdef __cplusplus
}
#endif

#endif	// _SPB_UTILS_
