/*****************************************************************
*
*  Project.....:  Wrox AppWizard
*  Application.:  TNA.exe
*  Module......:  TNA.cpp
*  Description.:  Application main module
*  Compiler....:  MS Visual C++
*  Written by..:  D. Esposito
*  Environment.:  Windows 9x/NT
*
******************************************************************/

/*---------------------------------------------------------------*/
//                        PRAGMA section
/*---------------------------------------------------------------*/
// Force the linker to add the following libraries.
#ifdef _MSC_VER

#pragma comment(lib, "kernel32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "comctl32.lib")

#endif

/*---------------------------------------------------------------*/
//                        INCLUDE section
/*---------------------------------------------------------------*/
#include "TNA.h"
#include <commctrl.h>
#include <shellapi.h> 
#include "resource.h"

/*---------------------------------------------------------------*/
//                        GLOBAL section
/*---------------------------------------------------------------*/
// Data
HINSTANCE g_hInstance;
HICON g_hSmallIcon;
UINT g_uShellRestart;

const int WM_EX_MESSAGE = (WM_APP + 1);
const int ICON_ID = 42;

// Functions
void OnOK(HWND);
BOOL TrayIcon(HWND, HICON, DWORD);
void ContextMenu(HWND);

// Callbacks
BOOL CALLBACK APP_DlgProc(HWND, UINT, WPARAM, LPARAM);


/*---------------------------------------------------------------*/
// Procedure....: WinMain()
// Description..: Entry point in any Windows program
// Input........: HINSTANCE, HINSTANCE, LPSTR, int
// Output.......: int
/*---------------------------------------------------------------*/
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
                   LPSTR lpCmdLine, int nCmdShow)
{
   // Copy the instance handle to a global
   g_hInstance = hInstance;
   g_uShellRestart = RegisterWindowMessage(__TEXT("TaskbarCreated"));

   // Load the 16x16 icon to go into the tray
   HICON hSmallIcon = reinterpret_cast<HICON>(LoadImage(hInstance,
                               __TEXT("APP_ICON"), IMAGE_ICON, 16, 16, 0));
   g_hSmallIcon = hSmallIcon;
   
   // Create an invisible dialog to get messages from the icon
   HWND hDlg = CreateDialog(hInstance, __TEXT("DLG_MAIN"), NULL, APP_DlgProc);

   // Show the icon
   TrayIcon(hDlg, hSmallIcon, NIM_ADD);

   // Enter the loop to keep this program running
   MSG msg;
   while(GetMessage(&msg, NULL, 0, 0))
   {
      if(!IsDialogMessage(hDlg, &msg))
      {
         TranslateMessage(&msg);
         DispatchMessage(&msg);
      }
   }

   // Remove the icon and exit
   TrayIcon(hDlg, hSmallIcon, NIM_DELETE);
   DestroyWindow(hDlg);
   DestroyIcon(hSmallIcon);
   return 1;
}


/*---------------------------------------------------------------*/
// Procedure....: APP_DlgProc()
// Description..: Responds to all messages sent to the dialog
// Input........: HWND, UINT, WPARAM, LPARAM
// Output.......: BOOL
/*---------------------------------------------------------------*/
BOOL CALLBACK APP_DlgProc(HWND hDlg, UINT uiMsg, WPARAM wParam, LPARAM lParam)
{
   if(uiMsg == g_uShellRestart)
      TrayIcon(hDlg, g_hSmallIcon, NIM_ADD);
	
   switch(uiMsg)
   {
   case WM_COMMAND:
      switch(LOWORD(wParam))
      {
      case IDCANCEL:
         PostQuitMessage(0);
         return FALSE;
      }
      break;

   case WM_EX_MESSAGE:
      if(wParam == ICON_ID)
      {
         switch(lParam)
         {
         case WM_RBUTTONUP:
            ContextMenu(hDlg);
            break;
         }
      }
      break;
   }
   return FALSE;
}


/*****************************************************************
*
*  Internals:
*    - OnOK()
*    - OnInitDialog()
*
******************************************************************/

/*---------------------------------------------------------------*/
// Procedure...: OnOK()
// Description.: Do something
// INPUT.......: HWND
// OUTPUT......: void
/*---------------------------------------------------------------*/
void OnOK(HWND hDlg)
{
   return;
}


BOOL TrayIcon(HWND hWnd, HICON hIcon, DWORD msg)
{
   NOTIFYICONDATA nid;
   ZeroMemory(&nid, sizeof(NOTIFYICONDATA));
   nid.cbSize = sizeof(NOTIFYICONDATA);
   nid.hWnd = hWnd;
   nid.uID = ICON_ID;
   nid.uFlags = NIF_TIP | NIF_ICON | NIF_MESSAGE;
   nid.uCallbackMessage = WM_EX_MESSAGE;
   nid.hIcon = hIcon;
   lstrcpyn(nid.szTip, __TEXT("This icon's been added by me!"), 64);

   // Perform the specified operation on the icon
   return Shell_NotifyIcon(msg, &nid);
}


void ContextMenu(HWND hwnd)
{
   HMENU hmenu = LoadMenu(g_hInstance, MAKEINTRESOURCE(IDR_MENU));
   HMENU hmnuPopup = GetSubMenu(hmenu, 0);
   SetMenuDefaultItem(hmnuPopup, IDOK, FALSE);

   POINT pt;
   GetCursorPos(&pt);
   SetForegroundWindow(hwnd);
   TrackPopupMenu(hmnuPopup, TPM_LEFTALIGN, pt.x, pt.y, 0, hwnd, NULL);
   SetForegroundWindow(hwnd);

   DestroyMenu(hmnuPopup);
   DestroyMenu(hmenu);
}

/*  End of file: TNA.cpp  */
