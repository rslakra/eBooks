//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Taskbar.rc
//
#define IDC_RETRIEVE                    1000
#define IDC_TEXT                        1001
#define IDC_TASKBAR                     1002
#define IDC_RESTART                     1003
#define IDC_ADDTAB                      1004
#define IDC_DELETETAB                   1005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
