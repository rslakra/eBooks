/*****************************************************************
*
*  Project.....:  Taskbar Fun
*  Application.:  TASKBAR.exe
*  Module......:  TASKBAR.cpp
*  Description.:  Application main module
*  Compiler....:  MS Visual C++
*  Written by..:  D. Esposito
*  Environment.:  Windows 9x/NT
*
******************************************************************/

/*---------------------------------------------------------------*/
//                        PRAGMA section
/*---------------------------------------------------------------*/
// Force the linker to add the following libraries.
#ifdef _MSC_VER

#pragma comment(lib, "kernel32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "ole32.lib")

#endif

/*---------------------------------------------------------------*/
//                        INCLUDE section
/*---------------------------------------------------------------*/
#include "Taskbar.h"
#include <commctrl.h>
#include <shellapi.h> 
#include "resource.h"
#include "ITaskbarList.h"
#include <shlguid.h>

/*---------------------------------------------------------------*/
//                        GLOBAL section
/*---------------------------------------------------------------*/
// Data
HICON g_hIconLarge;
HICON g_hIconSmall;
UINT g_uShellRestart;
HWND g_hwndButton;
WNDPROC g_pfnOldProc;
HWND g_hDlg;

struct STARTMENUPOS
{
   int  ix;
   int  iy;
   UINT uFlags;
};

typedef STARTMENUPOS* LPSTARTMENUPOS;

// Functions
void OnInitDialog(HWND);
void OnOK(HWND);
void SHShellRestart();
void OnTaskbarSettings(HWND);
void OnAddTab(HWND);
void OnDeleteTab();
void OnButtonActivation();
int GetMenuPosition(HWND, int, LPSTARTMENUPOS);

// Callbacks
BOOL CALLBACK APP_DlgProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK ButtonProc(HWND, UINT, WPARAM, LPARAM);

/*---------------------------------------------------------------*/
// Procedure....: WinMain()
// Description..: Entry point in any Windows program
// Input........: HINSTANCE, HINSTANCE, LPSTR, int
// Output.......: int
/*---------------------------------------------------------------*/
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevious, 
                     LPTSTR lpsz, int iCmd)
{
   // Save global data
   g_hIconLarge = static_cast<HICON>(
              LoadImage(hInstance, "APP_ICON", IMAGE_ICON,
              GetSystemMetrics(SM_CXICON), GetSystemMetrics(SM_CXICON), 0));
   g_hIconSmall = static_cast<HICON>(
              LoadImage(hInstance, "APP_ICON", IMAGE_ICON,
              GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CXSMICON), 0));

   // Enable common controls
   INITCOMMONCONTROLSEX iccex;
   iccex.dwSize = sizeof(INITCOMMONCONTROLSEX);
   iccex.dwICC = ICC_WIN95_CLASSES;
   InitCommonControlsEx(&iccex);

   g_uShellRestart = RegisterWindowMessage(__TEXT("TaskbarCreated"));

   // Run main dialog
   CoInitialize(NULL);
   BOOL b = DialogBox(hInstance, "DLG_MAIN", NULL, APP_DlgProc);

   // Exit
   OnDeleteTab();
   CoUninitialize();
   DestroyWindow(g_hwndButton);
   DestroyIcon(g_hIconLarge);
   DestroyIcon(g_hIconSmall);
   return b;
}


/*---------------------------------------------------------------*/
// Procedure....: APP_DlgProc()
// Description..: Responds to all messages sent to the dialog
// Input........: HWND, UINT, WPARAM, LPARAM
// Output.......: BOOL
/*---------------------------------------------------------------*/
BOOL CALLBACK APP_DlgProc(HWND hDlg, UINT uiMsg, WPARAM wParam, LPARAM lParam)
{
   switch(uiMsg)
   {
   case WM_INITDIALOG:
      OnInitDialog(hDlg);
      break;

   case WM_COMMAND:
      switch(wParam)
      {
      case IDC_ADDTAB:
         OnAddTab(hDlg);
         return FALSE;
      case IDC_DELETETAB:
         OnDeleteTab();
         return FALSE;
      case IDC_RETRIEVE:
         OnTaskbarSettings(hDlg);
         return FALSE;
      case IDC_RESTART:
         SHShellRestart();
         return FALSE;
      case IDCANCEL:
         EndDialog(hDlg, FALSE);
         return FALSE;
      }
      break;
   }

   // When the shell restarts...
   if(uiMsg == g_uShellRestart)
   {
      TCHAR szTime[50] = {0};
      TCHAR szMsg[MAX_PATH] = {0};
      GetTimeFormat(LOCALE_SYSTEM_DEFAULT, 0, NULL, NULL, szTime, 50);
      wsprintf(szMsg, __TEXT("The shell was last restarted at %s"), szTime);
      SetDlgItemText(hDlg, IDC_TASKBAR, szMsg);
   }
   return FALSE;
}


/*****************************************************************
*
*  Internals:
*    - OnOK()
*    - OnInitDialog()
*
******************************************************************/

/*---------------------------------------------------------------*/
// Procedure...: OnOK()
// Description.: Do something
// INPUT.......: HWND
// OUTPUT......: void
/*---------------------------------------------------------------*/
void OnOK(HWND hDlg)
{
   return;
}


/*---------------------------------------------------------------*/
// Procedure...: OnInitDialog()
// Description.: Initialize the dialog
// INPUT.......: HWND
// OUTPUT......: void
/*---------------------------------------------------------------*/
void OnInitDialog(HWND hDlg)
{
   g_hDlg = hDlg;

   // Set the icons (T/F as to Large/Small icon)
   SendMessage(hDlg, WM_SETICON, FALSE, reinterpret_cast<LPARAM>(g_hIconSmall));
   SendMessage(hDlg, WM_SETICON, TRUE, reinterpret_cast<LPARAM>(g_hIconLarge));
}


void SHShellRestart()
{
   HWND hwnd = FindWindow(__TEXT("Progman"), NULL);
   PostMessage(hwnd, WM_QUIT, 0, 0);
   ShellExecute(NULL, NULL, __TEXT("explorer.exe"), NULL, NULL, SW_SHOW);
}


void OnTaskbarSettings(HWND hDlg)
{
   TCHAR szText[MAX_PATH] = {0};

   APPBARDATA abd;
   abd.cbSize = sizeof(APPBARDATA);

   // Retrieve the taskbar edge
   SHAppBarMessage(ABM_GETTASKBARPOS, &abd);
   switch(abd.uEdge)
   {
   case ABE_BOTTOM:
      lstrcat(szText, __TEXT("aligned at the bottom\r\n"));
      break;
   case ABE_TOP:
      lstrcat(szText, __TEXT("aligned at the top\r\n"));
      break;
   case ABE_LEFT:
      lstrcat(szText, __TEXT("aligned on the left\r\n"));
      break;
   case ABE_RIGHT:
      lstrcat(szText, __TEXT("aligned on the right\r\n"));
      break;
   }

   // Retrieve the taskbar state
   DWORD rc = SHAppBarMessage(ABM_GETSTATE, &abd);
   if(rc & ABS_ALWAYSONTOP)
      lstrcat(szText, __TEXT("always on top\r\n"));
   if(rc & ABS_AUTOHIDE)
      lstrcat(szText, __TEXT("autohide\r\n"));

   // Retrieve the Show Clock option
   HWND hwnd1 = FindWindow(__TEXT("Shell_TrayWnd"), NULL);
   HWND hwnd2 = FindWindowEx(hwnd1, NULL, __TEXT("TrayNotifyWnd"), NULL);
   HWND hwndClock = FindWindowEx(hwnd2, NULL, __TEXT("TrayClockWClass"), NULL);
   if(hwndClock)
   {
      if(IsWindowVisible(hwndClock))
         lstrcat(szText, __TEXT("clock visible\r\n"));
      else
         lstrcat(szText, __TEXT("clock not visible\r\n"));
   }

   // Show settings
   SetDlgItemText(hDlg, IDC_TEXT, szText);
}


void OnAddTab(HWND hWnd)
{
   static BOOL bFirstTime = TRUE;
   ITaskbarList* pTList = NULL;

   HRESULT hr = CoCreateInstance(CLSID_TaskbarList, NULL, CLSCTX_SERVER,
                       IID_ITaskbarList, reinterpret_cast<void**>(&pTList));
   if(FAILED(hr))
      return;

   // Call the first time only
   if(bFirstTime)
   {
      bFirstTime = FALSE;
      pTList->HrInit();

      // Create a new button window (although any window class is fine)
      g_hwndButton = CreateWindow(__TEXT("Button"), __TEXT("Custom button..."),
                                  WS_CAPTION | WS_SYSMENU | WS_VISIBLE,
                                  -300, -300, 50, 50, hWnd, NULL, NULL, NULL);
      g_pfnOldProc = SubclassWindow(g_hwndButton, ButtonProc);
   }

   pTList->AddTab(g_hwndButton);
   pTList->Release();
   ShowWindow(g_hwndButton, SW_HIDE);
}


void OnDeleteTab()
{
   ITaskbarList* pTList = NULL;

   HRESULT hr = CoCreateInstance(CLSID_TaskbarList, NULL, CLSCTX_SERVER,
                       IID_ITaskbarList, reinterpret_cast<void**>(&pTList));
   if(FAILED(hr))
      return;

   pTList->DeleteTab(g_hwndButton);
   pTList->Release();
}


LRESULT CALLBACK ButtonProc(HWND hwnd, UINT uiMsg, WPARAM wParam, LPARAM lParam)
{
   switch(uiMsg)
   {
   case WM_ACTIVATE:
      if(LOWORD(wParam) == TRUE)
         OnButtonActivation();
   }
   return CallWindowProc(g_pfnOldProc, hwnd, uiMsg, wParam, lParam);
}


void OnButtonActivation()
{
   // Get the handle of the tab control
   HWND h0 = FindWindow(__TEXT("Shell_TrayWnd"), NULL);
   HWND h1 = FindWindowEx(h0, NULL, __TEXT("RebarWindow32"), NULL);
   HWND h2 = FindWindowEx(h1, NULL, __TEXT("MSTaskSwWClass"), NULL);
   HWND h3 = FindWindowEx(h2, NULL, __TEXT("SysTabControl32"), NULL);

   // Create a new popup menu
   HMENU hmenu = CreatePopupMenu();

   // Get the currently selected button in the tab control
   int i = TabCtrl_GetCurSel(h3);

   // If no tab is selected show a menu with a sole 'Close' item
   if(i == -1)
      AppendMenu(hmenu, MF_STRING, IDC_DELETETAB, __TEXT("&Close"));
   else
   {
      AppendMenu(hmenu, MF_STRING, IDC_RESTART, __TEXT("&Restart the shell"));
      AppendMenu(hmenu, MF_STRING, IDC_RETRIEVE, __TEXT("Re&trieve Taskbar Settings"));
      AppendMenu(hmenu, MF_SEPARATOR, 0, NULL);
      AppendMenu(hmenu, MF_STRING, IDC_DELETETAB, __TEXT("&Delete Me"));
   }

   // Find out the position for the menu. It depends upon the taskbar's edge
   STARTMENUPOS smp;
   if(i == -1)
   {
      POINT pt;
      GetCursorPos(&pt);
      smp.ix = pt.x;
      smp.iy = pt.y;
      smp.uFlags = TPM_BOTTOMALIGN;
   }
   else
      GetMenuPosition(h3, i, &smp);

   // Display and then destroy the menu
   TrackPopupMenu(hmenu, smp.uFlags, smp.ix, smp.iy, 0, g_hDlg, 0);
   DestroyMenu(hmenu);
}


int GetMenuPosition(HWND hwndTab, int iItem, LPSTARTMENUPOS lpsmp)
{
   // Set and then reset the size to get current width and height of button
   long iItemSize = TabCtrl_SetItemSize(hwndTab, 0, 0);
   TabCtrl_SetItemSize(hwndTab, LOWORD(iItemSize), HIWORD(iItemSize));

   // Get the tab control rectangle
   RECT r;
   GetWindowRect(hwndTab, &r);

   // Retrieve the taskbar's edge
   APPBARDATA abd;
   abd.cbSize = sizeof(APPBARDATA);
   SHAppBarMessage(ABM_GETTASKBARPOS, &abd);
   switch(abd.uEdge)
   {
   case ABE_BOTTOM:
      lpsmp->ix = r.left + LOWORD(iItemSize) * iItem + 3;
      lpsmp->iy = abd.rc.top;
      lpsmp->uFlags = TPM_LEFTALIGN | TPM_BOTTOMALIGN;
      break;

   case ABE_TOP:
      lpsmp->ix = r.left + LOWORD(iItemSize) * iItem + 3;
      lpsmp->iy = abd.rc.bottom;
      lpsmp->uFlags = TPM_LEFTALIGN | TPM_TOPALIGN;
      break;

   case ABE_LEFT:
      lpsmp->ix = abd.rc.right;
      lpsmp->iy = r.top + HIWORD(iItemSize) * iItem + 3;
      lpsmp->uFlags = TPM_LEFTALIGN | TPM_TOPALIGN;
      break;

   case ABE_RIGHT:
      lpsmp->ix = abd.rc.left;
      lpsmp->iy = r.top + HIWORD(iItemSize) * iItem + 3;
      lpsmp->uFlags = TPM_RIGHTALIGN | TPM_TOPALIGN;
      break;
   }

   return 1;
}

/*  End of file: Taskbar.cpp  */
