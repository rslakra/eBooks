/*****************************************************************
*
*  Application.:  SHHELPER.dll
*  Module......:  SHHelper.cpp
*  Description.:  DLL main module
*  Compiler....:  MS Visual C++
*  Written by..:  D. Esposito
*
*******************************/

/*---------------------------------------------------------------*/
//                        PRAGMA section
/*---------------------------------------------------------------*/
#ifdef _MSC_VER
   #pragma comment(lib, "kernel32.lib")
   #pragma comment(lib, "user32.lib")
   #pragma comment(lib, "gdi32.lib")
   #pragma comment(lib, "shell32.lib")
   #pragma comment(lib, "comctl32.lib")
   #pragma comment(lib, "comdlg32.lib")
#endif

/*---------------------------------------------------------------*/
//                        INCLUDE section
/*---------------------------------------------------------------*/
#include "SHHelper.h"
#include <shlobj.h>
#include "resource.h"
#include <commdlg.h>
#include <shellapi.h>

/*---------------------------------------------------------------*/
//                        GLOBAL section
/*---------------------------------------------------------------*/
HINSTANCE g_hThisDll;
TCHAR g_szFileName[MAX_PATH];
HIMAGELIST g_himl;
HICON g_hIcon;
int g_iIconIndex;

/*---------------------------------------------------------------*/
// Procedure....: DllMain()
// Description..: Library main function
// Input........: HINSTANCE, DWORD, LPVOID
// Output.......: int
/*---------------------------------------------------------------*/
int APIENTRY DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
   switch(dwReason)
   {
   case DLL_PROCESS_ATTACH:
      g_hThisDll = hInstance;
      break;
   }

   return TRUE;
}


int SHBrowseForIcon(LPTSTR szFile, HICON* lphIcon)
{
   // The function assumes default-sized icons (usually 32 x 32)
   int cx = GetSystemMetrics(SM_CXICON);
   int cy = GetSystemMetrics(SM_CYICON);

   lstrcpy(g_szFileName, szFile);
   g_himl = ImageList_Create(cx, cy, ILC_MASK, 1, 1);

   DialogBox(g_hThisDll, MAKEINTRESOURCE(IDD_BROWSEICON), GetFocus(), BrowseIconProc);

   // Free the image list
   ImageList_Destroy(g_himl);

   // Set the return values. (The file might have changed)
   *lphIcon = g_hIcon;
   lstrcpy(szFile, g_szFileName);

   // This index has been set by the dialog procedure
   return g_iIconIndex;
}

BOOL CALLBACK BrowseIconProc(HWND hDlg, UINT uiMsg, WPARAM wParam, LPARAM lParam)
{
   switch(uiMsg)
   {
   case WM_INITDIALOG:
      OnInitDialog(hDlg);
      break;

   case WM_COMMAND:
      switch(wParam)
      {
      case IDC_BROWSE:
         OnBrowse(hDlg);
         break;

      case IDCANCEL:
         EndDialog(hDlg, FALSE);
         return FALSE;

      case IDOK:
         DoGetIcon(hDlg);
         EndDialog(hDlg, TRUE);
         return FALSE;
      }
   }

   return FALSE;
}


void OnInitDialog(HWND hDlg)
{
   HWND hwndList = GetDlgItem(hDlg, IDC_LIST);
   SetDlgItemText(hDlg, IDC_FILENAME, g_szFileName);

   ListView_SetImageList(hwndList, g_himl, LVSIL_NORMAL);
   DoLoadIcons(hDlg, g_szFileName);
}


void OnBrowse(HWND hDlg)
{
   TCHAR szWinDir[MAX_PATH] = {0};
   TCHAR szFile[MAX_PATH] = {0};

   // Browse for files...
   OPENFILENAME ofn;
   ZeroMemory(&ofn, sizeof(OPENFILENAME));
   ofn.lStructSize = sizeof(OPENFILENAME);
   ofn.lpstrFilter = __TEXT("Icons\0*.exe;*.dll;*.ico\0");
   ofn.nMaxFile = MAX_PATH;
   GetWindowsDirectory(szWinDir, MAX_PATH);
   ofn.lpstrInitialDir = szWinDir;
   ofn.lpstrFile = szFile;
   if(!GetOpenFileName(&ofn))
      return;

   SetDlgItemText(hDlg, IDC_FILENAME, ofn.lpstrFile);
   DoLoadIcons(hDlg, ofn.lpstrFile);
   lstrcpy(g_szFileName, ofn.lpstrFile);
}


int DoLoadIcons(HWND hDlg, LPTSTR szFileName)
{
   TCHAR szStatus[30] = {0};

   // Get the number of icons
   int iNumOfIcons = reinterpret_cast<int>(ExtractIcon(g_hThisDll, szFileName, -1));

   // Update user interface
   HWND hwndList = GetDlgItem(hDlg, IDC_LIST);
   ListView_DeleteAllItems(hwndList);
   wsprintf(szStatus, __TEXT("%d icon(s) found."), iNumOfIcons);
   SetDlgItemText(hDlg, IDC_ICONCOUNT, szStatus);

   // Fill the image list and the list view at the same time
   for(int i = 0 ; i < iNumOfIcons ; i++)
   {
      HICON hIcon = ExtractIcon(g_hThisDll, szFileName, i);
      int iIndex = ImageList_AddIcon(g_himl, hIcon);

      // Add to the list view
      LV_ITEM lvi;
      ZeroMemory(&lvi, sizeof(LV_ITEM));
      lvi.mask = LVIF_IMAGE;
      lvi.iItem = iIndex;
      lvi.iImage = iIndex;
      ListView_InsertItem(hwndList, &lvi);
   }

   return iNumOfIcons;
}


void DoGetIcon(HWND hDlg)
{
   HWND hwndList = GetDlgItem(hDlg, IDC_LIST);

   // Get the index of the list view's selected item
   g_iIconIndex = -1;
   int i = ListView_GetNextItem(hwndList, -1, LVNI_SELECTED);
   if(i == -1)
      return;
   g_iIconIndex = i;

   // Get information about the selected item
   LV_ITEM lvi;
   ZeroMemory(&lvi, sizeof(LV_ITEM));
   lvi.mask = LVIF_IMAGE;
   lvi.iItem = i;
   ListView_GetItem(hwndList, &lvi);

   // Get the image list index of the icon and return the HICON
   g_hIcon = ImageList_GetIcon(g_himl, lvi.iImage, 0);
}

/*  End of module: SHHelper.cpp  */
