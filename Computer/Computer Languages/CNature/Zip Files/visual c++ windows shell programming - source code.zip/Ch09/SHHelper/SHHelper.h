/*****************************************************************
*
*  Application.:  SHHELPER.dll
*  Module......:  SHHelper.cpp
*  Description.:  Library header
*  Compiler....:  MS Visual C++
*  Written by..:  D. Esposito
*
*******************************/

/*---------------------------------------------------------------*/
//                     INCLUDE section
/*---------------------------------------------------------------*/
#define WIN32_LEAN_AND_MEAN
#define STRICT

#include <windows.h>
#include <windowsx.h>

/*---------------------------------------------------------------*/
//                     INCLUDE section
/*---------------------------------------------------------------*/
extern HINSTANCE g_hThisDll;


/*---------------------------------------------------------------*/
//                     PROTOTYPES section
/*---------------------------------------------------------------*/

int SHBrowseForIcon(LPTSTR szFile, HICON* lphIcon);
BOOL CALLBACK BrowseIconProc(HWND, UINT, WPARAM, LPARAM);
void OnInitDialog(HWND);
void OnBrowse(HWND);
int DoLoadIcons(HWND, LPTSTR);
void DoGetIcon(HWND);

/*  End of file: SHHelper.h  */
