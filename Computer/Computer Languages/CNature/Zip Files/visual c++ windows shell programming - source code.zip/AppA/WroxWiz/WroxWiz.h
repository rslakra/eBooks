#if !defined(AFX_WROXWIZ_H__02F6C287_6E54_11D2_9DAF_00104B4C822A__INCLUDED_)
#define AFX_WROXWIZ_H__02F6C287_6E54_11D2_9DAF_00104B4C822A__INCLUDED_

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

// TODO: You may add any other custom AppWizard-wide declarations here.
const TCHAR AW_DEFAULT_APPNAME[] = _T("Wrox AppWizard");
const TCHAR AW_DEFAULT_AUTHOR[] = _T("D. Esposito");

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WROXWIZ_H__02F6C287_6E54_11D2_9DAF_00104B4C822A__INCLUDED_)
