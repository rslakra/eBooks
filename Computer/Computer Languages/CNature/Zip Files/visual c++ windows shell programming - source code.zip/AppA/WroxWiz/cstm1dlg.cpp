// cstm1dlg.cpp : implementation file
//

#include "stdafx.h"
#include "WroxWiz.h"
#include "cstm1dlg.h"
#include "WroxWizaw.h"
#include "Chooser.h"         // For LAST_DLG

#ifdef _PSEUDO_DEBUG
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCustom1Dlg dialog


CCustom1Dlg::CCustom1Dlg()
	: CAppWizStepDlg(CCustom1Dlg::IDD)
{
	//{{AFX_DATA_INIT(CCustom1Dlg)
	m_szAppName = AW_DEFAULT_APPNAME;
	m_szAuthor = AW_DEFAULT_AUTHOR;
	//}}AFX_DATA_INIT

    WroxWizaw.m_Dictionary[_T("APPNAME")] = AW_DEFAULT_APPNAME;
    WroxWizaw.m_Dictionary[_T("AUTHOR")] = AW_DEFAULT_AUTHOR;
    WroxWizaw.m_Dictionary[_T("TYPE_DIALOG")] = _T("Yes");
}


void CCustom1Dlg::DoDataExchange(CDataExchange* pDX)
{
	CAppWizStepDlg::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCustom1Dlg)
	DDX_Text(pDX, IDC_APPNAME, m_szAppName);
	DDV_MaxChars(pDX, m_szAppName, 40);
	DDX_Text(pDX, IDC_AUTHOR, m_szAuthor);
	DDV_MaxChars(pDX, m_szAuthor, 40);
	//}}AFX_DATA_MAP
}

// This is called whenever the user presses Next, Back, or Finish with this step
//  present.  Do all validation & data exchange from the dialog in this function.
BOOL CCustom1Dlg::OnDismiss()
{
	if (!UpdateData(TRUE))
		return FALSE;

	// TODO: Set template variables based on the dialog's data.
    WroxWizaw.m_Dictionary[_T("APPNAME")] = m_szAppName;
    WroxWizaw.m_Dictionary[_T("AUTHOR")] = m_szAuthor;

	return TRUE;	// return FALSE if the dialog shouldn't be dismissed
}


BEGIN_MESSAGE_MAP(CCustom1Dlg, CAppWizStepDlg)
	//{{AFX_MSG_MAP(CCustom1Dlg)
	ON_BN_CLICKED(IDC_DIALOG, OnDialog)
	ON_BN_CLICKED(IDC_DLL, OnDll)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CCustom1Dlg message handlers

void CCustom1Dlg::OnDialog() 
{
   WroxWizaw.m_Dictionary.RemoveKey(_T("PROJTYPE_DLL"));
   WroxWizaw.m_Dictionary[_T("TYPE_DIALOG")] = _T("Yes");
   WroxWizaw.m_Dictionary.RemoveKey(_T("TYPE_DLL"));

   GetDlgItem(IDC_APPNAME)->EnableWindow(TRUE);

   // We make sure the chooser knows the Wizard has 2 steps
   // This is in case we passed for the next handler.
   SetNumberOfSteps(LAST_DLG);
}

void CCustom1Dlg::OnDll() 
{
   WroxWizaw.m_Dictionary[_T("PROJTYPE_DLL")] = _T("Yes");
   WroxWizaw.m_Dictionary[_T("TYPE_DLL")] = _T("Yes");
   WroxWizaw.m_Dictionary.RemoveKey(_T("TYPE_DIALOG"));

   GetDlgItem(IDC_APPNAME)->EnableWindow(FALSE);
   
   // Tell the chooser the Wizard now has just 1 step. This
   // causes the Next> button to gray, skipping the Common Controls page.
   SetNumberOfSteps(1);
}

BOOL CCustom1Dlg::OnInitDialog() 
{
	CAppWizStepDlg::OnInitDialog();
	
    // Local data
    CStatic* pStatic = NULL;

    // Bitmap initialization
    pStatic = static_cast<CStatic*>(GetDlgItem(IDC_IMAGE));
    pStatic->SetBitmap(static_cast<HBITMAP>(WroxWizaw.m_bmpPicture));
    pStatic = static_cast<CStatic*>(GetDlgItem(IDC_WROXLOGO));
    pStatic->SetBitmap(static_cast<HBITMAP>(WroxWizaw.m_bmpLogo));

    // Radio button initialization
    CheckRadioButton(IDC_DIALOG, IDC_DLL, IDC_DIALOG);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
