//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by WroxWiz.rc
//
#define IDI_WROXWIZ                     1
#define IDD_CUSTOM1                     129
#define IDD_CUSTOM2                     130
#define IDB_IMAGE                       132
#define IDB_WROXLOGO                    133
#define IDC_IMAGE                       1000
#define IDC_WROXLOGO                    1001
#define IDC_DIALOG                      1006
#define IDC_DLL                         1007
#define IDC_APPNAME                     1008
#define IDC_AUTHOR                      1009
#define IDC_USECC                       1010
#define IDC_WIN95                       1011
#define IDC_WIN98                       1012
#define IDC_UTILS                       1013
#define IDC_SHELLAPI                    1014

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
