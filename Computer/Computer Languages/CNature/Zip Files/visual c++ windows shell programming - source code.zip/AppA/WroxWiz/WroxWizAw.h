#if !defined(AFX_WROXWIZAW_H__02F6C28B_6E54_11D2_9DAF_00104B4C822A__INCLUDED_)
#define AFX_WROXWIZAW_H__02F6C28B_6E54_11D2_9DAF_00104B4C822A__INCLUDED_

// WroxWizaw.h : header file
//

class CDialogChooser;

// All function calls made by mfcapwz.dll to this custom AppWizard (except for
//  GetCustomAppWizClass-- see WroxWiz.cpp) are through this class.  You may
//  choose to override more of the CCustomAppWiz virtual functions here to
//  further specialize the behavior of this custom AppWizard.
class CWroxWizAppWiz : public CCustomAppWiz
{
public:
	virtual CAppWizStepDlg* Next(CAppWizStepDlg* pDlg);
	virtual CAppWizStepDlg* Back(CAppWizStepDlg* pDlg);
		
	virtual void InitCustomAppWiz();
	virtual void ExitCustomAppWiz();
	virtual void CustomizeProject(IBuildProject* pProject);

    // Custom data
    CBitmap m_bmpPicture;
    CBitmap m_bmpLogo;

protected:
	CDialogChooser* m_pChooser;
};

// This declares the one instance of the CWroxWizAppWiz class.  You can access
//  m_Dictionary and any other public members of this class through the
//  global WroxWizaw.  (Its definition is in WroxWizaw.cpp.)
extern CWroxWizAppWiz WroxWizaw;

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WROXWIZAW_H__02F6C28B_6E54_11D2_9DAF_00104B4C822A__INCLUDED_)
