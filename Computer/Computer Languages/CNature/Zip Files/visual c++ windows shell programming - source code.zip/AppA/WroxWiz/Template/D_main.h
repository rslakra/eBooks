/*****************************************************************
*
*  Application.:  $$ROOT$$.dll
*  Module......:  $$root$$.cpp
*  Description.:  Library header
*  Compiler....:  MS Visual C++
*  Written by..:  $$AUTHOR$$
*
*******************************/

/*---------------------------------------------------------------*/
//                     INCLUDE section
/*---------------------------------------------------------------*/
#define WIN32_LEAN_AND_MEAN
#define STRICT

#include <windows.h>
#include <windowsx.h>

/*---------------------------------------------------------------*/
//                     INCLUDE section
/*---------------------------------------------------------------*/
extern HINSTANCE g_hThisDll;

/*---------------------------------------------------------------*/
//                     PROTOTYPES section
/*---------------------------------------------------------------*/
// TODO:: list here all the constants, macros, typedefs, ...
// TODO:: list here all the exported functions


/*  End of file: $$Root$$.h  */
