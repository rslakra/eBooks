/*****************************************************************
*
*  Project.....:  $$APPNAME$$
*  Application.:  $$ROOT$$.exe
*  Module......:  $$ROOT$$.h
*  Description.:  Application main header
*  Compiler....:  MS Visual C++ 
*  Written by..:  $$AUTHOR$$
*  Environment.:  Windows 9x/NT
*
*******************************/

// Prevent multiple inclusions
#define WIN32_LEAN_AND_MEAN
#define STRICT

#ifndef _APP_DEFS_
#define _APP_DEFS_

/*---------------------------------------------------------------*/
//                        INCLUDE section
/*---------------------------------------------------------------*/
#include <windows.h>
#include <windowsx.h>
$$IF(ADDUTILS)
#include "SPBUtils.h" 
$$ENDIF

#endif   // _APP_DEFS_


/*  End of file: $$root$$.h  */
