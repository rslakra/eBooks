/*****************************************************************
*
*  Application.:  $$ROOT$$.dll
*  Module......:  $$root$$.cpp
*  Description.:  DLL main module
*  Compiler....:  MS Visual C++
*  Written by..:  $$AUTHOR$$
*
*******************************/

/*---------------------------------------------------------------*/
//                        PRAGMA section
/*---------------------------------------------------------------*/
#ifdef _MSC_VER
   #pragma comment(lib, "kernel32.lib")
   #pragma comment(lib, "user32.lib")
   #pragma comment(lib, "gdi32.lib")
   #pragma comment(lib, "shell32.lib")
#endif

/*---------------------------------------------------------------*/
//                        INCLUDE section
/*---------------------------------------------------------------*/
#include "$$root$$.h"

/*---------------------------------------------------------------*/
//                        GLOBAL section
/*---------------------------------------------------------------*/
HINSTANCE g_hThisDll;


/*---------------------------------------------------------------*/
// Procedure....: DllMain()
// Description..: Library main function
// Input........: HINSTANCE, DWORD, LPVOID
// Output.......: int
/*---------------------------------------------------------------*/
int APIENTRY DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
   switch(dwReason)
   {
   case DLL_PROCESS_ATTACH:
      g_hThisDll = hInstance;
      break;
   }

   return TRUE;
}


/*  End of module: $$Root$$.cpp  */
