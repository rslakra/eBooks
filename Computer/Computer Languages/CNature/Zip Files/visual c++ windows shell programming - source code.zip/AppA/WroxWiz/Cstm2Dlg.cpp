// cstm2dlg.cpp : implementation file
//

#include "stdafx.h"
#include "WroxWiz.h"
#include "cstm2dlg.h"
#include "WroxWizaw.h"

#ifdef _PSEUDO_DEBUG
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCustom2Dlg dialog


CCustom2Dlg::CCustom2Dlg()
	: CAppWizStepDlg(CCustom2Dlg::IDD)
{
	//{{AFX_DATA_INIT(CCustom2Dlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

    WroxWizaw.m_Dictionary[_T("USECC")] = _T("Yes");
    WroxWizaw.m_Dictionary[_T("USECC95")] = _T("Yes");
    WroxWizaw.m_Dictionary[_T("ADDUTILS")] = _T("Yes");
    WroxWizaw.m_Dictionary[_T("ADDSHELLAPI")] = _T("Yes");
}


void CCustom2Dlg::DoDataExchange(CDataExchange* pDX)
{
	CAppWizStepDlg::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCustom2Dlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

// This is called whenever the user presses Next, Back, or Finish with this step
//  present.  Do all validation & data exchange from the dialog in this function.
BOOL CCustom2Dlg::OnDismiss()
{
	if (!UpdateData(TRUE))
		return FALSE;

	// TODO: Set template variables based on the dialog's data.

	return TRUE;	// return FALSE if the dialog shouldn't be dismissed
}


BEGIN_MESSAGE_MAP(CCustom2Dlg, CAppWizStepDlg)
	//{{AFX_MSG_MAP(CCustom2Dlg)
	ON_BN_CLICKED(IDC_WIN95, OnWin95)
	ON_BN_CLICKED(IDC_WIN98, OnWin98)
	ON_BN_CLICKED(IDC_USECC, OnUsecc)
	ON_BN_CLICKED(IDC_UTILS, OnUtils)
	ON_BN_CLICKED(IDC_SHELLAPI, OnShellapi)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CCustom2Dlg message handlers

void CCustom2Dlg::OnWin95() 
{
   WroxWizaw.m_Dictionary[_T("USECC95")] = _T("Yes");
   WroxWizaw.m_Dictionary.RemoveKey(_T("USECC98"));
}

void CCustom2Dlg::OnWin98() 
{
   WroxWizaw.m_Dictionary[_T("USECC98")] = _T("Yes");
   WroxWizaw.m_Dictionary.RemoveKey(_T("USECC95"));
}

void CCustom2Dlg::OnUsecc() 
{
   BOOL bState = IsDlgButtonChecked(IDC_USECC);

   GetDlgItem(IDC_WIN95)->EnableWindow(bState);
   GetDlgItem(IDC_WIN98)->EnableWindow(bState);

   if(bState)
      WroxWizaw.m_Dictionary[_T("USECC")] = _T("Yes");
   else
      WroxWizaw.m_Dictionary.RemoveKey(_T("USECC"));   // Key must be removed
}

void CCustom2Dlg::OnUtils() 
{
   BOOL bState = IsDlgButtonChecked(IDC_UTILS);

   if(bState)
      WroxWizaw.m_Dictionary[_T("ADDUTILS")] = _T("Yes");
   else
      WroxWizaw.m_Dictionary.RemoveKey(_T("ADDUTILS"));   // Key must be removed
}

void CCustom2Dlg::OnShellapi() 
{
   BOOL bState = IsDlgButtonChecked(IDC_SHELLAPI);

   if(bState)
      WroxWizaw.m_Dictionary[_T("ADDSHELLAPI")] = _T("Yes");
   else
      WroxWizaw.m_Dictionary.RemoveKey(_T("ADDSHELLAPI"));
}

BOOL CCustom2Dlg::OnInitDialog() 
{
	CAppWizStepDlg::OnInitDialog();
	
    // Local data
    CStatic* pStatic = NULL;

    // Bitmap initialization
    pStatic = static_cast<CStatic*>(GetDlgItem(IDC_IMAGE));
    pStatic->SetBitmap(static_cast<HBITMAP>(WroxWizaw.m_bmpPicture));
    pStatic = static_cast<CStatic*>(GetDlgItem(IDC_WROXLOGO));
    pStatic->SetBitmap(static_cast<HBITMAP>(WroxWizaw.m_bmpLogo));

    // Radio and check button initialization
    CheckDlgButton(IDC_USECC, TRUE);
    CheckDlgButton(IDC_UTILS, TRUE);
    CheckDlgButton(IDC_SHELLAPI, TRUE);

    CheckRadioButton(IDC_WIN95, IDC_WIN98, IDC_WIN95);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
