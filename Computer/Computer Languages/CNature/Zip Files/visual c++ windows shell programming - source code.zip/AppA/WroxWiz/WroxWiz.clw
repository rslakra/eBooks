; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CCustom2Dlg
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "WroxWiz.h"

ClassCount=2
Class1=CCustom1Dlg
Class2=CCustom2Dlg

ResourceCount=2
Resource1=IDD_CUSTOM1
Resource2=IDD_CUSTOM2


[CLS:CCustom1Dlg]
Type=0
HeaderFile=cstm1dlg.h
ImplementationFile=cstm1dlg.cpp
Filter=D
BaseClass=CAppWizStepDlg
VirtualFilter=dWC
LastObject=CCustom1Dlg

[DLG:IDD_CUSTOM1]
Type=1
Class=CCustom1Dlg
ControlCount=10
Control1=IDC_IMAGE,static,1342183438
Control2=IDC_WROXLOGO,static,1342179342
Control3=IDC_STATIC,button,1342177287
Control4=IDC_STATIC,static,1342177280
Control5=IDC_DIALOG,button,1342308361
Control6=IDC_DLL,button,1342177289
Control7=IDC_STATIC,static,1342308352
Control8=IDC_APPNAME,edit,1350631552
Control9=IDC_STATIC,static,1342308352
Control10=IDC_AUTHOR,edit,1350631552

[CLS:CCustom2Dlg]
Type=0
HeaderFile=cstm2dlg.h
ImplementationFile=cstm2dlg.cpp
Filter=D
BaseClass=CAppWizStepDlg
VirtualFilter=dWC
LastObject=CCustom2Dlg

[DLG:IDD_CUSTOM2]
Type=1
Class=CCustom2Dlg
ControlCount=9
Control1=IDC_IMAGE,static,1342183438
Control2=IDC_WROXLOGO,static,1342179342
Control3=IDC_STATIC,static,1342308352
Control4=IDC_STATIC,button,1342177287
Control5=IDC_USECC,button,1342252035
Control6=IDC_WIN95,button,1342308361
Control7=IDC_WIN98,button,1342177289
Control8=IDC_UTILS,button,1342242819
Control9=IDC_SHELLAPI,button,1342242819

