#if !defined(AFX_CSTM2DLG_H__02F6C29A_6E54_11D2_9DAF_00104B4C822A__INCLUDED_)
#define AFX_CSTM2DLG_H__02F6C29A_6E54_11D2_9DAF_00104B4C822A__INCLUDED_

// cstm2dlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCustom2Dlg dialog

class CCustom2Dlg : public CAppWizStepDlg
{
// Construction
public:
	CCustom2Dlg();
	virtual BOOL OnDismiss();

// Dialog Data
	//{{AFX_DATA(CCustom2Dlg)
	enum { IDD = IDD_CUSTOM2 };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCustom2Dlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CCustom2Dlg)
	afx_msg void OnWin95();
	afx_msg void OnWin98();
	afx_msg void OnUsecc();
	afx_msg void OnUtils();
	afx_msg void OnShellapi();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CSTM2DLG_H__02F6C29A_6E54_11D2_9DAF_00104B4C822A__INCLUDED_)
