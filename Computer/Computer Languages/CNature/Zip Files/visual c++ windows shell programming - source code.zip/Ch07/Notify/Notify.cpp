/*****************************************************************
*
*  Project.....:  Shell Notifications
*  Application.:  NOTIFY.exe
*  Module......:  NOTIFY.cpp
*  Description.:  Application main module
*  Compiler....:  MS Visual C++
*  Written by..:  D. Esposito
*  Environment.:  Windows 9x/NT
*
******************************************************************/

/*---------------------------------------------------------------*/
//                        PRAGMA section
/*---------------------------------------------------------------*/
// Force the linker to add the following libraries.
#ifdef _MSC_VER

#pragma comment(lib, "kernel32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "comctl32.lib")

#endif

/*---------------------------------------------------------------*/
//                        INCLUDE section
/*---------------------------------------------------------------*/
#include "Notify.h"
#include <commctrl.h>
#include <shellapi.h> 
#include "resource.h"

/*---------------------------------------------------------------*/
//                        GLOBAL section
/*---------------------------------------------------------------*/
// Data
HICON g_hIconLarge;
HICON g_hIconSmall;
bool g_bContinue;   // Should be set to false in WinMain()

const int WM_EX_CHANGENOTIFICATION = WM_APP + 1;

// Custom data to be passed to the thread
struct CUSTOMINFO
{
   HWND hWnd;
   TCHAR pszDir[MAX_PATH];
};

typedef CUSTOMINFO* LPCUSTOMINFO;

// Functions
void OnInitDialog(HWND);
void OnOK(HWND);

HANDLE SHInstallNotifier(HWND, LPCTSTR);
DWORD WINAPI Notify(LPVOID);
void UpdateView(HWND);
void MakeReportView(HWND, LPTSTR*, int);
void AddStringToReportView(HWND, LPTSTR, int);

// Callbacks
BOOL CALLBACK APP_DlgProc(HWND, UINT, WPARAM, LPARAM);


/*---------------------------------------------------------------*/
// Procedure....: WinMain()
// Description..: Entry point in any Windows program
// Input........: HINSTANCE, HINSTANCE, LPSTR, int
// Output.......: int
/*---------------------------------------------------------------*/
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevious, 
                     LPTSTR lpsz, int iCmd)
{
   // Save global data
   g_hIconLarge = static_cast<HICON>(
              LoadImage(hInstance, "APP_ICON", IMAGE_ICON,
              GetSystemMetrics(SM_CXICON), GetSystemMetrics(SM_CXICON), 0));
   g_hIconSmall = static_cast<HICON>(
              LoadImage(hInstance, "APP_ICON", IMAGE_ICON,
              GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CXSMICON), 0));
   g_bContinue = false;

   // Enable common controls
   INITCOMMONCONTROLSEX iccex;
   iccex.dwSize = sizeof(INITCOMMONCONTROLSEX);
   iccex.dwICC = ICC_WIN95_CLASSES;
   InitCommonControlsEx(&iccex);

   // Run main dialog
   BOOL b = DialogBox(hInstance, "DLG_MAIN", NULL, APP_DlgProc);

   // Exit
   DestroyIcon(g_hIconLarge);
   DestroyIcon(g_hIconSmall);
   return b;
}


/*---------------------------------------------------------------*/
// Procedure....: APP_DlgProc()
// Description..: Responds to all messages sent to the dialog
// Input........: HWND, UINT, WPARAM, LPARAM
// Output.......: BOOL
/*---------------------------------------------------------------*/
BOOL CALLBACK APP_DlgProc(HWND hDlg, UINT uiMsg, WPARAM wParam, LPARAM lParam)
{
   switch(uiMsg)
   {
   case WM_INITDIALOG:
      OnInitDialog(hDlg);
      break;

   case WM_EX_CHANGENOTIFICATION:
      UpdateView(hDlg);
      break;

   case WM_COMMAND:
      switch(wParam)
      {
      case IDOK:
         OnOK(hDlg);
         return FALSE;

      case IDCANCEL:
         g_bContinue = false;
         EndDialog(hDlg, FALSE);
         return FALSE;
      }
      break;
   }

   return FALSE;
}


/*****************************************************************
*
*  Internals:
*    - OnOK()
*    - OnInitDialog()
*
******************************************************************/

/*---------------------------------------------------------------*/
// Procedure...: OnOK()
// Description.: Do something
// INPUT.......: HWND
// OUTPUT......: void
/*---------------------------------------------------------------*/
void OnOK(HWND hDlg)
{
   TCHAR szDir[MAX_PATH] = {0};
   GetDlgItemText(hDlg, IDC_EDIT, szDir, MAX_PATH);
   SHInstallNotifier(hDlg, szDir); 
}


/*---------------------------------------------------------------*/
// Procedure...: OnInitDialog()
// Description.: Initialize the dialog
// INPUT.......: HWND
// OUTPUT......: void
/*---------------------------------------------------------------*/
void OnInitDialog(HWND hDlg)
{
   // Set the icons (T/F as to Large/Small icon)
   SendMessage(hDlg, WM_SETICON, FALSE, reinterpret_cast<LPARAM>(g_hIconSmall));
   SendMessage(hDlg, WM_SETICON, TRUE, reinterpret_cast<LPARAM>(g_hIconLarge));

   LPTSTR psz[] = {__TEXT("Date and Time"), reinterpret_cast<LPTSTR>(400)};
   MakeReportView(GetDlgItem(hDlg, IDC_LIST), psz, 1);
}


HANDLE SHInstallNotifier(HWND hwndParent, LPCTSTR pszDir)
{
   DWORD dwID = 0;

   CUSTOMINFO ci;
   ZeroMemory(&ci, sizeof(CUSTOMINFO));
   ci.hWnd = hwndParent;
   lstrcpy(ci.pszDir, pszDir);

   // Create a new worker thread
   g_bContinue = true;
   HANDLE hThread = CreateThread(NULL, 0, Notify, &ci, 0, &dwID);

   return hThread;
}


DWORD WINAPI Notify(LPVOID lpv)
{
   CUSTOMINFO ci;
   ci.hWnd = static_cast<LPCUSTOMINFO>(lpv)->hWnd;
   lstrcpy(ci.pszDir, static_cast<LPCUSTOMINFO>(lpv)->pszDir);

   HANDLE hNotify = FindFirstChangeNotification(ci.pszDir, TRUE,
                   FILE_NOTIFY_CHANGE_FILE_NAME | FILE_NOTIFY_CHANGE_DIR_NAME |
                   FILE_NOTIFY_CHANGE_ATTRIBUTES | FILE_NOTIFY_CHANGE_SIZE);
   if(hNotify == INVALID_HANDLE_VALUE)
   {
      SPB_SystemMessage(GetLastError());
      return 0;
   }

   while(g_bContinue)
   {
      WaitForSingleObject(hNotify, INFINITE);
      PostMessage(ci.hWnd, WM_EX_CHANGENOTIFICATION, 0, 0);
      FindNextChangeNotification(hNotify);
   }

   FindCloseChangeNotification(hNotify);
   return 1;
}


void UpdateView(HWND hDlg)
{
   TCHAR szTime[100] = {0};

   HWND hwndList = GetDlgItem(hDlg,IDC_LIST);
   GetTimeFormat(LOCALE_SYSTEM_DEFAULT, 0, NULL, NULL, szTime, 100);
   AddStringToReportView(hwndList, szTime, 1);
}


void MakeReportView(HWND hwndList, LPTSTR* psz, int iNumOfCols)
{
   RECT rc;

   DWORD dwStyle = GetWindowStyle(hwndList);
   SetWindowLong(hwndList, GWL_STYLE, dwStyle | LVS_REPORT);
   GetClientRect(hwndList, &rc);

   // Handle pairs of entries. Array size is assumed to be 2 * iNumOfCols
   for(int i = 0 ; i < 2 * iNumOfCols ; i = i + 2)
   {
      LV_COLUMN lvc;
      ZeroMemory(&lvc, sizeof(LV_COLUMN));
      lvc.mask = LVCF_TEXT | LVCF_WIDTH;
      lvc.pszText = psz[i];
      if(reinterpret_cast<int>(psz[i + 1]) == 0)
         lvc.cx = rc.right / iNumOfCols;
      else
         lvc.cx = reinterpret_cast<int>(psz[i + 1]);

      ListView_InsertColumn(hwndList, i, &lvc);
   }
   return;
}


void AddStringToReportView(HWND hwndList, LPTSTR psz, int iNumOfCols)
{
   LV_ITEM lvi;
   ZeroMemory(&lvi, sizeof(LV_ITEM));
   lvi.mask = LVIF_TEXT;
   lvi.pszText = psz;
   lvi.cchTextMax = lstrlen(psz);
   lvi.iItem = 0;
   ListView_InsertItem(hwndList, &lvi);

   // Other columns
   for(int i = 1 ; i < iNumOfCols ; i++)
   {
      psz += lstrlen(psz) + 1;
      ListView_SetItemText(hwndList, 0, i, psz);
   }
   return;
}

/*  End of file: Notify.cpp  */
