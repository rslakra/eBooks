/*****************************************************************
*
*  Application.:  EXPHOOK.dll
*  Module......:  ExpHook.cpp
*  Description.:  DLL main module
*  Compiler....:  MS Visual C++
*  Written by..:  D. Esposito
*
*******************************/

/*---------------------------------------------------------------*/
//                        PRAGMA section
/*---------------------------------------------------------------*/
#ifdef _MSC_VER
   #pragma comment(lib, "kernel32.lib")
   #pragma comment(lib, "user32.lib")
   #pragma comment(lib, "gdi32.lib")
   #pragma comment(lib, "shell32.lib")
#endif

/*---------------------------------------------------------------*/
//                        INCLUDE section
/*---------------------------------------------------------------*/
#include "ExpHook.h"

/*---------------------------------------------------------------*/
//                        GLOBAL section
/*---------------------------------------------------------------*/
HINSTANCE g_hThisDll;


/*---------------------------------------------------------------*/
// Procedure....: DllMain()
// Description..: Library main function
// Input........: HINSTANCE, DWORD, LPVOID
// Output.......: int
/*---------------------------------------------------------------*/
int APIENTRY DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
   switch(dwReason)
   {
   case DLL_PROCESS_ATTACH:
      g_hThisDll = hInstance;
      break;
   }

   return TRUE;
}


// Sets up a hook to detect when Explorer starts
void APIENTRY ShellDll_Hook()
{
   g_hShellHook = SetWindowsHookEx(WH_CBT, ShellDll_MainHook, g_hThisDll, 0);
}


void APIENTRY ShellDll_Unhook()
{
   if(g_hKeybHook != NULL)
      UnhookWindowsHookEx(g_hKeybHook);

   if(g_hShellHook != NULL)
      UnhookWindowsHookEx(g_hShellHook);
}


LRESULT CALLBACK ShellDll_MainHook(int nCode, WPARAM wParam, LPARAM lParam)
{
   TCHAR szClass[MAX_PATH] = {0};

   // Typical beginning for any hook procedure
   if(nCode < 0)
      return CallNextHookEx(g_hShellHook, nCode, wParam, lParam);

   // The system is creating a window. Notice that the hook is invoked
   //  from within the code of both CreateWindow() and CreateWindowEx().
   // At this point the window already exists and its HWND is a valid one,
   //  even if we're still in the middle of the creation process.
   if(nCode == HCBT_CREATEWND)
   {
      // Get the HWND of the window
      HWND hwndExplorer = reinterpret_cast<HWND>(wParam);

      // Compare it to 'ExploreWClass' and install the keyboard hook
      GetClassName(hwndExplorer, szClass, MAX_PATH);
      if(!lstrcmpi(szClass, __TEXT("ExploreWClass")))
         InstallKeyboardHook(hwndExplorer);
   }

   return CallNextHookEx(g_hShellHook, nCode, wParam, lParam);
}


LRESULT CALLBACK ShellDll_KeybHook(int nCode, WPARAM wParam, LPARAM lParam)
{
   // Typical beginning for any hook procedure
   if(nCode < 0)
      return CallNextHookEx(g_hKeybHook, nCode, wParam, lParam);

   // Normally this code executes both when the key is pressed and released.
   // The information about the transition state is stored in the 2 most 
   // significant bits of lParam. In this way we process the key only once. 
   if((lParam & 0x80000000) || (lParam & 0x40000000))
      return CallNextHookEx(g_hKeybHook, nCode, wParam, lParam);

   if(wParam == VK_F12)
   {
      // Get the Explorer window handle and post the message
      g_hwndExplorer = FindWindow("ExploreWClass", NULL);
      PostMessage(g_hwndExplorer, WM_COMMAND, 29281, 0);
   }

   return CallNextHookEx(g_hKeybHook, nCode, wParam, lParam);
}


// Install a keyboard hook
void InstallKeyboardHook(HWND hwnd)
{
   g_hwndExplorer = hwnd;
   DWORD dwThread = GetWindowThreadProcessId(g_hwndExplorer, NULL);
   g_hKeybHook = SetWindowsHookEx(WH_KEYBOARD, ShellDll_KeybHook, g_hThisDll, dwThread);
}


/*  End of module: ExpHook.cpp  */
