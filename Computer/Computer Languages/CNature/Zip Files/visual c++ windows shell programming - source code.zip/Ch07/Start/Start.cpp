// Start.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include "start.h"
#include "resource.h"

HINSTANCE g_hInstance;
BOOL g_bInstalled = FALSE;
HBITMAP g_hbmStart = NULL;
BOOL g_bSubclassed = FALSE;
WNDPROC g_pfnStartProc = NULL;
HWND g_hwndTip = NULL;
TOOLINFO g_ti;
BOOL g_bAlreadyDrawn = FALSE;
BOOL g_bFirstTime = TRUE;

BOOL APIENTRY DllMain( HINSTANCE hInstance, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
   g_hInstance = hInstance;
   return TRUE;
}

/*---------------------------------------------------------------------------*/
// DllGetClassObject
// Main function for a COM in-proc object like this
/*---------------------------------------------------------------------------*/
STDAPI DllGetClassObject(REFCLSID rclsid, REFIID riid, LPVOID* ppv)
{
   InstallHandler();
   return CLASS_E_CLASSNOTAVAILABLE;
}


/*---------------------------------------------------------------------------*/
// DllCanUnloadNow
// Confirm the unload for a COM library
/*---------------------------------------------------------------------------*/
STDAPI DllCanUnloadNow()
{
   return (g_bInstalled ? S_FALSE : S_OK);
}


STDAPI DllRegisterServer()
{
   TCHAR szSubKey[MAX_PATH] = {0};
   TCHAR szCLSID[MAX_PATH] = {0};
   TCHAR szModule[MAX_PATH] = {0};
   HKEY hKey;
   DWORD dwDisp;

   // Set the CLSID
   lstrcpy(szCLSID, __TEXT("{20051998-0019-0005-1998-000000000000}"));

   // Get the module name
   GetModuleFileName(g_hInstance, szModule, MAX_PATH);

   // HKCR: CLSID\{...}
   wsprintf(szSubKey, __TEXT("CLSID\\%s"), szCLSID);
   LRESULT lResult = RegCreateKeyEx(HKEY_CLASSES_ROOT, szSubKey, 0, NULL,
                 REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &hKey, &dwDisp);
   if(lResult == NOERROR)
   {
      TCHAR szData[MAX_PATH] = {0};
      wsprintf(szData, __TEXT("Start Button"), szModule);
      lResult = RegSetValueEx(hKey, NULL, 0, REG_SZ,
                    reinterpret_cast<LPBYTE>(szData), lstrlen(szData) + 1);
      RegCloseKey(hKey);
   }

   // HKCR: CLSID\{...}\InProcServer32
   wsprintf(szSubKey, __TEXT("CLSID\\%s\\InProcServer32"), szCLSID);
   lResult = RegCreateKeyEx(HKEY_CLASSES_ROOT, szSubKey, 0, NULL,
                 REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &hKey, &dwDisp);
   if(lResult == NOERROR)
   {
      lResult = RegSetValueEx(hKey, NULL, 0, REG_SZ,
                reinterpret_cast<LPBYTE>(szModule), lstrlen(szModule) + 1);
      TCHAR szData[MAX_PATH] = {0};
      lstrcpy(szData, __TEXT("Apartment"));
      lResult = RegSetValueEx(hKey, __TEXT("ThreadingModel"), 0, REG_SZ,
                    reinterpret_cast<LPBYTE>(szData), lstrlen(szData) + 1);
      RegCloseKey(hKey);
   }

   return S_OK;
}


STDAPI DllUnregisterServer()
{
   TCHAR szSubKey[MAX_PATH] = {0};
   TCHAR szCLSID[MAX_PATH] = {0};
   TCHAR szModule[MAX_PATH] = {0};
   HKEY hKey;
   DWORD dwDisp;

   // Set the CLSID
   lstrcpy(szCLSID, __TEXT("{20051998-0019-0005-1998-000000000000}"));

   // Open HKCR
   LRESULT lResult = RegCreateKeyEx(HKEY_CLASSES_ROOT, "", 0, NULL,
                 REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &hKey, &dwDisp);
   if(lResult == NOERROR)
   {
      wsprintf(szSubKey, __TEXT("CLSID\\%s\\InProcServer32"), szCLSID);
      RegDeleteKey(hKey, szSubKey);
      wsprintf(szSubKey, __TEXT("CLSID\\%s"), szCLSID);
      RegDeleteKey(hKey, szSubKey);
      RegCloseKey(hKey);
   }

   return S_OK;
}


/*-------------------------------------------------------*/
// InstallHandler
// Replace the Start button and install the hooks
/*-------------------------------------------------------*/
void InstallHandler()
{
   if(g_bInstalled)
   {
      int irc = MessageBox(HWND_DESKTOP, 
          __TEXT("The extension is installed. Would you like to uninstall?"),
          __TEXT("Start"), MB_ICONQUESTION | MB_YESNO | MB_SETFOREGROUND);

      if(irc == IDYES)
         UninstallHandler();
      return;
   }

   // Remember whether the handler is installed
   g_bInstalled = TRUE;

   // Set a new Start button
   SetNewStartButton(TRUE);
}


void UninstallHandler()
{
   // Restore the Start settings
   SetNewStartButton(FALSE);

   // The handler is now uninstalled
   g_bInstalled = FALSE;

   // Restore the old tooltip text
   g_ti.lpszText = __TEXT("Click here to begin"); 
   SendMessage(g_hwndTip, TTM_UPDATETIPTEXT, 0, reinterpret_cast<LPARAM>(&g_ti));
}


HBITMAP NewStartBitmap(HWND hwndStart, BOOL fNew)
{
   if(!fNew)
   {
      if(g_hbmStart)
         SendMessage(hwndStart, BM_SETIMAGE, IMAGE_BITMAP, reinterpret_cast<LPARAM>(g_hbmStart));
  
      // Refresh the button to reflect the change
      SetWindowPos(hwndStart, NULL, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOMOVE | SWP_DRAWFRAME);
      return NULL;
   }
	
   // Save the current bitmap
   g_hbmStart = reinterpret_cast<HBITMAP>(SendMessage(hwndStart, BM_GETIMAGE, IMAGE_BITMAP, 0));

   // Load and set the new bitmap
   HBITMAP hbm = reinterpret_cast<HBITMAP>(LoadImage(g_hInstance, MAKEINTRESOURCE(IDB_NEWSTART), IMAGE_BITMAP, 0, 0, LR_DEFAULTSIZE));
   SendMessage(hwndStart, BM_SETIMAGE, IMAGE_BITMAP, reinterpret_cast<LPARAM>(hbm));

   // Refresh the button to reflect the change
   SetWindowPos(hwndStart, NULL, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOMOVE | SWP_DRAWFRAME);
   return g_hbmStart;
}

/*-------------------------------------------------------*/
// SetNewStartButton
// Replace/Restore the bitmap for the Start button
/*-------------------------------------------------------*/
void SetNewStartButton(BOOL fNew)
{
   // Get the handle to the Start button
   HWND hwndTray = FindWindowEx(NULL, NULL, "Shell_TrayWnd", NULL);
   HWND hwndStart = FindWindowEx(hwndTray, NULL, "Button", NULL); 

   // Change the bitmap
   g_hbmStart = NewStartBitmap(hwndStart, fNew);

   // Replace the tooltip text
   RemoveTooltip(hwndStart);

   // Subclass the button
   if(fNew)
   {
      if(!g_bSubclassed)
      {
         g_pfnStartProc = SubclassWindow(hwndStart, NewStartProc);
         g_bSubclassed = TRUE;
      }
   }
   else
   {
      if(g_pfnStartProc != NULL)
         SubclassWindow(hwndStart, g_pfnStartProc);
      g_bSubclassed = FALSE;
   }
}

LRESULT CALLBACK NewStartProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
   switch(uMsg)
   {
   case WM_SETCURSOR:
      SetCursor(LoadCursor(g_hInstance, MAKEINTRESOURCE(IDC_HANDY)));
      return 0;
   case WM_MEASUREITEM:
      MeasureItem(HWND_DESKTOP, reinterpret_cast<LPMEASUREITEMSTRUCT>(lParam));
      break;
   case WM_DRAWITEM:
      DrawItem(reinterpret_cast<LPDRAWITEMSTRUCT>(lParam));
      break;
   case WM_CONTEXTMENU:
      return 0; 
   case BM_SETSTATE:
   case WM_LBUTTONDOWN:
	  {
         WNDCLASS wc;
         GetClassInfo(NULL, "Button", &wc);
         CallWindowProc(wc.lpfnWndProc, hwnd, BM_SETSTATE, TRUE, 0);

         STARTMENUPOS smp;
         GetStartMenuPosition(&smp);
         HMENU hmnuPopup = GetMenuHandle("c:\\myStartMenu");
         int iCmd = TrackPopupMenu(hmnuPopup,
                                 smp.uFlags | TPM_RETURNCMD | TPM_NONOTIFY,
                                 smp.ix, smp.iy, 0, hwnd, NULL);

         // Handle the user's mouse clicks
         HandleResults(hmnuPopup, iCmd);

         // Free memory
         DestroyMenu(hmnuPopup);

         CallWindowProc(wc.lpfnWndProc, hwnd, BM_SETSTATE, FALSE, 0);
         return 0;
	  }
   }

   return CallWindowProc(g_pfnStartProc, hwnd, uMsg, wParam, lParam);
}


void RemoveTooltip(HWND hwndStart)
{
   EnumThreadWindows(GetCurrentThreadId(), EnumThreadWndProc, reinterpret_cast<LPARAM>(hwndStart));
}


// This thread created just one tooltip window. All the windows that belong
//  to the thread are enumerated in order to find the tooltip. This
//  callback receives the handle of all the windows the thread created. The
//  lParam is the handle (hwndStart) of the Start button.
BOOL CALLBACK EnumThreadWndProc(HWND hwnd, LPARAM lParam)
{
   TCHAR szClass[MAX_PATH] = {0};
   GetClassName(hwnd, szClass, MAX_PATH);
   if(0 == lstrcmpi(szClass, TOOLTIPS_CLASS))
   {
      // Tooltip window found, so try to locate the tool
      int iNumOfTools = SendMessage(hwnd, TTM_GETTOOLCOUNT, 0, 0);
      for(int i = 0 ; i < iNumOfTools ; i++)
      {
         // Get information about the ith tool
         TOOLINFO ti;
         g_hwndTip = hwnd;
         ti.cbSize = sizeof(TOOLINFO);
         SendMessage(hwnd, TTM_ENUMTOOLS, i, reinterpret_cast<LPARAM>(&ti));
         if(ti.uId == static_cast<UINT>(lParam))
         {
            // Tool for the Start button found.
            CopyMemory(&g_ti, &ti, sizeof(TOOLINFO));
            ti.lpszText = __TEXT("Buy this book!");
            SendMessage(hwnd, TTM_UPDATETIPTEXT, 0, reinterpret_cast<LPARAM>(&ti));
         }
      }
      return FALSE;
   }
   return TRUE;
}


void GetStartMenuPosition(LPSTARTMENUPOS lpsmp)
{
   // Get the taskbar's edge and position
   APPBARDATA abd;
   abd.cbSize = sizeof(APPBARDATA);
   SHAppBarMessage(ABM_GETTASKBARPOS, &abd);

   switch(abd.uEdge)
   {
   case ABE_BOTTOM:
      lpsmp->ix = 0;
      lpsmp->iy = abd.rc.top;
      lpsmp->uFlags = TPM_LEFTALIGN | TPM_BOTTOMALIGN;
      break;

   case ABE_TOP:
      lpsmp->ix = 0;
      lpsmp->iy = abd.rc.bottom;
      lpsmp->uFlags = TPM_LEFTALIGN | TPM_TOPALIGN;
      break;

   case ABE_LEFT:
      lpsmp->ix = abd.rc.right;
      lpsmp->iy = 0;
      lpsmp->uFlags = TPM_LEFTALIGN | TPM_TOPALIGN;
      break;

   case ABE_RIGHT:
      lpsmp->ix = abd.rc.left;
      lpsmp->iy = 0;
      lpsmp->uFlags = TPM_RIGHTALIGN | TPM_TOPALIGN;
      break;
   }
}


HMENU GetMenuHandle(LPTSTR szPath)
{
   LPMENUSTRUCT lpms;
   int iItemID = 1;

   // These globals are a reminder that the menu drawing is starting now
   g_bAlreadyDrawn = FALSE;       // Not already drawn
   g_bFirstTime = TRUE;           // First time we enter

   // Creates an empty menu
   HMENU hmenu = CreatePopupMenu();

   // Filter string for *.lnk
   TCHAR szDir[MAX_PATH] = {0};
   lstrcpy(szDir, szPath);
   if(szDir[lstrlen(szDir) - 1] != '\\')
      lstrcat(szDir, __TEXT("\\"));

   TCHAR szBuf[MAX_PATH] = {0};
   wsprintf(szBuf, __TEXT("%s*.lnk"), szDir);

   // Search for .lnk files
   WIN32_FIND_DATA wfd;
   HANDLE h = FindFirstFile(szBuf, &wfd);
   while(h != INVALID_HANDLE_VALUE)
   {
      // Resolve the shortcut
      SHORTCUTSTRUCT ss;
      ZeroMemory(&ss, sizeof(SHORTCUTSTRUCT));
      wsprintf(szBuf, __TEXT("%s\\%s"), szDir, wfd.cFileName);
      SHResolveShortcut(szBuf, &ss);

      // Prepare per-item data using ID, description and target file
      lpms = reinterpret_cast<LPMENUSTRUCT>(GlobalAllocPtr(GHND, sizeof(MENUSTRUCT)));
      lpms->iItemID = iItemID;
      if(!lstrlen(ss.pszDesc))
         lstrcpy(lpms->szText, wfd.cFileName);
      else
         lstrcpy(lpms->szText, ss.pszDesc);
      lstrcpy(lpms->szFile, ss.pszTarget);

      // Add the item
      AppendMenu(hmenu, MF_OWNERDRAW, iItemID++, reinterpret_cast<LPTSTR>(lpms));

      // Next file
      if(!FindNextFile(h, &wfd))
      {
         FindClose(h);
         break;
      }
   }

   // Add the separator and the 'Restore' item
   AppendMenu(hmenu, MF_OWNERDRAW | MF_SEPARATOR, 0, NULL);

   lpms = reinterpret_cast<LPMENUSTRUCT>(GlobalAllocPtr(GHND, sizeof(MENUSTRUCT)));
   lpms->iItemID = ID_FILE_EXIT;
   lstrcpy(lpms->szText, __TEXT("Restore Previous Settings"));
   lstrcpy(lpms->szFile, "");
   AppendMenu(hmenu, MF_OWNERDRAW, ID_FILE_EXIT, reinterpret_cast<LPTSTR>(lpms));

   return hmenu;
}


HRESULT SHResolveShortcut(LPCTSTR szLnkFile, LPSHORTCUTSTRUCT lpss)
{
   WCHAR wszLnkFile[MAX_PATH] = {0};
   IShellLink* pShellLink = NULL;
   IPersistFile* pPF = NULL;

   // Create the appropriate COM server
   HRESULT hr = CoCreateInstance(CLSID_ShellLink, NULL,
                                 CLSCTX_INPROC_SERVER, IID_IShellLink,
                                 reinterpret_cast<LPVOID*>(&pShellLink));
   if(FAILED(hr))
      return hr;

   // Get the IPersistFile interface to load the LNK file
   hr = pShellLink->QueryInterface(IID_IPersistFile, reinterpret_cast<LPVOID*>(&pPF));
   if(FAILED(hr))
   {
      pShellLink->Release();
      return hr;
   }

   // Load the shortcut (Unicode name)
   MultiByteToWideChar(CP_ACP, 0, szLnkFile, -1, wszLnkFile, MAX_PATH);
   hr = pPF->Load(wszLnkFile, STGM_READ);
   if(FAILED(hr))
   {
      pPF->Release();
      pShellLink->Release();
      return hr;
   }

   // Resolve the link
   hr = pShellLink->Resolve(NULL, SLR_ANY_MATCH);
   if(FAILED(hr))
   {
      pPF->Release();
      pShellLink->Release();
      return hr;
   }

   // Extract the information to fill lpss
   if(lpss != NULL)
   {
      TCHAR szPath[MAX_PATH] = {0};
      TCHAR szDesc[MAX_PATH] = {0};
      TCHAR szIcon[MAX_PATH] = {0};
      WORD w = 0;
      WORD wIcon = 0;
      WIN32_FIND_DATA wfd;

      pShellLink->GetPath(szPath, MAX_PATH, &wfd, SLGP_SHORTPATH);
      pShellLink->GetDescription(szDesc, MAX_PATH);
      pShellLink->GetHotkey(&w);
      pShellLink->GetIconLocation(szIcon, MAX_PATH, reinterpret_cast<int*>(&wIcon));

      lpss->pszTarget = szPath;
      lpss->pszDesc = szDesc;
      lpss->pszIconPath = szIcon;
      lpss->wHotKey = w;
      lpss->wIconIndex = wIcon;
   }

   pPF->Release();
   pShellLink->Release();
   return hr;
}


void MeasureItem(HWND hwnd, LPMEASUREITEMSTRUCT lpmis)
{
   SIZE size;
   int iItemID = lpmis->itemID;
   LPMENUSTRUCT lpms = reinterpret_cast<LPMENUSTRUCT>(lpmis->itemData);

   // Calculate the size of the item string
   HDC hdc = GetDC(hwnd);
   GetTextExtentPoint32(hdc, lpms->szText, lstrlen(lpms->szText), &size);
   ReleaseDC(hwnd, hdc);

   // Set width and height for the item
   lpmis->itemWidth = DEFBITMAPSIZE + DEFBANDSIZE + size.cx;

   // A separator has a zero ID
   if(iItemID)
      lpmis->itemHeight = DEFBITMAPSIZE;
   else
      lpmis->itemHeight = DEFSEPSIZE;
}


/*---------------------------------------------------------------*/
// DrawItem
// Handle the WM_DRAWITEM message on per-item basis
/*---------------------------------------------------------------*/
void DrawItem(LPDRAWITEMSTRUCT lpdis)
{
   TCHAR szItem[ITEMSIZE] = {0};
   TCHAR szFile[MAX_PATH] = {0};
   COLORREF crText, crBack;
   HICON hIcon = NULL;

   LPMENUSTRUCT lpms = reinterpret_cast<LPMENUSTRUCT>(lpdis->itemData);
   int iItemID = lpdis->itemID;
   int iTopEdge = 0;

   // Save the item text and target file
   if(lpms)
   {
      lstrcpy(szItem, lpms->szText);
      lstrcpy(szFile, lpms->szFile);
   }

   // Manage how to draw
   if(lpdis->itemAction & (ODA_DRAWENTIRE | ODA_SELECT))
   {
      COLORREF clr;
      RECT rtBand, rtBmp, rtText, rtItem, rt;
      SIZE size;

      // Defines rectangles for further use:
      //    lpdis->rcItem is the menu item rectangle  
      //    rtBand: portion of the menu item area for vertical band  
      //    rtBmp: portion of the menu item area for item icon  
      //    rtText: portion of the menu item area for item text  
      CopyRect(&rt, &(lpdis->rcItem));
      CopyRect(&rtBand, &rt);
      rtBand.right = rtBand.left + DEFBANDSIZE;
      CopyRect(&rtBmp, &rt);
      rtBmp.left = rtBand.right + DEFBORDERSIZE;
      rtBmp.right = rtBmp.left + DEFBITMAPSIZE;
      CopyRect(&rtText, &rt);
      rtText.left = rtBmp.right + 2 * DEFBORDERSIZE;
      CopyRect(&rtItem, &rt);
      rtItem.left += DEFBANDSIZE + DEFBORDERSIZE;

      // If it is the first item, store the y-coordinate
      if(g_bFirstTime)
      {
         iTopEdge = rtBand.top;
         g_bFirstTime = FALSE;
      }

      // Draw the band rectangle and the vertical bitmap
      if(!g_bAlreadyDrawn) 
      {
         // Draw the band area in blue
         clr = SetBkColor(lpdis->hDC, RGB(0, 0, 255));
         ExtTextOut(lpdis->hDC, 0, 0, ETO_CLIPPED | ETO_OPAQUE, &rtBand, NULL, 0, NULL);
         SetBkColor(lpdis->hDC, clr);
             
         // If it is the last item, determine the menu height,load the bitmap, and draw 
         if(iItemID == ID_FILE_EXIT)
         {
            int iMenuHeight = rtBand.bottom - iTopEdge;
            HBITMAP hbm = LoadBitmap(g_hInstance, MAKEINTRESOURCE(IDB_LOGO));
            DrawBitmap(lpdis->hDC, 0, iMenuHeight, hbm);
            DeleteObject(hbm);
            g_bAlreadyDrawn = TRUE;
         }
      }

      // Everything done so far is unaffected by seletion state.
      // Now need to draw icon and text with respect to 
      // the selection state and hence the background color
      if(lpdis->itemState & ODS_SELECTED)
      {
         crText = SetTextColor(lpdis->hDC, GetSysColor(COLOR_HIGHLIGHTTEXT));
         crBack = SetBkColor(lpdis->hDC, GetSysColor(COLOR_HIGHLIGHT));
      }
   
      // Clear the area with the correct background color
      ExtTextOut(lpdis->hDC, rtText.left, rtText.left, 
                 ETO_CLIPPED | ETO_OPAQUE, &rtItem, NULL, 0, NULL);

      // Get the icon to draw. Load it from our resource if it is
      // the last item. Otherwise, determine the system icon 
      // for the shortcut's target file 
      if(iItemID==ID_FILE_EXIT)
         hIcon = LoadIcon(g_hInstance, MAKEINTRESOURCE(iItemID));
      else 
      {
         SHFILEINFO sfi;
         ZeroMemory(&sfi, sizeof(SHFILEINFO));
         SHGetFileInfo(szFile, 0, &sfi, sizeof(SHFILEINFO), SHGFI_ICON);
         hIcon = sfi.hIcon;
      }

      // Draw the icon (transparence is automatic)
      if(hIcon)
      {
         DrawIcon(lpdis->hDC, rtBmp.left, rtBmp.top, hIcon);
         DestroyIcon(hIcon);
      }

      // Draw the text (one line centered vertically)
      if(!iItemID)
      {
         // It's a separator
         rt.top++;
         rt.bottom = rt.top + DEFBORDERSIZE;
         rt.left = rt.left + DEFBANDSIZE + DEFBORDERSIZE;
         DrawEdge(lpdis->hDC, &rt, EDGE_ETCHED, BF_RECT);
      } 
      else
      {
         // Get the size of the text according to the font 
         GetTextExtentPoint32(lpdis->hDC, szItem, lstrlen(szItem), &size); 

         // Center it vertically   
         int iy = ((lpdis->rcItem.bottom - lpdis->rcItem.top) - size.cy) / 2;
         iy = lpdis->rcItem.top + (iy >= 0 ? iy : 0);
         rtText.top = iy;
         DrawText(lpdis->hDC, szItem, lstrlen(szItem), &rtText, DT_LEFT | DT_EXPANDTABS);
      }
   }
}


/*---------------------------------------------------------------*/
// DrawBitmap
// Draw the bitmap with the vertical logo
/*---------------------------------------------------------------*/
void DrawBitmap(HDC hdc, int x, int iHeight, HBITMAP hbm)
{
   // This function calculates the y-coordinate based on the height 
   // of the area to cover. The bitmap will be aligned with the bottom  
   BITMAP bm;

   // Creates a memory device context and selects the bitmap in it
   HDC hdcMem = CreateCompatibleDC(hdc);
   HBITMAP hOldBm = static_cast<HBITMAP>(SelectObject(hdcMem, hbm));

   // Obtains information about the bitmap
   GetObject(hbm, sizeof(BITMAP), &bm);

   // Determine the y-coordinate
   int y = iHeight - bm.bmHeight;
   y = (y < 0 ? 0 : y);

   // Transfer the bitmap from memory DC to the menu DC
   BitBlt(hdc, x, y, bm.bmWidth, bm.bmHeight, hdcMem, 0, 0, SRCCOPY);

   // Free the memory DC 
   SelectObject(hdcMem, hOldBm);
   DeleteDC(hdcMem);
}


/*-------------------------------------------------------*/
// HandleResults
// Run the program the user clicked
/*-------------------------------------------------------*/
void HandleResults(HMENU hmenu, int iCmd)
{
   MENUITEMINFO mii;
   LPMENUSTRUCT lpms;

   if(iCmd <= 0)
      return;

   if(iCmd == ID_FILE_EXIT)
   {
      UninstallHandler();
      return;
   }

   mii.cbSize = sizeof(MENUITEMINFO);
   mii.fMask = MIIM_DATA;
   GetMenuItemInfo(hmenu, iCmd, FALSE, &mii);
   lpms = reinterpret_cast<LPMENUSTRUCT>(mii.dwItemData);
   ShellExecute(NULL, __TEXT("open"), lpms->szFile, NULL, NULL, SW_SHOW);
}