#include <windows.h>
#include <windowsx.h>
#include <objbase.h>
#include <shlobj.h>
#include <shellapi.h>

DEFINE_GUID(CLSID_NewStart, 0x20051998, 0x0020,
                        0x0005, 0x19, 0x98, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00);

// Maximum size allowed item names in an owner-drawn menu
const int ITEMSIZE = 100;

// These are absolute constants (expressed in pixels) that define
//  measurements for the items to draw
const int DEFBITMAPSIZE = 32; // 32 x 32 is the area reserved for bitmaps
const int DEFBANDSIZE = 25;   // Width of the vertical band
const int DEFSEPSIZE = 6;     // Height of the area reserved for separators
const int DEFBORDERSIZE = 2;  // Gap between item text and edge of the menu

struct STARTMENUPOS
{
   int ix;
   int iy;
   UINT uFlags;
};

typedef STARTMENUPOS* LPSTARTMENUPOS;

struct MENUSTRUCT
{
   TCHAR szText[ITEMSIZE];
   int iItemID;
   TCHAR szFile[MAX_PATH];
};

typedef MENUSTRUCT* LPMENUSTRUCT;

struct SHORTCUTSTRUCT
{
   LPTSTR pszTarget;
   LPTSTR pszDesc;
   WORD wHotKey;
   LPTSTR pszIconPath;
   WORD wIconIndex;
};

typedef SHORTCUTSTRUCT* LPSHORTCUTSTRUCT;


void InstallHandler();
void UninstallHandler();
void SetNewStartButton(BOOL);
void RemoveTooltip(HWND);
void GetStartMenuPosition(LPSTARTMENUPOS);
HMENU GetMenuHandle(LPTSTR);
HRESULT SHResolveShortcut(LPCTSTR, LPSHORTCUTSTRUCT);
void MeasureItem(HWND, LPMEASUREITEMSTRUCT);
void DrawItem(LPDRAWITEMSTRUCT);
void DrawBitmap(HDC, int, int, HBITMAP);
void HandleResults(HMENU, int);

LRESULT CALLBACK NewStartProc(HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK EnumThreadWndProc(HWND, LPARAM);