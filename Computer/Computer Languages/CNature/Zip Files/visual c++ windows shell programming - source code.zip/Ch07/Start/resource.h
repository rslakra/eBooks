//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Start.rc
//
#define IDB_NEWSTART                    101
#define IDC_HANDY                       102
#define IDR_MENU                        103
#define IDB_LOGO                        105
#define ID_FILE_EXIT                    10001
#define ID_FILE_CALCULATOR              10002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
