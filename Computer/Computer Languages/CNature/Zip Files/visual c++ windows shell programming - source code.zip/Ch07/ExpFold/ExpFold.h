/*****************************************************************
*
*  Project.....:  Dialog
*  Application.:  EXPFOLD.exe
*  Module......:  EXPFOLD.h
*  Description.:  Application main header
*  Compiler....:  MS Visual C++ 
*  Written by..:  D. Esposito
*  Environment.:  Windows 9x/NT
*
*******************************/

// Prevent multiple inclusions
#define WIN32_LEAN_AND_MEAN
#define STRICT

#ifndef _APP_DEFS_
#define _APP_DEFS_

/*---------------------------------------------------------------*/
//                        INCLUDE section
/*---------------------------------------------------------------*/
#include <windows.h>
#include <windowsx.h>
#include "SPBUtils.h" 

#endif	// _APP_DEFS_


/*  End of file: ExpFold.h  */
