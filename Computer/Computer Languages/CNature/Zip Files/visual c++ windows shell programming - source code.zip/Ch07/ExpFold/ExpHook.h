/*****************************************************************
*
*  Application.:  EXPHOOK.dll
*  Module......:  ExpHook.cpp
*  Description.:  Library header
*  Compiler....:  MS Visual C++
*  Written by..:  D. Esposito
*
*******************************/

/*---------------------------------------------------------------*/
//                     INCLUDE section
/*---------------------------------------------------------------*/
#define WIN32_LEAN_AND_MEAN
#define STRICT

#include <windows.h>
#include <windowsx.h>

/*---------------------------------------------------------------*/
//                     INCLUDE section
/*---------------------------------------------------------------*/
extern HINSTANCE g_hThisDll;

/*---------------------------------------------------------------*/
//                     PROTOTYPES section
/*---------------------------------------------------------------*/
HHOOK g_hShellHook;
HHOOK g_hKeybHook;
HWND g_hwndExplorer;

void InstallKeyboardHook(HWND hwnd);

void APIENTRY ShellDll_Hook();
void APIENTRY ShellDll_Unhook();
LRESULT CALLBACK ShellDll_KeybHook(int nCode, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK ShellDll_MainHook(int nCode, WPARAM wParam, LPARAM lParam);


/*  End of file: ExpHook.h  */
