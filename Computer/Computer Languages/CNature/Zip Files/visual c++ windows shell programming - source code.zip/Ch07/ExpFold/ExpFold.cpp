/*****************************************************************
*
*  Project.....:  Dialog
*  Application.:  EXPFOLD.exe
*  Module......:  EXPFOLD.cpp
*  Description.:  Application main module
*  Compiler....:  MS Visual C++ 
*  Written by..:  D. Esposito
*  Environment.:  Windows 9x/NT
*
******************************************************************/

/*---------------------------------------------------------------*/
//                        PRAGMA section
/*---------------------------------------------------------------*/
// Force the linker to add the following libraries.
// In doing so we prevent the use of MFC classes.
#ifdef _MSC_VER

#pragma comment(lib, "kernel32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "exphook.lib")

#endif

/*---------------------------------------------------------------*/
//                        INCLUDE section
/*---------------------------------------------------------------*/
#include "ExpFold.h"
#include "ExpHook.h"
#include <commctrl.h>
#include <shellapi.h>
#include "resource.h" 

/*---------------------------------------------------------------*/
//                        GLOBAL section
/*---------------------------------------------------------------*/
// Data
const int WM_MYMESSAGE = WM_APP + 1;
const int ICON_ID = 13;

HICON g_hIconLarge;
HICON g_hIconSmall;
HINSTANCE g_hInstance;

// Functions
void OnInitDialog(HWND);
void OnOK(HWND);

BOOL TrayIcon(HWND, DWORD);
void ContextMenu(HWND);

// Callbacks
BOOL CALLBACK APP_DlgProc(HWND, UINT, WPARAM, LPARAM);


/*---------------------------------------------------------------*/
// Procedure....: WinMain()
// Description..: Entry point in any Windows program
// Input........: HINSTANCE, HINSTANCE, LPSTR, int
// Output.......: INT
/*---------------------------------------------------------------*/
int APIENTRY WinMain(
   HINSTANCE hInstance, HINSTANCE hPrevious, LPTSTR lpsz, int iCmd)
{
   // Save global data
   g_hInstance = hInstance;
   g_hIconSmall = static_cast<HICON>(LoadImage(hInstance, "APP_ICON", IMAGE_ICON,
      GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CXSMICON), 0));

   // Create an invisible dialog to get messages from the icon
   HWND hDlg = CreateDialog(hInstance, "DLG_MAIN", NULL, APP_DlgProc);

   // Show the icon
   TrayIcon(hDlg, NIM_ADD);

   // Install the Explorer's hook
   ShellDll_Hook();

   MSG msg;
   while(GetMessage(&msg, NULL, 0, 0))
   {
      if(!IsDialogMessage(hDlg, &msg))
      {
         TranslateMessage(&msg);
         DispatchMessage(&msg);
      }
   }

   // Uninstall the hook
   ShellDll_Unhook();

   // Remove the icon
   TrayIcon(hDlg, NIM_DELETE);

   DestroyWindow(hDlg);
   DestroyIcon(g_hIconSmall);
   return 1;
}


/*---------------------------------------------------------------*/
// Procedure....: APP_DlgProc()
// Description..: Responds to all messages sent to the dialog
// Input........: HWND, UINT, WPARAM, LPARAM
// Output.......: BOOL
/*---------------------------------------------------------------*/
BOOL CALLBACK APP_DlgProc(HWND hDlg, UINT uiMsg, WPARAM wParam, LPARAM lParam)
{
   switch(uiMsg)
   {
   case WM_COMMAND:
      switch(wParam)
      {
      case IDCANCEL:
         PostQuitMessage(0);
         return FALSE;
      }
      break;

   case WM_MYMESSAGE:
      if(wParam == ICON_ID)
      {
         switch(lParam)
         {
         case WM_RBUTTONUP:
            ContextMenu(hDlg);
            break;
         }
      }
      break;
   }

   return FALSE;
}


/*****************************************************************
*
*  Internals:
*    - OnOK()
*    - OnInitDialog()
*
******************************************************************/

/*---------------------------------------------------------------*/
// Procedure...: OnOK()
// Description.: Do something
// INPUT.......: HWND
// OUTPUT......: void
/*---------------------------------------------------------------*/
void OnOK(HWND hDlg)
{
   return;
}


/*---------------------------------------------------------------*/
// Procedure...: OnInitDialog()
// Description.: Initialize the dialog
// INPUT.......: HWND
// OUTPUT......: void
/*---------------------------------------------------------------*/
void OnInitDialog(HWND hDlg)
{
   // Set the icons (T/F as to Large/Small icon)
   SendMessage(hDlg, WM_SETICON, FALSE, reinterpret_cast<LPARAM>(g_hIconSmall));
}


// Shows an icon in the tray area
BOOL TrayIcon(HWND hWnd, DWORD msg)
{
   NOTIFYICONDATA nid;
   ZeroMemory(&nid, sizeof(NOTIFYICONDATA));
   nid.cbSize = sizeof(NOTIFYICONDATA);
   nid.hWnd = hWnd;
   nid.uID = ICON_ID;
   nid.uFlags = NIF_TIP | NIF_ICON | NIF_MESSAGE;
   nid.uCallbackMessage = WM_MYMESSAGE;
   nid.hIcon = g_hIconSmall;
   lstrcpyn(nid.szTip, __TEXT("Explorer's Hook"), 64);
   return Shell_NotifyIcon(msg, &nid);
}


// Shows up the context menu for the icon
void ContextMenu(HWND hwnd)
{
   POINT pt;
   GetCursorPos(&pt);

   HMENU hmenu = LoadMenu(g_hInstance, MAKEINTRESOURCE(IDR_MENU));
   HMENU hmnuPopup = GetSubMenu(hmenu, 0);
   SetMenuDefaultItem(hmnuPopup, IDOK, FALSE);
   SetForegroundWindow(hwnd);
   TrackPopupMenu(hmnuPopup, TPM_LEFTALIGN, pt.x, pt.y, 0, hwnd, NULL);
   SetForegroundWindow(hwnd);
   DestroyMenu(hmnuPopup);
   DestroyMenu(hmenu);
}

/*  End of file: ExpFold.cpp  */
