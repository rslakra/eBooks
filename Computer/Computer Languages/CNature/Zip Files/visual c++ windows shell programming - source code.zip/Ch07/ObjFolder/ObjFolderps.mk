
ObjFolderps.dll: dlldata.obj ObjFolder_p.obj ObjFolder_i.obj
	link /dll /out:ObjFolderps.dll /def:ObjFolderps.def /entry:DllMain dlldata.obj ObjFolder_p.obj ObjFolder_i.obj \
		kernel32.lib rpcndr.lib rpcns4.lib rpcrt4.lib oleaut32.lib uuid.lib \

.c.obj:
	cl /c /Ox /DWIN32 /D_WIN32_WINNT=0x0400 /DREGISTER_PROXY_DLL \
		$<

clean:
	@del ObjFolderps.dll
	@del ObjFolderps.lib
	@del ObjFolderps.exp
	@del dlldata.obj
	@del ObjFolder_p.obj
	@del ObjFolder_i.obj
