// NewFolder.h : Declaration of the CNewFolder

#ifndef __NEWFOLDER_H_
#define __NEWFOLDER_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// Constants 
const int NEWFOLDERMSG = 29281;      // WM_COMMAND to send
const int NEWFOLDERKEY = VK_F12;     // Key to detect

/////////////////////////////////////////////////////////////////////////////
// CNewFolder
class ATL_NO_VTABLE CNewFolder : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CNewFolder, &CLSID_NewFolder>,
    public IObjectWithSiteImpl<CNewFolder>,
    public IDispatchImpl<INewFolder, &IID_INewFolder, &LIBID_OBJFOLDERLib>
{
public:
	CNewFolder()
	{
		m_bSubclassed = false;
	}
    ~CNewFolder();

DECLARE_REGISTRY_RESOURCEID(IDR_NEWFOLDER)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CNewFolder)
	COM_INTERFACE_ENTRY(INewFolder)
	COM_INTERFACE_ENTRY(IDispatch)
    COM_INTERFACE_ENTRY_IMPL(IObjectWithSite)
END_COM_MAP()

// INewFolder
public:
   STDMETHOD(SubclassExplorer)(bool bSubclass);

// IObjectWithSite
public:
   STDMETHOD(SetSite)(IUnknown* pUnkSite);

private:
   bool m_bSubclassed;
   HWND m_hwndExplorer;

// Callback functions
   static BOOL CALLBACK WndEnumProc(HWND, LPARAM);
   static LRESULT CALLBACK KeyboardProc(int, WPARAM, LPARAM);
   static LRESULT CALLBACK NewExplorerWndProc(HWND, UINT, WPARAM, LPARAM);
};

#endif //__NEWFOLDER_H_
