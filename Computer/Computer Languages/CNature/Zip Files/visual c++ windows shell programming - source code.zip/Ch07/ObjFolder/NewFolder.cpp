// NewFolder.cpp : Implementation of CNewFolder
#include "stdafx.h"
#include "ObjFolder.h"
#include "NewFolder.h"

// These constants are used inside the static members of the class
static WNDPROC g_pfnExplorerWndProc = NULL;
static HHOOK g_hHook = NULL;
static HWND g_hwndExplorer;

/////////////////////////////////////////////////////////////////////////////
// CNewFolder

CNewFolder::~CNewFolder()
{
   if(m_bSubclassed)
   {
      SubclassExplorer(false);
      m_bSubclassed = false;
   }
}


/*----------------------------------------------------------------*/
// SetSite
// Called by Explorer/IExplorer to get in touch
/*----------------------------------------------------------------*/
STDMETHODIMP CNewFolder::SetSite(IUnknown* pUnkSite)
{
   HRESULT hr = SubclassExplorer(true);   
   if(SUCCEEDED(hr))
      m_bSubclassed = true;

   return S_OK;
}


/*----------------------------------------------------------------*/
// SubclassExplorer
// Subclass the Explorer window and install the keyboard hook
/*----------------------------------------------------------------*/
STDMETHODIMP CNewFolder::SubclassExplorer(bool bSubclass)
{
   // Get the HWND of the Explorer's window
   EnumThreadWindows(GetCurrentThreadId(), WndEnumProc,
                                reinterpret_cast<LPARAM>(&m_hwndExplorer));

   if(!IsWindow(m_hwndExplorer))
      return E_FAIL;
   else
      g_hwndExplorer = m_hwndExplorer;

   // Subclass Explorer's window
   if(bSubclass && !m_bSubclassed)
   {
      g_pfnExplorerWndProc = reinterpret_cast<WNDPROC>(SetWindowLong(
                                 m_hwndExplorer, GWL_WNDPROC,
                                 reinterpret_cast<LONG>(NewExplorerWndProc)));

      // Set a keyboard hook to detect F12
      g_hHook = SetWindowsHookEx(WH_KEYBOARD, KeyboardProc, NULL, GetCurrentThreadId());
   }

   // Unsubclass Explorer's window
   if(!bSubclass && m_bSubclassed)
   {
      SetWindowLong(m_hwndExplorer, GWL_WNDPROC,
                             reinterpret_cast<LONG>(g_pfnExplorerWndProc));

      // Remove the hook
      UnhookWindowsHookEx(g_hHook);
   }

   return S_OK;
}


/*----------------------------------------------------------------*/
// WndEnumProc
// Static member to enumerate thread windows
/*----------------------------------------------------------------*/
BOOL CALLBACK CNewFolder::WndEnumProc(HWND hwnd, LPARAM lParam)
{
   TCHAR szClassName[MAX_PATH] = {0};
   GetClassName(hwnd, szClassName, MAX_PATH);
   if(!lstrcmpi(szClassName, __TEXT("ExploreWClass")))
   {
      HWND* phWnd = reinterpret_cast<HWND*>(lParam);
      *phWnd = hwnd;
      return FALSE;
   }
   return TRUE;
}

/*----------------------------------------------------------------*/
// NewExplorerWndProc
// Static member to replace Explorer's wndproc 
/*----------------------------------------------------------------*/
LRESULT CALLBACK CNewFolder::NewExplorerWndProc(
                        HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
   // This does nothing, so just call into the standard procedure
   return CallWindowProc(g_pfnExplorerWndProc, hwnd, uMsg, wParam, lParam);
}


/*----------------------------------------------------------------*/
// KeyboardProc
// Static member to handle keys
/*----------------------------------------------------------------*/
LRESULT CALLBACK CNewFolder::KeyboardProc(int nCode, WPARAM wParam, LPARAM lParam)
{
   // Typical start-off for any hook
   if(nCode < 0)
      return CallNextHookEx(g_hHook, nCode, wParam, lParam);

   // Process the key only once
   if((lParam & 0x80000000) || (lParam & 0x40000000))
      return CallNextHookEx(g_hHook, nCode, wParam, lParam);

   if(wParam == NEWFOLDERKEY)
      PostMessage(g_hwndExplorer, WM_COMMAND, NEWFOLDERMSG, 0);

   return CallNextHookEx(g_hHook, nCode, wParam, lParam);
}
