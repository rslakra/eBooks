/*****************************************************************
*
*  Project.....:  File Information
*  Application.:  FILEINFO.exe
*  Module......:  FILEINFO.cpp
*  Description.:  Application main module
*  Compiler....:  MS Visual C++
*  Written by..:  D. Esposito
*  Environment.:  Windows 9x/NT
*
******************************************************************/

/*---------------------------------------------------------------*/
//                        PRAGMA section
/*---------------------------------------------------------------*/
// Force the linker to add the following libraries.
#ifdef _MSC_VER

#pragma comment(lib, "kernel32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "comdlg32.lib")

#endif

/*---------------------------------------------------------------*/
//                        INCLUDE section
/*---------------------------------------------------------------*/
#include "FileInfo.h"
#include <commctrl.h>
#include <shellapi.h>
#include <shlobj.h>
#include <commdlg.h>
#include "resource.h"

/*---------------------------------------------------------------*/
//                        GLOBAL section
/*---------------------------------------------------------------*/
// Data
HICON g_hIconLarge;
HICON g_hIconSmall;

// Functions
void OnInitDialog(HWND);
void OnOK(HWND);
void OnBrowse(HWND);
HICON GetSharedFolderIcon(HICON);

// Callbacks
BOOL CALLBACK APP_DlgProc(HWND, UINT, WPARAM, LPARAM);

// Constants
const int PE_SIGN = 0x4550;
const int NE_SIGN = 0x454E;
const int MZ_SIGN = 0x5A4D;


/*---------------------------------------------------------------*/
// Procedure....: WinMain()
// Description..: Entry point in any Windows program
// Input........: HINSTANCE, HINSTANCE, LPSTR, int
// Output.......: int
/*---------------------------------------------------------------*/
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevious, 
                     LPTSTR lpsz, int iCmd)
{
   // Save global data
   g_hIconLarge = static_cast<HICON>(
              LoadImage(hInstance, "APP_ICON", IMAGE_ICON,
              GetSystemMetrics(SM_CXICON), GetSystemMetrics(SM_CXICON), 0));
   g_hIconSmall = static_cast<HICON>(
              LoadImage(hInstance, "APP_ICON", IMAGE_ICON,
              GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CXSMICON), 0));

   // Enable common controls
   INITCOMMONCONTROLSEX iccex;
   iccex.dwSize = sizeof(INITCOMMONCONTROLSEX);
   iccex.dwICC = ICC_WIN95_CLASSES;
   InitCommonControlsEx(&iccex);

   // Run main dialog
   BOOL b = DialogBox(hInstance, "DLG_MAIN", NULL, APP_DlgProc);

   // Exit
   DestroyIcon(g_hIconLarge);
   DestroyIcon(g_hIconSmall);
   return b;
}


/*---------------------------------------------------------------*/
// Procedure....: APP_DlgProc()
// Description..: Responds to all messages sent to the dialog
// Input........: HWND, UINT, WPARAM, LPARAM
// Output.......: BOOL
/*---------------------------------------------------------------*/
BOOL CALLBACK APP_DlgProc(HWND hDlg, UINT uiMsg, WPARAM wParam, LPARAM lParam)
{
   switch(uiMsg)
   {
   case WM_INITDIALOG:
      OnInitDialog(hDlg);
      break;

   case WM_COMMAND:
      switch(wParam)
      {
      case IDOK:
         OnOK(hDlg);
         return FALSE;

      case IDCANCEL:
         EndDialog(hDlg, FALSE);
         return FALSE;

      case IDC_BROWSE:
         OnBrowse(hDlg);
		 return FALSE;
	  }
      break;
   }

   return FALSE;
}


/*****************************************************************
*
*  Internals:
*    - OnOK()
*    - OnInitDialog()
*
******************************************************************/

/*---------------------------------------------------------------*/
// Procedure...: OnOK()
// Description.: Do something
// INPUT.......: HWND
// OUTPUT......: void
/*---------------------------------------------------------------*/
void OnOK(HWND hDlg)
{
   TCHAR szFile[MAX_PATH] = {0};
   TCHAR szBuf[1024] = {0};

   // Get the file name
   GetDlgItemText(hDlg, IDC_FILENAME, szFile, MAX_PATH);

   /////////////////////////////////////////
   // Collect Flags
   //
   DWORD dwFileAttributes = 0;
   UINT uFlags = 0;

   if(IsDlgButtonChecked(hDlg, IDC_FILEICON))
      uFlags |= SHGFI_ICON;
   if(IsDlgButtonChecked(hDlg, IDC_DISPLAYNAME))
      uFlags |= SHGFI_DISPLAYNAME;
   if(IsDlgButtonChecked(hDlg, IDC_TYPENAME))
      uFlags |= SHGFI_TYPENAME;
   if(IsDlgButtonChecked(hDlg, IDC_OTHER))
      uFlags |= SHGFI_ATTRIBUTES;
   if(IsDlgButtonChecked(hDlg, IDC_WILDCARD))
      uFlags |= SHGFI_USEFILEATTRIBUTES;
   if(IsDlgButtonChecked(hDlg, IDC_EXETYPE))
      uFlags = SHGFI_EXETYPE;

   /////////////////////////////////////////
   // Call the function
   //
   SHFILEINFO sfi;
   ZeroMemory(&sfi, sizeof(SHFILEINFO));

   DWORD dwRC = SHGetFileInfo(
                    szFile, dwFileAttributes, &sfi, sizeof(SHFILEINFO), uFlags);

   /////////////////////////////////////////
   // Deal with the UI
   //
   if(uFlags == SHGFI_EXETYPE)
   {
      if(dwRC == 0)
         lstrcpy(szBuf, "Not an executable file.");
      else
         lstrcpy(szBuf, "");

      if(LOWORD(dwRC) == PE_SIGN)
      {
         lstrcat(szBuf, "32-bit");
         if(HIWORD(dwRC))
            lstrcat(szBuf, " Windows executable");
         else
            lstrcat(szBuf, " Console executable");
      }
      else if(LOWORD(dwRC) == NE_SIGN)
         lstrcat(szBuf, "16-bit executable");
      else if(LOWORD(dwRC) == MZ_SIGN)
         lstrcat(szBuf, "DOS executable");
   }
   else
      wsprintf(szBuf, "%d", dwRC);

   SetDlgItemText(hDlg, IDC_RETCODE, szBuf);

   wsprintf(szBuf, "Icon Index: %d", sfi.iIcon);
   SetDlgItemText(hDlg, IDC_ICONINDEX, szBuf);

   SetDlgItemText(hDlg, IDC_DISPLAY, sfi.szDisplayName);
   SetDlgItemText(hDlg, IDC_TYPE, sfi.szTypeName);

   /////////////////////////////////////////
   // Parse attributes and display
   //
   DWORD dwAttrib = sfi.dwAttributes;
   lstrcpy(szBuf, "");
   if(dwAttrib != 0)
   {
      if(dwAttrib & SFGAO_CANCOPY)
         lstrcat(szBuf, "Copy, ");
      if(dwAttrib & SFGAO_CANMOVE)
         lstrcat(szBuf, "Move, ");
      if(dwAttrib & SFGAO_CANDELETE)
         lstrcat(szBuf, "Delete, ");
      if(dwAttrib & SFGAO_CANRENAME)
         lstrcat(szBuf, "Rename, ");
      if(dwAttrib & SFGAO_CANLINK)
         lstrcat(szBuf, "Link, ");
      if(dwAttrib & SFGAO_HASPROPSHEET)
         lstrcat(szBuf, "PropSheet, ");
      if(dwAttrib & SFGAO_GHOSTED)
         lstrcat(szBuf, "Ghosted, ");
      if(dwAttrib & SFGAO_SHARE)
         lstrcat(szBuf, "Shared, ");
      if(dwAttrib & SFGAO_HASSUBFOLDER)
         lstrcat(szBuf, "SubFolders, ");
      if(dwAttrib & SFGAO_REMOVABLE)
         lstrcat(szBuf, "On removable media, ");
      if(dwAttrib & SFGAO_FOLDER)
         lstrcat(szBuf, "Folder, ");

      lstrcat(szBuf, "and more!");
   }

   SetDlgItemText(hDlg, IDC_ATTRIB, szBuf);

   /////////////////////////////////////////
   // Show the icon
   //
   HICON hIcon;
   if(dwAttrib & SFGAO_SHARE)
      hIcon = GetSharedFolderIcon(sfi.hIcon);
   else
      hIcon = sfi.hIcon;
   
   SendDlgItemMessage(
               hDlg, IDI_ICON, STM_SETICON, reinterpret_cast<WPARAM>(hIcon), 0);
}


/*---------------------------------------------------------------*/
// Procedure...: OnInitDialog()
// Description.: Initialize the dialog
// INPUT.......: HWND
// OUTPUT......: void
/*---------------------------------------------------------------*/
void OnInitDialog(HWND hDlg)
{
   // Set the icons (T/F as to Large/Small icon)
   SendMessage(hDlg, WM_SETICON, FALSE, reinterpret_cast<LPARAM>(g_hIconSmall));
   SendMessage(hDlg, WM_SETICON, TRUE, reinterpret_cast<LPARAM>(g_hIconLarge));
}


void OnBrowse(HWND hDlg)
{
   TCHAR szFile[MAX_PATH] = {0};

   OPENFILENAME ofn;
   ZeroMemory(&ofn, sizeof(OPENFILENAME));
   ofn.lStructSize = sizeof(OPENFILENAME);
   ofn.lpstrFilter = "All files\0*.*\0";
   ofn.nMaxFile = MAX_PATH;
   ofn.lpstrFile = szFile;

   if(GetOpenFileName(&ofn))
      SetDlgItemText(hDlg, IDC_FILENAME, ofn.lpstrFile);
}


HICON GetSharedFolderIcon(HICON hiFolder)
{
   HICON hiShared;
   HICON hiHand;

   // Get the 'holding hand' icon
   ExtractIconEx("shell32.dll", 28, &hiHand, NULL, 1);

   // Create an image list to merge the folder and hand icons
   HIMAGELIST himl = ImageList_Create(32, 32, ILC_MASK, 1, 0);

   // Add icons to the image list
   ImageList_AddIcon(himl, hiFolder);
   ImageList_AddIcon(himl, hiHand);

   // Merge the icons to a new image list
   HIMAGELIST himlNew = ImageList_Merge(himl, 0, himl, 1, 0, 0);

   // Extract the icon from the new image list
   hiShared = ImageList_ExtractIcon(0, himlNew, 0);

   // Free the 'holding hand' icon. We don't also free the 'folder' icon
   //  because we received it from the caller, who may still need it.
   DestroyIcon(hiHand);

   // Clean up the image lists and exit
   ImageList_Destroy(himl);
   ImageList_Destroy(himlNew);
   return hiShared;
}

/*  End of file: FileInfo.cpp  */
