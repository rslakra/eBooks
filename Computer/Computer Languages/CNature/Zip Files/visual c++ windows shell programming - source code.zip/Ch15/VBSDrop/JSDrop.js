/////////////////////////////////////////////////////////////////////////
// JScript sample for shell DropHandler
// It simply displays what it receives on the command line

var shell = WScript.CreateObject("WScript.Shell");
var sDrop = "Arguments received:\n\n";

if(WScript.Arguments.Length > 0)
{
   for(i = 1 ; i <= WScript.Arguments.Length ; i++)
      sDrop += i + ") " + WScript.Arguments.Item(i - 1) + "\n";
   shell.Popup(sDrop);
}
else
   shell.Popup("No argument specified.");

WScript.Quit();
