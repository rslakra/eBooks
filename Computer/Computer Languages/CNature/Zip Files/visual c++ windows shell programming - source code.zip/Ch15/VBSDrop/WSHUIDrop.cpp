// WSHUIDrop.cpp : Implementation of CWSHUIDrop
#include "stdafx.h"
#include "VBSDrop.h"
#include "WSHUIDrop.h"
#include <shlobj.h>

/////////////////////////////////////////////////////////////////////////////
// CWSHUIDrop

///////////////////////////////////////////////////////////////////////////
// A portion of this code also appeared in the December 1998 issue of MIND

HRESULT CWSHUIDrop::Drop(LPDATAOBJECT pDO, DWORD dwKeyState, POINTL pt, LPDWORD pdwEffect)
{
   // Get the CF_HDROP data object
   HDROP hdrop = GetHDrop(pDO);
   if(hdrop == NULL)
      return E_INVALIDARG;

   // Get the Shell memory handler
   LPMALLOC pMalloc = NULL;
   SHGetMalloc(&pMalloc);

   // Allocate enough memory for the final string to be composed
   int iNumOfFiles = DragQueryFile(hdrop, -1, NULL, 0);
   LPTSTR pszBuf = static_cast<LPTSTR>(pMalloc->Alloc((1 + MAX_PATH) * iNumOfFiles));
   LPTSTR psz = pszBuf;
   if(!pszBuf)
   {
      pMalloc->Release();
      return E_OUTOFMEMORY;
   }
   ZeroMemory(pszBuf, (1 + MAX_PATH) * iNumOfFiles);

   // Get the dropped filenames and compose the string
   for(int i = 0 ; i < iNumOfFiles ; i++)
   {
      TCHAR s[MAX_PATH] = {0};
      DragQueryFile(hdrop, i, s, MAX_PATH);
      PathQuoteSpaces(s);
      lstrcat(pszBuf, s);
      lstrcat(pszBuf, __TEXT(" "));
   }
   DragFinish(hdrop);

   // Run the script, passing the dropped files as a command line argument
   ShellExecute(GetFocus(), __TEXT("open"), m_szFile, pszBuf, NULL, SW_SHOW);

   pMalloc->Release();
   return S_OK;
}


// Extracts an HDROP from an LPDATAOBJECT
HDROP CWSHUIDrop::GetHDrop(LPDATAOBJECT pDO)
{
   STGMEDIUM sm;
   FORMATETC fe;

   // Check for CF_HDROP data
   ZeroMemory(&sm, sizeof(STGMEDIUM));
   ZeroMemory(&fe, sizeof(FORMATETC));
   fe.tymed = TYMED_HGLOBAL;
   fe.lindex = -1;
   fe.dwAspect = DVASPECT_CONTENT;
   fe.cfFormat = CF_HDROP;
   if(FAILED(pDO->GetData(&fe, &sm)))
      return NULL;
   else
      return static_cast<HDROP>(sm.hGlobal);
}
