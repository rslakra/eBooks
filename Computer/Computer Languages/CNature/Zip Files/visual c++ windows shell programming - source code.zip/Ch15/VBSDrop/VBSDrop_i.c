/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Sat Nov 21 14:23:46 1998
 */
/* Compiler settings for C:\Windows\Desktop\VBSDrop\VBSDrop.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_IWSHUIDrop = {0x669A196D,0x8144,0x11D2,{0x8C,0xDB,0x20,0x58,0x50,0xC1,0x00,0x00}};


const IID LIBID_VBSDROPLib = {0x669A1961,0x8144,0x11D2,{0x8C,0xDB,0x20,0x58,0x50,0xC1,0x00,0x00}};


const CLSID CLSID_WSHUIDrop = {0x669A196E,0x8144,0x11D2,{0x8C,0xDB,0x20,0x58,0x50,0xC1,0x00,0x00}};


#ifdef __cplusplus
}
#endif

