// WSHUIDrop.h : Declaration of the CWSHUIDrop

#ifndef __WSHUIDROP_H_
#define __WSHUIDROP_H_

#include "resource.h"       // main symbols
#include "IPersistFileImpl.h"
#include "IDropTargetImpl.h"
#include <ComDef.h>

/////////////////////////////////////////////////////////////////////////////
// CWSHUIDrop
class ATL_NO_VTABLE CWSHUIDrop : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CWSHUIDrop, &CLSID_WSHUIDrop>,
	public IDropTargetImpl,
	public IPersistFileImpl,
	public IDispatchImpl<IWSHUIDrop, &IID_IWSHUIDrop, &LIBID_VBSDROPLib>
{
public:
	CWSHUIDrop()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_WSHUIDROP)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CWSHUIDrop)
	COM_INTERFACE_ENTRY(IWSHUIDrop)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IDropTarget)
	COM_INTERFACE_ENTRY(IPersistFile)
END_COM_MAP()

// IDropTarget
public:
   STDMETHOD(Drop)(LPDATAOBJECT, DWORD, POINTL, LPDWORD);

// IWSHUIDrop
public:

private:
   HDROP GetHDrop(LPDATAOBJECT);
};

#endif //__WSHUIDROP_H_
