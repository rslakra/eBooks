
VBSDropps.dll: dlldata.obj VBSDrop_p.obj VBSDrop_i.obj
	link /dll /out:VBSDropps.dll /def:VBSDropps.def /entry:DllMain dlldata.obj VBSDrop_p.obj VBSDrop_i.obj \
		kernel32.lib rpcndr.lib rpcns4.lib rpcrt4.lib oleaut32.lib uuid.lib \

.c.obj:
	cl /c /Ox /DWIN32 /D_WIN32_WINNT=0x0400 /DREGISTER_PROXY_DLL \
		$<

clean:
	@del VBSDropps.dll
	@del VBSDropps.lib
	@del VBSDropps.exp
	@del dlldata.obj
	@del VBSDrop_p.obj
	@del VBSDrop_i.obj
