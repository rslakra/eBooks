// Monitor.cpp : Implementation of CMonitor
#include "stdafx.h"
#include "Copy.h"
#include "Monitor.h"

/////////////////////////////////////////////////////////////////////////////
// CMonitor

UINT CMonitor::CopyCallback(HWND hwnd, UINT wFunc, UINT wFlags,
                            LPCSTR pszSrcFile,  DWORD dwSrcAttribs,
                            LPCSTR pszDestFile, DWORD dwDestAttribs)
{
   TCHAR szTime[50] = {0};
   GetTimeFormat(LOCALE_SYSTEM_DEFAULT, 0, NULL, NULL, szTime, 50);

   FILE* f = NULL;
   f = fopen(__TEXT("c:\\monitor.log"), __TEXT("a + t"));
   fseek(f, 0, SEEK_END);

   switch(wFunc)
   {
   case FO_MOVE:
      fprintf(f, __TEXT("\n\n\rMoving:\n\r[%s] to [%s]\n\rat %s"),
                                    pszSrcFile, pszDestFile, szTime);
      break;

   case FO_COPY:
      fprintf(f, __TEXT("\n\n\rCopying:\n\r[%s] to [%s]\n\rat %s"),
                                    pszSrcFile, pszDestFile, szTime);
      break;

   case FO_DELETE:
      fprintf(f, __TEXT("\n\n\rDeleting:\n\r[%s] \n\rat %s"),
                                                 pszSrcFile, szTime);
      break;
   }

   fclose(f);

   // Do not hamper the normal flow
   return IDYES;
}
