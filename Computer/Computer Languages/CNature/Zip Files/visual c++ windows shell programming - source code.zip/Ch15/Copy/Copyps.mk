
Copyps.dll: dlldata.obj Copy_p.obj Copy_i.obj
	link /dll /out:Copyps.dll /def:Copyps.def /entry:DllMain dlldata.obj Copy_p.obj Copy_i.obj \
		kernel32.lib rpcndr.lib rpcns4.lib rpcrt4.lib oleaut32.lib uuid.lib \

.c.obj:
	cl /c /Ox /DWIN32 /D_WIN32_WINNT=0x0400 /DREGISTER_PROXY_DLL \
		$<

clean:
	@del Copyps.dll
	@del Copyps.lib
	@del Copyps.exp
	@del dlldata.obj
	@del Copy_p.obj
	@del Copy_i.obj
