// Monitor.h : Declaration of the CMonitor

#ifndef __MONITOR_H_
#define __MONITOR_H_

#include "resource.h"       // main symbols
#include "ICopyHookImpl.h"

/////////////////////////////////////////////////////////////////////////////
// CMonitor
class ATL_NO_VTABLE CMonitor : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CMonitor, &CLSID_Monitor>,
	public IShellCopyHookImpl,
	public IDispatchImpl<IMonitor, &IID_IMonitor, &LIBID_COPYLib>
{
public:
	CMonitor()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_MONITOR)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CMonitor)
	COM_INTERFACE_ENTRY(IMonitor)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY_IID(IID_IShellCopyHook, CMonitor)
END_COM_MAP()

// ICopyHook
public:
   STDMETHOD_(UINT, CopyCallback)(HWND hwnd, UINT wFunc, UINT wFlags,
                            LPCSTR pszSrcFile,  DWORD dwSrcAttribs,
                            LPCSTR pszDestFile, DWORD dwDestAttribs);

// IMonitor
public:
};

#endif //__MONITOR_H_
