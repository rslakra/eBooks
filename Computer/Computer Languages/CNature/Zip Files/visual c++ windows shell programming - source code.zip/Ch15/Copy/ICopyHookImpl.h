#include <AtlCom.h>
#include <ShlObj.h>

class ATL_NO_VTABLE IShellCopyHookImpl : public ICopyHook
{
public:

   // IUnknown
   STDMETHOD(QueryInterface)(REFIID riid, void** ppvObject) = 0;
   _ATL_DEBUG_ADDREF_RELEASE_IMPL(IShellCopyHookImpl)

   // ICopyHook
   STDMETHOD_(UINT, CopyCallback)(HWND hwnd, UINT wFunc, UINT wFlags,
                            LPCSTR pszSrcFile,  DWORD dwSrcAttribs,
                            LPCSTR pszDestFile, DWORD dwDestAttribs);
};
