//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by BmpIcons.rc
//
#define IDS_PROJNAME                    100
#define IDR_ICON                        101
#define IDI_ICON1                       205
#define IDI_ICON2                       206
#define IDI_ICON3                       207
#define IDI_ICON4                       208

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        209
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
