/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Fri Nov 20 20:02:51 1998
 */
/* Compiler settings for C:\Windows\Desktop\BmpIcons\BmpIcons.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_IIcon = {0xB46F8E10,0x80A3,0x11D2,{0x9D,0xAF,0x00,0x10,0x4B,0x4C,0x82,0x2A}};


const IID LIBID_BMPICONSLib = {0xB46F8E04,0x80A3,0x11D2,{0x9D,0xAF,0x00,0x10,0x4B,0x4C,0x82,0x2A}};


const CLSID CLSID_Icon = {0x99739732,0x6A6B,0x11D2,{0x9D,0xAF,0x00,0x10,0x4B,0x4C,0x82,0x2A}};


#ifdef __cplusplus
}
#endif

