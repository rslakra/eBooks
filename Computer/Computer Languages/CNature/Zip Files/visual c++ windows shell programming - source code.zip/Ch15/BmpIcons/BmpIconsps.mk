
BmpIconsps.dll: dlldata.obj BmpIcons_p.obj BmpIcons_i.obj
	link /dll /out:BmpIconsps.dll /def:BmpIconsps.def /entry:DllMain dlldata.obj BmpIcons_p.obj BmpIcons_i.obj \
		kernel32.lib rpcndr.lib rpcns4.lib rpcrt4.lib oleaut32.lib uuid.lib \

.c.obj:
	cl /c /Ox /DWIN32 /D_WIN32_WINNT=0x0400 /DREGISTER_PROXY_DLL \
		$<

clean:
	@del BmpIconsps.dll
	@del BmpIconsps.lib
	@del BmpIconsps.exp
	@del dlldata.obj
	@del BmpIcons_p.obj
	@del BmpIcons_i.obj
