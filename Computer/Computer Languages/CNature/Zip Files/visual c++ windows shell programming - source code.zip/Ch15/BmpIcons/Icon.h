// Icon.h : Declaration of the CIcon

#ifndef __ICON_H_
#define __ICON_H_

#include "resource.h"       // main symbols
#include "IPersistFileImpl.h"
#include "IExtractIconImpl.h"
#include <comdef.h>

/////////////////////////////////////////////////////////////////////////////
// CIcon
class ATL_NO_VTABLE CIcon : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CIcon, &CLSID_Icon>,
    public IExtractIconImpl,
    public IPersistFileImpl,
	public IDispatchImpl<IIcon, &IID_IIcon, &LIBID_BMPICONSLib>
{
public:
	CIcon()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_ICON)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CIcon)
	COM_INTERFACE_ENTRY(IIcon)
	COM_INTERFACE_ENTRY(IDispatch)
    COM_INTERFACE_ENTRY(IPersistFile)
    COM_INTERFACE_ENTRY(IExtractIcon)
END_COM_MAP()

// IExtractIcon
	STDMETHOD(GetIconLocation)(UINT, LPSTR, UINT, LPINT, UINT*);

// IIcon
public:

protected:
   int GetBitmapColorDepth();
};

#endif //__ICON_H_
