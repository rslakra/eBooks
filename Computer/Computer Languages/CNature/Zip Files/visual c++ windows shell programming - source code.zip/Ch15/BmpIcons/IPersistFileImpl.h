// IPersistFileImpl.h

#include <AtlCom.h>

class ATL_NO_VTABLE IPersistFileImpl : public IPersistFile
{
public:
   TCHAR m_szFile[MAX_PATH];

   // IUnknown
   STDMETHOD(QueryInterface)(REFIID riid, void** ppvObject) = 0;
   _ATL_DEBUG_ADDREF_RELEASE_IMPL(IPersistFileImpl)

   // IPersistFile
   STDMETHOD(GetClassID)(LPCLSID)
   {
      return E_NOTIMPL;
   }

   STDMETHOD(IsDirty)()
   {
      return E_NOTIMPL;
   }

   STDMETHOD(Load)(LPCOLESTR wszFile, DWORD /*dwMode*/)
   {
      USES_CONVERSION;
      lstrcpy(m_szFile, OLE2T(wszFile));
      return S_OK;
   }

   STDMETHOD(Save)(LPCOLESTR, BOOL)
   {
      return E_NOTIMPL;
   }

   STDMETHOD(SaveCompleted)(LPCOLESTR)
   {
      return E_NOTIMPL;
   }

   STDMETHOD(GetCurFile)(LPOLESTR*)
   {
      return E_NOTIMPL;
   }
};
