// IExtractIconImpl.h

#include <AtlCom.h>
#include <ShlObj.h>

class ATL_NO_VTABLE IExtractIconImpl : public IExtractIcon
{
public:

   // IUnknown
   STDMETHOD(QueryInterface)(REFIID riid, void** ppvObject) = 0;
   _ATL_DEBUG_ADDREF_RELEASE_IMPL(IExtractIconImpl)

   // IExtractIcon
   STDMETHOD(Extract)(LPCSTR, UINT, HICON*, HICON*, UINT)
   {
      return S_FALSE;
   }

   STDMETHOD(GetIconLocation)(UINT, LPSTR, UINT, LPINT, UINT*)
   {
      return S_FALSE;
   }
};
