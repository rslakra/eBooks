// Icon.cpp : Implementation of CIcon
#include "stdafx.h"
#include "BmpIcons.h"
#include "Icon.h"

/////////////////////////////////////////////////////////////////////////////
// CIcon

HRESULT CIcon::GetIconLocation(
        UINT uFlags, LPSTR szIconFile, UINT cchMax, LPINT piIndex, UINT* pwFlags)
{
   // We store ourselves the icons
   ::GetModuleFileName(_Module.GetModuleInstance(), szIconFile, cchMax);

   // Analyze the bitmap color table
   int iBitCount = GetBitmapColorDepth();
   if(iBitCount < 0)
      return S_FALSE;

   switch(iBitCount)
   {
   case 1:
      *piIndex = 0;              // Monochrome
      break;

   case 4:
      *piIndex = 1;              // 16 colors
      break;

   case 8:
      *piIndex = 2;              // 256 colors
      break;

   default:
      *piIndex = 3;              // True color
   }

   *pwFlags |= GIL_PERINSTANCE | GIL_DONTCACHE;
   return S_OK;
};

int CIcon::GetBitmapColorDepth()
{
   // Read file header
   HFILE fh = _lopen(m_szFile, OF_READ);
   if(fh == HFILE_ERROR)
      return -1;

   BITMAPFILEHEADER bf;
   _lread(fh, &bf, sizeof(BITMAPFILEHEADER));

   BITMAPINFOHEADER bi;
   _lread(fh, &bi, sizeof(BITMAPINFOHEADER));
   _lclose(fh);

   // Returns
   return bi.biBitCount;
};
