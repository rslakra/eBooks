// PropPage.cpp : Implementation of CPropPage
#include "stdafx.h"
#include "WMFProp.h"
#include "PropPage.h"

TCHAR g_szFile[MAX_PATH];

/////////////////////////////////////////////////////////////////////////////
// CPropPage

HRESULT CPropPage::Initialize(LPCITEMIDLIST pidlFolder, LPDATAOBJECT lpdobj, HKEY hKeyProgID)
{
   if(lpdobj == NULL)
      return E_INVALIDARG;

   // Initialize common controls (Property Sheets are common controls)
   InitCommonControls();

   // Get the name of the selected file from the IDataObject
   // Data is stored in the CF_HDROP format
   STGMEDIUM medium;
   FORMATETC fe = {CF_HDROP, NULL, DVASPECT_CONTENT, -1, TYMED_HGLOBAL};
   HRESULT hr = lpdobj->GetData(&fe, &medium);
   if(FAILED(hr))
      return E_INVALIDARG;
   HDROP hDrop = static_cast<HDROP>(medium.hGlobal);

   if(DragQueryFile(hDrop, 0xFFFFFFFF, NULL, 0) == 1)
   {
      DragQueryFile(hDrop, 0, m_szFile, sizeof(m_szFile));
      hr = NOERROR;
   }
   else
      hr = E_INVALIDARG;

   ReleaseStgMedium(&medium);
   return hr;
}


HRESULT CPropPage::AddPages(LPFNADDPROPSHEETPAGE lpfnAddPage, LPARAM lParam)
{
   lstrcpy(g_szFile, m_szFile);

   // Fill out the PROPSHEETPAGE structure needed to create a new page
   PROPSHEETPAGE psp;
   ZeroMemory(&psp, sizeof(PROPSHEETPAGE));
   psp.dwSize = sizeof(PROPSHEETPAGE);
   psp.dwFlags = PSP_USEREFPARENT | PSP_USETITLE | PSP_DEFAULT;
   psp.hInstance = _Module.GetModuleInstance();
   psp.pszTemplate = MAKEINTRESOURCE(IDD_WMFPROP);
   psp.pszTitle = __TEXT("Preview");
   psp.pfnDlgProc = PropPage_DlgProc;
   psp.lParam = reinterpret_cast<LPARAM>(g_szFile); // Custom data for dlgproc
   psp.pcRefParent = reinterpret_cast<UINT*>(&_Module.m_nLockCnt);

   // Create the new page
   HPROPSHEETPAGE hPage = ::CreatePropertySheetPage(&psp);

   // Add the page to the property sheet
   if(hPage != NULL)
   {
      if(!lpfnAddPage(hPage, lParam))
         ::DestroyPropertySheetPage(hPage);
      return NOERROR;
   }
   return E_INVALIDARG;
}

BOOL CALLBACK PropPage_DlgProc(HWND hwnd, UINT uiMsg, WPARAM wParam, LPARAM lParam)
{
   switch(uiMsg)
   {
   case WM_INITDIALOG:
      HWND hwndMeta = GetDlgItem(hwnd, IDC_METAFILE);
      LPPROPSHEETPAGE lppsp = reinterpret_cast<LPPROPSHEETPAGE>(lParam);
      DisplayMetaFile(hwndMeta, reinterpret_cast<LPTSTR>(lppsp->lParam));
      return FALSE;
   }
   return FALSE;
}

void DisplayMetaFile(HWND hwndMeta, LPTSTR szFile)
{
   // Get the metafile handle
   HENHMETAFILE hemf = GetMetaFileHandle(szFile);
   if(hemf == NULL)
   {
      MessageBox(NULL, __TEXT("Unable to handle the file."), szFile, MB_OK | MB_ICONSTOP);
      return;
   }

   // Free the old file and display the new one
   HENHMETAFILE hemfOld = reinterpret_cast<HENHMETAFILE>(
                SendMessage(hwndMeta, STM_GETIMAGE, IMAGE_ENHMETAFILE, 0));
   if(hemfOld)
      DeleteEnhMetaFile(hemfOld);

   // hwndMeta is a Picture control
   SendMessage(hwndMeta, STM_SETIMAGE, IMAGE_ENHMETAFILE, reinterpret_cast<LPARAM>(hemf));
}

HENHMETAFILE GetMetaFileHandle(LPTSTR szFile)
{
   DWORD dwSize = 0;
   LPBYTE pb = NULL;

   // Try to read it as an EMF
   HENHMETAFILE hEMF = GetEnhMetaFile(szFile);
   if(hEMF)
      return hEMF;

   // Try to read it as a WMF
   HMETAFILE hWMF = GetMetaFile(szFile);
   if(hWMF)
   {
      dwSize = GetMetaFileBitsEx(hWMF, 0, NULL);
      if(dwSize == 0)
      {
         DeleteMetaFile(hWMF);
         return NULL;
      }

      // Allocate enough memory
      pb = new BYTE[dwSize];
      if(pb == NULL)
      {
         DeleteMetaFile(hWMF);
         return NULL;
      }

      // Get the metafile bits
      dwSize = GetMetaFileBitsEx(hWMF, dwSize, pb);
      if(dwSize == 0)
      {
         delete [] pb;
         DeleteMetaFile(hWMF);
         return NULL;
      }

      // Convert to EMF
      hEMF = SetWinMetaFileBits(dwSize, pb, NULL, NULL);

      // Clean up
      DeleteMetaFile(hWMF);
      delete [] pb;
      return hEMF;
   }

   // Try to handle the input as a placeable metafile
   HANDLE hFile = CreateFile(szFile, GENERIC_READ, 0, NULL,
                               OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
   if(hFile == INVALID_HANDLE_VALUE)
      return NULL;

   // Read the file to a buffer
   dwSize = GetFileSize(hFile, NULL);
   pb = new BYTE[dwSize];
   ReadFile(hFile, pb, dwSize, &dwSize, NULL);
   CloseHandle(hFile);

   // Check to see if it is a placeable metafile
   if((reinterpret_cast<LPAPMHEADER>(pb))->dwKey != 0x9ac6cdd7l)
   {
      // Don't know how to handle this...
      delete [] pb;
      return NULL;
   }

   // Create an enhanced metafile from the bits
   hEMF = SetWinMetaFileBits(dwSize, &(pb[sizeof(APMHEADER)]), NULL, NULL);

   delete [] pb;
   return hEMF;
}
