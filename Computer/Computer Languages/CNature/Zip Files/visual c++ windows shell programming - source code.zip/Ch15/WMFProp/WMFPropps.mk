
WMFPropps.dll: dlldata.obj WMFProp_p.obj WMFProp_i.obj
	link /dll /out:WMFPropps.dll /def:WMFPropps.def /entry:DllMain dlldata.obj WMFProp_p.obj WMFProp_i.obj \
		kernel32.lib rpcndr.lib rpcns4.lib rpcrt4.lib oleaut32.lib uuid.lib \

.c.obj:
	cl /c /Ox /DWIN32 /D_WIN32_WINNT=0x0400 /DREGISTER_PROXY_DLL \
		$<

clean:
	@del WMFPropps.dll
	@del WMFPropps.lib
	@del WMFPropps.exp
	@del dlldata.obj
	@del WMFProp_p.obj
	@del WMFProp_i.obj
