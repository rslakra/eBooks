// PropPage.h : Declaration of the CPropPage

#ifndef __PROPPAGE_H_
#define __PROPPAGE_H_

#include "resource.h"               // main symbols
#include <comdef.h>                 // Standard interface GUIDs
#include "IShellExtInitImpl.h"      // IShellExtInit
#include "IShellPropSheetExtImpl.h" // IShellPropSheetExt

#pragma pack(push)
#pragma pack(2)
typedef struct
{
   DWORD       dwKey;
   WORD        hmf;
   SMALL_RECT  bbox;
   WORD        wInch;
   DWORD       dwReserved;
   WORD        wCheckSum;
} APMHEADER, *LPAPMHEADER;
#pragma pack(pop)

void DisplayMetaFile(HWND, LPTSTR);
HENHMETAFILE GetMetaFileHandle(LPTSTR);
BOOL CALLBACK PropPage_DlgProc(HWND, UINT, WPARAM, LPARAM);

/////////////////////////////////////////////////////////////////////////////
// CPropPage
class ATL_NO_VTABLE CPropPage : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CPropPage, &CLSID_PropPage>,
	public IShellExtInitImpl,
	public IShellPropSheetExtImpl,
	public IDispatchImpl<IPropPage, &IID_IPropPage, &LIBID_WMFPROPLib>
{
public:
	CPropPage()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_PROPPAGE)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CPropPage)
	COM_INTERFACE_ENTRY(IPropPage)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IShellExtInit)
	COM_INTERFACE_ENTRY(IShellPropSheetExt)
END_COM_MAP()

// IPropPage
public:
   STDMETHOD(Initialize)(LPCITEMIDLIST, LPDATAOBJECT, HKEY);
   STDMETHOD(AddPages)(LPFNADDPROPSHEETPAGE, LPARAM);
};

#endif //__PROPPAGE_H_
