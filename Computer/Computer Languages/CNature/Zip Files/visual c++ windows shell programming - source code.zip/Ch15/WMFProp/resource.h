//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by WMFProp.rc
//
#define IDS_PROJNAME                    100
#define IDR_PROPPAGE                    101
#define IDD_WMFPROP                     201
#define IDC_METAFILE                    201

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        202
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         202
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
