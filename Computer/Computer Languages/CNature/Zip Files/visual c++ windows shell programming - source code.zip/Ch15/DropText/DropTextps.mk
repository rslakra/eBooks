
DropTextps.dll: dlldata.obj DropText_p.obj DropText_i.obj
	link /dll /out:DropTextps.dll /def:DropTextps.def /entry:DllMain dlldata.obj DropText_p.obj DropText_i.obj \
		kernel32.lib rpcndr.lib rpcns4.lib rpcrt4.lib oleaut32.lib uuid.lib \

.c.obj:
	cl /c /Ox /DWIN32 /D_WIN32_WINNT=0x0400 /DREGISTER_PROXY_DLL \
		$<

clean:
	@del DropTextps.dll
	@del DropTextps.lib
	@del DropTextps.exp
	@del dlldata.obj
	@del DropText_p.obj
	@del DropText_i.obj
