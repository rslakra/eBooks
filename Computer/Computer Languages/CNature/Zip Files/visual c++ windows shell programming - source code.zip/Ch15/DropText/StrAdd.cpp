// StrAdd.cpp : Implementation of CStrAdd
#include "stdafx.h"
#include "DropText.h"
#include "StrAdd.h"
#include <shlwapi.h>

// Constants
const int MAXBUFSIZE = 2048;      // Size of text to retrieve
const int MINBUFSIZE = 50;        // Size of text to be shown

/////////////////////////////////////////////////////////////////////////////
// CStrAdd

HRESULT CStrAdd::Drop(
           LPDATAOBJECT pDO, DWORD dwKeyState, POINTL pt, LPDWORD pdwEffect)
{
   // Get the CF_HDROP data object
   HDROP hdrop = GetHDrop(pDO);
   if(hdrop)
   {
      // Consider only the first file in case of multiple selection
      TCHAR szSrcFile[MAX_PATH] = {0};
      DragQueryFile(hdrop, 0, szSrcFile, MAX_PATH);
      DragFinish(hdrop);

      // Check whether it is a TXT file
      LPTSTR pszExt = PathFindExtension(szSrcFile);
      if(lstrcmpi(pszExt, __TEXT(".txt")))
      {
         MessageBox(GetFocus(),
            __TEXT("Sorry, but you can only drop TXT files!"),
            __TEXT("Drop Files..."),
            MB_ICONSTOP);
         return E_INVALIDARG;
      }

      // Confirmation before concatenating...
      TCHAR s[2 * MAX_PATH] = {0};
      wsprintf(s, __TEXT("Would you add \n%s\nat the bottom of\n%s?"),
                                                       szSrcFile, m_szFile);
      UINT rc = MessageBox(GetFocus(), s,
                       __TEXT("Drop Files..."), MB_ICONQUESTION | MB_YESNO);
      if(rc == IDNO)
         return E_ABORT;
   }
   else
   {
      TCHAR szBuf[MAXBUFSIZE] = {0};
      GetCFText(pDO, szBuf, MAXBUFSIZE);

      TCHAR s[MAX_PATH + MINBUFSIZE] = {0};
      TCHAR sClipb[MINBUFSIZE] = {0};
      lstrcpyn(sClipb, szBuf, MINBUFSIZE);
      wsprintf(s, __TEXT("Would you add\n[%s...]\nat the bottom of\n%s?"),
                                                          sClipb, m_szFile);
      UINT rc = MessageBox(GetFocus(), s,
                       __TEXT("Drop Files..."), MB_ICONQUESTION | MB_YESNO);
      if(rc == IDNO)
         return E_ABORT;
   }

   // TO DO: concatenate the text...
   return S_OK;
}


// Extracts an HDROP from a LPDATAOBJECT
HDROP CStrAdd::GetHDrop(LPDATAOBJECT pDO)
{
   STGMEDIUM sm;
   FORMATETC fe;

   // Check for CF_HDROP data
   ZeroMemory(&sm, sizeof(STGMEDIUM));
   ZeroMemory(&fe, sizeof(FORMATETC));
   fe.tymed = TYMED_HGLOBAL;
   fe.lindex = -1;
   fe.dwAspect = DVASPECT_CONTENT;
   fe.cfFormat = CF_HDROP;
   if(FAILED(pDO->GetData(&fe, &sm)))
      return NULL;
   else
      return static_cast<HDROP>(sm.hGlobal);
}


// Extracts CF_TEXT from a LPDATAOBJECT
BOOL CStrAdd::GetCFText(LPDATAOBJECT pDO, LPTSTR szBuf, UINT nMax)
{
   STGMEDIUM sm;
   FORMATETC fe;

   // Check for CF_TEXT data
   ZeroMemory(&sm, sizeof(STGMEDIUM));
   ZeroMemory(&fe, sizeof(FORMATETC));
   fe.tymed = TYMED_HGLOBAL;
   fe.lindex = -1;
   fe.dwAspect = DVASPECT_CONTENT;
   fe.cfFormat = CF_TEXT;
   if(FAILED(pDO->GetData(&fe, &sm)))
      return FALSE;
   else
   {
      LPTSTR p = static_cast<LPTSTR>(GlobalLock(sm.hGlobal));
      lstrcpyn(szBuf, p, nMax);
      GlobalUnlock(sm.hGlobal);
      return TRUE;
   }
}
