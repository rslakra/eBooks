// StrAdd.h : Declaration of the CStrAdd

#ifndef __STRADD_H_
#define __STRADD_H_

#include "resource.h"       // main symbols
#include "IPersistFileImpl.h"
#include "IDropTargetImpl.h"
#include <ComDef.h>

/////////////////////////////////////////////////////////////////////////////
// CStrAdd
class ATL_NO_VTABLE CStrAdd : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CStrAdd, &CLSID_StrAdd>,
    public IDropTargetImpl,
    public IPersistFileImpl,
	public IDispatchImpl<IStrAdd, &IID_IStrAdd, &LIBID_DROPTEXTLib>
{
public:
	CStrAdd()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_STRADD)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CStrAdd)
	COM_INTERFACE_ENTRY(IStrAdd)
	COM_INTERFACE_ENTRY(IDispatch)
    COM_INTERFACE_ENTRY(IDropTarget)
    COM_INTERFACE_ENTRY(IPersistFile)
END_COM_MAP()

// IDropTarget
public:
   STDMETHOD(Drop)(LPDATAOBJECT, DWORD, POINTL, LPDWORD);

// IStrAdd
public:

private:
   HDROP GetHDrop(LPDATAOBJECT);
   BOOL GetCFText(LPDATAOBJECT, LPTSTR, UINT);
};

#endif //__STRADD_H_
