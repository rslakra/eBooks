// IDropTargetImpl.h

#include <AtlCom.h>

class ATL_NO_VTABLE IDropTargetImpl : public IDropTarget
{
public:

   // IUnknown
   STDMETHOD(QueryInterface)(REFIID riid, void** ppvObject) = 0;
   _ATL_DEBUG_ADDREF_RELEASE_IMPL( IDropTargetImpl )

   // IDropTarget (optimized for shell drag-and-drop)
   STDMETHOD(DragEnter)(LPDATAOBJECT pDO, DWORD dwKeyState, POINTL pt, DWORD *pdwEffect)
   {
      STGMEDIUM sm;
      FORMATETC fe;
   
      // Do we accept this type of data?
      ZeroMemory(&sm, sizeof(STGMEDIUM));
      ZeroMemory(&fe, sizeof(FORMATETC));
      fe.tymed = TYMED_HGLOBAL;
      fe.lindex = -1;
      fe.dwAspect = DVASPECT_CONTENT;
      fe.cfFormat = CF_HDROP; 
      if(FAILED(pDO->GetData(&fe, &sm)))
      {
         fe.cfFormat = CF_TEXT;
         if(FAILED(pDO->GetData(&fe, &sm)))
         {
            // Reject the drag-and-drop
            *pdwEffect = DROPEFFECT_NONE;
            return E_ABORT;
         }
      }

      // The default action is to copy data...
      *pdwEffect = DROPEFFECT_COPY;
      return S_OK;
   }

   STDMETHOD(DragOver)(DWORD dwKeyState, POINTL pt, DWORD* pdwEffect)
   {
      // Do not accept keyboard modifiers
      *pdwEffect = DROPEFFECT_COPY;
      return S_OK;
   }

   STDMETHOD(DragLeave)()
   {
      return S_OK;
   }

   STDMETHOD(Drop)(LPDATAOBJECT pDO, DWORD dwKeyState, POINTL pt, DWORD* pdwEffect);
};
