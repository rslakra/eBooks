/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Fri Nov 20 17:27:34 1998
 */
/* Compiler settings for C:\WINDOWS\Desktop\Depends\Depends.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_IExeMenu = {0x5A72096D,0x808E,0x11D2,{0x9D,0xAF,0x00,0x10,0x4B,0x4C,0x82,0x2A}};


const IID LIBID_DEPENDSLib = {0x5A720961,0x808E,0x11D2,{0x9D,0xAF,0x00,0x10,0x4B,0x4C,0x82,0x2A}};


const CLSID CLSID_ExeMenu = {0x20349851,0x699F,0x11D2,{0x9D,0xAF,0x00,0x10,0x4B,0x4C,0x82,0x2A}};


#ifdef __cplusplus
}
#endif

