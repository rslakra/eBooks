/*****************************************************************
*
*  Application.:  DEPLIST.dll
*  Module......:  DepList.cpp
*  Description.:  DLL main module
*  Compiler....:  MS Visual C++
*  Written by..:  D. Esposito
*
*******************************/

/*---------------------------------------------------------------*/
//                        PRAGMA section
/*---------------------------------------------------------------*/
#ifdef _MSC_VER
   #pragma comment(lib, "kernel32.lib")
   #pragma comment(lib, "user32.lib")
   #pragma comment(lib, "gdi32.lib")
   #pragma comment(lib, "shell32.lib")
   #pragma comment(lib, "imagehlp.lib")
#endif

/*---------------------------------------------------------------*/
//                        INCLUDE section
/*---------------------------------------------------------------*/
#include "DepList.h"

/*---------------------------------------------------------------*/
//                        GLOBAL section
/*---------------------------------------------------------------*/
HINSTANCE g_hThisDll;

// Data
LPTSTR* g_ppszBuf = NULL;
int g_iNumOfBytes = 0;
int g_iNumOfDLLs = 0;

// Callbacks
BOOL CALLBACK SizeOfDLLs(IMAGEHLP_STATUS_REASON, LPSTR, LPSTR, ULONG, ULONG);
BOOL CALLBACK GetDLLs(IMAGEHLP_STATUS_REASON, LPSTR, LPSTR, ULONG, ULONG);

/*---------------------------------------------------------------*/
// Procedure....: DllMain()
// Description..: Library main function
// Input........: HINSTANCE, DWORD, LPVOID
// Output.......: int
/*---------------------------------------------------------------*/
int APIENTRY DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
   switch(dwReason)
   {
   case DLL_PROCESS_ATTACH:
      g_hThisDll = hInstance;
      break;
   }

   return TRUE;
}

int APIENTRY GetImportTableSize(LPCTSTR pszFileName)
{
   g_iNumOfBytes = 0;

   // Bind to the executable
   BindImageEx(BIND_NO_BOUND_IMPORTS | BIND_NO_UPDATE,
               const_cast<LPTSTR>(pszFileName), NULL, NULL, SizeOfDLLs);
   return g_iNumOfBytes;
}

/*----------------------------------------------------------------*/
// Procedure...: GetImportTable
/*----------------------------------------------------------------*/
int APIENTRY GetImportTable(LPCTSTR pszFileName, LPTSTR pszBuf)
{
   g_ppszBuf = &pszBuf;
   g_iNumOfDLLs = 0;

   // Bind to the executable
   BindImageEx(BIND_NO_BOUND_IMPORTS | BIND_NO_UPDATE,
               const_cast<LPTSTR>(pszFileName), NULL, NULL, GetDLLs);
   return g_iNumOfDLLs;
}


/*----------------------------------------------------------------*/
// Procedure...: SizeOfDLLs()
// Description.: Callback for calculating the size of DLLs
/*----------------------------------------------------------------*/
BOOL CALLBACK SizeOfDLLs(IMAGEHLP_STATUS_REASON Reason,
                LPSTR ImageName, LPSTR DllName, ULONG Va, ULONG Parameter)
{
   if(Reason == BindImportModule || Reason == BindImportModuleFailed)
      g_iNumOfBytes += lstrlen(DllName) + 1;
   return TRUE;
}


/*----------------------------------------------------------------*/
// Procedure...: GetDLLs()
// Description.: Callback for packaging a string
/*----------------------------------------------------------------*/
BOOL CALLBACK GetDLLs(IMAGEHLP_STATUS_REASON Reason, LPSTR ImageName,
                      LPSTR DllName, ULONG Va, ULONG Parameter)
{
   if(Reason == BindImportModule || Reason == BindImportModuleFailed)
   {
      lstrcpy(*g_ppszBuf, DllName);
      *g_ppszBuf += lstrlen(*g_ppszBuf) + 1;
      g_iNumOfDLLs++;
   }
   return TRUE;
}


/*  End of module: DepList.cpp  */
