// DepListView.cpp : Implementation of CDepListView
#include "stdafx.h"
#include "DepListView.h"


void MakeReportView(HWND hwndList, LPTSTR* psz, int iNumOfCols)
{
   RECT rc;

   DWORD dwStyle = GetWindowStyle(hwndList);
   SetWindowLong(hwndList, GWL_STYLE, dwStyle | LVS_REPORT);
   GetClientRect(hwndList, &rc);

   // Handle pairs of entries. Array size is assumed to be 2 * iNumOfCols
   for(int i = 0 ; i < 2 * iNumOfCols ; i = i + 2)
   {
      LV_COLUMN lvc;
      ZeroMemory(&lvc, sizeof(LV_COLUMN));
      lvc.mask = LVCF_TEXT | LVCF_WIDTH;
      lvc.pszText = psz[i];
      if(reinterpret_cast<int>(psz[i + 1]) == 0)
         lvc.cx = rc.right / iNumOfCols;
      else
         lvc.cx = reinterpret_cast<int>(psz[i + 1]);

      ListView_InsertColumn(hwndList, i, &lvc);
   }
   return;
}

void AddStringToReportView(HWND hwndList, LPTSTR psz, int iNumOfCols)
{
   LV_ITEM lvi;
   ZeroMemory(&lvi, sizeof(LV_ITEM));
   lvi.mask = LVIF_TEXT;
   lvi.pszText = psz;
   lvi.cchTextMax = lstrlen(psz);
   lvi.iItem = 0;
   ListView_InsertItem(hwndList, &lvi);

   // Other columns
   for(int i = 1 ; i < iNumOfCols ; i++)
   {
      psz += lstrlen(psz) + 1;
      ListView_SetItemText(hwndList, 0, i, psz);
   }
   return;
}

DWORD SHGetVersionOfFile(LPTSTR szFile, LPTSTR szBuf, LPINT lpiBuf, int iNumOfFields)
{
   DWORD dwUseless = 0;
   UINT iBufSize = 0;
   VS_FIXEDFILEINFO* lpFFI = NULL;
   TCHAR s[MAX_PATH] = {0};

   DWORD dwLen = GetFileVersionInfoSize(szFile, &dwUseless);
   if(dwLen == 0)
   {
      if(szBuf)
         lstrcpy(szBuf, __TEXT("<unknown>"));
      return 0;
   }

   LPVOID lpVI = GlobalAllocPtr(GHND, dwLen);
   GetFileVersionInfo(szFile, NULL, dwLen, lpVI);
   VerQueryValue(lpVI, __TEXT("\\"), reinterpret_cast<LPVOID*>(&lpFFI), &iBufSize);
   DWORD dwVer1 = lpFFI->dwFileVersionMS;
   DWORD dwVer2 = lpFFI->dwFileVersionLS;
   GlobalFreePtr(lpVI);

   // Fill return buffers
   if(szBuf != NULL)
   {
      wsprintf(s, __TEXT("%d.%d.%d.%d"), HIWORD(dwVer1), LOWORD(dwVer1), HIWORD(dwVer2), LOWORD(dwVer2));
      lstrcpy(szBuf, s);
   }

   if(lpiBuf != NULL)
   {
      for(int i = 0 ; i < iNumOfFields ; i++)
      {
         if(i == 0)
            lpiBuf[i] = HIWORD(dwVer1);
         if(i == 1)
            lpiBuf[i] = LOWORD(dwVer1);
         if(i == 2)
            lpiBuf[i] = HIWORD(dwVer2);
         if(i == 3)
            lpiBuf[i] = LOWORD(dwVer2);
      }
   }

   return dwVer1;
}

/////////////////////////////////////////////////////////////////////////////
// CDepListView
