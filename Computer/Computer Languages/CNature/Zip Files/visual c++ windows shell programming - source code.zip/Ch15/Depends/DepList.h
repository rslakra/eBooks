/*****************************************************************
*
*  Application.:  DEPLIST.dll
*  Module......:  DepList.cpp
*  Description.:  Library header
*  Compiler....:  MS Visual C++
*  Written by..:  D. Esposito
*
*******************************/

/*---------------------------------------------------------------*/
//                     INCLUDE section
/*---------------------------------------------------------------*/
#define WIN32_LEAN_AND_MEAN
#define STRICT

#include <windows.h>
#include <windowsx.h>
#include <imagehlp.h>

/*---------------------------------------------------------------*/
//                     INCLUDE section
/*---------------------------------------------------------------*/
extern HINSTANCE g_hThisDll;

/*---------------------------------------------------------------*/
//                     PROTOTYPES section
/*---------------------------------------------------------------*/
// Returns the bytes required to hold the names of the DLLs
int APIENTRY GetImportTableSize(LPCTSTR pszFileName);

// Fills the specified buffer with the name of the DLLs
int APIENTRY GetImportTable(LPCTSTR pszFileName, LPTSTR pszBuf);



/*  End of file: DepList.h  */
