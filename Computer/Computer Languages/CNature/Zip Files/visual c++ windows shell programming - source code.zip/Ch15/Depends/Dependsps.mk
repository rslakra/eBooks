
Dependsps.dll: dlldata.obj Depends_p.obj Depends_i.obj
	link /dll /out:Dependsps.dll /def:Dependsps.def /entry:DllMain dlldata.obj Depends_p.obj Depends_i.obj \
		kernel32.lib rpcndr.lib rpcns4.lib rpcrt4.lib oleaut32.lib uuid.lib \

.c.obj:
	cl /c /Ox /DWIN32 /D_WIN32_WINNT=0x0400 /DREGISTER_PROXY_DLL \
		$<

clean:
	@del Dependsps.dll
	@del Dependsps.lib
	@del Dependsps.exp
	@del dlldata.obj
	@del Depends_p.obj
	@del Depends_i.obj
