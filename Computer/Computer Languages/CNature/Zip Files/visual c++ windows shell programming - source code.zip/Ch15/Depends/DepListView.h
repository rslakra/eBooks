// DepListView.h : Declaration of the CDepListView

#ifndef __DEPLISTVIEW_H_
#define __DEPLISTVIEW_H_

#include "resource.h"       // main symbols
#include <atlhost.h>
#include <shlobj.h>
#include <windowsx.h>
#include "DepList.h"

void MakeReportView(HWND, LPTSTR*, int);
void AddStringToReportView(HWND, LPTSTR, int);
DWORD SHGetVersionOfFile(LPTSTR, LPTSTR, LPINT, int);

/////////////////////////////////////////////////////////////////////////////
// CDepListView
class CDepListView : 
	public CAxDialogImpl<CDepListView>
{
public:
	CDepListView()
	{
	}

	~CDepListView()
	{
	}

	enum { IDD = IDD_DEPLISTVIEW };
	TCHAR m_szFile[MAX_PATH];

BEGIN_MSG_MAP(CDepListView)
	MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
	COMMAND_ID_HANDLER(IDOK, OnOK)
	COMMAND_ID_HANDLER(IDCANCEL, OnCancel)
END_MSG_MAP()
// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);

	LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		// Prepare the listview. Uses functions defined in previous chapters
		HWND hwndList = GetDlgItem(IDC_LIST);
		LPTSTR pszCols[] = {__TEXT("Library"), reinterpret_cast<TCHAR*>(280),
		                    __TEXT("Version"), reinterpret_cast<TCHAR*>(103)};
		MakeReportView(hwndList, pszCols, 2);

		// Set the file name using an ellipsis if it's too long
		TCHAR szTemp[60] = {0};
		PathCompactPathEx(szTemp, m_szFile, 60, '\\');
		SetDlgItemText(IDC_FILENAME, szTemp);

		// Get the size of the import table
		int iNumOfBytes = GetImportTableSize(m_szFile);
		if(iNumOfBytes <= 0)
			return 0;

		// Get the COM allocator and reserve some memory
		LPMALLOC pM = NULL;
		SHGetMalloc(&pM);
		LPTSTR psz = static_cast<LPTSTR>(pM->Alloc(iNumOfBytes));
		if(psz == NULL)
		{
			::MessageBox(0, __TEXT("Not enough memory!"), 0, MB_ICONSTOP);
			pM->Release();
			return 0;
		}
		ZeroMemory(psz, iNumOfBytes);

		// Access the import table
		int iNumOfLibs = GetImportTable(m_szFile, psz);
		if(iNumOfLibs <= 0)
		{
			pM->Release();
			return 0;
		}

		int i = 0;
		while(i < iNumOfLibs)
		{
			// p formats a null-separated string for the list view
			TCHAR buf[2048] = {0};
			LPTSTR p = buf;

			lstrcpy(p, psz);
			lstrcat(p, __TEXT("\0"));
			p += lstrlen(p) + 1;

			// Get the version info
			TCHAR szInfo[30] = {0};
			SHGetVersionOfFile(psz, szInfo, NULL, 0);
			lstrcpy(p, szInfo);
			lstrcat(p, __TEXT("\0"));
			p += lstrlen(p) + 1;

			// Add the string
			AddStringToReportView(hwndList, buf, 2);

			// Next library
			psz += lstrlen(psz) + 1;
			i++;
		}

		pM->Release();
		return 1;  // Let the system set the focus
	}

	LRESULT OnOK(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		EndDialog(wID);
		return 0;
	}

	LRESULT OnCancel(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		EndDialog(wID);
		return 0;
	}
};

#endif //__DEPLISTVIEW_H_
