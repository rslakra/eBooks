//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Depends.rc
//
#define IDS_PROJNAME                    100
#define IDR_EXEMENU                     101
#define IDD_DEPLISTVIEW                 102
#define IDC_FILENAME                    201
#define IDC_LIST                        202

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         203
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
