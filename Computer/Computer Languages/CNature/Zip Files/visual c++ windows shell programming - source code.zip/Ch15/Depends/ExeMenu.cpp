// ExeMenu.cpp : Implementation of CExeMenu
#include "stdafx.h"
#include "Depends.h"
#include "ExeMenu.h"

/////////////////////////////////////////////////////////////////////////////
// CExeMenu

// QueryContextMenu
HRESULT CExeMenu::QueryContextMenu(HMENU hmenu, UINT indexMenu, UINT idCmdFirst, UINT idCmdLast, UINT uFlags)
{
   // This shell extension is intended to provide a 'Dependency List'
   //  item on the context menu for EXE files.
   UINT idCmd = idCmdFirst;

   // Add the new item
   InsertMenu(hmenu, indexMenu++, MF_STRING | MF_BYPOSITION, idCmd++, __TEXT("Dependency &List"));
   return MAKE_HRESULT(SEVERITY_SUCCESS, FACILITY_NULL, idCmd - idCmdFirst);
}

// InvokeCommand
HRESULT CExeMenu::InvokeCommand(LPCMINVOKECOMMANDINFO lpcmi)
{
   // Creates a modal dialog to display the information
   lstrcpy(m_Dlg.m_szFile, m_szFile);
   m_Dlg.DoModal();
   return S_OK;
}

// GetCommandString
HRESULT CExeMenu::GetCommandString(UINT idCmd, UINT uFlags, UINT* pwReserved, LPSTR pszText, UINT cchMax)
{
   // We don't care about the command ID, since we have a single item
   if(uFlags & GCS_HELPTEXT)
      lstrcpyn(pszText, __TEXT("Displays all the DLLs needed by the module"), cchMax);
   return S_OK;
}

// Initialize
HRESULT CExeMenu::Initialize(LPCITEMIDLIST pidlFolder, LPDATAOBJECT lpdobj, HKEY hKeyProgID)
{
   if(lpdobj == NULL)
      return E_INVALIDARG;

   // Get the data as CF_HDROP
   STGMEDIUM medium;
   FORMATETC fe = {CF_HDROP, NULL, DVASPECT_CONTENT, -1, TYMED_HGLOBAL};
   HRESULT hr = lpdobj->GetData(&fe, &medium);
   if(FAILED(hr))
      return E_INVALIDARG;

   // Get the name of the selected file
   DragQueryFile(reinterpret_cast<HDROP>(medium.hGlobal), 0, m_szFile, MAX_PATH);

   ReleaseStgMedium(&medium);
   return hr;
};
