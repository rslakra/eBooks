// ExeMenu.h : Declaration of the CExeMenu

#ifndef __EXEMENU_H_
#define __EXEMENU_H_

#include "resource.h"                  // main symbols
#include "IContextMenuImpl.h"          // IContextMenu
#include "IShellExtInitImpl.h"         // IShellExtInit
#include "DepListView.h"               // Dialog
#include <comdef.h>                    // Interface IDs

/////////////////////////////////////////////////////////////////////////////
// CExeMenu
class ATL_NO_VTABLE CExeMenu : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CExeMenu, &CLSID_ExeMenu>,
    public IShellExtInitImpl,
    public IContextMenuImpl,
	public IDispatchImpl<IExeMenu, &IID_IExeMenu, &LIBID_DEPENDSLib>
{
public:
	CExeMenu()
	{
	}

	TCHAR m_szFile[MAX_PATH];           // Name of the executable
    CDepListView m_Dlg;                 // Dialog that shows the results

	// IContextMenu
	STDMETHOD(GetCommandString)(UINT, UINT, UINT*, LPSTR, UINT);
	STDMETHOD(InvokeCommand)(LPCMINVOKECOMMANDINFO);
	STDMETHOD(QueryContextMenu)(HMENU, UINT, UINT , UINT, UINT);

	// IShellExtInit
	STDMETHOD(Initialize)(LPCITEMIDLIST, LPDATAOBJECT, HKEY);

DECLARE_REGISTRY_RESOURCEID(IDR_EXEMENU)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CExeMenu)
	COM_INTERFACE_ENTRY(IExeMenu)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IShellExtInit)
	COM_INTERFACE_ENTRY(IContextMenu)
END_COM_MAP()

// IExeMenu
public:
};

#endif //__EXEMENU_H_
