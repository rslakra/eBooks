/*****************************************************************
*
*  Project.....:  Version Checker
*  Application.:  VERSION.exe
*  Module......:  VERSION.cpp
*  Description.:  Application main module
*  Compiler....:  MS Visual C++
*  Written by..:  D. Esposito
*  Environment.:  Windows 9x/NT
*
******************************************************************/

/*---------------------------------------------------------------*/
//                        PRAGMA section
/*---------------------------------------------------------------*/
// Force the linker to add the following libraries.
#ifdef _MSC_VER

#pragma comment(lib, "kernel32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "comdlg32.lib")
#pragma comment(lib, "version.lib")

#endif

/*---------------------------------------------------------------*/
//                        INCLUDE section
/*---------------------------------------------------------------*/
#include "Version.h"
#include <commctrl.h>
#include <commdlg.h>
#include <shellapi.h>
#include "resource.h"

/*---------------------------------------------------------------*/
//                        GLOBAL section
/*---------------------------------------------------------------*/
// Data
HICON g_hIconLarge;
HICON g_hIconSmall;

const int BUFSIZE = 1024;
const int MSGSIZE = 40;

// Functions
void OnInitDialog(HWND);
void OnOK(HWND);
void OnBrowse(HWND, WPARAM);
void DoGetVersionInfo(HWND);

DWORD SHGetVersionOfFile(LPTSTR, LPTSTR, LPINT, int);

// Callbacks
BOOL CALLBACK APP_DlgProc(HWND, UINT, WPARAM, LPARAM);

// List view helpers
void MakeReportView(HWND hwndList, LPTSTR* psz, int iNumOfCols)
{
   RECT rc;

   DWORD dwStyle = GetWindowStyle(hwndList);
   SetWindowLong(hwndList, GWL_STYLE, dwStyle | LVS_REPORT);
   GetClientRect(hwndList, &rc);

   // Handle pairs of entries. Array size is assumed to be 2 * iNumOfCols
   for(int i = 0 ; i < 2 * iNumOfCols ; i = i + 2)
   {
      LV_COLUMN lvc;
      ZeroMemory(&lvc, sizeof(LV_COLUMN));
      lvc.mask = LVCF_TEXT | LVCF_WIDTH;
      lvc.pszText = psz[i];
      if(reinterpret_cast<int>(psz[i + 1]) == 0)
         lvc.cx = rc.right / iNumOfCols;
      else
         lvc.cx = reinterpret_cast<int>(psz[i + 1]);

      ListView_InsertColumn(hwndList, i, &lvc);
   }
   return;
}


void AddStringToReportView(HWND hwndList, LPTSTR psz, int iNumOfCols)
{
   LV_ITEM lvi;
   ZeroMemory(&lvi, sizeof(LV_ITEM));
   lvi.mask = LVIF_TEXT;
   lvi.pszText = psz;
   lvi.cchTextMax = lstrlen(psz);
   lvi.iItem = 0;
   ListView_InsertItem(hwndList, &lvi);

   // Other columns
   for(int i = 1 ; i < iNumOfCols ; i++)
   {
      psz += lstrlen(psz) + 1;
      ListView_SetItemText(hwndList, 0, i, psz);
   }
   return;
}

/*---------------------------------------------------------------*/
// Procedure....: WinMain()
// Description..: Entry point in any Windows program
// Input........: HINSTANCE, HINSTANCE, LPSTR, int
// Output.......: int
/*---------------------------------------------------------------*/
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevious, 
                     LPTSTR lpsz, int iCmd)
{
   // Save global data
   g_hIconLarge = static_cast<HICON>(
              LoadImage(hInstance, "APP_ICON", IMAGE_ICON,
              GetSystemMetrics(SM_CXICON), GetSystemMetrics(SM_CXICON), 0));
   g_hIconSmall = static_cast<HICON>(
              LoadImage(hInstance, "APP_ICON", IMAGE_ICON,
              GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CXSMICON), 0));

   // Enable common controls
   INITCOMMONCONTROLSEX iccex;
   iccex.dwSize = sizeof(INITCOMMONCONTROLSEX);
   iccex.dwICC = ICC_WIN95_CLASSES;
   InitCommonControlsEx(&iccex);

   // Run main dialog
   BOOL b = DialogBox(hInstance, "DLG_MAIN", NULL, APP_DlgProc);

   // Exit
   DestroyIcon(g_hIconLarge);
   DestroyIcon(g_hIconSmall);
   return b;
}


/*---------------------------------------------------------------*/
// Procedure....: APP_DlgProc()
// Description..: Responds to all messages sent to the dialog
// Input........: HWND, UINT, WPARAM, LPARAM
// Output.......: BOOL
/*---------------------------------------------------------------*/
BOOL CALLBACK APP_DlgProc(HWND hDlg, UINT uiMsg, WPARAM wParam, LPARAM lParam)
{
   switch(uiMsg)
   {
   case WM_INITDIALOG:
      OnInitDialog(hDlg);
      break;

   case WM_COMMAND:
      switch(wParam)
      {
      case IDC_BROWSE:
         OnBrowse(hDlg, IDC_FILENAME);
         return FALSE;
      
	  case IDOK:
         DoGetVersionInfo(hDlg);
         return FALSE;

      case IDCANCEL:
         EndDialog(hDlg, FALSE);
         return FALSE;
      }
      break;
   }

   return FALSE;
}


/*****************************************************************
*
*  Internals:
*    - OnOK()
*    - OnInitDialog()
*
******************************************************************/

/*---------------------------------------------------------------*/
// Procedure...: OnOK()
// Description.: Do something
// INPUT.......: HWND
// OUTPUT......: void
/*---------------------------------------------------------------*/
void OnOK(HWND hDlg)
{
   return;
}


/*---------------------------------------------------------------*/
// Procedure...: OnInitDialog()
// Description.: Initialize the dialog
// INPUT.......: HWND
// OUTPUT......: void
/*---------------------------------------------------------------*/
void OnInitDialog(HWND hDlg)
{
   // Initialize the report view with 2 columns: File and Version
   HWND hwndList = GetDlgItem(hDlg, IDC_VIEW);
   LPTSTR psz[] = { __TEXT("File"), reinterpret_cast<TCHAR*>(350),
                    __TEXT("Version"), reinterpret_cast<TCHAR*>(95) };
   MakeReportView(hwndList, psz, 2);

   // Set the icons (T/F as to Large/Small icon)
   SendMessage(hDlg, WM_SETICON, FALSE, reinterpret_cast<LPARAM>(g_hIconSmall));
   SendMessage(hDlg, WM_SETICON, TRUE, reinterpret_cast<LPARAM>(g_hIconLarge));
}


void OnBrowse(HWND hDlg, WPARAM wID)
{
   TCHAR szFile[MAX_PATH] = {0};
   TCHAR szWinDir[MAX_PATH] = {0};
   GetWindowsDirectory(szWinDir, MAX_PATH);

   OPENFILENAME ofn;
   ZeroMemory(&ofn, sizeof(OPENFILENAME));
   ofn.lStructSize = sizeof(OPENFILENAME);
   ofn.lpstrFilter = __TEXT("Executable\0*.exe;*.dll;*.drv;*.vxd\0");
   ofn.nMaxFile = MAX_PATH;
   ofn.lpstrInitialDir = szWinDir;
   ofn.lpstrFile = szFile;

   if(!GetOpenFileName(&ofn))
      return;
   else
      SetDlgItemText(hDlg, wID, ofn.lpstrFile);
}


void DoGetVersionInfo(HWND hDlg)
{
   TCHAR szTemp[MAX_PATH] = {0};
   HWND hwndList = GetDlgItem(hDlg, IDC_VIEW);
   GetDlgItemText(hDlg, IDC_FILENAME, szTemp, MAX_PATH);

   // Create the string for the list view
   TCHAR pszBuf[BUFSIZE] = {0};
   LPTSTR psz = pszBuf;

   lstrcpy(psz, szTemp);
   lstrcat(psz, __TEXT("\0"));
   psz += lstrlen(psz) + 1;

   // Get the version info
   TCHAR szInfo[MSGSIZE] = {0};
   SHGetVersionOfFile(szTemp, szInfo, NULL, 0);
   lstrcpy(psz, szInfo);
   lstrcat(psz, __TEXT("\0"));
   psz += lstrlen(psz) + 1;

   // Add the two column text
   AddStringToReportView(hwndList, pszBuf, 2);
}


DWORD SHGetVersionOfFile(LPTSTR szFile, LPTSTR szBuf, LPINT lpiBuf, int iNumOfFields)
{
   DWORD dwUseless = 0;
   UINT iBufSize = 0;
   VS_FIXEDFILEINFO* lpFFI = NULL;
   TCHAR s[MAX_PATH] = {0};

   DWORD dwLen = GetFileVersionInfoSize(szFile, &dwUseless);
   if(dwLen == 0)
   {
      if(szBuf)
         lstrcpy(szBuf, __TEXT("<unknown>"));
      return 0;
   }

   LPVOID lpVI = GlobalAllocPtr(GHND, dwLen);
   GetFileVersionInfo(szFile, NULL, dwLen, lpVI);
   VerQueryValue(lpVI, __TEXT("\\"), reinterpret_cast<LPVOID*>(&lpFFI), &iBufSize);
   DWORD dwVer1 = lpFFI->dwFileVersionMS;
   DWORD dwVer2 = lpFFI->dwFileVersionLS;
   GlobalFreePtr(lpVI);

   // Fill return buffers
   if(szBuf != NULL)
   {
      wsprintf(s, __TEXT("%d.%d.%d.%d"), HIWORD(dwVer1), LOWORD(dwVer1), HIWORD(dwVer2), LOWORD(dwVer2));
      lstrcpy(szBuf, s);
   }

   if(lpiBuf != NULL)
   {
      for(int i = 0 ; i < iNumOfFields ; i++)
      {
         if(i == 0)
            lpiBuf[i] = HIWORD(dwVer1);
         if(i == 1)
            lpiBuf[i] = LOWORD(dwVer1);
         if(i == 2)
            lpiBuf[i] = HIWORD(dwVer2);
         if(i == 3)
            lpiBuf[i] = LOWORD(dwVer2);
      }
   }

   return dwVer1;
}


/*  End of file: Version.cpp  */
