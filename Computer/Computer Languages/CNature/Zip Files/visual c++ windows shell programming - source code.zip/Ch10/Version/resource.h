//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Version.rc
//
#define IDC_VIEW                        1000
#define IDC_FILENAME                    1001
#define IDC_BROWSE                      1002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
