/*****************************************************************
*
*  Project.....:  Drive Formatting
*  Application.:  FORMAT.exe
*  Module......:  FORMAT.cpp
*  Description.:  Application main module
*  Compiler....:  MS Visual C++
*  Written by..:  D. Esposito
*  Environment.:  Windows 9x/NT
*
******************************************************************/

/*---------------------------------------------------------------*/
//                        PRAGMA section
/*---------------------------------------------------------------*/
// Force the linker to add the following libraries.
#ifdef _MSC_VER

#pragma comment(lib, "kernel32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "comctl32.lib")

#endif

// Macro to post check messages more quickly
#define CHECK(h,b) PostMessage(h, BM_SETCHECK, (b ? BST_CHECKED : BST_UNCHECKED), 0)

/*---------------------------------------------------------------*/
//                        INCLUDE section
/*---------------------------------------------------------------*/
#include "Format.h"
#include <commctrl.h>
#include <shellapi.h> 
#include "resource.h"

/*---------------------------------------------------------------*/
//                        GLOBAL section
/*---------------------------------------------------------------*/
// Structures
struct FORMATDRIVESTRUCT
{
   BOOL  bShowSummary;            // Unused under Windows NT
   BOOL  bNoLabel;                // Unused under Windows NT
   BOOL  bCopySystemFiles;        // Unused under Windows NT
   BOOL  bAutomatic;              // Unused under Windows NT
   TCHAR szLabel[11];
};

typedef FORMATDRIVESTRUCT* LPFORMATDRIVESTRUCT;

// Data
HICON g_hIconLarge;
HICON g_hIconSmall;
HHOOK g_hHook = NULL;             // CBT hook
BOOL g_bIsNT;                     // Are we on NT?
FORMATDRIVESTRUCT g_fd;           // Other options
HWND g_hwndDlg;                   // Dialog HWND
UINT g_idTimer;                   // Timer ID

// IDs of Windows 9x standard dialog controls
const int ID_DLG_TEXTLABEL =       0x26;    // Edit box for label
const int ID_DLG_NOLABEL =         0x27;    // "No Label" checkbox
const int ID_DLG_BOOTABLE =        0x28;    // "System files" checkbox
const int ID_DLG_SHOWSUMMARY =     0x29;    // "Show Summary" checkbox

// IDs of NT4 standard dialog controls
const int ID_NT_DLG_TEXTLABEL =    0x7007;  // Edit box for label

// Functions
void OnInitDialog(HWND);
void OnOK(HWND);

extern "C" DWORD WINAPI SHFormatDrive(HWND hwnd, UINT drive, UINT fmtID, UINT options);
int FormatDrive(HWND hWnd, int iDrive, int iCapacity, int iType, LPFORMATDRIVESTRUCT lpfd);

// Callbacks
BOOL CALLBACK APP_DlgProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK CBTProc(int, WPARAM, LPARAM);
void CALLBACK TimerProc(HWND, UINT, UINT, DWORD);

/*---------------------------------------------------------------*/
// Procedure....: WinMain()
// Description..: Entry point in any Windows program
// Input........: HINSTANCE, HINSTANCE, LPSTR, int
// Output.......: int
/*---------------------------------------------------------------*/
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevious, 
                     LPTSTR lpsz, int iCmd)
{
   // Save global data
   g_hIconLarge = static_cast<HICON>(
              LoadImage(hInstance, "APP_ICON", IMAGE_ICON,
              GetSystemMetrics(SM_CXICON), GetSystemMetrics(SM_CXICON), 0));
   g_hIconSmall = static_cast<HICON>(
              LoadImage(hInstance, "APP_ICON", IMAGE_ICON,
              GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CXSMICON), 0));

   // Enable common controls
   INITCOMMONCONTROLSEX iccex;
   iccex.dwSize = sizeof(INITCOMMONCONTROLSEX);
   iccex.dwICC = ICC_WIN95_CLASSES;
   InitCommonControlsEx(&iccex);

   // Run main dialog
   BOOL b = DialogBox(hInstance, "DLG_MAIN", NULL, APP_DlgProc);

   // Exit
   DestroyIcon(g_hIconLarge);
   DestroyIcon(g_hIconSmall);
   return b;
}


/*---------------------------------------------------------------*/
// Procedure....: APP_DlgProc()
// Description..: Responds to all messages sent to the dialog
// Input........: HWND, UINT, WPARAM, LPARAM
// Output.......: BOOL
/*---------------------------------------------------------------*/
BOOL CALLBACK APP_DlgProc(HWND hDlg, UINT uiMsg, WPARAM wParam, LPARAM lParam)
{
   switch(uiMsg)
   {
   case WM_INITDIALOG:
      OnInitDialog(hDlg);
      break;

   case WM_COMMAND:
      switch(wParam)
      {
      case IDOK:
         OnOK(hDlg);
         return FALSE;

      case IDCANCEL:
         EndDialog(hDlg, FALSE);
         return FALSE;
      }
      break;
   }

   return FALSE;
}


/*****************************************************************
*
*  Internals:
*    - OnOK()
*    - OnInitDialog()
*
******************************************************************/

/*---------------------------------------------------------------*/
// Procedure...: OnOK()
// Description.: Do something
// INPUT.......: HWND
// OUTPUT......: void
/*---------------------------------------------------------------*/
void OnOK(HWND hDlg)
{
   HWND hwndCbo = GetDlgItem(hDlg, IDC_DRIVE);
   int iDrive = ComboBox_GetCurSel(hwndCbo);

   FORMATDRIVESTRUCT fd;
   ZeroMemory(&fd, sizeof(FORMATDRIVESTRUCT));
   fd.bNoLabel = (IsDlgButtonChecked(hDlg, IDC_NOLABEL) == BST_CHECKED);
   fd.bShowSummary = (IsDlgButtonChecked(hDlg, IDC_SUMMARY) == BST_CHECKED);
   fd.bCopySystemFiles = (IsDlgButtonChecked(hDlg, IDC_COPYSYSTEMFILES) == BST_CHECKED);
   fd.bAutomatic = (IsDlgButtonChecked(hDlg, IDC_AUTOMATIC) == BST_CHECKED);
   GetDlgItemText(hDlg, IDC_EDIT, fd.szLabel, 11);
   int irc = FormatDrive(hDlg, iDrive, -1, 0, &fd);

   TCHAR szBuf[MAX_PATH] = {0};
   wsprintf(szBuf, __TEXT("%d"), irc);
   SetDlgItemText(hDlg, IDC_ERRCODE, szBuf);
}


/*---------------------------------------------------------------*/
// Procedure...: OnInitDialog()
// Description.: Initialize the dialog
// INPUT.......: HWND
// OUTPUT......: void
/*---------------------------------------------------------------*/
void OnInitDialog(HWND hDlg)
{
   // Read the platform...
   OSVERSIONINFO os;
   os.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
   GetVersionEx(&os);
   BOOL bIsNT = (os.dwPlatformId == VER_PLATFORM_WIN32_NT);

   // Change something if under NT
   if(bIsNT)
   {
      EnableWindow(GetDlgItem(hDlg, IDC_SUMMARY), FALSE);
      EnableWindow(GetDlgItem(hDlg, IDC_NOLABEL), FALSE);
      EnableWindow(GetDlgItem(hDlg, IDC_COPYSYSTEMFILES), FALSE);
      EnableWindow(GetDlgItem(hDlg, IDC_AUTOMATIC), FALSE);
   }

   // Fill the drive list
   HWND hwndCbo = GetDlgItem(hDlg, IDC_DRIVE);
   ComboBox_AddString(hwndCbo, __TEXT(" A:"));
   ComboBox_AddString(hwndCbo, __TEXT(" B:"));
   ComboBox_AddString(hwndCbo, __TEXT(" C:"));
   ComboBox_AddString(hwndCbo, __TEXT(" D:"));
   ComboBox_AddString(hwndCbo, __TEXT(" E:"));
   ComboBox_SetCurSel(hwndCbo, 0);

   // Set the icons (T/F as to Large/Small icon)
   SendMessage(hDlg, WM_SETICON, FALSE, reinterpret_cast<LPARAM>(g_hIconSmall));
   SendMessage(hDlg, WM_SETICON, TRUE, reinterpret_cast<LPARAM>(g_hIconLarge));
}


// Format a drive calling the standard SHFormatDrive() function
int FormatDrive(HWND hWnd, int iDrive, int iCapacity, int iType, LPFORMATDRIVESTRUCT lpfd)
{
   // Read the platform for later use...
   OSVERSIONINFO os;
   os.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
   GetVersionEx(&os);
   g_bIsNT = (os.dwPlatformId == VER_PLATFORM_WIN32_NT);

   // Check the drive type
   TCHAR sz[5] = {0};
   wsprintf(sz, __TEXT("%c:\\"), 'A' + iDrive);
   BOOL bIsFloppy = (GetDriveType(sz) == DRIVE_REMOVABLE);
   if(!bIsFloppy)
      return -3;

   // Copy the additional parameters to global memory
   CopyMemory(&g_fd, lpfd, sizeof(FORMATDRIVESTRUCT));

   // Install the hook and call the function
   g_hHook = SetWindowsHookEx(WH_CBT, CBTProc, NULL, GetCurrentThreadId());
   int irc = SHFormatDrive(hWnd, iDrive, iCapacity, iType);
   UnhookWindowsHookEx(g_hHook);
   return irc;
}


// CBT hook callback
LRESULT CALLBACK CBTProc(int iCode, WPARAM wParam, LPARAM lParam)
{
   static BOOL bFirstTime = TRUE;

   if(iCode < 0)
      return CallNextHookEx(g_hHook, iCode, wParam, lParam);

   // About to activate the dialog
   if(iCode == HCBT_ACTIVATE)
   {
      // Get a handle to the dialog
      g_hwndDlg = reinterpret_cast<HWND>(wParam);

      // Set the label edit box
      int iLabelID = (g_bIsNT ? ID_NT_DLG_TEXTLABEL : ID_DLG_TEXTLABEL);
      SetDlgItemText(g_hwndDlg, iLabelID, g_fd.szLabel);
      SendDlgItemMessage(g_hwndDlg, iLabelID, EM_SETMODIFY, TRUE, 0);

      // Check the option buttons
      CHECK(GetDlgItem(g_hwndDlg, ID_DLG_SHOWSUMMARY), g_fd.bShowSummary);
      CHECK(GetDlgItem(g_hwndDlg, ID_DLG_NOLABEL), g_fd.bNoLabel);
      CHECK(GetDlgItem(g_hwndDlg, ID_DLG_BOOTABLE), g_fd.bCopySystemFiles);

      // If not the first time, then must skip
      if(g_fd.bAutomatic && bFirstTime)
      {
         // Simulate a click on the Start button
         bFirstTime = FALSE;
         PostMessage(g_hwndDlg, WM_COMMAND, IDOK, 0);

         // Set the timer to detect when formatting ends
         g_idTimer = SetTimer(NULL, 1, 1000, TimerProc);
      }
   }

   // About to destroy the dialog
   if(iCode == HCBT_DESTROYWND)
   {
      // Reset first time flag and stop the timer
      bFirstTime = TRUE;
      if(g_fd.bAutomatic)
         KillTimer(NULL, g_idTimer);
   }

   return CallNextHookEx(g_hHook, iCode, wParam, lParam);
}


// Timer callback
void CALLBACK TimerProc(HWND hwnd, UINT uMsg, UINT idEvent, DWORD dwTime)
{
   HWND hwndOK = GetDlgItem(g_hwndDlg, IDOK);

   // Simulate the Close button being pressed
   if(IsWindowEnabled(hwndOK))
      PostMessage(g_hwndDlg, WM_COMMAND, IDCANCEL, 0);
}

/*  End of file: Format.cpp  */
