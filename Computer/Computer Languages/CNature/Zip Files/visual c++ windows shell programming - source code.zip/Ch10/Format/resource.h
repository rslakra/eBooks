//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Format.rc
//
#define IDC_DRIVE                       1000
#define IDC_AUTOMATIC                   1007
#define IDC_EDIT                        1012
#define IDC_NOLABEL                     1013
#define IDC_SUMMARY                     1014
#define IDC_COPYSYSTEMFILES             1015
#define IDC_ERRCODE                     1016

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
