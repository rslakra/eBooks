/******************************************************************
*
*  Project.....:  Windows View (Namespace Extension)
*
*  Application.:  WINVIEW.dll
*  Module......:  ExtrIcon.h
*  Description.:  IExtractIcon header
*
*  Compiler....:  MS Visual C++ 
*  Written by..:  D. Esposito
*
*  Environment.:  Windows 9x/NT
*
*******************************/


#ifndef EXTRACTICON_H
#define EXTRACTICON_H


#include <windows.h>
#include <shlobj.h>
#include "PidlMgr.h"

// external references
extern HINSTANCE  g_hInst;
extern UINT       g_DllRefCount;
extern HIMAGELIST g_himlLarge;
extern HIMAGELIST g_himlSmall;



/*---------------------------------------------------------------*/
//  CExtractIcon
/*---------------------------------------------------------------*/
class CExtractIcon : public IExtractIcon
{
protected:
   DWORD m_ObjRefCount;

public:
   CExtractIcon(LPCITEMIDLIST);
   ~CExtractIcon();

   //IUnknown methods
   STDMETHOD (QueryInterface) (REFIID riid, LPVOID * ppvObj);
   STDMETHOD_ (ULONG, AddRef) (void);
   STDMETHOD_ (ULONG, Release) (void);

   //IExtractIcon methods
   STDMETHOD (GetIconLocation) (UINT, LPTSTR, UINT, LPINT, LPUINT);
   STDMETHOD (Extract) (LPCTSTR, UINT, HICON*, HICON*, UINT);

private:
	LPITEMIDLIST m_pidl;
    LPPIDLMGR m_pPidlMgr;
};


#endif   //EXTRACTICON_H
