/******************************************************************
*
*  Project.....:  Windows View (Namespace Extension)
*
*  Application.:  WINVIEW.dll
*  Module......:  ClsFact.cpp
*  Description.:  IClassFactory implementation
*
*  Compiler....:  MS Visual C++ 
*  Written by..:  D. Esposito
*
*  Environment.:  Windows 9x/NT
*
*******************************/



/*---------------------------------------------------------------*/
//                        INCLUDE section
/*---------------------------------------------------------------*/
#include "ClsFact.h"



/*---------------------------------------------------------------*/
// Class constructor and destructor
/*---------------------------------------------------------------*/
CClassFactory::CClassFactory()
{
m_ObjRefCount = 1;
g_DllRefCount++;
}

CClassFactory::~CClassFactory()
{
g_DllRefCount--;
}



/*---------------------------------------------------------------*/
// IUnknown methods
/*---------------------------------------------------------------*/
STDMETHODIMP CClassFactory::QueryInterface( REFIID riid, LPVOID *ppReturn )
{
	*ppReturn = NULL;

	if( IsEqualIID(riid, IID_IUnknown) )
		*ppReturn = this;
	else 
	if( IsEqualIID(riid, IID_IClassFactory) )
		*ppReturn = (IClassFactory*)this;
	

	if( *ppReturn )
    {
        LPUNKNOWN pUnk = (LPUNKNOWN)(*ppReturn);
		pUnk->AddRef();
		return S_OK;
    }

    return E_NOINTERFACE;
}                                             


STDMETHODIMP_(DWORD) CClassFactory::AddRef()
{
	return ++m_ObjRefCount;
}


STDMETHODIMP_(DWORD) CClassFactory::Release()
{
	if(--m_ObjRefCount == 0)
    {
		delete this;
		return 0;
    }
   
	return m_ObjRefCount;
}



/*---------------------------------------------------------------*/
// IClassFactory methods
/*---------------------------------------------------------------*/
STDMETHODIMP CClassFactory::CreateInstance( LPUNKNOWN pUnknown, 
       REFIID riid, LPVOID *ppObject )
{
	*ppObject = NULL;
	if( pUnknown != NULL )
		return CLASS_E_NOAGGREGATION;

	// creates the namespace's main class
	CShellFolder *pShellFolder = new CShellFolder(NULL, NULL);
	if( NULL==pShellFolder ) 
		return E_OUTOFMEMORY;
  
	// query interface for the return value
	HRESULT hResult = pShellFolder->QueryInterface(riid, ppObject);
	pShellFolder->Release();
	return hResult;
}




/*   End of file: ClsFact.cpp  */