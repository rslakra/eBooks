/******************************************************************
*
*  Project.....:  Windows View (Namespace Extension)
*
*  Application.:  WINVIEW.dll
*  Module......:  MenuIDs.h
*  Description.:  Custom menu item IDs
*
*  Compiler....:  MS Visual C++ 
*  Written by..:  D. Esposito
*
*  Environment.:  Windows 9x/NT
*
*******************************/


// menu items
#define COPY_OF_FCIDM_SHVIEWFIRST 0 // see shlobj.h

#define IDM_VIEW_WEB		(COPY_OF_FCIDM_SHVIEWFIRST + 0x500)
#define IDM_WIN_PROPERTIES	(COPY_OF_FCIDM_SHVIEWFIRST + 0x501)
#define IDM_WIN_PROCESS		(COPY_OF_FCIDM_SHVIEWFIRST + 0x502)
#define IDM_HELP_ABOUT		(COPY_OF_FCIDM_SHVIEWFIRST + 0x503)
