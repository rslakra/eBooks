/******************************************************************
*
*  Project.....:  Windows View (Namespace Extension)
*
*  Application.:  WINVIEW.dll
*  Module......:  ShlFldr.h
*  Description.:  IShellFolder header
*
*  Compiler....:  MS Visual C++ 
*  Written by..:  D. Esposito
*
*  Environment.:  Windows 9x/NT
*
*******************************/


#ifndef SHELLFOLDER_H
#define SHELLFOLDER_H

#include <windows.h>
#include <shlobj.h>
#include "EnumIDL.h"
#include "PidlMgr.h"

extern HINSTANCE g_hInst;
extern UINT g_DllRefCount;



/*---------------------------------------------------------------*/
// CShellFolder
/*---------------------------------------------------------------*/
class CShellFolder : public IShellFolder, IPersistFolder
{
friend class CShellView;

protected:
   DWORD m_ObjRefCount;

public:
   CShellFolder(CShellFolder*, LPCITEMIDLIST);
   ~CShellFolder();

   // IUnknown methods
   STDMETHOD (QueryInterface) (REFIID riid, LPVOID * ppvObj);
   STDMETHOD_ (ULONG, AddRef) (void);
   STDMETHOD_ (ULONG, Release) (void);

   // IPersist methods
   STDMETHODIMP GetClassID(LPCLSID);

   // IPersistFolder methods
   STDMETHODIMP Initialize(LPCITEMIDLIST);

   // IShellFolder methods
   STDMETHOD (ParseDisplayName) (HWND, LPBC, LPOLESTR, LPDWORD, LPITEMIDLIST*, LPDWORD);
   STDMETHOD (EnumObjects) (HWND, DWORD, LPENUMIDLIST*);
   STDMETHOD (BindToObject) (LPCITEMIDLIST, LPBC, REFIID, LPVOID*);
   STDMETHOD (BindToStorage) (LPCITEMIDLIST, LPBC, REFIID, LPVOID*);
   STDMETHOD (CompareIDs) (LPARAM, LPCITEMIDLIST, LPCITEMIDLIST);
   STDMETHOD (CreateViewObject) (HWND, REFIID, LPVOID* );
   STDMETHOD (GetAttributesOf) (UINT, LPCITEMIDLIST*, LPDWORD);
   STDMETHOD (GetUIObjectOf) (HWND, UINT, LPCITEMIDLIST*, REFIID, LPUINT, LPVOID*);
   STDMETHOD (GetDisplayNameOf) (LPCITEMIDLIST, DWORD, LPSTRRET);
   STDMETHOD (SetNameOf) (HWND, LPCITEMIDLIST, LPCOLESTR, DWORD, LPITEMIDLIST*);

private:
	LPITEMIDLIST m_pidl;
	CShellFolder *m_pSFParent;
	LPMALLOC m_pMalloc;
    LPPIDLMGR m_pPidlMgr;
	HWND m_hWnd;
	LPVOID m_pShellView;
	INT m_uSortField;
};

#endif   //SHELLFOLDER_H
