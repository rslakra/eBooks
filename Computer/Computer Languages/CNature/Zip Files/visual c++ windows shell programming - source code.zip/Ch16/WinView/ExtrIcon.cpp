/******************************************************************
*
*  Project.....:  Windows View (Namespace Extension)
*
*  Application.:  WINVIEW.dll
*  Module......:  ExtrIcon.cpp
*  Description.:  IExtractIcon implementation
*
*  Compiler....:  MS Visual C++ 
*  Written by..:  D. Esposito
*
*  Environment.:  Windows 9x/NT
*
*******************************/

#include "ExtrIcon.h"
#include "resource.h"
#include "Utility.h"


/*---------------------------------------------------------------*/
// Constructor and destructor
/*---------------------------------------------------------------*/
CExtractIcon::CExtractIcon( LPCITEMIDLIST pidl )
{
	m_ObjRefCount = 1;
	g_DllRefCount++;

	// creates the PIDL manager
	m_pPidlMgr = new CPidlMgr();
	if( !m_pPidlMgr )
    {
		delete this;
		return;
    }

	m_pidl = m_pPidlMgr->Copy( pidl );
}

CExtractIcon::~CExtractIcon()
{
	g_DllRefCount--;
}



/*---------------------------------------------------------------*/
// IUnknown methods
/*---------------------------------------------------------------*/
STDMETHODIMP CExtractIcon::QueryInterface( REFIID riid, LPVOID *ppReturn )
{
	*ppReturn = NULL;

	if( IsEqualIID(riid, IID_IUnknown) )
		*ppReturn = this;
	else 
	if( IsEqualIID(riid, IID_IExtractIcon) )
		*ppReturn = (IExtractIcon*)this;
	

	if( *ppReturn )
    {
        LPUNKNOWN pUnk = (LPUNKNOWN)(*ppReturn);
		pUnk->AddRef();
		return S_OK;
    }

    return E_NOINTERFACE;
}                                             


STDMETHODIMP_(DWORD) CExtractIcon::AddRef()
{
	return ++m_ObjRefCount;
}


STDMETHODIMP_(DWORD) CExtractIcon::Release()
{
	if( --m_ObjRefCount==0 )
    {
	   delete this;
	   return 0;
	}
   
	return m_ObjRefCount;
}




/*---------------------------------------------------------------*/
// IExtractIcon methods
/*---------------------------------------------------------------*/

STDMETHODIMP CExtractIcon::GetIconLocation(UINT uFlags,
              LPTSTR szIconFile, UINT cchMax, LPINT piIndex, LPUINT puFlags)
{
   *puFlags = GIL_DONTCACHE | GIL_PERINSTANCE;
   return S_FALSE;
}


STDMETHODIMP CExtractIcon::Extract(LPCTSTR pszFile, UINT nIconIndex,
                     HICON* phiconLarge, HICON* phiconSmall, UINT nIconSize)
{
   HWND hwnd = m_pPidlMgr->GetData(m_pidl);
   if(hwnd == GetDesktopWindow() || hwnd == FindWindow(__TEXT("shell_traywnd"), NULL))
   {
      *phiconLarge = LoadIcon(NULL, MAKEINTRESOURCE(IDI_WINLOGO));
      *phiconSmall = LoadIcon(NULL, MAKEINTRESOURCE(IDI_WINLOGO));
      return S_OK;
   }

   *phiconLarge = LoadIcon(g_hInst, MAKEINTRESOURCE(IDI_WINVIEW));
   *phiconSmall = LoadIcon(g_hInst, MAKEINTRESOURCE(IDI_WINVIEW));
   return S_OK;
}


/*  End of file: ExtrIcon.cpp  */