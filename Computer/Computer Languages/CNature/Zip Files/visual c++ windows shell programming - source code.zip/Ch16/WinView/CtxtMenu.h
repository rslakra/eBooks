/******************************************************************
*
*  Project.....:  Windows View (Namespace Extension)
*
*  Application.:  WINVIEW.dll
*  Module......:  CtxtMenu.h
*  Description.:  IContextMenu header
*
*  Compiler....:  MS Visual C++ 
*  Written by..:  D. Esposito
*
*  Environment.:  Windows 9x/NT
*
*******************************/


#ifndef CONTEXTMENU_H
#define CONTEXTMENU_H


#include <windows.h>
#include <shlobj.h>
#include "PidlMgr.h"

// external references
extern HINSTANCE  g_hInst;
extern UINT       g_DllRefCount;
extern HIMAGELIST g_himlSmall;



/*---------------------------------------------------------------*/
//  CContextMenu
/*---------------------------------------------------------------*/
class CContextMenu : public IContextMenu
{
protected:
   DWORD m_ObjRefCount;

public:
   CContextMenu(LPCITEMIDLIST);
   ~CContextMenu();

   // IUnknown methods
   STDMETHOD (QueryInterface) (REFIID riid, LPVOID * ppvObj);
   STDMETHOD_ (ULONG, AddRef) (void);
   STDMETHOD_ (ULONG, Release) (void);

   // IContextMenu methods
   STDMETHOD (InvokeCommand) (LPCMINVOKECOMMANDINFO);
   STDMETHOD (GetCommandString) (UINT, UINT, UINT*, LPSTR, UINT);
   STDMETHOD (QueryContextMenu) (HMENU, UINT, UINT, UINT, UINT);
   

private:
	LPITEMIDLIST m_pidl;
    LPPIDLMGR m_pPidlMgr;


	VOID CopyTextToClipboard( VOID );
	VOID ShowProperties( VOID );
	VOID GetWindowInfoFromPIDL( LPITEMIDLIST, LPSTR );
	static LRESULT CALLBACK PropDlgProc( HWND, UINT, WPARAM, LPARAM );


};


#endif   //CONTEXTMENU_H
