/******************************************************************
*
*  Project.....:  Windows View (Namespace Extension)
*
*  Application.:  WINVIEW.dll
*  Module......:  EnumIDL.h
*  Description.:  IEnumIDList header
*
*  Compiler....:  MS Visual C++ 
*  Written by..:  D. Esposito
*
*  Environment.:  Windows 9x/NT
*
*******************************/


#ifndef ENUMIDLIST_H
#define ENUMIDLIST_H


#include <windows.h>
#include <shlobj.h>
#include "PidlMgr.h"
#include "Utility.h"


// list to keep track of the folder items
typedef struct tagENUMLIST  {
   struct tagENUMLIST   *pNext;
   LPITEMIDLIST         pidl;
} ENUMLIST, FAR *LPENUMLIST;


// data to be passed to the window enumerator
typedef struct tagENUMWND {
	LPARAM lParam;
	HWND hwndParent;
	DWORD dwFlags;
} ENUMWND, FAR* LPENUMWND;



// external references
extern HINSTANCE g_hInst;
extern UINT g_DllRefCount;



/*---------------------------------------------------------------*/
//  CEnumIDList
/*---------------------------------------------------------------*/
class CEnumIDList : public IEnumIDList
{
protected:
   DWORD m_ObjRefCount;
   
public:
   CEnumIDList(HWND, DWORD, HRESULT*);
	~CEnumIDList();
   
   // IUnknown methods
   STDMETHOD (QueryInterface)(REFIID, LPVOID*);
   STDMETHOD_ (DWORD, AddRef)();
   STDMETHOD_ (DWORD, Release)();
   
   // IEnumIDList
   STDMETHOD (Next) (DWORD, LPITEMIDLIST*, LPDWORD);
   STDMETHOD (Skip) (DWORD);
   STDMETHOD (Reset) (void);
   STDMETHOD (Clone) (LPENUMIDLIST*);

   // private data made public by necessity...
   LPMALLOC m_pMalloc;
   LPPIDLMGR  m_pPidlMgr;
   LPENUMLIST m_pFirst;
   LPENUMLIST m_pLast;
   LPENUMLIST m_pCurrent; 
   BOOL NewEnumItem( HWND );
   static BOOL CALLBACK AddToEnumList( HWND, LPARAM );
   
private:
   BOOL CreateEnumList( HWND, DWORD );
   BOOL DeleteList( VOID );
};

#endif   //ENUMIDLIST_H

