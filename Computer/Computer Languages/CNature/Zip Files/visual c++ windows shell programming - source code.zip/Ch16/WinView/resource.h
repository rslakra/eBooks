//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by WinView.rc
//
#define IDS_MI_WINVIEW                  2
#define IDS_MI_PROPERTIES               3
#define IDS_COLUMN1                     7
#define IDS_COLUMN2                     8
#define IDS_COLUMN3                     13
#define IDS_COLUMN4                     14
#define IDS_NOCHILDREN                  15
#define IDS_CHILDREN                    16
#define IDS_MI_PROCESSVIEW              18
#define IDS_MI_ABOUT                    19
#define IDS_COMMENT                     20
#define IDS_ABOUTTEXT                   21
#define IDS_MI_COPY                     22
#define IDS_GENERAL                     23
#define IDS_SELECTFIRST                 24
#define IDI_WINVIEW                     100
#define IDI_WINDOW                      101
#define IDI_PARWND                      113
#define IDI_WND                         114
#define IDR_CTXTMENU                    115
#define IDD_PROP                        116
#define IDB_BITMAP1                     117
#define IDC_TAB1                        1000
#define IDC_TABCTRL                     1000
#define IDC_EDIT1                       1001
#define IDC_EDIT                        1001
#define IDC_CHECK1                      1002
#define IDC_WNDICON                     1003
#define IDM_CTXT_COPY                   40002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        118
#define _APS_NEXT_COMMAND_VALUE         40004
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
