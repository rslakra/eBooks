/******************************************************************
*
*  Project.....:  Windows View (Namespace Extension)
*
*  Application.:  WINVIEW.dll
*  Module......:  WinView.cpp
*  Description.:  Main DLL/COM functions
*
*  Compiler....:  MS Visual C++ 
*  Written by..:  D. Esposito
*
*  Environment.:  Windows 9x/NT
*
*******************************/


#define _WIN32_IE  0x0401

#include "ShlView.h"
#include "ClsFact.h"
#include "Utility.h"
#include <olectl.h>

#pragma data_seg(".text")
	#define INITGUID
	#include <initguid.h>
	#include <shlguid.h>
	#include "Guid.h"
#pragma data_seg()



// functions
extern "C" BOOL WINAPI DllMain(HINSTANCE, DWORD, LPVOID);

// data
HINSTANCE   g_hInst;
UINT        g_DllRefCount;
int         g_nColumn1;
int         g_nColumn2;
int         g_nColumn3;
int         g_nColumn4;
HIMAGELIST  g_himlSmall;




/*---------------------------------------------------------------*/
// DllMain()
/*---------------------------------------------------------------*/
extern "C" 
BOOL WINAPI DllMain( HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
	switch(dwReason)
	{
	   case DLL_PROCESS_ATTACH:
		  g_hInst = hInstance;
		  GetGlobalSettings();
		  CreateImageLists();
		  break;

	   case DLL_PROCESS_DETACH:
	      SaveGlobalSettings();
		  DestroyImageLists();
		  break;
    }
   
    return TRUE;
}                                 



/*---------------------------------------------------------------*/
// DllCanUnloadNow()
/*---------------------------------------------------------------*/
STDAPI DllCanUnloadNow( VOID )
{
	return (g_DllRefCount ? S_FALSE : S_OK);
}


/*---------------------------------------------------------------*/
// DllGetClassObject()
/*---------------------------------------------------------------*/
STDAPI DllGetClassObject( REFCLSID rclsid, REFIID riid, LPVOID *ppReturn )
{
	*ppReturn = NULL;

	// do we support the CLSID?
	if( !IsEqualCLSID(rclsid, CLSID_WinView) )
	   return CLASS_E_CLASSNOTAVAILABLE;
   
	// call the factory
	CClassFactory *pClassFactory = new CClassFactory();
	if( pClassFactory==NULL )
	   return E_OUTOFMEMORY;
   
	// query interface for the a pointer
	HRESULT hResult = pClassFactory->QueryInterface(riid, ppReturn);
	pClassFactory->Release();
	return hResult;
}


/*---------------------------------------------------------------*/
// DllGetRegisterServer()
/*---------------------------------------------------------------*/

typedef struct{
   HKEY  hRootKey;
   LPTSTR lpszSubKey;
   LPTSTR lpszValueName;
   LPTSTR lpszData;
}REGSTRUCT, *LPREGSTRUCT;

STDAPI DllRegisterServer( VOID )
{
	INT i;
	HKEY hKey;
	LRESULT lResult;
	DWORD dwDisp;
	TCHAR szSubKey[MAX_PATH];
	TCHAR szCLSID[MAX_PATH];
	TCHAR szModule[MAX_PATH];
	LPWSTR pwsz;

	// get the CLSID in string form
	StringFromIID( CLSID_WinView, &pwsz );

	if( pwsz )
	{
		WideCharToLocal( szCLSID, pwsz, ARRAYSIZE(szCLSID) );
        LPMALLOC pMalloc;
        CoGetMalloc(1, &pMalloc);
		if( pMalloc )
		{
	      pMalloc->Free(pwsz);
		  pMalloc->Release();
		}
    }

	// get this DLL's path and file name
	GetModuleFileName( g_hInst, szModule, ARRAYSIZE(szModule) );

	// CLSID entries
	REGSTRUCT ClsidEntries[] = {  
		HKEY_CLASSES_ROOT, TEXT("CLSID\\%s"),                  NULL,                   TEXT("Windows View"),
		HKEY_CLASSES_ROOT, TEXT("CLSID\\%s"),                  TEXT("InfoTip"),        TEXT("Displays the hierarchy of the currently opened windows."),
		HKEY_CLASSES_ROOT, TEXT("CLSID\\%s\\InprocServer32"),  NULL,                   TEXT("%s"),
        HKEY_CLASSES_ROOT, TEXT("CLSID\\%s\\InprocServer32"),  TEXT("ThreadingModel"), TEXT("Apartment"),
        HKEY_CLASSES_ROOT, TEXT("CLSID\\%s\\DefaultIcon"),     NULL,                   TEXT("%s,0"),
        NULL,              NULL,                               NULL,                   NULL};

	for( i=0; ClsidEntries[i].hRootKey; i++ )
    {
		// create the sub key string.
		wsprintf( szSubKey, ClsidEntries[i].lpszSubKey, szCLSID );
        lResult = RegCreateKeyEx(  ClsidEntries[i].hRootKey,
                              szSubKey,
                              0,
                              NULL,
                              REG_OPTION_NON_VOLATILE,
                              KEY_WRITE,
                              NULL,
                              &hKey,
                              &dwDisp );
   
		if( lResult==NOERROR )
		{
			 TCHAR szData[MAX_PATH];
			 wsprintf(szData, ClsidEntries[i].lpszData, szModule);
			 lResult = RegSetValueEx( hKey,
                            ClsidEntries[i].lpszValueName,
                            0,
                            REG_SZ,
                            (LPBYTE)szData,
                            lstrlen(szData) + 1);
      
			 RegCloseKey(hKey);
		}
		else
			return SELFREG_E_CLASS;
    }

	// register the default flags for the folder.
	wsprintf( szSubKey, TEXT("CLSID\\%s\\ShellFolder"), szCLSID );
    lResult = RegCreateKeyEx(  HKEY_CLASSES_ROOT, szSubKey, 0, 
                    NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE,
                    NULL, &hKey, &dwDisp );

	if( lResult==NOERROR )
	{
		DWORD dwData = SFGAO_FOLDER|SFGAO_HASSUBFOLDER|SFGAO_CANDELETE| SFGAO_BROWSABLE | SFGAO_FILESYSTEM;
		lResult = RegSetValueEx( hKey, TEXT("Attributes"), 0,
                REG_BINARY, (LPBYTE)&dwData, sizeof(dwData) );
        RegCloseKey(hKey);
    }
    else
		return SELFREG_E_CLASS;

/*
	Create the sub key string. Change this from "...Desktop..." to 
	"...MyComputer..." if desired.
*/

	// register the name space extension
	wsprintf( szSubKey, 
            TEXT("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Desktop\\NameSpace\\%s"), 
            szCLSID );

	lResult = RegCreateKeyEx(  HKEY_LOCAL_MACHINE,
							   szSubKey,
							   0,
							   NULL,
							   REG_OPTION_NON_VOLATILE,
							   KEY_WRITE,
							   NULL,
							   &hKey,
							   &dwDisp );

	if( lResult==NOERROR )
	{
		TCHAR szData[MAX_PATH];

	    // set the Default string
	    lstrcpy( szData, TEXT("Windows View") );
		lResult = RegSetValueEx(   hKey,
                              NULL,
                              0,
                              REG_SZ,
                              (LPBYTE)szData,
                              lstrlen(szData) + 1);
   
	    // set the "Removal Message" string
		lstrcpy( szData, TEXT("This will remove the icon from your desktop. Run 'regsvr32.exe' to reinstall the Windows View on your PC.") );
		lResult = RegSetValueEx(   hKey,
                              "Removal Message",
                              0,
                              REG_SZ,
                              (LPBYTE)szData,
                              lstrlen(szData) + 1);
		
		RegCloseKey( hKey );
   }
   else
		return SELFREG_E_CLASS;

   // register the extension as approved by NT
   OSVERSIONINFO  osvi;
   osvi.dwOSVersionInfoSize = sizeof(osvi);
   GetVersionEx( &osvi );

   if( VER_PLATFORM_WIN32_NT == osvi.dwPlatformId )
   {
	   lstrcpy( szSubKey, TEXT("Software\\Microsoft\\Windows\\CurrentVersion\\Shell Extensions\\Approved"));
	   lResult = RegCreateKeyEx(  HKEY_LOCAL_MACHINE,
                              szSubKey,
                              0,
                              NULL,
                              REG_OPTION_NON_VOLATILE,
                              KEY_WRITE,
                              NULL,
                              &hKey,
                              &dwDisp);

       if( lResult==NOERROR )
       {
		   TCHAR szData[MAX_PATH];
	       lstrcpy(szData, TEXT("Windows View"));
           lResult = RegSetValueEx( hKey,
                                 szCLSID,
                                 0,
                                 REG_SZ,
                                 (LPBYTE)szData,
                                 lstrlen(szData) + 1);
      
	      RegCloseKey(hKey);
      }
	  else
		  return SELFREG_E_CLASS;
   }

   return S_OK;
}



/*  End of file: WinView.cpp  */