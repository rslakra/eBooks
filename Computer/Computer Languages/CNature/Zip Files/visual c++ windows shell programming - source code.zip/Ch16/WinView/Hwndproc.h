#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>
#include <tlhelp32.h>   // Win9x only
// #include <psapi.h>      // WinNT only

#ifdef __cplusplus
extern "C" {
#endif

BOOL APIENTRY GetProgramFromHwnd( 
    HWND hWnd, LPTSTR szProcName, INT iBufSize );

#ifdef __cplusplus
}
#endif



/*  End of file: HWndProc.h  */
