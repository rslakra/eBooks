/******************************************************************
*
*  Project.....:  Windows View (Namespace Extension)
*
*  Application.:  WINVIEW.dll
*  Module......:  ShlView.h
*  Description.:  IShellView header
*
*  Compiler....:  MS Visual C++ 
*  Written by..:  D. Esposito
*
*  Environment.:  Windows 9x/NT
*
*******************************/


#ifndef SHELLVIEW_H
#define SHELLVIEW_H

#include <windows.h>
#include <windowsx.h>
#include <objbase.h>
#include <shlobj.h>
#include <ServProv.h>
#include <DocObj.h>
#include "ShlFldr.h"
#include "PidlMgr.h"
#include "MenuIDs.h"

extern HINSTANCE  g_hInst;
extern UINT       g_DllRefCount;
extern HIMAGELIST g_himlSmall;

#define NS_CLASS_NAME   TEXT("WinViewNSClass")


//control IDs
#define ID_LISTVIEW     2000



/*--------------------------------------------------------------*/
//  CShellView
/*--------------------------------------------------------------*/
class CShellView : public IShellView, public IOleCommandTarget
{
protected:
   DWORD m_ObjRefCount;
   
public:
   CShellView(CShellFolder*, LPCITEMIDLIST);
   ~CShellView();
   
   // IUnknown methods
   STDMETHOD (QueryInterface)(REFIID, LPVOID*);
   STDMETHOD_ (DWORD, AddRef)();
   STDMETHOD_ (DWORD, Release)();
   
   // IOleWindow
   STDMETHOD (GetWindow) (HWND*);
   STDMETHOD (ContextSensitiveHelp) (BOOL);

   // IShellView methods
   STDMETHOD (TranslateAccelerator) (LPMSG);
   STDMETHOD (EnableModeless) (BOOL);
   STDMETHOD (UIActivate) (UINT);
   STDMETHOD (Refresh) (void);
   STDMETHOD (CreateViewWindow) (LPSHELLVIEW, LPCFOLDERSETTINGS, LPSHELLBROWSER, LPRECT, HWND*);
   STDMETHOD (DestroyViewWindow) (void);
   STDMETHOD (GetCurrentInfo) (LPFOLDERSETTINGS);
   STDMETHOD (AddPropertySheetPages) (DWORD, LPFNADDPROPSHEETPAGE, LPARAM);
   STDMETHOD (SaveViewState) (void);
   STDMETHOD (SelectItem) (LPCITEMIDLIST, UINT);
   STDMETHOD (GetItemObject) (UINT, REFIID, LPVOID*);

   // IOleCommandTarget methods
   STDMETHOD (QueryStatus) (const GUID *, ULONG, OLECMD prgCmds[], OLECMDTEXT *);
   STDMETHOD (Exec) (const GUID *, DWORD, DWORD, VARIANTARG *, VARIANTARG *);

private:
	//private member variables
    UINT m_uState;
	LPITEMIDLIST m_pidl;
	FOLDERSETTINGS m_FolderSettings;
	LPSHELLBROWSER m_pShellBrowser;
	HWND m_hwndParent;
	HWND m_hWnd;
	HWND m_hwndList;
	HMENU m_hMenu;
    CShellFolder *m_pSFParent;
	LPMALLOC m_pMalloc;
    LPPIDLMGR m_pPidlMgr;


	//private member functions
    static LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
    static LRESULT CALLBACK PropDlgProc(HWND, UINT, WPARAM, LPARAM);

	LRESULT UpdateMenu( HMENU );
	HMENU BuildWinViewMenu( VOID );
	VOID MergeFileMenu( HMENU );
	VOID MergeHelpMenu( HMENU );
	LRESULT OnCommand( DWORD, DWORD, HWND );
	LRESULT OnActivate( UINT );
	VOID OnDeactivate( VOID );
	LRESULT OnContextMenu( VOID );
	LRESULT OnSetFocus( VOID );
	LRESULT OnKillFocus( VOID );
	LRESULT OnNotify( UINT, LPNMHDR );
	LRESULT OnSize( WORD, WORD );
	LRESULT OnCreate( VOID );
	LRESULT OnMenuSelect( WORD );
	BOOL CreateList( VOID );
	BOOL InitList( VOID );
	VOID FillList( VOID );
    LRESULT GetSelectedItem( LPLVITEM );
    VOID CopyTextToClipboard( LPITEMIDLIST );
	VOID ShowProperties( LPITEMIDLIST );
};

#endif   //SHELLVIEW_H
