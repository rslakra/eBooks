/******************************************************************
*
*  Project.....:  Windows View (Namespace Extension)
*
*  Application.:  WINVIEW.dll
*  Module......:  Guid.h
*  Description.:  CLSID definition
*
*  Compiler....:  MS Visual C++ 
*  Written by..:  D. Esposito
*
*  Environment.:  Windows 9x/NT
*
*******************************/


// {F778AFE0-2289-11d0-8AEC-00A0C90C9246}
DEFINE_GUID(CLSID_WinView, 0xF778AFE0, 0x2289, 0x11D0, 0x8A, 0xEC, 0x0, 0xA0, 0xC9, 0xC, 0x92, 0x46);
#define CLSID_CmdGrp CLSID_WinView
