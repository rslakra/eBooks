/******************************************************************
*
*  Project.....:  Windows View (Namespace Extension)
*
*  Application.:  WINVIEW.dll
*  Module......:  PidlMgr.h
*  Description.:  PIDL header
*
*  Compiler....:  MS Visual C++ 
*  Written by..:  D. Esposito
*
*  Environment.:  Windows 9x/NT
*
*******************************/

#ifndef PIDLMGR_H
#define PIDLMGR_H

#include <windows.h>
#include <shlobj.h>

// Data structure for PIDLs
struct PIDLDATA
{
   // Add a signature and a version number here if backward compatibility
   //  is a real issue for you. Also add other data that's required to
   //  identify the elements of your folder.
   HWND hwnd;
};

typedef PIDLDATA* LPPIDLDATA;

extern HINSTANCE g_hInst;
extern UINT g_DllRefCount;

/*---------------------------------------------------------------*/
//   CPidlMgr class definition
/*---------------------------------------------------------------*/
class CPidlMgr
{
public:
   CPidlMgr();
   ~CPidlMgr();

   LPITEMIDLIST Create(HWND);
   LPITEMIDLIST Copy(LPCITEMIDLIST);
   void Delete(LPITEMIDLIST);
   UINT GetSize(LPCITEMIDLIST);

   LPITEMIDLIST GetNextItem(LPCITEMIDLIST);
   LPITEMIDLIST GetLastItem(LPCITEMIDLIST);

   BOOL HasChildren(HWND);
   BOOL HasChildrenOfChildren(HWND);
   HWND GetData(LPCITEMIDLIST);
   DWORD GetPidlPath(LPCITEMIDLIST, LPTSTR);

private:
   LPMALLOC m_pMalloc;
   HWND GetDataPointer(LPCITEMIDLIST);
   static BOOL CALLBACK WindowHasChildren(HWND, LPARAM);
};

typedef CPidlMgr* LPPIDLMGR;

#endif  // PIDLMGR_H
