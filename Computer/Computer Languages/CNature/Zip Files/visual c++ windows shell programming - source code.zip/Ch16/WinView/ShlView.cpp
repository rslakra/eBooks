/******************************************************************
*
*  Project.....:  Windows View (Namespace Extension)
*
*  Application.:  WINVIEW.dll
*  Module......:  ShlView.cpp
*  Description.:  IShellView implementation
*
*  Compiler....:  MS Visual C++ 
*  Written by..:  D. Esposito
*
*  Environment.:  Windows 9x/NT
*
*******************************/



/*---------------------------------------------------------------*/
//                        INCLUDE section
/*---------------------------------------------------------------*/
#include "ShlView.h"
#include "Guid.h"
#include "resource.h"
#include "EnumProc.h"




/*---------------------------------------------------------------*/
//  Constructor and destructor
/*---------------------------------------------------------------*/
#pragma comment( lib, "comctl32.lib" )
CShellView::CShellView( CShellFolder *pFolder, LPCITEMIDLIST pidl )
{
	// init common controls
	INITCOMMONCONTROLSEX iccex;
	iccex.dwSize = sizeof(INITCOMMONCONTROLSEX);
	iccex.dwICC = ICC_LISTVIEW_CLASSES;
	InitCommonControlsEx(&iccex);

	m_hMenu = NULL;

	// get the PIDL manager
	m_pPidlMgr = new CPidlMgr();
	if( !m_pPidlMgr )
    {
	   delete this;
	   return;
    }

	m_pSFParent = pFolder;
	if( m_pSFParent )
		m_pSFParent->AddRef();

	// get the shell's memory manager
	if( FAILED(SHGetMalloc(&m_pMalloc)) )
    {
	   delete this;
	   return;
    }

	// other settings
	m_pidl = m_pPidlMgr->Copy(pidl);
	m_uState = SVUIA_DEACTIVATE;

	m_ObjRefCount = 1;
	g_DllRefCount++;
}


CShellView::~CShellView()
{
	if( m_pidl )
    {
	   m_pPidlMgr->Delete( m_pidl );
	   m_pidl = NULL;
    }

	if( m_pSFParent )
	   m_pSFParent->Release();

	if( m_pMalloc )
	   m_pMalloc->Release();

	if( m_pPidlMgr )
	   delete m_pPidlMgr;

	g_DllRefCount--;
}




/*---------------------------------------------------------------*/
// IUnknown methods
/*---------------------------------------------------------------*/
STDMETHODIMP CShellView::QueryInterface( REFIID riid, LPVOID *ppReturn )
{
	*ppReturn = NULL;

	if(IsEqualIID(riid, IID_IUnknown))
	   *ppReturn = this;
	else 
	if(IsEqualIID(riid, IID_IOleWindow))
	   *ppReturn = (IOleWindow*)this;
	else 
	if(IsEqualIID(riid, IID_IOleCommandTarget))
	   *ppReturn = (IOleCommandTarget*)this;
	else 
	if(IsEqualIID(riid, IID_IShellView))
	   *ppReturn = (IShellView*)this;
	
	if( *ppReturn )
    {
        LPUNKNOWN pUnk = (LPUNKNOWN)(*ppReturn);
		pUnk->AddRef();
		return S_OK;
    }

	return E_NOINTERFACE;
}                                             


STDMETHODIMP_(DWORD) CShellView::AddRef()
{
	return ++m_ObjRefCount;
}


STDMETHODIMP_(DWORD) CShellView::Release()
{
	if(--m_ObjRefCount == 0)
    {
	   delete this;
	   return 0;
    }
   
	return m_ObjRefCount;
}



/*---------------------------------------------------------------*/
// IOleWindow methods
/*---------------------------------------------------------------*/
STDMETHODIMP CShellView::GetWindow(HWND *phWnd)
{
	*phWnd = m_hWnd;
	return S_OK;
}

STDMETHODIMP CShellView::ContextSensitiveHelp(BOOL fEnterMode)
{
	return E_NOTIMPL;
}



/*---------------------------------------------------------------*/
// IOleCommandTarget methods
/*---------------------------------------------------------------*/
STDMETHODIMP CShellView::QueryStatus( const GUID *pguidCmdGroup, 
        ULONG cCmds, OLECMD prgCmds[], OLECMDTEXT *pCmdText )
{
	// our command group only
	if( pguidCmdGroup && (*pguidCmdGroup != CLSID_CmdGrp) )
	   return OLECMDERR_E_UNKNOWNGROUP;

	if(!prgCmds)
	   return E_POINTER;

	// return info for all of the commands
	for( UINT i=0; i < cCmds; i++ )
	{
	   switch( prgCmds[i].cmdID )
	   {
		  case IDM_WIN_PROCESS:
		  case IDM_WIN_PROPERTIES:
			 prgCmds[i].cmdf = OLECMDF_SUPPORTED | OLECMDF_ENABLED;
			 break;
	   }
	}

	return S_OK;
}


STDMETHODIMP CShellView::Exec( const GUID *pguidCmdGroup, 
    DWORD nCmdID, DWORD nCmdExecOpt, VARIANTARG *pvaIn, 
    VARIANTARG *pvaOut)
{
	// our command group only
	if( pguidCmdGroup && (*pguidCmdGroup == CLSID_CmdGrp) )
	{
	   OnCommand( nCmdID, 0, NULL );
	   return S_OK;
	}

	return OLECMDERR_E_UNKNOWNGROUP;
}




/*---------------------------------------------------------------*/
// IShellView methods
/*---------------------------------------------------------------*/

// TranslateAccelerator
STDMETHODIMP CShellView::TranslateAccelerator( LPMSG pMsg )
{
	return E_NOTIMPL;
}

// EnableModeless
STDMETHODIMP CShellView::EnableModeless( BOOL fEnable )
{
	return E_NOTIMPL;
}

// Refresh
STDMETHODIMP CShellView::Refresh( VOID )
{
	ListView_DeleteAllItems(m_hwndList);
	FillList();
	return S_OK;
}

// UIActivate
STDMETHODIMP CShellView::UIActivate(UINT uState)
{
   // Exit if the state hasn't changed since last time
   if(m_uState == uState)
      return S_OK;

   // Modify the menu
   OnActivate(uState);

   // Modify the status bar
   if(uState != SVUIA_DEACTIVATE)
   {
      TCHAR szName[MAX_PATH] = {0};

      // Add more parts if needed... as is, it's equivalent to SB_SIMPLE
      int aParts[1] = {-1};

      // Set the number of parts
      m_pShellBrowser->SendControlMsg(FCW_STATUS, SB_SETPARTS, 1,
                                    reinterpret_cast<LPARAM>(aParts), NULL);

      m_pPidlMgr->GetPidlPath(m_pidl, szName);
      m_pShellBrowser->SendControlMsg(FCW_STATUS, SB_SETTEXT, 0,
                                    reinterpret_cast<LPARAM>(szName), NULL);
   }
   return S_OK;
}



// CreateViewWindow
STDMETHODIMP CShellView::CreateViewWindow( LPSHELLVIEW pPrevView, 
    LPCFOLDERSETTINGS lpfs, LPSHELLBROWSER psb, LPRECT prcView, 
    HWND *phWnd )
{
	WNDCLASS wc;
	*phWnd = NULL;

	// register the class
	if( !GetClassInfo(g_hInst, NS_CLASS_NAME, &wc) )
	{
	   ZeroMemory( &wc, sizeof(WNDCLASS) );
	   wc.style          = CS_HREDRAW | CS_VREDRAW;
	   wc.lpfnWndProc    = (WNDPROC)WndProc;
	   wc.cbClsExtra     = 0;
	   wc.cbWndExtra     = 0;
	   wc.hInstance      = g_hInst;
	   wc.hIcon          = NULL;
	   wc.hCursor        = LoadCursor(NULL, IDC_ARROW);
	   wc.hbrBackground  = (HBRUSH)(COLOR_WINDOW + 1);
	   wc.lpszMenuName   = NULL;
	   wc.lpszClassName  = NS_CLASS_NAME;
   
	   if( !RegisterClass(&wc) )
		  return E_FAIL;
	}

	// set up the member variables
	m_pShellBrowser = psb;
	m_FolderSettings = *lpfs;


	// get the parent window
	m_pShellBrowser->GetWindow( &m_hwndParent );

	// create the window, parent of the listview
	*phWnd = CreateWindowEx( 0, NS_CLASS_NAME, NULL,
       WS_CHILD|WS_VISIBLE|WS_CLIPSIBLINGS,
       prcView->left, prcView->top, 
	   prcView->right - prcView->left,
	   prcView->bottom - prcView->top,
	   m_hwndParent, NULL, g_hInst, this );
                           
	if( !*phWnd )
	   return E_FAIL;

	m_pShellBrowser->AddRef();
	return S_OK;
}



// DestroyViewWindow
STDMETHODIMP CShellView::DestroyViewWindow( VOID )
{
	// clean up the UI
	UIActivate( SVUIA_DEACTIVATE );

	if( m_hMenu )
	   DestroyMenu(m_hMenu);

	DestroyWindow( m_hWnd );
	m_pShellBrowser->Release();
	return S_OK;
}



// GetCurrentInfo
STDMETHODIMP CShellView::GetCurrentInfo( LPFOLDERSETTINGS lpfs )
{
	*lpfs = m_FolderSettings;
	return S_OK;
}


// AddPropertySheetPages
STDMETHODIMP CShellView::AddPropertySheetPages( DWORD dwReserved, 
     LPFNADDPROPSHEETPAGE lpfn, LPARAM lParam )
{
	return E_NOTIMPL;
}

// SaveViewState
STDMETHODIMP CShellView::SaveViewState( VOID )
{
	return E_NOTIMPL;
}

// SelectItem
STDMETHODIMP CShellView::SelectItem( LPCITEMIDLIST pidl, UINT u )
{
	return E_NOTIMPL;
}

// GetItemObject
STDMETHODIMP CShellView::GetItemObject( UINT, REFIID, LPVOID* )
{
	return E_NOTIMPL;
}







/*---------------------------------------------------------------*/
// Private Class Members
/*---------------------------------------------------------------*/

// OnActivate
LRESULT CShellView::OnActivate(UINT uState)
{
   // Has state changed since the last time we were called?
   if(m_uState == uState)
      return S_OK;

   // Destroy all our previous changes to the menu
   OnDeactivate();

   // If active...
   if(uState != SVUIA_DEACTIVATE)
   {
      // Step 1: create a new menu
      m_hMenu = CreateMenu();
      if(m_hMenu)
      {
         // Step 2: Share it with the shell through a menu group descriptor
         OLEMENUGROUPWIDTHS omw = {0, 0, 0, 0, 0, 0};
         m_pShellBrowser->InsertMenusSB(m_hMenu, &omw);

         // Step 3: Change the menu
         // Step 3.1: Build and insert the 'Windows View' top level menu
         TCHAR szText[MAX_PATH] = {0};
         LoadString(g_hInst, IDS_MI_WINVIEW, szText, MAX_PATH);

         MENUITEMINFO mii;
         ZeroMemory(&mii, sizeof(MENUITEMINFO));
         mii.cbSize = sizeof(mii);
         mii.fMask = MIIM_SUBMENU | MIIM_TYPE | MIIM_STATE;
         mii.fType = MFT_STRING;
         mii.fState = MFS_ENABLED;
         mii.dwTypeData = szText;
         mii.hSubMenu = BuildWinViewMenu();
         if(mii.hSubMenu)
            InsertMenuItem(m_hMenu, FCIDM_MENU_HELP, FALSE, &mii);

         // Step 3.2: Get the Help menu and merge
         ZeroMemory(&mii, sizeof(MENUITEMINFO));
         mii.cbSize = sizeof(MENUITEMINFO);
         mii.fMask = MIIM_SUBMENU;
         if(GetMenuItemInfo(m_hMenu, FCIDM_MENU_HELP, FALSE, &mii))
            MergeHelpMenu(mii.hSubMenu);

         // Step 3.3: Remove the Edit menu
         DeleteMenu(m_hMenu, FCIDM_MENU_EDIT, MF_BYCOMMAND);

         // Step 3.4: If we have the focus, add items to the File menu
         if(uState == SVUIA_ACTIVATE_FOCUS)
         {
            // Get the File menu and merge
            ZeroMemory(&mii, sizeof(MENUITEMINFO));
            mii.cbSize = sizeof(MENUITEMINFO);
            mii.fMask = MIIM_SUBMENU;
            if(GetMenuItemInfo(m_hMenu, FCIDM_MENU_FILE, FALSE, &mii))
               MergeFileMenu(mii.hSubMenu);
         }

         // Set the new menu
         m_pShellBrowser->SetMenuSB(m_hMenu, NULL, m_hWnd);
      }
   }

   // Save the current state
   m_uState = uState;
   return 0;
}


// OnDeactivate
void CShellView::OnDeactivate()
{
   if(m_uState != SVUIA_DEACTIVATE)
   {
      if(m_hMenu)
      {
         m_pShellBrowser->SetMenuSB(NULL, NULL, NULL);
         m_pShellBrowser->RemoveMenusSB(m_hMenu);
         DestroyMenu(m_hMenu);
         m_hMenu = NULL;
      }
      m_uState = SVUIA_DEACTIVATE;
   }
}


// BuildWinViewMenu
HMENU CShellView::BuildWinViewMenu()
{
   HMENU hSubMenu = CreatePopupMenu();
   if(hSubMenu)
   {
      TCHAR szText[100] = {0};
      MENUITEMINFO mii;

      // Add "Properties" to "Windows View"
      LoadString(g_hInst, IDS_MI_PROPERTIES, szText, 100);
      ZeroMemory(&mii, sizeof(MENUITEMINFO));
      mii.cbSize = sizeof(MENUITEMINFO);
      mii.fMask = MIIM_TYPE | MIIM_ID | MIIM_STATE;
      mii.fType = MFT_STRING;
      mii.fState = MFS_ENABLED;
      mii.dwTypeData = szText;
      mii.wID = IDM_WIN_PROPERTIES;

      // Add at the end of the menu
      InsertMenuItem(hSubMenu, static_cast<UINT>(-1), TRUE, &mii);

      // Add "Process View" to "Windows View"
      LoadString(g_hInst, IDS_MI_PROCESSVIEW, szText, 100);
      ZeroMemory(&mii, sizeof(MENUITEMINFO));
      mii.cbSize = sizeof(MENUITEMINFO);
      mii.fMask = MIIM_TYPE | MIIM_ID | MIIM_STATE;
      mii.fType = MFT_STRING;
      mii.fState = MFS_ENABLED;
      mii.dwTypeData = szText;
      mii.wID = IDM_WIN_PROCESS;

      // Add at the end of the menu
      InsertMenuItem(hSubMenu, static_cast<UINT>(-1), TRUE, &mii);
   }
   return hSubMenu;
}


// MergeFileMenu
void CShellView::MergeFileMenu( HMENU hSubMenu )
{
	if( hSubMenu )
	{
	   MENUITEMINFO mii;
	   CHAR szText[MAX_PATH];

	   ZeroMemory( &mii, sizeof(MENUITEMINFO) );

	   // add "Process View"
	   LoadString(g_hInst, IDS_MI_PROCESSVIEW, szText, 20 );
	   mii.cbSize = sizeof(MENUITEMINFO);
	   mii.fMask = MIIM_TYPE | MIIM_ID | MIIM_STATE;
	   mii.fType = MFT_STRING;
	   mii.fState = MFS_ENABLED;
	   mii.dwTypeData = szText;
	   mii.wID = IDM_WIN_PROCESS;
	   InsertMenuItem( hSubMenu, 0, TRUE, &mii );

	   // add "Properties"
	   LoadString(g_hInst, IDS_MI_PROPERTIES, szText, 20 );
	   mii.cbSize = sizeof(MENUITEMINFO);
	   mii.fMask = MIIM_TYPE | MIIM_ID | MIIM_STATE;
	   mii.fType = MFT_STRING;
	   mii.fState = MFS_ENABLED;
	   mii.dwTypeData = szText;
	   mii.wID = IDM_WIN_PROPERTIES;
	   InsertMenuItem( hSubMenu, 0, TRUE, &mii );

	   // add a separator after them
	   mii.fMask = MIIM_TYPE | MIIM_ID | MIIM_STATE;
	   mii.fType = MFT_SEPARATOR;
	   mii.fState = MFS_ENABLED;
	   InsertMenuItem( hSubMenu, 2, TRUE, &mii );
	}
}


// MergeHelpMenu
void CShellView::MergeHelpMenu( HMENU hSubMenu )
{
	if( hSubMenu )
	{
		CHAR szText[30];
		DeleteMenu( hSubMenu, 0, MF_BYPOSITION );
	    LoadString( g_hInst, IDS_MI_ABOUT, szText, 30 );
		AppendMenu( hSubMenu, MF_STRING, IDM_HELP_ABOUT, szText );
	}		
}




// NS main window's procedure
LRESULT CALLBACK CShellView::WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
   CShellView* pThis = reinterpret_cast<CShellView*>(GetWindowLong(hWnd, GWL_USERDATA));

   switch(uMsg)
   {
   case WM_NCCREATE:
      {
         LPCREATESTRUCT lpcs = reinterpret_cast<LPCREATESTRUCT>(lParam);
         pThis = reinterpret_cast<CShellView*>(lpcs->lpCreateParams);
         SetWindowLong(hWnd, GWL_USERDATA, reinterpret_cast<LONG>(pThis));
         pThis->m_hWnd = hWnd;
      }
      break;

   case WM_CONTEXTMENU:
      return pThis->OnContextMenu();

   case WM_MENUSELECT:
      return pThis->OnMenuSelect(LOWORD(wParam));

   case WM_SIZE:
      return pThis->OnSize(LOWORD(lParam), HIWORD(lParam));

   case WM_CREATE:
      return pThis->OnCreate();

   case WM_SETFOCUS:
      return pThis->OnSetFocus();

   case WM_KILLFOCUS:
      return pThis->OnKillFocus();

   case WM_ACTIVATE:
      return pThis->OnActivate(SVUIA_ACTIVATE_FOCUS);

   case WM_COMMAND:
      return pThis->OnCommand(GET_WM_COMMAND_ID(wParam, lParam),
                              GET_WM_COMMAND_CMD(wParam, lParam),
                              GET_WM_COMMAND_HWND(wParam, lParam));

   case WM_NOTIFY:
      return pThis->OnNotify(wParam, reinterpret_cast<LPNMHDR>(lParam));
   }
   return DefWindowProc(hWnd, uMsg, wParam, lParam);
}


// OnSetFocus
LRESULT CShellView::OnSetFocus()
{
   // Tell the browser we have the focus
   m_pShellBrowser->OnViewWindowActive(this);

   OnActivate(SVUIA_ACTIVATE_FOCUS);
   return 0;
}

// OnKillFocus
LRESULT CShellView::OnKillFocus()
{
   OnActivate(SVUIA_ACTIVATE_NOFOCUS);
   return 0;
}

// OnCommand
LRESULT CShellView::OnCommand( DWORD dwCmdID, DWORD dwCmd, HWND hwndCmd )
{
	switch( dwCmdID )
	{
		case IDM_WIN_PROCESS:
			ProcessDlg( m_hWnd );
			break;
   
		case IDM_WIN_PROPERTIES:
			ShowProperties( NULL );
			break;

		case IDM_HELP_ABOUT:
		{
			HICON hIcon = LoadIcon( g_hInst, MAKEINTRESOURCE(IDI_WINVIEW) );
			CHAR s1[50], s2[50];
		    LoadString( g_hInst, IDS_ABOUTTEXT, s1, 50 );
		    LoadString( g_hInst, IDS_COMMENT, s2, 50 );
			ShellAbout( m_hWnd, s1, s2, hIcon );
			DestroyIcon( hIcon );
		}
		break;
	}

	return 0;
}


// OnNotify
LRESULT CShellView::OnNotify(UINT CtlID, LPNMHDR lpnmh)
{
   switch(lpnmh->code)
   {
   case NM_SETFOCUS:
      OnSetFocus();
      break;

   case NM_KILLFOCUS:
      OnDeactivate();
      break;

   case HDN_ENDTRACK:
      g_nColumn1 = ListView_GetColumnWidth(m_hwndList, 0);
      g_nColumn2 = ListView_GetColumnWidth(m_hwndList, 1);
      g_nColumn3 = ListView_GetColumnWidth(m_hwndList, 2);
      g_nColumn4 = ListView_GetColumnWidth(m_hwndList, 3);
      return 0;

   case HDN_ITEMCLICK:
      {
         NMHEADER* pNMH = reinterpret_cast<NMHEADER*>(lpnmh);

         // Have we to reverse the order?
         if(m_pSFParent->m_uSortField == 1 + pNMH->iItem)
            m_pSFParent->m_uSortField = (-1) * (1 + pNMH->iItem);
         else
            m_pSFParent->m_uSortField = 1 + pNMH->iItem;

         ListView_SortItems(m_hwndList, CompareItems, reinterpret_cast<LPARAM>(m_pSFParent));
      }
      return 0;

   case LVN_ITEMACTIVATE:
      {
         LV_ITEM lvItem;
         ZeroMemory(&lvItem, sizeof(LV_ITEM));
         lvItem.mask = LVIF_PARAM;

         LPNMLISTVIEW lpnmlv = reinterpret_cast<LPNMLISTVIEW>(lpnmh);
         lvItem.iItem = lpnmlv->iItem;
         ListView_GetItem(m_hwndList, &lvItem);
         m_pShellBrowser->BrowseObject(reinterpret_cast<LPITEMIDLIST>(lvItem.lParam),
                              SBSP_DEFBROWSER | SBSP_RELATIVE);
         return 0;
      }
   }
    return 0;
}



// OnSize
LRESULT CShellView::OnSize( WORD wWidth, WORD wHeight )
{
	if( m_hwndList )
	   MoveWindow( m_hwndList, 0, 0, wWidth, wHeight, TRUE );
	return 0;
}


// OnCreate	
LRESULT CShellView::OnCreate( VOID )
{
	if( CreateList() )
	if( InitList() )
		FillList();

    return 0;
}


// OnContextMenu
LRESULT CShellView::OnContextMenu( VOID )
{
	HMENU h = LoadMenu( g_hInst, MAKEINTRESOURCE(IDR_CTXTMENU) );
	HMENU hmnu = GetSubMenu( h, 0 );

	POINT pt;
	::GetCursorPos( &pt );
	UINT uCmd = TrackPopupMenu( hmnu, TPM_LEFTALIGN|TPM_NONOTIFY|TPM_RETURNCMD,
		pt.x, pt.y, 0, m_hwndList/* any wnd, but a wnd! */, NULL );
	DestroyMenu( h );
	

	switch( uCmd )
	{
		case IDM_CTXT_COPY:
			CopyTextToClipboard( NULL );
			break;

		case IDM_WIN_PROPERTIES:
			ShowProperties( NULL );
			break;
	}

	return 1; 
}


// CopyTextToClipboard
VOID CShellView::CopyTextToClipboard( LPITEMIDLIST pidlSource )
{
	// Get a valid PIDL. If NULL is passed try to get the 
	// currently selected item in the listview.
	LPITEMIDLIST pidl;
	if( pidlSource==NULL )
	{
		LV_ITEM lvi;
		if( !GetSelectedItem( &lvi ) ) 
		{
			CHAR s[200];
			LoadString( g_hInst, IDS_SELECTFIRST, s, 200 );
			MessageBox( 0, s, 0, MB_ICONEXCLAMATION );
			return;
		}
		pidl = m_pPidlMgr->Copy( (LPITEMIDLIST) lvi.lParam );
	}
	else
		pidl = m_pPidlMgr->Copy(pidlSource);



	// copy to clipboard
	CHAR szText[MAX_PATH];
	m_pPidlMgr->GetPidlPath( pidl, szText );
	ClipboardCopy( szText );
	return;
}


// ShowProperties
VOID CShellView::ShowProperties( LPITEMIDLIST pidlSource )
{
	// Get a valid PIDL. If NULL is passed try to get the 
	// currently selected item in the listview.
	LPITEMIDLIST pidl;

	if( pidlSource==NULL )
	{
		LV_ITEM lvi;
		if( !GetSelectedItem( &lvi ) ) 
		{
			CHAR s[200];
			LoadString( g_hInst, IDS_SELECTFIRST, s, 200 );
			MessageBox( 0, s, 0, MB_ICONEXCLAMATION );
			return;
		}
		pidl = m_pPidlMgr->Copy( (LPITEMIDLIST) lvi.lParam );
	}
	else
		pidl = m_pPidlMgr->Copy(pidlSource);

	// get the HWND
	HWND hwnd = m_pPidlMgr->GetData( pidl );

	// get info about the window 
	WNDINFO wi;
	GetWindowProperties( hwnd, &wi );
	DialogBoxParam( g_hInst, MAKEINTRESOURCE(IDD_PROP),
		GetFocus(), (DLGPROC) PropDlgProc, (LPARAM) &wi );
}


// GetSelectedItem
LRESULT CShellView::GetSelectedItem( LPLVITEM plvi )
{
	INT i = ListView_GetNextItem( m_hwndList, -1, LVNI_SELECTED );
	if( i == -1 ) 
		return 0;

	if( plvi==NULL )
		return 0;
	
	ZeroMemory( plvi, sizeof(LV_ITEM) );
	plvi->mask = LVIF_PARAM;
	plvi->iItem = i;
	ListView_GetItem( m_hwndList, plvi );
	return 1;
}



// Properties dialog procedure
LRESULT CALLBACK CShellView::PropDlgProc( HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam )
{

	switch( uMsg )
	{
		case WM_INITDIALOG:
		{
			// add a tab
			TC_ITEM tcPage;      
			HWND hctlTab = GetDlgItem( hDlg, IDC_TABCTRL );
		    tcPage.mask = TCIF_TEXT;
			CHAR szBuf[100];
			LoadString( g_hInst, IDS_GENERAL, szBuf, 100 );
			tcPage.pszText = szBuf;
			tcPage.cchTextMax = sizeof(szBuf);
			TabCtrl_InsertItem( hctlTab, 0, (TC_ITEM FAR*)&tcPage );
			
			// initialize
			LPWNDINFO lpwi = (LPWNDINFO) lParam;
			SetDlgItemText( hDlg, IDC_EDIT, lpwi->pszInfo );
			HWND hwndIcon = GetDlgItem(hDlg, IDC_WNDICON);
			SendMessage( hwndIcon, STM_SETIMAGE, IMAGE_ICON, 
				(LPARAM) lpwi->hIcon );
			SetWindowText( hDlg, lpwi->szCaption );
			SetFocus( hwndIcon );
		}
		break;

		case WM_COMMAND:
			switch( LOWORD(wParam) )
			{
				case IDCANCEL:
					EndDialog( hDlg, 0 );
					break;
			}
	}

	return 0;
}





// CreateList
BOOL CShellView::CreateList()
{
   DWORD dwStyle = WS_TABSTOP | WS_VISIBLE | WS_CHILD | WS_BORDER |
                           LVS_SINGLESEL | LVS_REPORT | LVS_SHAREIMAGELISTS;

   // Create the list view
   m_hwndList = CreateWindowEx(WS_EX_CLIENTEDGE, WC_LISTVIEW, NULL, dwStyle,
                               0, 0, 0, 0, m_hWnd,
                               reinterpret_cast<HMENU>(ID_LISTVIEW),
                               g_hInst, NULL);

   if(!m_hwndList)
      return FALSE;

   // Set some extended styles
   DWORD dwExStyle = LVS_EX_TRACKSELECT | LVS_EX_UNDERLINEHOT |
                               LVS_EX_FULLROWSELECT | LVS_EX_HEADERDRAGDROP;

   ListView_SetExtendedListViewStyle(m_hwndList, dwExStyle);
   return TRUE;
}



// InitList
BOOL CShellView::InitList()
{
   TCHAR szString[MAX_PATH] = {0};

   // Empty the list view
   ListView_DeleteAllItems(m_hwndList);

   // Initialize the columns
   LV_COLUMN lvColumn;
   lvColumn.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
   lvColumn.fmt = LVCFMT_LEFT;
   lvColumn.pszText = szString;

   lvColumn.cx = g_nColumn1;
   LoadString(g_hInst, IDS_COLUMN1, szString, MAX_PATH);
   ListView_InsertColumn(m_hwndList, 0, &lvColumn);
   RECT rc;
   GetClientRect(m_hWnd, &rc);

   lvColumn.cx = g_nColumn2;
   LoadString(g_hInst, IDS_COLUMN2, szString, MAX_PATH);
   ListView_InsertColumn(m_hwndList, 1, &lvColumn);

   lvColumn.cx = g_nColumn3;
   LoadString(g_hInst, IDS_COLUMN3, szString, MAX_PATH);
   ListView_InsertColumn(m_hwndList, 2, &lvColumn);

   lvColumn.cx = g_nColumn4;
   LoadString(g_hInst, IDS_COLUMN4, szString, MAX_PATH);
   ListView_InsertColumn(m_hwndList, 3, &lvColumn);

   ListView_SetImageList(m_hwndList, g_himlSmall, LVSIL_SMALL);
   return TRUE;
}


// FillList
void CShellView::FillList()
{
   LPENUMIDLIST pEnumIDList = NULL;

   // Get the enumerator object for the folder. EnumObjects() is called
   // through the pointer received via the CShellView constructor.
   HRESULT hr = m_pSFParent->EnumObjects(
                m_hWnd, SHCONTF_NONFOLDERS | SHCONTF_FOLDERS, &pEnumIDList);

   if(SUCCEEDED(hr))
   {
      LPITEMIDLIST pidl = NULL;

      // Stop redrawing to avoid flickering
      SendMessage(m_hwndList, WM_SETREDRAW, FALSE, 0);

      // Add items
      DWORD dwFetched;
      while((pEnumIDList->Next(1, &pidl, &dwFetched) == S_OK) && dwFetched)
      {
         LV_ITEM lvi;
         ZeroMemory(&lvi, sizeof(LV_ITEM));
         lvi.mask = LVIF_TEXT | LVIF_IMAGE | LVIF_PARAM;
         lvi.iItem = ListView_GetItemCount(m_hwndList);

         // Store PIDL to the HWND, using the lParam member for each item
         HWND h = m_pPidlMgr->GetData(pidl);
         lvi.lParam = reinterpret_cast<LPARAM>(m_pPidlMgr->Create(h));

         // Column 1: state (set image too)
         TCHAR szState[30] = {0};
         if(m_pPidlMgr->HasChildren(h))
         {
            lvi.iImage = 0;
            LoadString(g_hInst, IDS_CHILDREN, szState, 30);
         }
         else
         {
            lvi.iImage = 1;
            LoadString(g_hInst, IDS_NOCHILDREN, szState, 30);
         }
         lvi.pszText = szState;

         // Add the item
         int i = ListView_InsertItem(m_hwndList, &lvi);

         // Fill the subitem 2: HWND
         TCHAR szBuf[MAX_PATH] = {0};
         wsprintf(szBuf, __TEXT("0x%04X"), h);
         ListView_SetItemText(m_hwndList, i, 2, szBuf);

         // Fill the subitem 3: Title
         GetWindowText(h, szBuf, MAX_PATH);
         ListView_SetItemText(m_hwndList, i, 3, szBuf);

         // Fill the subitem 1: Class
         GetClassName(h, szBuf, MAX_PATH);
         ListView_SetItemText(m_hwndList, i, 1, szBuf);
      }

      // Sort the items by HWND initially
      ListView_SortItems(
           m_hwndList, CompareItems, reinterpret_cast<LPARAM>(m_pSFParent));

      // Redraw the list view
      SendMessage(m_hwndList, WM_SETREDRAW, TRUE, 0);
      InvalidateRect(m_hwndList, NULL, TRUE);
      UpdateWindow(m_hwndList);
      pEnumIDList->Release();
   }
}


// OnMenuSelect
LRESULT CShellView::OnMenuSelect( WORD wID )
{
	if( wID==IDM_WIN_PROCESS )
		m_pShellBrowser->SetStatusTextSB( L"Shows the active processes." );

	if( wID==IDM_WIN_PROPERTIES )
		m_pShellBrowser->SetStatusTextSB( L"Shows window properties." );
	
	if( wID==IDM_HELP_ABOUT )
		m_pShellBrowser->SetStatusTextSB( L"Shows information about the 'Windows View' namespace extension." );

	if( wID==4 )
		m_pShellBrowser->SetStatusTextSB( L"Displays command for the 'Windows View' namespace extension." );

	return 1;
}

/*  End of file:  ShlView.cpp  */
