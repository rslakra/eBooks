/******************************************************************
*
*  Project.....:  Windows View (Namespace Extension)
*
*  Application.:  WINVIEW.dll
*  Module......:  CtxtMenu.cpp
*  Description.:  IContextMenu implementation
*
*  Compiler....:  MS Visual C++ 
*  Written by..:  D. Esposito
*
*  Environment.:  Windows 9x/NT
*
*******************************/

#include "CtxtMenu.h"
#include "resource.h"
#include "MenuIDs.h"
#include "PidlMgr.h"
#include "Utility.h"


/*---------------------------------------------------------------*/
// Constructor and destructor
/*---------------------------------------------------------------*/
CContextMenu::CContextMenu( LPCITEMIDLIST pidl )
{
	m_ObjRefCount = 1;
	g_DllRefCount++;
	
	// creates the PIDL manager
	m_pPidlMgr = new CPidlMgr();
	if( !m_pPidlMgr )
    {
		delete this;
		return;
    }

	m_pidl = m_pPidlMgr->Copy( pidl );
}


CContextMenu::~CContextMenu()
{
	if( m_pidl )
		m_pPidlMgr->Delete( m_pidl );

	g_DllRefCount--;
}



/*---------------------------------------------------------------*/
// IUnknown methods
/*---------------------------------------------------------------*/
STDMETHODIMP CContextMenu::QueryInterface( REFIID riid, LPVOID *ppReturn )
{
	*ppReturn = NULL;

	if( IsEqualIID(riid, IID_IUnknown) )
		*ppReturn = this;
	else 
	if( IsEqualIID(riid, IID_IContextMenu) )
		*ppReturn = (IContextMenu*)this;
	

	if( *ppReturn )
    {
        LPUNKNOWN pUnk = (LPUNKNOWN)(*ppReturn);
		pUnk->AddRef();
		return S_OK;
    }

    return E_NOINTERFACE;
}                                             


STDMETHODIMP_(DWORD) CContextMenu::AddRef()
{
	return ++m_ObjRefCount;
}


STDMETHODIMP_(DWORD) CContextMenu::Release()
{
	if( --m_ObjRefCount==0 )
    {
	   delete this;
	   return 0;
	}
   
	return m_ObjRefCount;
}




/*---------------------------------------------------------------*/
// IContextMenu methods
/*---------------------------------------------------------------*/

STDMETHODIMP CContextMenu::InvokeCommand(LPCMINVOKECOMMANDINFO lpcmi)
{
   WORD wCmd = LOWORD(lpcmi->lpVerb);

   switch(wCmd)
   {
   case 1:                        // Properties
      ShowProperties();
      break;

   case 0:                        // Copy
      CopyTextToClipboard();
      break;
   }

   return S_OK;
}


STDMETHODIMP CContextMenu::GetCommandString(UINT, UINT, UINT*, LPSTR, UINT)
{
   return E_NOTIMPL;
}


STDMETHODIMP CContextMenu::QueryContextMenu(HMENU hmenu,
               UINT indexMenu, UINT idCmdFirst, UINT idCmdLast, UINT uFlags)
{
   UINT idCmd = idCmdFirst;

   // Add the new items, loading strings from resources
   TCHAR szItem[100] = {0};

   LoadString(g_hInst, IDS_MI_COPY, szItem, 100);
   InsertMenu(hmenu, indexMenu++, MF_STRING | MF_BYPOSITION, idCmd++, szItem);

   LoadString(g_hInst, IDS_MI_PROPERTIES, szItem, 100);
   InsertMenu(hmenu, indexMenu++, MF_STRING | MF_BYPOSITION, idCmd++, szItem);

   return MAKE_SCODE(SEVERITY_SUCCESS, FACILITY_NULL, idCmd - idCmdFirst);
}






/*----------------------------------------------------------------*/
// Helper functions
/*----------------------------------------------------------------*/

// CopyTextToClipboard
VOID CContextMenu::CopyTextToClipboard( VOID )
{
	CHAR szText[MAX_PATH];
	m_pPidlMgr->GetPidlPath( m_pidl, szText );

	// copy to clipboard
	ClipboardCopy( szText );
	return;
}


// ShowProperties
VOID CContextMenu::ShowProperties( VOID )
{
	// get the HWND
	HWND hwnd = m_pPidlMgr->GetData( m_pidl );

	// get info about the window 
	WNDINFO wi;
	GetWindowProperties( hwnd, &wi );
	DialogBoxParam( g_hInst, MAKEINTRESOURCE(IDD_PROP),
		GetFocus(), (DLGPROC) PropDlgProc, (LPARAM) &wi );
}




// Properties dialog procedure
LRESULT CALLBACK CContextMenu::PropDlgProc( HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	switch( uMsg )
	{
		case WM_INITDIALOG: 
		{
			// add a tab
			TC_ITEM tcPage;      
			HWND hctlTab = GetDlgItem( hDlg, IDC_TABCTRL );
		    tcPage.mask = TCIF_TEXT;
			CHAR szBuf[100];
			LoadString( g_hInst, IDS_GENERAL, szBuf, 100 );
			tcPage.pszText = szBuf;
			tcPage.cchTextMax = sizeof(szBuf);
			TabCtrl_InsertItem( hctlTab, 0, (TC_ITEM FAR*)&tcPage );

			// initialize
			LPWNDINFO lpwi = (LPWNDINFO) lParam;
			SetDlgItemText( hDlg, IDC_EDIT, (LPSTR) lpwi->pszInfo );
			HWND hwndIcon = GetDlgItem( hDlg, IDC_WNDICON );
			SetWindowText( hDlg, lpwi->szCaption );
			SendMessage( hwndIcon, STM_SETIMAGE, IMAGE_ICON, 
				(LPARAM) lpwi->hIcon );
			SetFocus( hwndIcon );
		}
		break;

		case WM_COMMAND:
			switch( LOWORD(wParam) )
			{
				case IDCANCEL:
					EndDialog( hDlg, 0 );
					break;
			}
	}

	return 0;
}



/*  End of file: CtxtMenu.cpp  */