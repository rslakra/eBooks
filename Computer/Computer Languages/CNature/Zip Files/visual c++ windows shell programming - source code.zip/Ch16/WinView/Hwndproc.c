#include "HWndProc.h"

static DWORD g_dwPlatformId=0;
static FARPROC g_pfnCreateSnapshot=0;
static FARPROC g_pfnProcessFirst=0;
static FARPROC g_pfnProcessNext=0;
static FARPROC g_pfnEnumModule=0;
static FARPROC g_pfnModuleNameEx=0;
static HANDLE g_hSupportLib=NULL;

static VOID LoadFuncAddress( VOID );
static VOID UnloadFuncAddress( VOID );


/*--------------------------------------------------------------*/
// GetProgramFromHwnd
/*--------------------------------------------------------------*/
BOOL APIENTRY GetProgramFromHwnd( HWND hWnd, 
    LPTSTR szProcName, INT iBufSize )
{
    if( szProcName==NULL ) return FALSE;
 
    LoadFuncAddress();
    if( g_dwPlatformId==VER_PLATFORM_WIN32_WINDOWS )
    {
       HANDLE hSnapShot;
       PROCESSENTRY32 pe;
       DWORD dwProcessID; 
       BOOL bResult;

       hSnapShot = (HANDLE) g_pfnCreateSnapshot(
          TH32CS_SNAPPROCESS, 0 );
       if( hSnapShot==(HANDLE)-1 ) return FALSE;

       GetWindowThreadProcessId( hWnd, &dwProcessID );
       pe.dwSize = sizeof(PROCESSENTRY32);

       bResult = g_pfnProcessFirst( hSnapShot, &pe );
       while( bResult )
       {
          if( pe.th32ProcessID==dwProcessID )
          {
             lstrcpyn( szProcName, pe.szExeFile, 
                 iBufSize );
             break;
          }
          bResult = g_pfnProcessNext( hSnapShot, &pe );
       }

       CloseHandle( hSnapShot );
    }
    else
    if( g_dwPlatformId==VER_PLATFORM_WIN32_NT )
    {
       DWORD dwProcessID, cb;
       HANDLE hProcess;
       HMODULE hModule;
		
       GetWindowThreadProcessId( hWnd, &dwProcessID );
       hProcess = OpenProcess( PROCESS_QUERY_INFORMATION|
           PROCESS_VM_READ, FALSE, dwProcessID );
       lstrcpy( szProcName, "<Information Unavailable>" );
       if( g_pfnEnumModule( hProcess, &hModule, 
           sizeof(HMODULE), &cb ) )
       {
          g_pfnModuleNameEx( hProcess, hModule, 
            szProcName, iBufSize );
       }
       CloseHandle( hProcess );	
    }
    
    UnloadFuncAddress();
	return TRUE;
}


/*--------------------------------------------------------------*/
//   HELPERs
/*--------------------------------------------------------------*/


VOID LoadFuncAddress( VOID )
{
    OSVERSIONINFO osv;
    osv.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
    GetVersionEx( &osv );
    g_dwPlatformId = osv.dwPlatformId;
    if( g_dwPlatformId==VER_PLATFORM_WIN32_WINDOWS )
    {
      g_hSupportLib = LoadLibrary( "kernel32.dll" );
      g_pfnCreateSnapshot = GetProcAddress( g_hSupportLib,
        "CreateToolhelp32Snapshot" );
      g_pfnProcessFirst = GetProcAddress( g_hSupportLib,
        "Process32First" );
      g_pfnProcessNext = GetProcAddress( g_hSupportLib,
        "Process32Next" );
    }
    else
    if( g_dwPlatformId==VER_PLATFORM_WIN32_NT )
    {
      g_hSupportLib = LoadLibrary( "psapi.dll" );
      g_pfnEnumModule = GetProcAddress( g_hSupportLib, 
        "EnumProcessModules" );
      g_pfnModuleNameEx = GetProcAddress( g_hSupportLib,
        "GetModuleFileNameExA" );
    }
}


VOID UnloadFuncAddress( VOID )
{
    if( g_hSupportLib )
    {
       FreeLibrary( g_hSupportLib );
       g_hSupportLib = NULL;
    }
}



/*  End of module: HWndProc.c  */
