// CUrlfFolder member functions
#include "stdhdr.h"
#include "Urlfenum.h"
#include "Urlfview.h"

extern UINT g_cRefThisDll;


 
/*-------------------------------------------------------------------*/
// Procedure....: CUrlfFolder()
// Description..: Constructor of the class
/*-------------------------------------------------------------------*/
CUrlfFolder::CUrlfFolder()
{
    m_cRef = 1;
    g_cRefThisDll++;
}






/*-------------------------------------------------------------------*/
// Procedure....: ~CUrlfFolder()
// Description..: Destructor of the class
/*-------------------------------------------------------------------*/
CUrlfFolder::~CUrlfFolder()
{
    g_cRefThisDll--;
}






/*-------------------------------------------------------------------*/
// Procedure....: ::QueryInterface()
// Description..: return a pointer to the specified interface
/*-------------------------------------------------------------------*/
STDMETHODIMP CUrlfFolder::QueryInterface( REFIID riid, LPVOID FAR *ppv )
{
    if( IsEqualIID(riid, IID_IUnknown) ) 
	{
        *ppv = (LPUNKNOWN) (IShellFolder *) this;
        m_cRef++;
        return NOERROR;
    }
    else 
	if( IsEqualIID(riid, IID_IShellFolder) ) 
	{
        *ppv = (IShellFolder *) this;
        m_cRef++;
        return NOERROR;
    }
    else 
	if( IsEqualIID(riid, IID_IPersistFolder) ) 
	{
        *ppv = (IPersistFolder *) this;
        m_cRef++;
        return NOERROR;
    }
    else 
	{
        *ppv = NULL;
        return ResultFromScode( E_NOINTERFACE );
    }
}





/*-------------------------------------------------------------------*/
// Procedure....: ::AddRef()
// Description..: increase the reference count for the server 
/*-------------------------------------------------------------------*/
STDMETHODIMP_(ULONG) CUrlfFolder::AddRef()
{
    return ++m_cRef;
}
 




/*-------------------------------------------------------------------*/
// Procedure....: ::Release()
// Description..: decrease the reference count for the server 
/*-------------------------------------------------------------------*/
STDMETHODIMP_(ULONG) CUrlfFolder::Release()
{
    if( --m_cRef==0 )
        delete this;
    return m_cRef;
}





/*-------------------------------------------------------------------*/
// Procedure....: GetFileName()
// Description..: Returns the name of the file being displayed
/*-------------------------------------------------------------------*/
STDMETHODIMP CUrlfFolder::GetFileName( LPTSTR szFileName, INT iBufSize )
{
	if( szFileName==NULL )
		return E_OUTOFMEMORY;

	lstrcpyn( szFileName, m_szFile, iBufSize );
	return NOERROR;
}


// IMPLEMENTED
// IShellFolder methods
//
//   - EnumObjects
//   - CompareIDs
//   - CreateViewObject
//   - GetAttributesOf
//   - GetUIObjectOf
//   - GetDisplayNameOf
//


/*-------------------------------------------------------------------*/
// Procedure....: EnumObjects()
// Description..: Returns a pointer to an item enumerator 
/*-------------------------------------------------------------------*/
STDMETHODIMP CUrlfFolder::EnumObjects( HWND hwndOwner, 
   DWORD grfFlags, LPENUMIDLIST *ppEnum )
{
	CUrlfEnumItem *phei = new CUrlfEnumItem( this, grfFlags );
	if( !phei )  return E_OUTOFMEMORY;

	phei->AddRef();
	HRESULT hr = phei->QueryInterface( IID_IEnumIDList, (LPVOID*)ppEnum );
	phei->Release();

	return hr;
}



/*-------------------------------------------------------------------*/
// Procedure....: CompareIDs()
// Description..: Compares two items in a folder
/*-------------------------------------------------------------------*/
STDMETHODIMP CUrlfFolder::CompareIDs( LPARAM lParam, 
   LPCITEMIDLIST pidl1, LPCITEMIDLIST pidl2 )
{
	return E_NOTIMPL;
}


/*-------------------------------------------------------------------*/
// Procedure....: CreateViewObject()
// Description..: Creates a view for the folder
/*-------------------------------------------------------------------*/
STDMETHODIMP CUrlfFolder::CreateViewObject( HWND hwndOwner, 
   REFIID riid, LPVOID FAR* ppvObj )
{
	IUnknown *pObj = NULL;

	if( riid != IID_IShellView )
		return E_NOINTERFACE;
	
	CUrlfView *phv = new CUrlfView( this );
	if( !phv )  return E_OUTOFMEMORY;

	phv->AddRef();
	HRESULT hr = phv->QueryInterface( riid, ppvObj );
	phv->Release();

	return NOERROR;
}


/*-------------------------------------------------------------------*/
// Procedure....: GetAttributesOf()
// Description..: Returns the attribute of some objects
/*-------------------------------------------------------------------*/
STDMETHODIMP CUrlfFolder::GetAttributesOf( UINT cidl, 
   LPCITEMIDLIST FAR* apidl, ULONG FAR* rgfInOut )
{
	return E_NOTIMPL;
}



/*-------------------------------------------------------------------*/
// Procedure....: GetUIObjectOf()
// Description..: Returns an interface to perform UI actions
/*-------------------------------------------------------------------*/
STDMETHODIMP CUrlfFolder::GetUIObjectOf( HWND hwndOwner, 
   UINT cidl, LPCITEMIDLIST FAR* apidl, REFIID riid, 
   UINT FAR* prgfInOut, LPVOID FAR* ppvObj )
{
/*	IUnknown *pObj = NULL;

	// IExtractIcon required
	if( riid==IID_IExtractIcon )
	{
		if( cidl != 1 )  return E_INVALIDARG;
	}
	else 
	// IContextMenu required
	if( riid==IID_IContextMenu )
	{
		if( cidl <1 ) 	return E_INVALIDARG;
	}
	else 
	// IDataObject required
	if( riid==IID_IDataObject )
	{
		if( cidl <1 ) 	return E_INVALIDARG;
	}
	else
		return E_NOINTERFACE;

	if( !pObj ) 	
		return E_OUTOFMEMORY;
	
	pObj->AddRef();
	HRESULT hr = pObj->QueryInterface( riid, ppvObj );
	pObj->Release();

	return hr;
*/
	return E_NOTIMPL;
}


/*-------------------------------------------------------------------*/
// Procedure....: GetDisplayNameOf()
// Description..: Returns the name to display
/*-------------------------------------------------------------------*/
STDMETHODIMP CUrlfFolder::GetDisplayNameOf( LPCITEMIDLIST pidl, 
   DWORD dwReserved, LPSTRRET lpName )
{
	return E_NOTIMPL;
}




// UNIMPLEMENTED
// IShellFolder methods
//
//   - ParseDisplayName
//   - BindToObject
//   - BindToStorage
//   - SetNameOf
//



/*-------------------------------------------------------------------*/
// Procedure....: ::ParseDisplayName()
// Description..: 
/*-------------------------------------------------------------------*/
STDMETHODIMP CUrlfFolder::ParseDisplayName( HWND hwndOwner,
   LPBC pbc, LPOLESTR lpszDisplayName, ULONG FAR* pchEaten, 
   LPITEMIDLIST * ppidl, ULONG *pdwAttributes)
{
	return E_NOTIMPL;
}


/*-------------------------------------------------------------------*/
// Procedure....: ::BindToObject()
// Description..: 
/*-------------------------------------------------------------------*/
STDMETHODIMP CUrlfFolder::BindToObject( LPCITEMIDLIST pidl, 
   LPBC pbc, REFIID riid, LPVOID FAR* ppvObj )
{
	return E_NOTIMPL;
}


/*-------------------------------------------------------------------*/
// Procedure....: ::BindToStorage()
// Description..: 
/*-------------------------------------------------------------------*/
STDMETHODIMP CUrlfFolder::BindToStorage( LPCITEMIDLIST pidl, 
   LPBC pbc, REFIID riid, LPVOID FAR* ppvObj )
{
	return E_NOTIMPL;
}


/*-------------------------------------------------------------------*/
// Procedure....: ::SetNameOf()
// Description..: 
/*-------------------------------------------------------------------*/
STDMETHODIMP CUrlfFolder::SetNameOf( HWND hwndOwner, LPCITEMIDLIST pidl,
	LPCOLESTR lpszName, DWORD dwReserved, LPITEMIDLIST FAR* ppidlOut )
{
	return E_NOTIMPL;
}





// IMPLEMENTED
// IPersistFolder methods
//
//   - GetClassID
//   - Initialize



/*-------------------------------------------------------------------*/
// Procedure....: GetClassID()
// Description..: Returns the CLSID of this server
/*-------------------------------------------------------------------*/
STDMETHODIMP CUrlfFolder::GetClassID( LPCLSID lpClassID )
{
	*lpClassID = CLSID_UrlfFolder;
	return NOERROR;
}



/*-------------------------------------------------------------------*/
// Procedure....: Initialize()
// Description..: Save the name of the folder
/*-------------------------------------------------------------------*/
STDMETHODIMP CUrlfFolder::Initialize( LPCITEMIDLIST pidl )
{
	SHGetPathFromIDList( pidl, m_szFile );
	return S_OK;
}
