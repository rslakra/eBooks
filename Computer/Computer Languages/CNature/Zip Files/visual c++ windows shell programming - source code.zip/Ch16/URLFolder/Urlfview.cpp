// CUrlfView member functions
#include "stdhdr.h"
#include "Urlfview.h"
#include "Urlffold.h" 
#include "resource.h"
#include <ShlObj.h>

// menu/toolbar command ID
#define IDM_FILE_RUN		101


extern HINSTANCE g_hInstance;

// accessing the object from the dlgproc
static CUrlfView* g_pUrlfView=NULL;

// View functions
LRESULT CALLBACK View_DlgProc( HWND, UINT, WPARAM, LPARAM );
static VOID View_ResizeControls( HWND, LPARAM );
static VOID View_ShowTooltips( LPARAM );

// A more compact macro
#define CHECKMENU(m,id,b)   \
	CheckMenuItem(m, id, MF_BYCOMMAND|(b ?MF_CHECKED :MF_UNCHECKED)) 

static WNDPROC g_pfn = NULL; 
LRESULT CALLBACK MyToolbarProc(HWND, UINT, WPARAM, LPARAM);


/*-------------------------------------------------------------------*/
// Procedure....: CUrlfView()
// Description..: Constructor of the class
/*-------------------------------------------------------------------*/
CUrlfView::CUrlfView( LPSHELLFOLDER lpsf ) 
{
	m_cRef = 1;
	m_pShellFolder = lpsf;
	m_pShellBrowser = NULL;
	m_hwndView = NULL;
	m_hwndMain = NULL;
	m_hMenu = NULL;
	m_uState = SVUIA_DEACTIVATE;

	// save the name of the file being viewed 
	CUrlfFolder *p;
	p = (CUrlfFolder *)m_pShellFolder;
	p->GetFileName( m_szFile, MAX_PATH );

	// save a pointer to this object
	g_pUrlfView = this;
}


/*-------------------------------------------------------------------*/
// Procedure....: ~CUrlfView()
// Description..: Destructor of the class
/*-------------------------------------------------------------------*/
CUrlfView::~CUrlfView()
{
	if( m_hMenu )
	{
		m_pShellBrowser->RemoveMenusSB( m_hMenu );
		DestroyMenu( m_hMenu );
	}
}






/*-------------------------------------------------------------------*/
// Procedure....: ::QueryInterface()
// Description..: return a pointer to the specified interface
/*-------------------------------------------------------------------*/
STDMETHODIMP CUrlfView::QueryInterface( REFIID riid, LPVOID FAR *ppv )
{
    if( IsEqualIID(riid, IID_IUnknown) ) 
	{
        *ppv = (IUnknown *) this;
        m_cRef++;
        return NOERROR;
    }
    else 
	if( IsEqualIID(riid, IID_IShellView) ) 
	{
        *ppv = (IEnumIDList *) this;
        m_cRef++;
        return NOERROR;
    }
    else 
	{
        *ppv = NULL;
        return ResultFromScode( E_NOINTERFACE );
    }
}





/*-------------------------------------------------------------------*/
// Procedure....: ::AddRef()
// Description..: increase the reference count for the server 
/*-------------------------------------------------------------------*/
STDMETHODIMP_(ULONG) CUrlfView::AddRef()
{
    return ++m_cRef;
}
 




/*-------------------------------------------------------------------*/
// Procedure....: ::Release()
// Description..: decrease the reference count for the server 
/*-------------------------------------------------------------------*/
STDMETHODIMP_(ULONG) CUrlfView::Release()
{
    if( --m_cRef==0 )
        delete this;
    return m_cRef;
}







// IMPLEMENTED
// IShellView methods
//
//   - CreateViewWindow
//   - DestroyViewWindow
//   - Refresh
//


/*-------------------------------------------------------------------*/
// Procedure....: CreateViewWindow()
// Description..: 
/*-------------------------------------------------------------------*/
STDMETHODIMP CUrlfView::CreateViewWindow( IShellView *lpPrevView,
    LPCFOLDERSETTINGS lpfs, IShellBrowser *psb, LPRECT prcView, 
	HWND *phWnd )
{
	*phWnd = NULL;
	m_pShellBrowser = psb;

	
	// get the main window handle from shell browser
	psb->GetWindow(&m_hwndMain);

	// show the contents of the file
	m_hwndView = CreateDialog( g_hInstance,
		MAKEINTRESOURCE(IDD_VIEW), m_hwndMain, 
		(DLGPROC) View_DlgProc );
	*phWnd = m_hwndView;


	// resize the view (since it will contains some controls
	// you should resize them in WM_INITDIALOG)
	SetWindowPos( m_hwndView, NULL, prcView->left, prcView->top,
		prcView->right-prcView->left, prcView->bottom-prcView->top,
		SWP_NOZORDER|SWP_SHOWWINDOW );

	return NOERROR;
}


/*-------------------------------------------------------------------*/
// Procedure....: DestroyViewWindow()
// Description..: 
/*-------------------------------------------------------------------*/
STDMETHODIMP CUrlfView::DestroyViewWindow()
{
	if( !m_hwndView )
		return E_UNEXPECTED;

	DestroyWindow( m_hwndView );
	return NOERROR;
}



/*-------------------------------------------------------------------*/
// Procedure....: Refresh()
// Description..: 
/*-------------------------------------------------------------------*/
STDMETHODIMP CUrlfView::Refresh( VOID )
{
	ShowWindow( m_hwndView, SW_SHOW );
	UpdateWindow( m_hwndView );
	return NOERROR;
}






//////////////////////////////////////////////////////////
//
//  Custom methods
//
//


/*-------------------------------------------------------------------*/
// Procedure....: SetToolbar()
// Description..: Set up the folder toolbar
/*-------------------------------------------------------------------*/
STDMETHODIMP CUrlfView::SetToolbar()
{
	TBADDBITMAP tbab;
	LONG lNewIndex;
	LONG lNewString1;

	m_pShellBrowser->GetControlWindow( FCW_TOOLBAR, &m_hwndToolbar );

	// subclass the toolbar if Active Desktop is present
	if( m_hwndToolbar != NULL )
    	g_pfn = (WNDPROC)SetWindowLong( m_hwndToolbar, GWL_WNDPROC, (LONG) MyToolbarProc );


	// declare an array of buttons
    TBBUTTON tbb[] = {
		{0,IDM_FILE_RUN,TBSTATE_ENABLED,TBSTYLE_BUTTON, 0, 0 }
	};

	// first add new bitmaps to the Explorer toolbar
	tbab.hInst = g_hInstance;
	tbab.nID = IDB_TOOLBAR;
	m_pShellBrowser->SendControlMsg( FCW_TOOLBAR, TB_ADDBITMAP,
			1, (LPARAM) &tbab, &lNewIndex );

	// add text labels if Active Desktop is installed
	CHAR sz[100];
	LoadString( g_hInstance, IDS_CONNECT, sz, 100 );
	m_pShellBrowser->SendControlMsg( FCW_TOOLBAR, TB_ADDSTRING,
			NULL, (LPARAM) sz, &lNewString1 );


	// The folder's toolbar holds a variety of bitmaps. We need
	// to know where are our most recent bitmaps.
	// lNewIndex has been filled out with the index of the first
	// image we added with the previous instruction.
	tbb[0].iBitmap = lNewIndex;
	tbb[0].iString = lNewString1;

	// now just add the new buttons
	m_pShellBrowser->SendControlMsg( FCW_TOOLBAR, TB_INSERTBUTTON,
		0, (LPARAM) &tbb[0], NULL );

	return NOERROR;
}



/*-------------------------------------------------------------------*/
// Procedure....: SetMenu()
// Description..: Sets up the folder menu
/*-------------------------------------------------------------------*/
STDMETHODIMP CUrlfView::SetMenu()
{
	OLEMENUGROUPWIDTHS mgw = { {0, 0, 0, 0, 0, 0} };
        
	if( m_hMenu )
		DestroyMenu( m_hMenu );

	// create a new menu to insert into the shell browser
	m_hMenu = CreateMenu();
	HOLEMENU hm = OleCreateMenuDescriptor( m_hMenu, &mgw );
	m_pShellBrowser->OnViewWindowActive( this );
	m_pShellBrowser->InsertMenusSB( m_hMenu, &mgw );

	
	// prepare to change menu
	MENUITEMINFO mii;
	ZeroMemory( &mii, sizeof(MENUITEMINFO) );
	mii.cbSize = sizeof(MENUITEMINFO);
	mii.fMask = MIIM_SUBMENU;

	// modify menus: File
	GetMenuItemInfo( m_hMenu, FCIDM_MENU_FILE, FALSE, &mii );
	HMENU hmnuFile = mii.hSubMenu;
    InsertMenu( hmnuFile, 0, MF_BYPOSITION|MF_SEPARATOR, 0, NULL );
	InsertMenu( hmnuFile, 0, MF_BYPOSITION|MF_STRING, IDM_FILE_RUN, "Connect..." );

	// modify menus: Help
	GetMenuItemInfo( m_hMenu, FCIDM_MENU_HELP, FALSE, &mii );
	HMENU hmnuHelp = mii.hSubMenu;
	DeleteMenu( hmnuHelp, 0, MF_BYPOSITION );
    AppendMenu( hmnuHelp, MF_STRING, IDM_HELP_ABOUT, "About..." );

	// remove Edit and Tools menu	
	DeleteMenu( m_hMenu, FCIDM_MENU_EDIT, MF_BYCOMMAND );
	DeleteMenu( m_hMenu, FCIDM_MENU_TOOLS, MF_BYCOMMAND );
	DeleteMenu( m_hMenu, 2, MF_BYPOSITION );
	
	// save changes
	m_pShellBrowser->SetMenuSB( m_hMenu, NULL, NULL );
	return NOERROR;
}



/*-------------------------------------------------------------------*/
// Procedure....: GetFileName()
// Description..: Returns the current file name
/*-------------------------------------------------------------------*/
STDMETHODIMP CUrlfView::GetFileName( LPTSTR szFile )
{
	if( szFile==NULL )
		return E_OUTOFMEMORY;
	lstrcpyn( szFile, m_szFile, MAX_PATH );

	return NOERROR;
}



/*-------------------------------------------------------------------*/
// Procedure....: SetStatusText()
// Description..: Writes a line on the status bar
/*-------------------------------------------------------------------*/
STDMETHODIMP CUrlfView::SetStatusText( UINT uID )
{
	CHAR szText[MAX_PATH];
	WCHAR wszText[2*MAX_PATH];
	DWORD dwSize;

	szText[0] = 0;
	ZeroMemory( wszText, 2*MAX_PATH );

	LoadString( g_hInstance, uID, szText, MAX_PATH );

	dwSize = MultiByteToWideChar( CP_ACP, 0, szText, lstrlen(szText),
		NULL, 0 );
	MultiByteToWideChar( CP_ACP, 0, szText, lstrlen(szText),
		wszText, dwSize );

	m_pShellBrowser->SetStatusTextSB( wszText );
	return NOERROR;
}







// UNIMPLEMENTED
// IShellView methods
//
//   - GetWindow
//   - ContextSensitiveHelp
//   - EnableModeless
//   - UIActivate
//   - AddPropertySheetPages
//   - SelectItem
//   - GetItemObject
//   - SaveViewState
//   - TranslateAccelerator
//   - GetCurrentInfo
//



/*-------------------------------------------------------------------*/
// Procedure....: SaveViewState()
// Description..: 
/*-------------------------------------------------------------------*/
STDMETHODIMP CUrlfView::SaveViewState()
{
	return E_NOTIMPL;
}


/*-------------------------------------------------------------------*/
// Procedure....: TranslateAccelerator()
// Description..: 
/*-------------------------------------------------------------------*/
STDMETHODIMP CUrlfView::TranslateAccelerator( LPMSG lpmsg )
{
	return E_NOTIMPL;
}


/*-------------------------------------------------------------------*/
// Procedure....: GetCurrentInfo()
// Description..: 
/*-------------------------------------------------------------------*/
STDMETHODIMP CUrlfView::GetCurrentInfo( LPFOLDERSETTINGS lpfs )
{
	return E_NOTIMPL;
}


/*-------------------------------------------------------------------*/
// Procedure....: GetWindow()
// Description..: 
/*-------------------------------------------------------------------*/
STDMETHODIMP CUrlfView::GetWindow( HWND *lphwnd )
{
    *lphwnd = m_hwndView;
	return E_NOTIMPL;
}


/*-------------------------------------------------------------------*/
// Procedure....: ContextSensitiveHelp()
// Description..: 
/*-------------------------------------------------------------------*/
STDMETHODIMP CUrlfView::ContextSensitiveHelp( BOOL fEnterMode )
{
	return E_NOTIMPL;
}


/*-------------------------------------------------------------------*/
// Procedure....: EnableModeless()
// Description..: 
/*-------------------------------------------------------------------*/
STDMETHODIMP CUrlfView::EnableModeless( BOOL fEnable )
{
	return E_NOTIMPL;
}


/*-------------------------------------------------------------------*/
// Procedure....: AddPropertySheetPages()
// Description..: 
/*-------------------------------------------------------------------*/
STDMETHODIMP CUrlfView::AddPropertySheetPages( DWORD dwReserved,
    LPFNADDPROPSHEETPAGE lpfn, LPARAM lParam )
{
	return E_NOTIMPL;
}


/*-------------------------------------------------------------------*/
// Procedure....: SelectItem()
// Description..: 
/*-------------------------------------------------------------------*/
STDMETHODIMP CUrlfView::SelectItem( LPCITEMIDLIST pidlItem, 
	UINT uFlags )
{
	return E_NOTIMPL;
}


/*-------------------------------------------------------------------*/
// Procedure....: GetItemObject()
// Description..: 
/*-------------------------------------------------------------------*/
STDMETHODIMP CUrlfView::GetItemObject( UINT uItem, REFIID riid,
    LPVOID *ppv )
{
	return E_NOTIMPL;
}


/*-------------------------------------------------------------------*/
// Procedure....: UIActivate()
// Description..: The folder has the focus
/*-------------------------------------------------------------------*/
STDMETHODIMP CUrlfView::UIActivate( UINT uState )
{
  if( m_uState==uState )
	  return S_OK;

  m_pShellBrowser->OnViewWindowActive( this );
  m_uState = uState;

  OnDeactivate();
  if( uState==SVUIA_ACTIVATE_FOCUS || uState==SVUIA_ACTIVATE_NOFOCUS )
  {
		SetMenu();
		SetToolbar();
  }
  return NOERROR;
}


/*-------------------------------------------------------------------*/
// Procedure....: OnDeactivate()
// Description..: Remove UI changes
/*-------------------------------------------------------------------*/
VOID CUrlfView::OnDeactivate( VOID )
{
	// clear menus
	m_pShellBrowser->SetMenuSB( NULL, NULL, NULL );
	m_pShellBrowser->RemoveMenusSB( m_hMenu );
	DestroyMenu( m_hMenu );

	// clear toolbar
	TBBUTTON tbb;
	m_pShellBrowser->SendControlMsg( FCW_TOOLBAR, TB_GETBUTTON,
		    0, (LPARAM) &tbb, NULL );
	if( tbb.idCommand==IDM_FILE_RUN )
		m_pShellBrowser->SendControlMsg( FCW_TOOLBAR, 
			TB_DELETEBUTTON, 0, TRUE, NULL );

	 SetWindowLong( m_hwndToolbar, GWL_WNDPROC, (LONG) g_pfn );
} 



//////////////////////////////////////////
//
//  View dialog proc
//

/*-------------------------------------------------------------------*/
// Procedure....: View_DlgProc()
// Description..: Dialog procedure for the folder view
/*-------------------------------------------------------------------*/
LRESULT CALLBACK View_DlgProc( HWND hwnd, UINT uiMsg, WPARAM wParam,
	LPARAM lParam )
{
	HICON hIcon;
	CHAR szBrowser[MAX_PATH];
	HFILE hfile; 

	switch( uiMsg )
    {
		case WM_MENUSELECT:
			g_pUrlfView->SetStatusText(LOWORD(wParam));
			break;

		case WM_COMMAND:
			switch( LOWORD(wParam) )
			{
			    case IDC_LINK:
			    case IDM_FILE_RUN:
					hfile = _lcreat("any.htm",0);
					_lclose( hfile );
					FindExecutable( "any.htm", NULL, szBrowser );
					ShellExecute( hwnd, NULL, szBrowser, "http://www.wrox.com", NULL, SW_SHOW );					
					DeleteFile( "any.htm" );
					break;

				case IDM_HELP_ABOUT:
					hIcon = LoadIcon( g_hInstance, 
						MAKEINTRESOURCE(IDI_WROX) );
					ShellAbout( hwnd, 
						"URL Folder#NameSpace Extension", 
						"'Pro Shell Programming for Windows', Dino Esposito", hIcon );
					DestroyIcon( hIcon );
					break;
			}
			break;

		case WM_NOTIFY:  // only if not Active Desktop
			View_ShowTooltips( lParam );
			break;

		case WM_SIZE:
			View_ResizeControls( hwnd, lParam );
			break;
	}

	return 0;
}


/*-------------------------------------------------------------------*/
// Procedure....: View_ResizeControls()
// Description..: Resizes the inner treeview
/*-------------------------------------------------------------------*/
VOID View_ResizeControls( HWND hwnd, LPARAM lParam )
{
	HWND hwndBmp, hwndBtn;
	hwndBmp = GetDlgItem( hwnd, IDC_BITMAP );
	MoveWindow( hwndBmp, 0, 0, LOWORD(lParam), HIWORD(lParam), TRUE );
	
	hwndBtn = GetDlgItem( hwnd, IDC_LINK );
	RECT rc;
	GetClientRect( hwndBtn, &rc );
	SetWindowPos( hwndBtn, NULL, (LOWORD(lParam)-rc.right)/2, 
		(HIWORD(lParam)-rc.bottom)/2, 0, 0, SWP_NOSIZE|SWP_NOZORDER|
		SWP_SHOWWINDOW );
}



/*-------------------------------------------------------------------*/
// Procedure....: View_ShowTooltips()
// Description..: Responds to tooltips notifications 
/*-------------------------------------------------------------------*/
VOID View_ShowTooltips( LPARAM lParam )
{
	LPTOOLTIPTEXT lpToolTipText;
	static UINT s_wButtonID=0;

	switch( ((LPNMHDR)lParam)->code )
	{
		case TTN_NEEDTEXT:
			 lpToolTipText = (LPTOOLTIPTEXT)lParam;
			 LoadString( g_hInstance, TIP_TEXT(lpToolTipText->hdr.idFrom), lpToolTipText->lpszText, 30 );
			 s_wButtonID = lpToolTipText->hdr.idFrom;
			 break;

		// tooltip is about to be shown: update the status window
		case TTN_SHOW:
			 g_pUrlfView->SetStatusText( s_wButtonID );
			 return;

		// tooltip is about to be hidden: clear the status window
		case TTN_POP:
			 g_pUrlfView->SetStatusText( 0 );
			 return;
	}

	return;
}



/*-------------------------------------------------------------------*/
// Procedure....: MyToolbarProc()
// Description..: Custom toolbar wndproc 
/*-------------------------------------------------------------------*/
LRESULT CALLBACK MyToolbarProc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	if( msg==WM_LBUTTONUP )
	{
		// new IE40 specific message
		INT i = SendMessage( hwnd, TB_GETHOTITEM, 0, 0 );
		
		// retrieve the hot button and post it to the view window
		TBBUTTON tb;
		SendMessage( hwnd, TB_GETBUTTON, i, (LPARAM) &tb );
		PostMessage( g_pUrlfView->GetViewHandle(), WM_COMMAND, 
			MAKEWPARAM(tb.idCommand,0), 0 );
	}

	return CallWindowProc( g_pfn, hwnd, msg, wParam, lParam );
}



