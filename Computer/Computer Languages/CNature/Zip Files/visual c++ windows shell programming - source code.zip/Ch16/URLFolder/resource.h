//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by UrlFold.rc
//
#define IDS_CONNECT                     1
#define IDM_HELP_ABOUT                  2
#define IDD_VIEW                        113
#define IDB_BITMAP                      114
#define IDB_TOOLBAR                     118
#define IDB_WALLPAPER                   123
#define IDI_WROX                        125
#define IDB_WROX                        128
#define IDC_TEXT                        1002
#define IDC_BITMAP                      1003
#define IDC_LINK                        1004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
