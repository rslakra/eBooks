#ifndef _URLF_VIEW_
#define _URLF_VIEW_
#include "resource.h"


// used to get tooltip strings from the RC
#define TIP_TEXT(id)		(1000+id)
 


// View object for the folder
class CUrlfView: public IShellView
{
	protected:
		ULONG m_cRef;
		LPSHELLFOLDER m_pShellFolder;
		LPSHELLBROWSER m_pShellBrowser;
		HWND m_hwndView;
		HWND m_hwndMain;
		HMENU m_hMenu;
		HWND m_hwndToolbar;
		UINT m_uState;
		TCHAR m_szFile[MAX_PATH];

	public:
		CUrlfView( LPSHELLFOLDER lpsf ); 
		~CUrlfView();

		// custom methods
		STDMETHODIMP SetToolbar();
		STDMETHODIMP SetMenu();
		STDMETHODIMP SetStatusText( UINT uID );
		STDMETHODIMP GetFileName( LPTSTR szFile );
		VOID OnDeactivate( VOID );
		HWND GetViewHandle() { return m_hwndView; }

		// IUnknown methods
		STDMETHODIMP         QueryInterface( REFIID, LPVOID* );
		STDMETHODIMP_(ULONG) AddRef();
		STDMETHODIMP_(ULONG) Release();

		// IShellView methods 
		STDMETHODIMP GetWindow( HWND * );
		STDMETHODIMP ContextSensitiveHelp( BOOL );
		STDMETHODIMP TranslateAccelerator( LPMSG );
		STDMETHODIMP EnableModeless( BOOL );
		STDMETHODIMP UIActivate( UINT );
		STDMETHODIMP Refresh();
		STDMETHODIMP CreateViewWindow( IShellView*,
			LPCFOLDERSETTINGS, IShellBrowser*, LPRECT, HWND* );
		STDMETHODIMP DestroyViewWindow();
		STDMETHODIMP GetCurrentInfo( LPFOLDERSETTINGS );
		STDMETHODIMP AddPropertySheetPages( DWORD,
			LPFNADDPROPSHEETPAGE, LPARAM );
		STDMETHODIMP SaveViewState();
		STDMETHODIMP SelectItem( LPCITEMIDLIST, UINT );
		STDMETHODIMP GetItemObject( UINT, REFIID, LPVOID * );
};

#endif