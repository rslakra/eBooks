/*****************************************************************
*
*  Project.....:  File Mapping Objects
*  Application.:  FILEMAP.exe
*  Module......:  FILEMAP.cpp
*  Description.:  Application main module
*  Compiler....:  MS Visual C++
*  Written by..:  D. Esposito
*  Environment.:  Windows 9x/NT
*
******************************************************************/

/*---------------------------------------------------------------*/
//                        PRAGMA section
/*---------------------------------------------------------------*/
// Force the linker to add the following libraries.
#ifdef _MSC_VER

#pragma comment(lib, "kernel32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "comctl32.lib")

#endif

/*---------------------------------------------------------------*/
//                        INCLUDE section
/*---------------------------------------------------------------*/
#include "FileMap.h"
#include <commctrl.h>
#include <shellapi.h>
#include "resource.h"

/*---------------------------------------------------------------*/
//                        GLOBAL section
/*---------------------------------------------------------------*/
// Data
HICON g_hIconLarge;
HICON g_hIconSmall;

struct SHNAMEMAPPINGHEADER
{
   UINT cNumOfMappings;
   LPSHNAMEMAPPING lpNM;
};

typedef SHNAMEMAPPINGHEADER* LPSHNAMEMAPPINGHEADER;

typedef BOOL (CALLBACK *ENUMFILEMAPPROC)(LPSHNAMEMAPPING, DWORD);

// Functions
void OnInitDialog(HWND);
void OnOK(HWND);

int SHEnumFileMapping(HANDLE, ENUMFILEMAPPROC, DWORD);

// Callbacks
BOOL CALLBACK APP_DlgProc(HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK ProcessNM(LPSHNAMEMAPPING, DWORD);


/*---------------------------------------------------------------*/
// Procedure....: WinMain()
// Description..: Entry point in any Windows program
// Input........: HINSTANCE, HINSTANCE, LPSTR, int
// Output.......: int
/*---------------------------------------------------------------*/
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevious, 
                     LPTSTR lpsz, int iCmd)
{
   // Save global data
   g_hIconLarge = static_cast<HICON>(
              LoadImage(hInstance, "APP_ICON", IMAGE_ICON,
              GetSystemMetrics(SM_CXICON), GetSystemMetrics(SM_CXICON), 0));
   g_hIconSmall = static_cast<HICON>(
              LoadImage(hInstance, "APP_ICON", IMAGE_ICON,
              GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CXSMICON), 0));

   // Enable common controls
   INITCOMMONCONTROLSEX iccex;
   iccex.dwSize = sizeof(INITCOMMONCONTROLSEX);
   iccex.dwICC = ICC_WIN95_CLASSES;
   InitCommonControlsEx(&iccex);

   // Run main dialog
   BOOL b = DialogBox(hInstance, "DLG_MAIN", NULL, APP_DlgProc);

   // Exit
   DestroyIcon(g_hIconLarge);
   DestroyIcon(g_hIconSmall);
   return b;
}


/*---------------------------------------------------------------*/
// Procedure....: APP_DlgProc()
// Description..: Responds to all messages sent to the dialog
// Input........: HWND, UINT, WPARAM, LPARAM
// Output.......: BOOL
/*---------------------------------------------------------------*/
BOOL CALLBACK APP_DlgProc(HWND hDlg, UINT uiMsg, WPARAM wParam, LPARAM lParam)
{
   switch(uiMsg)
   {
   case WM_INITDIALOG:
      OnInitDialog(hDlg);
      break;

   case WM_COMMAND:
      switch(wParam)
      {
      case IDOK:
         OnOK(hDlg);
         return FALSE;

      case IDCANCEL:
         EndDialog(hDlg, FALSE);
         return FALSE;
      }
      break;
   }

   return FALSE;
}


/*****************************************************************
*
*  Internals:
*    - OnOK()
*    - OnInitDialog()
*
******************************************************************/

/*---------------------------------------------------------------*/
// Procedure...: OnOK()
// Description.: Do something
// INPUT.......: HWND
// OUTPUT......: void
/*---------------------------------------------------------------*/
void OnOK(HWND hDlg)
{
   TCHAR pszFrom[1024] = {0};
   TCHAR pszTo[MAX_PATH] = {0};

   GetDlgItemText(hDlg, IDC_FROM, pszFrom, MAX_PATH);
   GetDlgItemText(hDlg, IDC_TO, pszTo, MAX_PATH);

   SHFILEOPSTRUCT shfo;
   ZeroMemory(&shfo, sizeof(SHFILEOPSTRUCT));
   shfo.hwnd = hDlg;
   shfo.wFunc = FO_COPY;
   shfo.pFrom = pszFrom;
   shfo.pTo = pszTo;
   shfo.fFlags = FOF_NOCONFIRMMKDIR |
                 FOF_RENAMEONCOLLISION |
                 FOF_WANTMAPPINGHANDLE;

   int iRC = SHFileOperation(&shfo);
   if(iRC)
   {
      SPB_SystemMessage(iRC);
      return;
   }

   // Trace the value of the handle
   Msg("hNameMappings is: %x", shfo.hNameMappings);

   // Enumerate the file mapping objects
   SHEnumFileMapping(shfo.hNameMappings, ProcessNM,
                           reinterpret_cast<DWORD>(GetDlgItem(hDlg, IDC_LIST)));

   // Free the object, as recommended
   if(shfo.hNameMappings)
      SHFreeNameMappings(shfo.hNameMappings);
}


/*---------------------------------------------------------------*/
// Procedure...: OnInitDialog()
// Description.: Initialize the dialog
// INPUT.......: HWND
// OUTPUT......: void
/*---------------------------------------------------------------*/
void OnInitDialog(HWND hDlg)
{
   HWND hwndList = GetDlgItem(hDlg, IDC_LIST);

   // Set up the report view
   LV_COLUMN lvc;
   ZeroMemory(&lvc, sizeof(LV_COLUMN));

   lvc.mask = LVCF_TEXT | LVCF_WIDTH;
   lvc.cx = 200;

   lvc.pszText = "Original File";
   ListView_InsertColumn(hwndList, 0, &lvc);

   lvc.pszText = "Target File";
   ListView_InsertColumn(hwndList, 1, &lvc);

   // Initialize the edit fields
   SetDlgItemText(hDlg, IDC_FROM, "c:\\thedir\\*.*");
   SetDlgItemText(hDlg, IDC_TO, "c:\\newdir");

   // Set the icons (T/F as to Large/Small icon)
   SendMessage(hDlg, WM_SETICON, FALSE, reinterpret_cast<LPARAM>(g_hIconSmall));
   SendMessage(hDlg, WM_SETICON, TRUE, reinterpret_cast<LPARAM>(g_hIconLarge));
}


int SHEnumFileMapping(HANDLE hNameMappings, ENUMFILEMAPPROC lpfnEnum, DWORD dwData)
{
   SHNAMEMAPPING shNM;

   // Check the handle
   if(!hNameMappings)
      return -1;

   // Get the header of the structure
   LPSHNAMEMAPPINGHEADER lpNMH = static_cast<LPSHNAMEMAPPINGHEADER>(hNameMappings);
   int iNumOfNM = lpNMH->cNumOfMappings;

   // Check the function pointer; if NULL, just return the number of mappings
   if(!lpfnEnum)
      return iNumOfNM;

   // Enumerate the objects
   LPSHNAMEMAPPING lp = lpNMH->lpNM;
   int i = 0;

   while(i < iNumOfNM)
   {
      CopyMemory(&shNM, &lp[i++], sizeof(SHNAMEMAPPING));
      if(!lpfnEnum(&shNM, dwData))
         break;
   }

   // Returns the number of objects actually processed
   return i;
}


BOOL CALLBACK ProcessNM(LPSHNAMEMAPPING pshNM, DWORD dwData)
{
   TCHAR szBuf[1024] = {0};
   TCHAR szOldPath[MAX_PATH] = {0};
   TCHAR szNewPath[MAX_PATH] = {0};
   OSVERSIONINFO os;

   // We need to know the underlying OS
   os.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
   GetVersionEx(&os);
   BOOL bIsNT = (os.dwPlatformId == VER_PLATFORM_WIN32_NT);

   // Under NT the SHNAMEMAPPING structure includes UNICODE strings
   if(bIsNT)
   {
      WideCharToMultiByte(CP_ACP, 0, (LPWSTR)pshNM->pszOldPath,
         MAX_PATH, szOldPath, MAX_PATH, NULL, NULL);
      WideCharToMultiByte(CP_ACP, 0, (LPWSTR)pshNM->pszNewPath,
         MAX_PATH, szNewPath, MAX_PATH, NULL, NULL);
   }
   else
   {
      lstrcpy(szOldPath, pshNM->pszOldPath);
      lstrcpy(szNewPath, pshNM->pszNewPath);
   }

   // Save the list view handle
   HWND hwndListView = reinterpret_cast<HWND>(dwData);

   // Create a \0 separated string
   LPTSTR psz = szBuf;
   lstrcpyn(psz, szOldPath, pshNM->cchOldPath + 1);
   lstrcat(psz, __TEXT("\0"));

   psz += lstrlen(psz) + 1;

   lstrcpyn(psz, szNewPath, pshNM->cchNewPath + 1);
   lstrcat(psz, __TEXT("\0"));

   // Add the strings to the report view
   LV_ITEM lvi;
   ZeroMemory(&lvi, sizeof(LV_ITEM));
   lvi.mask = LVIF_TEXT;
   lvi.pszText = szBuf;
   lvi.cchTextMax = lstrlen(szBuf);
   lvi.iItem = 0;
   ListView_InsertItem(hwndListView, &lvi);

   psz = szBuf + lstrlen(szBuf) + 1;
   ListView_SetItemText(hwndListView, 0, 1, psz);

   return TRUE;
}

/*  End of file: FileMap.cpp  */
