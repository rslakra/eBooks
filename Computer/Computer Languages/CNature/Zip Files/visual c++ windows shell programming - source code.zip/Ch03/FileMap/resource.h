//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FileMap.rc
//
#define IDC_FROM                        1000
#define IDC_TO                          1001
#define IDC_LIST                        1002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
