/*****************************************************************
*
*  Project.....:  Move/Copy Files
*  Application.:  SHMOVE.exe
*  Module......:  SHMOVE.cpp
*  Description.:  Application main module
*  Compiler....:  MS Visual C++
*  Written by..:  D. Esposito
*  Environment.:  Windows 9x/NT
*
******************************************************************/

/*---------------------------------------------------------------*/
//                        PRAGMA section
/*---------------------------------------------------------------*/
// Force the linker to add the following libraries.
#ifdef _MSC_VER

#pragma comment(lib, "kernel32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "comctl32.lib")

#endif

/*---------------------------------------------------------------*/
//                        INCLUDE section
/*---------------------------------------------------------------*/
#include "SHMove.h"
#include <commctrl.h>
#include <shellapi.h>
#include "resource.h" 

/*---------------------------------------------------------------*/
//                        GLOBAL section
/*---------------------------------------------------------------*/
// Data
HICON g_hIconLarge;
HICON g_hIconSmall;

// Functions
void OnInitDialog(HWND);
void OnOK(HWND);

// Callbacks
BOOL CALLBACK APP_DlgProc(HWND, UINT, WPARAM, LPARAM);


/*---------------------------------------------------------------*/
// Procedure....: WinMain()
// Description..: Entry point in any Windows program
// Input........: HINSTANCE, HINSTANCE, LPSTR, int
// Output.......: int
/*---------------------------------------------------------------*/
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevious, 
                     LPTSTR lpsz, int iCmd)
{
   // Save global data
   g_hIconLarge = static_cast<HICON>(
              LoadImage(hInstance, "APP_ICON", IMAGE_ICON,
              GetSystemMetrics(SM_CXICON), GetSystemMetrics(SM_CXICON), 0));
   g_hIconSmall = static_cast<HICON>(
              LoadImage(hInstance, "APP_ICON", IMAGE_ICON,
              GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CXSMICON), 0));

   // Enable common controls
   INITCOMMONCONTROLSEX iccex;
   iccex.dwSize = sizeof(INITCOMMONCONTROLSEX);
   iccex.dwICC = ICC_WIN95_CLASSES;
   InitCommonControlsEx(&iccex);

   // Run main dialog
   BOOL b = DialogBox(hInstance, "DLG_MAIN", NULL, APP_DlgProc);

   // Exit
   DestroyIcon(g_hIconLarge);
   DestroyIcon(g_hIconSmall);
   return b;
}


/*---------------------------------------------------------------*/
// Procedure....: APP_DlgProc()
// Description..: Responds to all messages sent to the dialog
// Input........: HWND, UINT, WPARAM, LPARAM
// Output.......: BOOL
/*---------------------------------------------------------------*/
BOOL CALLBACK APP_DlgProc(HWND hDlg, UINT uiMsg, WPARAM wParam, LPARAM lParam)
{
   switch(uiMsg)
   {
   case WM_INITDIALOG:
      OnInitDialog(hDlg);
      break;

   case WM_COMMAND:
      switch(wParam)
      {
      case IDOK:
         OnOK(hDlg);
         return FALSE;

      case IDCANCEL:
         EndDialog(hDlg, FALSE);
         return FALSE;
      }
      break;
   }

   return FALSE;
}


/*****************************************************************
*
*  Internals:
*    - OnOK()
*    - OnInitDialog()
*
******************************************************************/

/*---------------------------------------------------------------*/
// Procedure...: OnOK()
// Description.: Do something
// INPUT.......: HWND
// OUTPUT......: void
/*---------------------------------------------------------------*/
void OnOK(HWND hDlg)
{
   SHFILEOPSTRUCT shfo;
   WORD wFunc;
   TCHAR pszTo[1024] = {0};
   TCHAR pszFrom[1024] = {0};
   TCHAR pszTitle[MAX_PATH] = {0};

   // Set the operation to perform
   if(IsDlgButtonChecked(hDlg, IDC_COPY))
      wFunc = FO_COPY;
   else
      wFunc = FO_MOVE;

   // Get the 'progress' string
   GetDlgItemText(hDlg, IDC_PROGRESSTITLE, pszTitle, MAX_PATH);

   // Get the 'from' buffer
   GetDlgItemText(hDlg, IDC_FROM, pszFrom, MAX_PATH);
   pszFrom[lstrlen(pszFrom) + 1] = 0;

   // Get the 'to' buffer
   GetDlgItemText(hDlg, IDC_TO, pszTo, MAX_PATH);

   // Get the flags
   WORD wFlags = 0;

   if(IsDlgButtonChecked(hDlg, IDC_FOFSILENT))
      wFlags |= FOF_SILENT;
   if(IsDlgButtonChecked(hDlg, IDC_FOFNOERRORUI))
      wFlags |= FOF_NOERRORUI;
   if(IsDlgButtonChecked(hDlg, IDC_FOFNOCONFIRMATION))
      wFlags |= FOF_NOCONFIRMATION;
   if(IsDlgButtonChecked(hDlg, IDC_FOFNOCONFIRMMKDIR))
      wFlags |= FOF_NOCONFIRMMKDIR;
   if(IsDlgButtonChecked(hDlg, IDC_FOFSIMPLEPROGRESS))
      wFlags |= FOF_SIMPLEPROGRESS;
   if(IsDlgButtonChecked(hDlg, IDC_FOFRENAMEONCOLLISION))
      wFlags |= FOF_RENAMEONCOLLISION;
   if(IsDlgButtonChecked(hDlg, IDC_FOFFILESONLY))
      wFlags |= FOF_FILESONLY;

   // Call SHFileOperation()
   ZeroMemory(&shfo, sizeof(SHFILEOPSTRUCT));
   shfo.hwnd = hDlg;
   shfo.wFunc = wFunc;
   shfo.lpszProgressTitle = pszTitle;
   shfo.fFlags = static_cast<FILEOP_FLAGS>(wFlags);
   shfo.pTo = pszTo;
   shfo.pFrom = pszFrom;

// shfo.pFrom = "c:\\demo\\one.txt\0c:\\two.txt\0c:\\three.txt\0";
// shfo.pTo = "c:\\NewDir";

// shfo.pFrom = "c:\\demo\\one.txt\0";
// shfo.pTo = "c:\\NewDir";

// shfo.pFrom = "c:\\demo\\one.txt\0";
// shfo.pTo = "c:\\NewDir\\";

// shfo.pFrom = "c:\\demo\\one.txt*\0";
// shfo.pTo = "c:\\NewDir";

// shfo.fFlags |= FOF_MULTIDESTFILES;
// shfo.pFrom = "c:\\one.txt\0c:\\two.txt\0";
// shfo.pTo = "c:\\New one.txt\0c:\\New two.txt\0";

// shfo.fFlags |= FOF_MULTIDESTFILES;
// shfo.pFrom = "c:\\one.txt\0c:\\two.txt\0c:\\three.txt\0";
// shfo.pTo = "c:\\New one.txt\0c:\\New two.txt\0";

// ZeroMemory(&shfo, sizeof(SHFILEOPSTRUCT));
// shfo.hwnd = hDlg;
// shfo.wFunc = FO_DELETE;
// shfo.lpszProgressTitle = pszTitle;
// shfo.fFlags = FOF_NOERRORUI | FOF_ALLOWUNDO;
// shfo.pFrom = "c:\\demo\\*.*\0";

// ZeroMemory(&shfo, sizeof(SHFILEOPSTRUCT));
// shfo.wFunc = FO_RENAME;
// shfo.pFrom = "c:\\demo\\one.txt\0";
// shfo.pTo = "c:\\demo\\one.xxx";
// shfo.pFrom = "c:\\demo\\*.*\0";
// shfo.pTo = "c:\\newdir";
// shfo.pFrom = "c:\\demo\\*.txt\0";
// shfo.pTo = "c:\\demo\\*.xtt";

// shfo.pFrom = "c:\\demo\\*.*\0";
// shfo.pTo = "NewDir";

   int iRC = SHFileOperation(&shfo);
   if(shfo.fAnyOperationsAborted)
   {
      Msg("Aborted!");
      return;
   }

   // Display the result of the operation
   SPB_SystemMessage(iRC);
}


/*---------------------------------------------------------------*/
// Procedure...: OnInitDialog()
// Description.: Initialize the dialog
// INPUT.......: HWND
// OUTPUT......: void
/*---------------------------------------------------------------*/
void OnInitDialog(HWND hDlg)
{
   // Set the icons (T/F as to Large/Small icon)
   SendMessage(hDlg, WM_SETICON, FALSE, reinterpret_cast<LPARAM>(g_hIconSmall));
   SendMessage(hDlg, WM_SETICON, TRUE, reinterpret_cast<LPARAM>(g_hIconLarge));

   // Initialize the 'to' and 'from' edit fields
   SetDlgItemText(hDlg, IDC_TO, "c:\\NewDir");
   SetDlgItemText(hDlg, IDC_FROM, "c:\\demo\\*.*");

   // Take care of the 'progress' title
   SetDlgItemText(hDlg, IDC_PROGRESSTITLE, "This is a string");

   // Select the default operation
   CheckRadioButton(hDlg, IDC_COPY, IDC_MOVE, IDC_COPY);
}


/*  End of file: SHMove.cpp  */
