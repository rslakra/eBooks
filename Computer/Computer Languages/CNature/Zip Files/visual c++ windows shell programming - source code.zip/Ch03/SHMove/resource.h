//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SHMove.rc
//
#define IDC_FOFSILENT                   1000
#define IDC_FOFFILESONLY                1001
#define IDC_FOFNOCONFIRMATION           1002
#define IDC_FOFNOCONFIRMMKDIR           1003
#define IDC_FOFNOERRORUI                1004
#define IDC_FOFSIMPLEPROGRESS           1005
#define IDC_FOFRENAMEONCOLLISION        1006
#define IDC_FOFMULTIDESTFILES           1007
#define IDC_PROGRESSTITLE               1009
#define IDC_COPY                        1010
#define IDC_MOVE                        1011
#define IDC_FROM                        1012
#define IDC_TO                          1013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
