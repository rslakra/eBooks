VERSION 5.00
Begin VB.Form Form1 
   Caption         =   "Calling the Shell Object..."
   ClientHeight    =   4575
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   5835
   LinkTopic       =   "Form1"
   ScaleHeight     =   4575
   ScaleWidth      =   5835
   StartUpPosition =   3  'Windows Default
   Begin VB.ListBox List2 
      Height          =   2400
      Left            =   3720
      TabIndex        =   8
      Top             =   1920
      Width           =   1935
   End
   Begin VB.ListBox List1 
      Height          =   2400
      Left            =   240
      TabIndex        =   7
      Top             =   1920
      Width           =   3255
   End
   Begin VB.TextBox Text1 
      Height          =   375
      Left            =   240
      Locked          =   -1  'True
      TabIndex        =   4
      Text            =   "Text1"
      Top             =   1080
      Width           =   5415
   End
   Begin VB.CommandButton btnNameSpace 
      Caption         =   "NameSpace"
      Height          =   375
      Left            =   4080
      TabIndex        =   2
      Top             =   240
      Width           =   1575
   End
   Begin VB.CommandButton btnBrowseForFolder 
      Caption         =   "BrowseForFolder"
      Height          =   375
      Left            =   2160
      TabIndex        =   1
      Top             =   240
      Width           =   1695
   End
   Begin VB.CommandButton btnFindComputer 
      Caption         =   "Find Computer"
      Height          =   375
      Left            =   240
      TabIndex        =   0
      Top             =   240
      Width           =   1695
   End
   Begin VB.Label Label3 
      Caption         =   "Verbs:"
      Height          =   255
      Left            =   3720
      TabIndex        =   6
      Top             =   1680
      Width           =   495
   End
   Begin VB.Label Label2 
      Caption         =   "Start Menu items:"
      Height          =   255
      Left            =   240
      TabIndex        =   5
      Top             =   1680
      Width           =   1335
   End
   Begin VB.Label Label1 
      Caption         =   "Selected folder:"
      Height          =   255
      Left            =   240
      TabIndex        =   3
      Top             =   840
      Width           =   1215
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

' Finds a computer
Private Sub btnFindComputer_Click()
   Dim s As New Shell
   s.FindComputer
End Sub

' Navigates the History folder
Private Sub btnBrowseForFolder_Click()
On Error Resume Next
   Dim s As New Shell
   Dim f As Folder
   Dim fi As FolderItem

   Set f = s.BrowseForFolder(Me.hWnd, "My Computer:", 0, ssfDRIVES)
   Set fi = f.Items.Item

   ' Show the selected path in a textbox
   Text1.Text = fi.Path
End Sub


' Enumerates the content of the Start Menu folder
Private Sub btnNameSpace_Click()
   Dim s As New Shell
   Dim f As Folder
   Dim i As Integer
   Dim Item As FolderItem

   Set f = s.NameSpace(ssfSTARTMENU)
   For Each Item In f.Items
      List1.AddItem Item.Path
   Next
End Sub


' Displays the verbs for each folder item
Private Sub List1_Click()
   Dim s As New Shell
   Dim f As Folder
   Dim fi As FolderItem
   Dim fiv As FolderItemVerb
   Dim i As Integer

   Set f = s.NameSpace(ssfSTARTMENU)
   i = List1.ListIndex

   Set fi = f.Items.Item(i)

   List2.Clear
   For Each fiv In fi.Verbs
      List2.AddItem fiv.Name
   Next
End Sub

