/*****************************************************************
*
*  Project.....:  Shell Console
*  Application.:  CPPSHELL.exe
*  Module......:  CPPSHELL.cpp
*  Description.:  Application main module
*  Compiler....:  MS Visual C++
*  Written by..:  D. Esposito
*  Environment.:  Windows 9x/NT
*
******************************************************************/

/*---------------------------------------------------------------*/
//                        PRAGMA section
/*---------------------------------------------------------------*/
// Force the linker to add the following libraries.
#ifdef _MSC_VER

#pragma comment(lib, "kernel32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "comctl32.lib")

#endif

/*---------------------------------------------------------------*/
//                        INCLUDE section
/*---------------------------------------------------------------*/
#include "CppShell.h"
#include <commctrl.h>
#include <shellapi.h> 
#include <shlobj.h>
#include <comdef.h>
#include <exdisp.h>
#include <atlbase.h>
#include "resource.h"

/*---------------------------------------------------------------*/
//                        GLOBAL section
/*---------------------------------------------------------------*/
// Data
HICON g_hIconLarge;
HICON g_hIconSmall;
BOOL g_bMinimized = FALSE;

// Functions
void OnInitDialog(HWND);
void OnOK(HWND);
void OnFindComputer();
void OnAddFavorites();
void OnNameSpace(HWND);
void OnBrowseForFolder(HWND);
void OnMinimizeAll(HWND);
void OnTaskbarProperties();

// Callbacks
BOOL CALLBACK APP_DlgProc(HWND, UINT, WPARAM, LPARAM);


/*---------------------------------------------------------------*/
// Procedure....: WinMain()
// Description..: Entry point in any Windows program
// Input........: HINSTANCE, HINSTANCE, LPSTR, int
// Output.......: int
/*---------------------------------------------------------------*/
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevious, 
                     LPTSTR lpsz, int iCmd)
{
   // Save global data
   g_hIconLarge = static_cast<HICON>(
              LoadImage(hInstance, "APP_ICON", IMAGE_ICON,
              GetSystemMetrics(SM_CXICON), GetSystemMetrics(SM_CXICON), 0));
   g_hIconSmall = static_cast<HICON>(
              LoadImage(hInstance, "APP_ICON", IMAGE_ICON,
              GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CXSMICON), 0));

   // Enable common controls
   INITCOMMONCONTROLSEX iccex;
   iccex.dwSize = sizeof(INITCOMMONCONTROLSEX);
   iccex.dwICC = ICC_WIN95_CLASSES;
   InitCommonControlsEx(&iccex);

   // Initialize the COM libraries
   CoInitialize(NULL);

   // Run main dialog
   BOOL b = DialogBox(hInstance, "DLG_MAIN", NULL, APP_DlgProc);

   // Uninitialize COM
   CoUninitialize();

   // Exit
   DestroyIcon(g_hIconLarge);
   DestroyIcon(g_hIconSmall);
   return b;
}


/*---------------------------------------------------------------*/
// Procedure....: APP_DlgProc()
// Description..: Responds to all messages sent to the dialog
// Input........: HWND, UINT, WPARAM, LPARAM
// Output.......: BOOL
/*---------------------------------------------------------------*/
BOOL CALLBACK APP_DlgProc(HWND hDlg, UINT uiMsg, WPARAM wParam, LPARAM lParam)
{
   switch(uiMsg)
   {
   case WM_INITDIALOG:
      OnInitDialog(hDlg);
      break;

   case WM_COMMAND:
      switch(wParam)
      {
      case IDC_FINDCOMPUTER:
         OnFindComputer();
         return FALSE;

      case IDC_FAVORITES:
         OnAddFavorites();
         return FALSE;

      case IDC_NAMESPACE:
         OnNameSpace(hDlg);
         return FALSE;

      case IDC_BROWSEFOLDER:
         OnBrowseForFolder(hDlg);
         return FALSE;

      case IDC_MINIMIZE:
         OnMinimizeAll(hDlg);
         return FALSE;

      case IDC_PROPERTIES:
         OnTaskbarProperties();
         return FALSE;

      case IDCANCEL:
         EndDialog(hDlg, FALSE);
         return FALSE;
      }
      break;
   }

   return FALSE;
}


/*****************************************************************
*
*  Internals:
*    - OnOK()
*    - OnInitDialog()
*
******************************************************************/

/*---------------------------------------------------------------*/
// Procedure...: OnOK()
// Description.: Do something
// INPUT.......: HWND
// OUTPUT......: void
/*---------------------------------------------------------------*/
void OnOK(HWND hDlg)
{
   return;
}


/*---------------------------------------------------------------*/
// Procedure...: OnInitDialog()
// Description.: Initialize the dialog
// INPUT.......: HWND
// OUTPUT......: void
/*---------------------------------------------------------------*/
void OnInitDialog(HWND hDlg)
{
   // Set the icons (T/F as to Large/Small icon)
   SendMessage(hDlg, WM_SETICON, FALSE, reinterpret_cast<LPARAM>(g_hIconSmall));
   SendMessage(hDlg, WM_SETICON, TRUE, reinterpret_cast<LPARAM>(g_hIconLarge));
}

void OnFindComputer()
{
   IShellDispatch* pShellDisp = NULL;

   HRESULT hr = CoCreateInstance(CLSID_Shell, NULL, CLSCTX_SERVER,
                    IID_IShellDispatch, reinterpret_cast<LPVOID*>(&pShellDisp));
   if(FAILED(hr))
      return;

   pShellDisp->FindComputer();
   pShellDisp->Release();
}

void OnTaskbarProperties()
{
   IShellDispatch* pShellDisp = NULL;

   HRESULT hr = CoCreateInstance(CLSID_Shell, NULL, CLSCTX_SERVER,
                    IID_IShellDispatch, reinterpret_cast<LPVOID*>(&pShellDisp));
   if(FAILED(hr))
      return;

   pShellDisp->TrayProperties();
   pShellDisp->Release();
}

void OnBrowseForFolder(HWND hDlg)
{
   TCHAR szTitle[MAX_PATH] = {0};
   IShellDispatch* pShellDisp = NULL;
   Folder* pFolder = NULL;

   HRESULT hr = CoCreateInstance(CLSID_Shell, NULL, CLSCTX_SERVER,
      IID_IShellDispatch, reinterpret_cast<LPVOID*>(&pShellDisp));
   if(FAILED(hr))
      return;

   // Set the root of the namespace displayed
   CComVariant vRoot(CSIDL_HISTORY);

   // Displays the dialog
   CComBSTR bstrFolder(__TEXT("History Folder:"));
   hr = pShellDisp->BrowseForFolder(reinterpret_cast<long>(hDlg), bstrFolder, 0, vRoot, &pFolder);
   if(pFolder)
   {
      // Get the display name of the selected item
      CComBSTR bstr;
      pFolder->get_Title(&bstr);

      // Convert it to ANSI and display
      wcstombs(szTitle, bstr, MAX_PATH);
      SetDlgItemText(hDlg, IDC_FOLDER, szTitle);
   }

   // Clean up
   pFolder->Release();
   pShellDisp->Release();
}

void OnNameSpace( HWND hDlg )
{
   IShellDispatch* pShellDisp = NULL;
   Folder* pFolder = NULL;

   HRESULT hr = CoCreateInstance(CLSID_Shell, NULL, CLSCTX_SERVER, 
      IID_IShellDispatch, reinterpret_cast<LPVOID*>(&pShellDisp));
   if(FAILED(hr))
      return;

   // Set the folder to work with
   CComVariant vDir(CSIDL_STARTMENU);

   // Get the Folder object
   pShellDisp->NameSpace(vDir, &pFolder);  

   // Prepare to enumerate the folder's content
   long nLength;
   FolderItems* pFIColl = NULL;
   pFolder->Items(&pFIColl);
   pFIColl->get_Count(&nLength);

   // Prepare the list view to fill
   HIMAGELIST himl = ImageList_Create(32, 32, ILC_MASK, 1, 1);
   HWND hwndList = GetDlgItem(hDlg, IDC_LIST);
   ListView_SetImageList(hwndList, himl, LVSIL_NORMAL);

   // Enumerate the folder items
   for(int i = 0 ; i < nLength ; i++)
   {
      // Get the ith folder item
      CComVariant varIndex(i);
      FolderItem* pFI;
	
      hr = pFIColl->Item(varIndex, &pFI);
      if(SUCCEEDED(hr))
	  {
         CComBSTR bstr;
         TCHAR szFile[MAX_PATH] = {0};

         // Get the ANSI version of the ith item path 
         pFI->get_Path(&bstr);
         wcstombs(szFile, bstr, MAX_PATH);

         // Add the item to the list view
         LV_ITEM lvi;
         ZeroMemory(&lvi, sizeof(LV_ITEM));
         lvi.mask = LVIF_TEXT | LVIF_IMAGE;
         lvi.pszText = szFile;
         lvi.cchTextMax = lstrlen(szFile);

         // Get the icon and add to the list view
         SHFILEINFO sfi;
         SHGetFileInfo(szFile, 0, &sfi, sizeof(SHFILEINFO), SHGFI_ICON);
         int iIconPos = ImageList_AddIcon(himl, sfi.hIcon);
         lvi.iImage = iIconPos;
         ListView_InsertItem(hwndList, &lvi);
	  }
      pFI->Release();
   }

   pFIColl->Release();
   pFolder->Release();
   pShellDisp->Release();
}

void OnMinimizeAll(HWND hDlg)
{
   IShellDispatch* pShellDisp = NULL;

   HRESULT hr = CoCreateInstance(CLSID_Shell, NULL, CLSCTX_SERVER, 
      IID_IShellDispatch, reinterpret_cast<LPVOID*>(&pShellDisp));
   if(FAILED(hr))
      return;

   // Use a global flag to remember the current status 
   if(!g_bMinimized)
   {
      pShellDisp->MinimizeAll();  

      // Change the button's caption
      SetDlgItemText(hDlg, IDC_MINIMIZE, "&Undo Minimize All");
      g_bMinimized = TRUE;
   }
   else
   {
      pShellDisp->UndoMinimizeALL();  

      // Change the button's caption
      SetDlgItemText(hDlg, IDC_MINIMIZE, "&Minimize All");
      g_bMinimized = FALSE;
   }

   pShellDisp->Release();
}

void OnAddFavorites()
{
   IShellUIHelper* pShellUI = NULL;

   // Creates the Shell UI Helper object
   HRESULT hr = CoCreateInstance(CLSID_ShellUIHelper, NULL, CLSCTX_SERVER,
                      IID_IShellUIHelper, reinterpret_cast<LPVOID*>(&pShellUI));
   if(FAILED(hr))
      return;

   // Sets the title of the item to add
   CComVariant vTitle(__TEXT("My C Drive"));

   // Causes the dialog to appear with the specified default settings
   CComBSTR bstrPath(__TEXT("c:\\"));
   pShellUI->AddFavorite(bstrPath, &vTitle);

   // Clean up
   pShellUI->Release();
}

/*  End of file: CppShell.cpp  */
