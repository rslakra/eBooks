//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CppShell.rc
//
#define IDC_FINDCOMPUTER                1000
#define IDC_BROWSEFOLDER                1001
#define IDC_PROPERTIES                  1002
#define IDC_MINIMIZE                    1003
#define IDC_NAMESPACE                   1005
#define IDC_FOLDER                      1006
#define IDC_LIST                        1007
#define IDC_FAVORITES                   1008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
