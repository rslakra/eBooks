/*
 * Created on Jun 19, 2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package au.com.tusc.mdb;

import javax.ejb.MessageDrivenBean;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;
import javax.naming.InitialContext;

import au.com.tusc.cmp.ItemLocal;
import au.com.tusc.cmp.ItemLocalHome;
import au.com.tusc.cmp.ItemUtil;
import au.com.tusc.cmp.SupplierData;

import au.com.tusc.session.StoreAccess;
import au.com.tusc.session.StoreAccessHome;
import au.com.tusc.session.StoreAccessUtil;

/**
 * @ejb.bean name="DeliverItems" 
 *     acknowledge-mode="Auto-acknowledge" 
 *     destination-type="javax.jms.Queue" 
 *     subscription-durability="NonDurable" 
 *     transaction-type="Bean" 
 * 
 * @ejb.ejb-ref
 *      ejb-name="StoreAccess"
 *      view-type="remote"
 *      ref-name="StoreAccess"
 * 
 * @ejb.ejb-ref
 *      ejb-name="Item"
 *      view-type="local"
 *      ref-name="ItemLocal"
 *  
 * @jboss.ejb-ref-jndi ref-name="ItemLocal"
 *		jndi-name="ItemLocal"
 
 * @jboss.ejb-ref-jndi ref-name="StoreAccess"
 *		jndi-name="StoreAccessBean"
 * 
 * @jboss.destination-jndi-name
 *      name="queue/DelMdbQueue"
 * 
 **/

public class DeliverItemsBean implements MessageDrivenBean, MessageListener {

	/** Required method for container to set context. */
	public void setMessageDrivenContext(
		javax.ejb.MessageDrivenContext messageContext)
		throws javax.ejb.EJBException {
		this.messageContext = messageContext;
	}
	/** 
	* Required creation method for message-driven beans. 
	* 
	* @ejb.create-method 
	*/
	public void ejbCreate() {
		// no specific action required for message-driven beans 
	}

	/** Required removal method for message-driven beans. */
	public void ejbRemove() {
		messageContext = null;
	}

	/** 
	* This method implements the business logic for the EJB. 
	* 
	* <p>Make sure that the business logic accounts for asynchronous message processing. 
	* For example, it cannot be assumed that the EJB receives messages in the order they were 
	* sent by the client. Instance pooling within the container means that messages are not 
	* received or processed in a sequential order, although individual onMessage() calls to 
	* a given message-driven bean instance are serialized. 
	* 
	* <p>The <code>onMessage()</code> method is required, and must take a single parameter 
	* of type javax.jms.Message. The throws clause (if used) must not include an application 
	* exception. Must not be declared as final or static. 
	*/
	public void onMessage(javax.jms.Message message) {
		System.out.println("Message Driven Bean got message " + message);
		// do business logic here
		
		System.out.println ("Entering DeliverItemsBean.onMessage()");
						
		try {
			
			if (message instanceof ObjectMessage) {
				DeliverItem di =  (DeliverItem) ((ObjectMessage) message).getObject();
				
				StoreAccess access = StoreAccessUtil.getHome().create();				
				itemLocalHome = ItemUtil.getLocalHome();
				
				String suppAccessID = access.loginUser(di.getUsername(),di.getPasswd());				
				System.out.println(" Login is sucessful with "+ suppAccessID);
				SupplierData sd = access.getSupplierData(suppAccessID);
				String suppID = sd.getSupplierID();
				
				if ( suppID != null ) {
					ItemLocal item = this.itemLocalHome.findByPrimaryKey(di.getItemID());			
					String itemSuppID = item.getSupplierID() ;	
				
					if ( suppID.equals(itemSuppID)) {					
							System.out.println ("Delivering items in store now... :");
							Integer quantity = new Integer (di.getQuantity());
							item.fillStock(quantity);
							System.out.println ("Stock of iten after dleivery is :" + item.getItemData());											
					}
				  }				 				
				}						
				}catch (Exception e) {
					System.out.println ("In DeliverItems.onMessage  " +  e.getMessage() );																
				}			
				System.out.println("Entering DeliverItemsBean.onMessage()");						
	}
	
	/** The context for the message-driven bean, set by the EJB container. */
	private javax.ejb.MessageDrivenContext messageContext = null;
	
	private InitialContext context = null;

	private StoreAccessHome storeAccess = null;
	private ItemLocalHome itemLocalHome = null;

}
