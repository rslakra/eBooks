/*
 * Created on Jun 11, 2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
 

package au.com.tusc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.ejb.EJBException;
import javax.ejb.FinderException;
import javax.naming.InitialContext;
import javax.sql.DataSource;
import au.com.tusc.bmp.ManagerDAO;
import au.com.tusc.bmp.ManagerPK;

public class ManagerDAOImpl  implements ManagerDAO{

	   private DataSource jdbcFactory;
	
		public ManagerDAOImpl () {
			super();		
		}

	    public void init() {
			System.out.println (" Entering ManageDAOImpl.init() ");
				
			InitialContext c = null ;		
			if  (this.jdbcFactory == null ){		
				try {
					c = new InitialContext() ;
					this.jdbcFactory= (DataSource) c.lookup("java:comp/env/jdbc/DefaultDS");
				}catch (Exception e) {
					System.out.println ("Error in ManagerDAOImpl.init() ");
				}
			}			
			System.out.println (" Leaving ManagerDAOImpl.init() ");	
	    }

		public void load(au.com.tusc.bmp.ManagerPK pk, au.com.tusc.bmp.ManagerBean ejb) throws javax.ejb.EJBException {
		
			System.out.println (" Entering ManagerDAOImpl.load()  ");
			Connection conn = null;		
			PreparedStatement ps = null;
			ResultSet rs = null;			
			try {
				conn = jdbcFactory.getConnection();
				String queryString = "select managerid, userid, firstname, lastname, address, message,"+
											 "salary from manager where managerid = ?";
				ps = conn.prepareStatement(queryString);
				ps.setString(1,pk.getManagerID());
			    rs = ps.executeQuery();
				System.out.println ("QueryString is " + queryString) ;
				if ( rs.next() )  {
					int count =1;
					ejb.setManagerID((rs.getString(count++)).trim());					
					ejb.setUserID((rs.getString(count++)).trim());					
					ejb.setFirstName((rs.getString(count++)).trim());
					ejb.setLastName((rs.getString(count++)).trim());
					ejb.setAddress((rs.getString(count++)).trim());
					ejb.setMessage((rs.getString(count++)).trim());
					ejb.setSalary( rs. getFloat(count) ) ;					
				}
			}
			catch (SQLException e) {
				throw new EJBException("Row for id " + pk.managerID + " not found in database" + e);
			} 
			finally  {
				try {
					rs.close();
					ps.close();
					conn.close();
				} catch (Exception e) {}						
			}
			System.out.println (" Leaving ManagerDAOImpl.load() ") ;	
		}
		public void store(au.com.tusc.bmp.ManagerBean ejb) throws javax.ejb.EJBException {
			
			System.out.println (" Entering ManagerDAOImpl.store()  ");
			Connection conn = null;		
			PreparedStatement ps = null;
			ResultSet rs = null;
			try {
		
				conn = jdbcFactory.getConnection();				
				String updateString = "update customer set userid = ?, firstname = ?,lastname = ?," +"" +					                            "address = ?, message = ?, salary = ? where managerid = ?";				
				ps = conn.prepareStatement(updateString);
				
				ps.setString (1,ejb.getUserID().trim());
				ps.setString(2,ejb.getFirstName().trim());
				ps.setString(3,ejb.getLastName().trim());
				ps.setString(4,ejb.getAddress().trim());
				ps.setString(5,ejb.getMessage().trim());
				ps.setFloat (6, ejb.getSalary());				
				int count  = ps.executeUpdate();
				System.out.println ("Update String is " + updateString) ;			
			}	
			catch (Exception e ) {
				e.printStackTrace();
			}
			finally  {
				try {
					ps.close();					
					rs.close();
					conn.close();
				}catch (Exception e) {
			    } 
			}
			System.out.println (" Leaving ManagerDAOImpl.store()  ");
		}
		
		public void remove(au.com.tusc.bmp.ManagerPK pk) throws javax.ejb.RemoveException, javax.ejb.EJBException {
			
		}

		public au.com.tusc.bmp.ManagerPK create(au.com.tusc.bmp.ManagerBean ejb) throws javax.ejb.CreateException, javax.ejb.EJBException {
			return null;
		}

		public ManagerPK findByPrimaryKey(ManagerPK pk) throws javax.ejb.FinderException {
			    
			    System.out.println (" Entering ManagerDAOImpl.findByPrimaryKey()  ");				
				Connection conn = null;		
				PreparedStatement ps = null;
				ResultSet rs = null;
				try {
					conn = jdbcFactory.getConnection();
					String queryString = "select managerid from customer where managerid = ?";			
					ps = conn.prepareStatement(queryString);				
					String key = pk.getManagerID();
					ps.setString (1, key);			
					rs = ps.executeQuery();				
					boolean result =rs .next();
					if ( result) {
						System.out.println (" Primary Key found");
					}
				}
				catch (Exception e) {
					e.printStackTrace();
					       throw new FinderException("Inside ManagerDAOImpl.findbyPrimaryKey()" +
                           " following primarykey " + pk.getManagerID() + "notfound ");			
					}
				finally {
					try {
						rs.close();
						ps.close();
						conn.close();
					}
					catch(Exception e ) {				
					}
				}
				System.out.println (" Leaving ManagerDAOImpl.findByPrimaryKey()  " + pk.getManagerID());
				return pk;			
		}
		
		public au.com.tusc.bmp.ManagerPK findByUserID (java.lang.String userID) throws javax.ejb.FinderException {
		
    
			System.out.println (" Entering ManagerDAOImpl.findByUserID()  ");				
			Connection conn = null;		
			PreparedStatement ps = null;
			ResultSet rs = null;
			ManagerPK pk = new ManagerPK() ;
				
			try {
				conn = jdbcFactory.getConnection();
				String queryString = "select managerid from manager where userid = ?";			
				ps = conn.prepareStatement(queryString);								
				ps.setString (1, userID);			
				rs = ps.executeQuery();
								
				boolean result =rs .next();
				if ( result) {
					pk.setManagerID( rs.getString(1) );
					System.out.println (" Primary Key found :" + pk.getManagerID() );
				}
			}
			catch (Exception e) {
				e.printStackTrace();
					   throw new FinderException("Inside ManagerDAOImpl.findbyPrimaryKey()" + e);			
				}
			finally {
				try {
					rs.close();
					ps.close();
					conn.close();
				}
				catch(Exception e ) {				
				}
			}
			System.out.println (" Leaving ManagerDAOImpl.findByUserID() with key " + pk.getManagerID());
			return pk;					
		}
		
		
		
}
