/*
 * Created on Jun 18, 2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package au.com.tusc.cmp;

import javax.ejb.EntityBean;
import javax.ejb.EntityContext;


/**
 * @ejb.bean name="Supplier"
 *	jndi-name="SupplierBean"
 *	type="CMP"
 *  primkey-field="supplierID"
  *  schema="MyStoreSupplier" 
 *  cmp-version="2.x"
 * 
 *  @ejb.persistence 
 *   table-name="Supplier" 
 * 
 * @ejb.finder 
 *    query="SELECT OBJECT(a) FROM MyStoreSupplier as a"  
 *    signature="java.util.Collection findAll()"
 *  
 * @ejb.finder 
 *    query="SELECT OBJECT(b) FROM MyStoreSupplier as b where b.userID = ?1"  
 *    signature="au.com.tusc.cmp.SupplierLocal findUserID(java.lang.String userID)"  
 *  
 **/

public abstract class SupplierBean implements EntityBean {

	protected EntityContext eContext ;
    /**
	 * Sets the entity context 
	 * @param javax.ejb.EntityContext the new eContext value
	 * @ejb.method setEnityContext
	**/   			
	public void setEntityContext(EntityContext context) {
		eContext = context;
	}
	 
   /**
	* Unsets the enity context 
	*  @param javax.ejb.EntityContext eContext value
	*  @ejb.method unsetSessionContext
	**/
	public void unsetEntityContext()	  {
		eContext = null;
	}


	/**
 	* The  ejbCreate method.
	* 
	* @ejb.create-method 
	*/
	public java.lang.String ejbCreate(String supplierID, String userID, String firstName,
									String lastName, String address, String message, Float creditLimit ) throws javax.ejb.CreateException {
		// EJB 2.0 spec says return null for CMP ejbCreate methods.
		// TODO: YOU MUST INITIALIZE THE FIELDS FOR THE BEAN HERE. 
		// setMyField("Something"); 
		setSupplierID(supplierID);
		setUserID(userID);
		setFirstName(firstName);
		setLastName(lastName);
		setAddress(address);
		setMessage(message);
		setCreditLimit(creditLimit);
		return null;
	}

	/**
	 * The container invokes this method immediately after it calls ejbCreate.
	 * 
	 */
	 public void ejbPostCreate() throws javax.ejb.CreateException {
	 }

	/**
	* Returns the supplierID
	* @return the supplierID
	* 
	* @ejb.persistent-field 
	* @ejb.persistence
	*    column-name="SUPPLIERID"
	*     sql-type="VARCHAR"
	* @ejb.pk-field 
	* @ejb.interface-method
	*/
	public abstract java.lang.String getSupplierID();

	/**
	* Sets the supplierID
	* 
	* @param java.lang.String the new supplierID value
	* 
	* @ejb.interface-method
	*/
	public abstract void setSupplierID(java.lang.String supplierID);

	/**
	* Returns the userID
	* @return the userID
	* 
	* @ejb.persistent-field 
	* @ejb.persistence
	*    column-name="USERID"
	*     sql-type="VARCHAR"
	*  
	* @ejb.interface-method
	*/
	public abstract java.lang.String getUserID();

	/**
	* Sets the userID
	* 
	* @param java.lang.String the new userID value
	* 
	* @ejb.interface-method
	*/
	public abstract void setUserID(java.lang.String userID);

	/**
	* Returns the firstName
	* @return the firstName
	* 
	* @ejb.persistent-field 
	* @ejb.persistence
	*    column-name="FIRSTNAME"
	*     sql-type="VARCHAR"
	*  
	* @ejb.interface-method
	*/
	public abstract java.lang.String getFirstName();

	/**
	* Sets the firstName
	* 
	* @param java.lang.String the new firstName value
	* 
	* @ejb.interface-method
	*/
	public abstract void setFirstName(java.lang.String firstName);

	/**
	* Returns the lastName
	* @return the lastName
	* 
	* @ejb.persistent-field 
	* @ejb.persistence
	*    column-name="LASTNAME"
	*     sql-type="VARCHAR"
	*  
	* @ejb.interface-method
	*/
	public abstract java.lang.String getLastName();

	/**
	* Sets the lastName
	* 
	* @param java.lang.String the new lastName value
	* 
	* @ejb.interface-method
	*/
	public abstract void setLastName(java.lang.String lastName);

	/**
	* Returns the address
	* @return the address
	* 
	* @ejb.persistent-field 
	* @ejb.persistence
	* column-name="ADDRESS"
	* sql-type="VARCHAR"
	*  
	* @ejb.interface-method
	*/
	public abstract java.lang.String getAddress();

	/**
	* Sets the address
	* 
	* @param java.lang.String the new address value
	* 
	* @ejb.interface-method
	*/
	public abstract void setAddress(java.lang.String address);

	/**
	* Returns the message
	* @return the message
	* 
	* @ejb.persistent-field 
	* @ejb.persistence
	* column-name="MESSAGE"
	* sql-type="VARCHAR"
	*  
	* @ejb.interface-method
	*/
	public abstract java.lang.String getMessage();

	/**
	* Sets the message
	* 
	* @param java.lang.String the new message value
	* 
	* @ejb.interface-method
	*/
	public abstract void setMessage(java.lang.String message);

	/**
	* Returns the creditLimit
	* @return the creditLimit
	* 
	* @ejb.persistent-field 
	* @ejb.persistence
	* column-name="CREDIT_LIMIT"
	* sql-type="DECIMAL"
	*  
	* @ejb.interface-method
	*/
	public abstract java.lang.Float getCreditLimit();

	/**
	* Sets the creditLimit
	* 
	* @param java.lang.Float the new creditLimit value
	* 
	* @ejb.interface-method
	*/
	public abstract void setCreditLimit(java.lang.Float creditLimit);
	
	/**
	* @ejb.interface-method
	* view-type="local" 
	**/
	public au.com.tusc.cmp.SupplierData getSupplierData()  { 
		 System.out.println ("Entering SupplierBean.getSupplierData() ");
		 System.out.println ("Leaving SupplierBean.getSupplierData() ");  
		 return new SupplierData ( getSupplierID(), getUserID(), 
			 getFirstName(), getLastName(),getAddress(), getMessage(), getCreditLimit()); 
	 }
 	  
		/**
		* @ejb.interface-method
		* view-type="local" 
		**/
		public  void requestItem (java.lang.String itemID,  java.lang.Integer quantity) {
	 			
	 		System.out.println (" Entering SupplierBean.requestItem() " + quantity.toString() );
			String message = itemID +  quantity.toString();
	 		this.setMessage(message);
			System.out.println (" Leaving SupplierBean.requestItem()"); 
		}
	

}
