/*
 * Created on Jun 19, 2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package au.com.tusc.mdb;

import java.io.Serializable;

/**
 * @author vishal
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class DeliverItem  extends Object implements Serializable{

	private String username;
	private String passwd;
	private String itemID;
	private int quantity;

	/**
	 * 
	 */
	public DeliverItem(String username, String passwd, String itemID, int quantity) {
		super();
		setUsername(username);
		setPasswd(passwd);
		setItemID(itemID);
		setQuantity(quantity);
	}

	/**
	 * @return
	 */
	public String getItemID() {
		return itemID;
	}

	/**
	 * @return
	 */
	public String getPasswd() {
		return passwd;
	}

	/**
	 * @return
	 */
	public int getQuantity() {
		return quantity;
	}

	/**
	 * @return
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * @param string
	 */
	public void setItemID(String string) {
		itemID = string;
	}

	/**
	 * @param string
	 */
	public void setPasswd(String string) {
		passwd = string;
	}

	/**
	 * @param i
	 */
	public void setQuantity(int i) {
		quantity = i;
	}

	/**
	 * @param string
	 */
	public void setUsername(String string) {
		username = string;
	}

}
