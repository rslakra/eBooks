/*
 * Created on May 28, 2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package au.com.tusc.client;


import java.util.Hashtable;

import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import au.com.tusc.mdb.DeliverItem;



/**
 * @author vishal
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class DeliverMDBClient {


	private InitialContext getContext() throws NamingException {
			Hashtable props = new Hashtable();

			props.put(
				InitialContext.INITIAL_CONTEXT_FACTORY,
				"org.jnp.interfaces.NamingContextFactory");
			props.put(InitialContext.PROVIDER_URL, "jnp://127.0.0.1:1099");

			InitialContext initialContext = new InitialContext(props);
			return initialContext;
	}


	public static void main(String[] args) {
	
		DeliverMDBClient mdbean = new DeliverMDBClient ();
		mdbean.testMDBBean() ;
	}
	
	public void testMDBBean() {

		
		DeliverItem di = new DeliverItem ("TUSX","PASSWD","I1",30);
		
		
			try {
			System.out.println("Looking up the factory ");
		
			InitialContext ctx = getContext();
		
			QueueConnectionFactory factory = (QueueConnectionFactory) ctx.lookup("ConnectionFactory");
			
			System.out.println("Looking up the queue ");			
			Queue queue = (Queue) ctx.lookup("queue/DelMdbQueue");			

			System.out.println("Creating the connection ");			
			
			QueueConnection connection = factory.createQueueConnection();
			
			System.out.println("Creating the session ");			
			QueueSession session = connection.createQueueSession(true, 1);
			
			System.out.println("Creating the sender ");			
			QueueSender sender = session.createSender(queue);			
			ObjectMessage message = session.createObjectMessage();
						System.out.println ("Setting the object in message ");						
			message.setObject(di);
			
			System.out.println ("Sending the message ");
			
			sender.send(message);
			System.out.println ("Shuting down");
			session.commit();
			session.close();
			connection.close();
			
			System.out.println ("Done ! ");															

		} catch (Exception e) {
			e.printStackTrace();
		}	
	}
}
