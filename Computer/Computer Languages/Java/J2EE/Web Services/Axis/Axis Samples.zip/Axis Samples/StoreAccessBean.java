/*
 * Created on Jun 4, 2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package au.com.tusc.session;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import au.com.tusc.bmp.CustomerData;
import au.com.tusc.bmp.CustomerLocal;
import au.com.tusc.bmp.CustomerLocalHome;
import au.com.tusc.bmp.CustomerUtil;
import au.com.tusc.bmp.ManagerData;
import au.com.tusc.bmp.ManagerLocal;
import au.com.tusc.bmp.ManagerLocalHome;
import au.com.tusc.bmp.ManagerUtil;
/**
 * @ejb.bean name="StoreAccess"
 *	jndi-name="StoreAccessBean"
 *	type="Stateless" 
 *
 * @ejb.dao class="au.com.tusc.session.StoreAccessDAO"
 *  impl-class="au.com.tusc.dao.StoreAccessDAOImpl"
 * 
 * @ejb.resource-ref res-ref-name="jdbc/DefaultDS"
 * 	res-type="javax.sql.Datasource"
 * 	res-auth="Container"
 * 
 * @jboss.resource-ref  res-ref-name="jdbc/DefaultDS"
 * 	jndi-name="java:/DefaultDS"
 *  
 * @ejb.ejb-ref ejb-name="Customer"
 *    view-type="local"
 *    ref-name="CustomerLocal"
 *
 *  @jboss.ejb-ref-jndi ref-name="CustomerLocal"
 *     jndi-name="CustomerLocal"
 * 
 * @ejb.ejb-ref ejb-name="Manager"
 *    view-type="local"
 *    ref-name="ManagerLocal"
 *
 *  @jboss.ejb-ref-jndi ref-name="ManagerLocal"
 *     jndi-name="ManagerLocal" 
** 
**/



public abstract class StoreAccessBean implements SessionBean {

	protected  SessionContext ctx;	
	private CustomerLocalHome customerLocalHome;
	private ManagerLocalHome managerLocalHome;
	
	
   /**
   * @ejb.interface-method
   * tview-type="remote" 
   * @dao.call name="loginUser"
   **/   
    public String loginUser(String username, String password ) {
	
	     System.out.println("Entering StoreAccesBean");
   	     System.out.println("Leaving StoreAccesBean");
	     return null;
    }

  /**
   *  Sets the session context 
   *  @param javax.ejb.SessionContext the new ctx value
   **/   
   public void setSessionContext(javax.ejb.SessionContext ctx)  {
       this.ctx = ctx;	
   }    


   /**
    * Unsets the session context 
    *  @param javax.ejb.SessionContext ctx value
    **/
    public void unsetSessionContext()  {
       this.ctx = null;	
    }    

    /**
     * Returns object CustomerData
     * @ejb.interface-method
     *  tview-type="remote" 
     **/
     public au.com.tusc.bmp.CustomerData getCustomerData(String userID){ 
	
         System.out.println (" Entering StoreAccessBean.getCustomerData() ");
	 CustomerData cd = null;
	     try {
	         CustomerLocal myCustomer  =   customerLocalHome.findByUserID(userID);								
	        if (myCustomer != null ) {
                   cd = myCustomer.getCustomerData();
		}				
	     } catch (Exception e) {
	        System.out.println (" Error in StoreAccessBean.getCustomerData() " + e);
	    }
	    System.out.println (" Leaving StoreAccessBean.getCustomerData() ");
	    return cd;
       }
       
      /**
       * Returns object ManagerData
       * @ejb.interface-method
       *  tview-type="remote" 
       **/
       public au.com.tusc.bmp.ManagerData getManagerData(String mgrID){ 

	   System.out.println (" Entering StoreAccessBean.getManagerData() ");
	   ManagerData md = null;
			   
	   try {
	      ManagerLocal myManager  =   managerLocalHome.findByUserID(mgrID);								
	      if (myManager != null ) {
		  md = myManager.getManagerData();
	      }				
	   } catch (Exception e) {
	       System.out.println (" Error in StoreAccessBean.getManagerData() " + e);
	   }
	   System.out.println (" Leaving StoreAccessBean.getMangerData() ");
	   return md;
	}
       
       
       
       /**
        * The  ejbCreate method.
        * @ejb.create-method 
        **/
	public void ejbCreate () throws  javax.ejb.CreateException {
	
            System.out.println (" Entering  StoreAccessBean.ejbCreate() ");			
	    try {						
	       customerLocalHome = CustomerUtil.getLocalHome();
	       managerLocalHome = ManagerUtil.getLocalHome();
	    }
	    catch (Exception e) {
		e.printStackTrace();
	    }
	    System.out.println (" Leaving  StoreAccesBean.ejbCreate() ");			
	}     
}
