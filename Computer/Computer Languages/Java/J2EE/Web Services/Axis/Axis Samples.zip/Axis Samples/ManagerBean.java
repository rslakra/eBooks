/*
 * Created on Jun 17, 2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package au.com.tusc.bmp;

import javax.ejb.EntityBean;
import javax.ejb.FinderException;

/**
 * @ejb.bean name="Manager"
 *	jndi-name="ManagerBean"
 *	type="BMP" 
 *
 *@ejb.dao class="au.com.tusc.bmp.ManagerDAO"
 *  impl-class="au.com.tusc.dao.ManagerDAOImpl"
 *
 *  @ejb.resource-ref res-ref-name="jdbc/DefaultDS"
 *  res-type="javax.sql.Datasource"
 *  res-auth="Container"
 * 
 * @jboss.resource-ref  res-ref-name="jdbc/DefaultDS"
 * jndi-name="java:/DefaultDS"
 *
**/

public abstract class ManagerBean implements EntityBean {

        private String managerID;
	private String userID;
	private String firstName;
	private String lastName;
	private String address;
	private String message;
	private float salary;
		
	/**
	 * Returns the managerID
	 * @return the managerID
	 * @ejb.persistence
	 * @ejb.pk-field
	 * @ejb.interface-method 
	 */
 	 public  java.lang.String getManagerID(){
		 return managerID;
	  }

	 /**
	 * Sets the mangerID
	 * @param java.lang.String the new managerID value
	 * @ejb.interface-method 
	 */
	 public  void setManagerID (java.lang.String managerID) {
		 this.managerID = managerID ;  
	 }
		
	 /**
	  * Returns the userID
	  * @return the userID
	  * @ejb.persistence
	  * @ejb.interface-method 
	  */
	   public  java.lang.String getUserID(){
		  return userID;
	   }

	  /**
	  * Sets the userID
	  * @param java.lang.String the new userID value
	  * @ejb.interface-method 
	  */
	  public  void setUserID (java.lang.String userID) {
		  this.userID = userID ;  
	  }
		
	  /**
	  * Returns the firstName
	  * @return the firstName
	  * @ejb.persistence
	  * @ejb.interface-method
	  */
	  public  java.lang.String getFirstName() {
		  return firstName;
	  }

	  /**
	  * Sets the firstName
	  * @param java.lang.String the new firstName value
	  * @ejb.interface-method
	  */
	  public void setFirstName(java.lang.String firstName) {
		   this.firstName = firstName;
	  }

	  /**
	  * Returns the lastName
	  * @return the lastName
	  * 
	  * @ejb.persistence			 
	  * @ejb.interface-method
	  */
	  public java.lang.String getLastName() {
		   return lastName;
	  }

	  /**
	  * Sets the lastName
	  * 
	  * @param java.lang.String the new lastName value
	  * @ejb.interface-method
	  */
	  public void setLastName(java.lang.String lastName) {
		   this.lastName = lastName ;
	  }

	 /** 
	  * Returns the address
	  * @return the address
	  * 
	  * @ejb.persistence
	  * @ejb.interface-method
	  */
	  public java.lang.String getAddress() {
	      return address;
	  }

	  /**
	   * Sets the address
	   * 
	   * @param java.lang.String the new address value
	   * @ejb.interface-method
	   */
	  public void setAddress(java.lang.String address) {
	 	  this.address = address;
	  }

	  /** 
	   * Returns the message
	   * @return the message
	   * 
	   * @ejb.persistence
	   * @ejb.interface-method
	   */
	  public java.lang.String getMessage() {
	   	  return message;
	  }

	  /**
	   * Sets the message
	   * 
	   * @param java.lang.String the new message value  
	   * @ejb.interface-method
	   */
	  public void setMessage(java.lang.String message) {
		 this.message = message;
	  }

	  /** 
	   * Returns the salary
	   * @return the salary
	   * 
	   * @ejb.persistence 
	   * @ejb.interface-method
	   */
	  public float getSalary() {
		  return salary;
	  }

	  /**
	   * Sets the salary
	   * 
	   * @param java.lang.String the new salary value					  
	   * @ejb.interface-method
	   */
	   public void setSalary(float salary) {
		    this.salary = salary;
	   }

	  /**
	   *  @param CustomerPK pk value
	   *  Finds the Primary Key
	   *  @return CustomerPk object  
	   *	
	   **/
	   public ManagerPK ejbFindByPrimaryKey (au.com.tusc.bmp.ManagerPK pk) throws FinderException{ 
		   System.out.println ("Entering ManagerBean.ejbFindByPrimatyKey ");
		   System.out.println ("Leaving ManagerBean.ejbFindByPrimaryKey ");
		   return null; 
	    }

	    /**
	     *  Finds the Primary Key
	     *  @return ManagerPk object  
	     *  
	     *  @param String userID value
	     *	
	     **/       
	     public ManagerPK ejbFindByUserID (String userID) throws FinderException{ 
		 System.out.println ("Entering ManagerBean.ejbFindByUserID ");
		 System.out.println ("Leaving ManagerBean.ejbFindByUserID ");
		 return null; 
	     }

	     /**
	      *  Returns the Manager Data Object
	      *  @return the ManagerData
	      * @ejb.interface-method
	      *  tview-type="local" 
	      **/
	      public ManagerData getManagerData(){
		  System.out.println ("Entering ManagerBean.getManagerData() ");
		  System.out.println ("Leaving ManagerBean.getManagerData() ");
	    
		  return new ManagerData ( getManagerID(), getUserID(), getFirstName(), getLastName(), getAddress(), getMessage(), getSalary()); 
	      }    
}
