/*
 * Created on Jun 4, 2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package au.com.tusc.session;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;


import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import au.com.tusc.bmp.CustomerData;
import au.com.tusc.bmp.CustomerLocal;
import au.com.tusc.bmp.CustomerLocalHome;
import au.com.tusc.bmp.CustomerUtil;
import au.com.tusc.bmp.ManagerData;
import au.com.tusc.bmp.ManagerLocal;
import au.com.tusc.bmp.ManagerLocalHome;
import au.com.tusc.bmp.ManagerUtil;
import au.com.tusc.cmp.ItemData;
import au.com.tusc.cmp.ItemLocal;
import au.com.tusc.cmp.ItemLocalHome;
import au.com.tusc.cmp.ItemUtil;
import au.com.tusc.cmp.SupplierData;
import au.com.tusc.cmp.SupplierLocal;
import au.com.tusc.cmp.SupplierLocalHome;
import au.com.tusc.cmp.SupplierUtil;
/**
 * @ejb.bean name="StoreAccess"
 *	jndi-name="StoreAccessBean"
 *	type="Stateless" 
 *
 * @ejb.dao class="au.com.tusc.session.StoreAccessDAO"
 *  impl-class="au.com.tusc.dao.StoreAccessDAOImpl"
 * 
 * @ejb.resource-ref res-ref-name="jdbc/DefaultDS"
 * 	res-type="javax.sql.Datasource"
 * 	res-auth="Container"
 * 
 * @jboss.resource-ref  res-ref-name="jdbc/DefaultDS"
 * 	jndi-name="java:/DefaultDS"
 *  
 * @ejb.ejb-ref ejb-name="Customer"
 *    view-type="local"
 *    ref-name="CustomerLocal"
 *
 *  @jboss.ejb-ref-jndi ref-name="CustomerLocal"
 *     jndi-name="CustomerLocal"
 * 
 * @ejb.ejb-ref ejb-name="Manager"
 *    view-type="local"
 *    ref-name="ManagerLocal"
 *
 *  @jboss.ejb-ref-jndi ref-name="ManagerLocal"
 *     jndi-name="ManagerLocal" 
 * 
 * @ejb.ejb-ref ejb-name="Item"
 *    view-type="local"
 *    ref-name="ItemLocal"
 *
 *  @jboss.ejb-ref-jndi ref-name="ItemLocal"
 *     jndi-name="ItemLocal" 
 * 
 *  @ejb.ejb-ref ejb-name="Supplier"
 *    view-type="local"
 *    ref-name="SupplierLocal"
 *
 *  @jboss.ejb-ref-jndi ref-name="SupplierLocal"
 *     jndi-name="SupplierLocal" 
 * 
**/

public abstract class StoreAccessBean implements SessionBean {

	protected  SessionContext ctx;	
	private CustomerLocalHome customerLocalHome;
	private ManagerLocalHome managerLocalHome;
	private ItemLocalHome itemLocalHome;
	private SupplierLocalHome supplierLocalHome;
	
	
   /**
   * @ejb.interface-method
   * tview-type="remote" 
   * @dao.call name="loginUser"
   **/   
    public String loginUser(String username, String password ) {
	
	     System.out.println("Entering StoreAccesBean");
   	     System.out.println("Leaving StoreAccesBean");
	     return null;
    }

	/**
	 *	Sets the session context 
	 *  @param javax.ejb.SessionContext the new ctx value
	 *  @ejb.method stSessionContext
	 **/   
     public void setSessionContext(javax.ejb.SessionContext ctx)  {
	      this.ctx = ctx;	
     }    


	/**
	 * Unsets the session context 
	 *  @param javax.ejb.SessionContext ctx value
	 *  @ejb.method unsetSessionContext
     **/
	 public void unsetSessionContext()  {
	      this.ctx = null;	
     }    

     /**
      * Returns object CustomerData
      * @ejb.interface-method
      *  tview-type="remote" 
      **/
       public au.com.tusc.bmp.CustomerData getCustomerData(String userID){ 
	
	        System.out.println (" Entering StoreAccessBean.getCustomerData() ");
			CustomerData cd = null;
			try {
				CustomerLocal myCustomer  =   customerLocalHome.findByUserID(userID);								
				if (myCustomer != null ) {
                     cd = myCustomer.getCustomerData();
				 }				
			 } catch (Exception e) {
			        System.out.println (" Error in StoreAccessBean.getCustomerData() " + e);
			 }
			 System.out.println (" Leaving StoreAccessBean.getCustomerData() ");
			 return cd;
       }
       
	    /**
		 * Returns object ManagerData
		 * @ejb.interface-method
		 *  tview-type="remote" 
		 **/
		 public au.com.tusc.bmp.ManagerData getManagerData(String mgrID){ 
	
			   System.out.println (" Entering StoreAccessBean.getManagerData() ");
			   ManagerData md = null;
			   
			   try {
				   ManagerLocal myManager  =   managerLocalHome.findByUserID(mgrID);								
				   if (myManager != null ) {
						md = myManager.getManagerData();
					}				
				} catch (Exception e) {
					   System.out.println (" Error in StoreAccessBean.getManagerData() " + e);
				}
				System.out.println (" Leaving StoreAccessBean.getMangerData() ");
				return md;
		 }
	
	     /**
		  * Returns object SupplierData		  
		  *  @ejb.interface-method
		  *  tview-type="remote" 
		  **/
		public SupplierData getSupplierData(String userID){ 
	
			 System.out.println (" Entering StoreAccessBean.getSupplierData() ");
			 SupplierData sd = null;
			
			 try {
			
				 SupplierLocal mySupplier  =   supplierLocalHome.findUserID(userID);								
		
				 if (mySupplier != null ) {
					  sd = mySupplier.getSupplierData();
				  }				
			  } catch (Exception e) {
					 System.out.println (" Error in StoreAccessBean.getSupplierData() " + e);
			  }
			  System.out.println (" Leaving StoreAccessBean.getSupplierData() ");
			  return sd;
		 }
    
	
		 
	     /**
		   * Returns object ItemData		  
		  *  @ejb.interface-method
		  *  tview-type="remote" 
		  **/
		 public au.com.tusc.cmp.ItemData getItemData(String itemID){ 
	
			  System.out.println (" Entering StoreAccessBean.getItemData() ");
			  ItemData myItem = null;
			   
			  try {
				  ItemLocal item  =   itemLocalHome.findByPrimaryKey(itemID);								
		
				  if (item != null ) {
					   myItem = item.getItemData();
				   }				
			   } catch (Exception e) {
					  System.out.println (" Error in StoreAccessBean.getItemData() " + e);
			   }
			   System.out.println (" Leaving StoreAccessBean.getItemData() ");
			   return myItem;
		  }
    		
	      /**
		   * Returns ArrayList of Items which are out of Stock.
		   * @ejb.interface-method
		   *  tview-type="remote" 
		   **/
		   public java.util.ArrayList getOutOfStockItems( ){ 
	
		   	   System.out.println (" Entering StoreAccessBean.getItemsOutOfStock() ");		   	   
		   	   Collection items = null;
		   	   ArrayList itemsOutOfStock = new ArrayList();
		   	   			   
			   try {
				   items  =   itemLocalHome.findByOutOfStock();				   
				   Iterator iterate = items.iterator();								
				   		while (iterate.hasNext()) {				   	
				   			ItemLocal myItemLocal = (ItemLocal) iterate.next();				   		
				   			itemsOutOfStock.add(myItemLocal.getItemData());
				   		}
				   } catch (Exception e) {
						  System.out.println (" Error in StoreAccessBean.getItemsOutOfStock() " + e);
				   }
				   System.out.println (" Leaving StoreAccessBean.getItemsOutOfStock() ");
				   return itemsOutOfStock;
		   }       
		   
		   
	         /**
			  * Returns ArrayList of Items supplied by a supplier
			  * @ejb.interface-method
			  *  tview-type="remote" 
			  **/
			  public java.util.ArrayList getItemsBySupplier(String supplierID ){ 
	
				  System.out.println (" Entering StoreAccessBean.getItemsBySupplier() ");		   	   
				  Collection suppliedItems = null;
				  ArrayList itemsBySupplier = new ArrayList();
		   	   			   
				  try {
					  suppliedItems  =   itemLocalHome.findSupplierID (supplierID);				   
					  Iterator iterate = suppliedItems.iterator();								
						   while (iterate.hasNext()) {				   	
							   ItemLocal myItemsLocal = (ItemLocal) iterate.next();				   		
							   itemsBySupplier.add(myItemsLocal.getItemData());
						   }
					  } catch (Exception e) {
							 System.out.println (" Error in StoreAccessBean.getItemsBySupplier() " + e);
					  }
					  System.out.println (" Leaving StoreAccessBean.getItemsbySupplier() ");
					  return itemsBySupplier;
			  }       
		   
		   
		          
       /**
        * The  ejbCreate method.
        * @ejb.create-method 
        **/
	    public void ejbCreate () throws  javax.ejb.CreateException {
		
		      System.out.println (" Entering  StoreAccessBean.ejbCreate() ");			
		      try {						
			       customerLocalHome = CustomerUtil.getLocalHome();
				   managerLocalHome = ManagerUtil.getLocalHome();
				   itemLocalHome = ItemUtil.getLocalHome();
				   supplierLocalHome = SupplierUtil.getLocalHome();
	 	      }
		      catch (Exception e) {
					e.printStackTrace();
		      }
		      System.out.println (" Leaving  StoreAccesBean.ejbCreate() ");			
	     }     
}
