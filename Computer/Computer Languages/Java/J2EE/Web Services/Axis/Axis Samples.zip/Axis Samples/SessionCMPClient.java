/*
 * Created on Jun 17, 2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package au.com.tusc.client;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;

import javax.ejb.CreateException;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import au.com.tusc.bmp.CustomerData;
import au.com.tusc.bmp.ManagerData;
import au.com.tusc.cmp.ItemData;
import au.com.tusc.cmp.SupplierData;

/**
 * @author vishal
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class SessionCMPClient {

	private au.com.tusc.session.StoreAccessHome getHome()
		throws NamingException {
		return (au.com.tusc.session.StoreAccessHome) getContext().lookup(
			au.com.tusc.session.StoreAccessHome.JNDI_NAME);
	}
	private InitialContext getContext() throws NamingException {
		Hashtable props = new Hashtable();

		props.put(
			InitialContext.INITIAL_CONTEXT_FACTORY,
			"org.jnp.interfaces.NamingContextFactory");
		props.put(InitialContext.PROVIDER_URL, "jnp://127.0.0.1:1099");

		InitialContext initialContext = new InitialContext(props);
		return initialContext;
	}
	public void testBean() {

		Iterator itemsIterator = null;
		ArrayList items = null;
		try {
			au.com.tusc.session.StoreAccess myBean = getHome().create();
			//--------------------------------------
			//This is the place you make your calls.
			//System.out.println(myBean.callYourMethod());			
			System.out.println("Request from client : ");
			String userID =   myBean.loginUser("ANDY","PASSWD");
			System.out.println("Reply from Server: Your userid is " + userID );
			CustomerData cd = myBean.getCustomerData(userID);			
			System.out.println ("Andy your details with MyStore are  " + cd );
						
			String suppID =   myBean.loginUser("TUSX","PASSWD");
			System.out.println("Reply from Server: Your supplierID is " + suppID );			
			SupplierData sd = myBean.getSupplierData(suppID);
			System.out.println ("TUSX your details with MyStore are  " + sd );			
			
			String mgrID =   myBean.loginUser("RUSTY","PASSWD");
			System.out.println("Reply from Server: Your mgrid is " + mgrID );
			ManagerData md = myBean.getManagerData(mgrID);			
			System.out.println ("Rusty your details with MyStore are  " + md );			
			System.out.println("Manager Request : List items out of stock ");
						
			items = myBean.getOutOfStockItems();
			itemsIterator = items.iterator();
			System.out.println("List Of Out Of stock Items ");			
			while ( itemsIterator.hasNext() ) {			
				ItemData itemData= ( ItemData ) itemsIterator.next();
				System.out.println ("Item Data " + itemData );
			}						
		} catch (RemoteException e) {
			e.printStackTrace();
		} catch (CreateException e) {
			e.printStackTrace();
		} catch (NamingException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		SessionCMPClient test = new SessionCMPClient();
		test.testBean();

	}
}
