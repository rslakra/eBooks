package com.ogilviepartners.jdobook.other; // Same package as Account

import javax.jdo.JDOHelper;

public class ChangeAccount {
	public static void safeIncrementBalance(Account a) {
		JDOHelper.makeDirty(a,"balance");  // now JDO knows it is dirty
		a.balance++;        
	}
	
	public static void unsafeIncrementBalance(Account a) {
		// Do not do this! by failing to invoke makeDirty you do not let
		// JDO know that the field needs saving!  You also don't give it the
		// chance to cache values for future rollback
		a.balance++;        
	}
}