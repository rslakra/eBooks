package com.ogilviepartners.jdobook.app;

import javax.jdo.*;
import com.ogilviepartners.jdo.JDOBootstrap;
import com.ogilviepartners.jdobook.op.BusinessPartner;
import com.ogilviepartners.jdobook.op.pk.BusinessPartnerPK;

import java.util.Collection;

public class ChangeApplicationIdentity {
	
	final static String changeIdentity = "javax.jdo.option.ChangeApplicationIdentity";
	
	public static void main(String[] args) {
		JDOBootstrap bootstrap;
		PersistenceManagerFactory pmf;
		PersistenceManager pm;
		BusinessPartner bp;
		BusinessPartnerPK oldKey;
		String newPartnerNumber;
		Collection supportedOptions;
		Transaction t;
		
		
		bootstrap = new JDOBootstrap();
		pmf = bootstrap.getPersistenceManagerFactory();
		supportedOptions = pmf.supportedOptions();
		
		// is changing of application identity supported?
		if (!supportedOptions.contains(changeIdentity)) {
			System.err.println("This JDO Implementation does not support the " +
				"changing of application identities");
		}
		
		if (args.length != 2) {
			System.err.println("usage: java ChangeApplicationIdentity " +
				"<oldPartnerNumber> <newPartnerNumber>");
			System.exit(1);
		}
		
		oldKey = new BusinessPartnerPK(args[0]);
		newPartnerNumber = args[1];
		
		pm = pmf.getPersistenceManager();
		t = pm.currentTransaction();
		t.begin();
		
		// find the BusinessPartner
		bp = (BusinessPartner) pm.getObjectById(oldKey, true);
		
		// change the primary key field
		bp.setPartnerNumber(newPartnerNumber);
		
		// print out the ObjectId and TransactionalObjectId
		System.out.println("ObjectId=" + pm.getObjectId(bp));
		System.out.println("TransactionalObjectId=" +
			pm.getTransactionalObjectId(bp));
		
		// done
		t.commit();
		pm.close();
	}
}
