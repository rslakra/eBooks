package com.ogilviepartners.jdobook.other; 

public class Account {
	double balance; // package level ("friendly") visibility
	
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public String toString() {
		return "balance=" + balance;
	}
}
