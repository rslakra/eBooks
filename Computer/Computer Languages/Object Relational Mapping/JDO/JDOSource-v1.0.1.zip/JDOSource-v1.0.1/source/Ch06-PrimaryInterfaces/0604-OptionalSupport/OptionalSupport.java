package com.ogilviepartners.jdobook.app;

import javax.jdo.*;
import com.ogilviepartners.jdo.JDOBootstrap;
import java.util.Collection;
import java.util.Iterator;

public class OptionalSupport
{
	public static void main(String[] args) {
	
		// instantiate the PersistenceManagerFactory
		
		JDOBootstrap bootstrap = new JDOBootstrap();

		bootstrap.listJDOProperties();
	  bootstrap.listVendorProperties();
		PersistenceManagerFactory pmf = bootstrap.getPersistenceManagerFactory();
		
		System.out.println("Supported Optional Features:");
		
		Collection c = pmf.supportedOptions();
		Iterator i = c.iterator();
		while (i.hasNext()) {		
			System.out.println(i.next());		
		}
	}
}

