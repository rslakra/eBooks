package com.ogilviepartners.jdobook.app;

import javax.jdo.*;
import com.ogilviepartners.jdo.JDOBootstrap;
import com.ogilviepartners.jdobook.other.Account;
import com.ogilviepartners.jdobook.other.ChangeAccount;

import java.util.Iterator;

public class TestMakeDirty
{
	public static void main(String[] args) {

		// instantiate the PersistenceManagerFactory		
		JDOBootstrap bootstrap = new JDOBootstrap();
		bootstrap.listJDOProperties();
	  	bootstrap.listVendorProperties();
		PersistenceManagerFactory pmf = bootstrap.getPersistenceManagerFactory();
				
		// obtain a PersistenceManager
		PersistenceManager pm = pmf.getPersistenceManager();
		
		// get a reference to the Transaction object		
		Transaction t = pm.currentTransaction();
		
		// create a (transient) Account		
		Account acct = new Account();
		acct.setBalance(10);
		
		// persist the BusinessPartner		
		System.out.println("Persisting " + acct);
		t.begin();
		pm.makePersistent(acct);
		t.commit();
		
		// increment the balance
		System.out.println("Safe increment of balance");
		t.begin();
		ChangeAccount.safeIncrementBalance(acct);
		t.commit();
		
		System.out.println("After commit: " + acct);
		
		// increment the balance
		System.out.println("Safe increment of balance");
		t.begin();
		ChangeAccount.safeIncrementBalance(acct);
		t.rollback();
		
		System.out.println("After rollback: " + acct);

		// increment the balance
		System.out.println("Unsafe increment of balance");
		t.begin();
		ChangeAccount.unsafeIncrementBalance(acct);
		t.commit();
		
		System.out.println("After commit: " + acct);
		
		// increment the balance
		System.out.println("Unsafe increment of balance");
		t.begin();
		ChangeAccount.unsafeIncrementBalance(acct);
		t.rollback();
		
		System.out.println("After rollback: " + acct);
		
		
		// close resources		
		pm.close();	
	}
}

