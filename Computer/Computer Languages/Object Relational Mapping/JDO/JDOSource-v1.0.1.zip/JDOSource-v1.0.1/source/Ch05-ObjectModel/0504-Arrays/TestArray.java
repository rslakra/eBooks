package com.ogilviepartners.jdobook.app;

import javax.jdo.*;
import com.ogilviepartners.jdo.JDOBootstrap;
import com.ogilviepartners.jdobook.other.FiveHolder;
import java.util.Iterator;

public class TestArray
{
	public static void main(String[] args) {

		// check the arguments		
		if (args.length != 5) {
			System.out.println("usage: java TestArray <text1> <text2> <text3> <text4> <text5>");
			System.exit(1);
		}
		
		// instantiate the PersistenceManagerFactory		
		JDOBootstrap bootstrap = new JDOBootstrap();
		bootstrap.listJDOProperties();
	  	bootstrap.listVendorProperties();
		PersistenceManagerFactory pmf = bootstrap.getPersistenceManagerFactory();
				
		// obtain a PersistenceManager
		PersistenceManager pm = pmf.getPersistenceManager();
		
		// get a reference to the Transaction object		
		Transaction t = pm.currentTransaction();
		
		// create a (transient) FiveHolder		
		FiveHolder five = new FiveHolder(args[0], args[1], args[2], args[3], args[4]);

		// persist the FiveHolder		
		System.out.println("Persisting " + five);
		t.begin();
		pm.makePersistent(five);
		t.commit();
		
		// obtain Extent of FiveHolder and iterate contents		
		t.begin();
		Extent extFive = pm.getExtent(FiveHolder.class, false);
		Iterator i = extFive.iterator();
		System.out.println("Listing persistent FiveHolder instances:");
		while (i.hasNext()) {
			System.out.println(i.next());
		}
		System.out.println("Done.");
		extFive.close(i);
		t.commit();
		
		// close resources		
		pm.close();	
	}
}

