package com.ogilviepartners.jdobook.app;

import javax.jdo.*;
import com.ogilviepartners.jdo.JDOBootstrap;
import com.ogilviepartners.jdobook.op.Order;
import com.ogilviepartners.jdobook.op.SellableItem;
import com.ogilviepartners.jdobook.op.OrderLine;
import com.ogilviepartners.jdobook.op.Product;
import com.ogilviepartners.jdobook.op.ServiceContract;
import com.ogilviepartners.jdobook.op.Dimension;


import java.util.Iterator;

public class TestInterface
{
	public static void main(String[] args) {
	
		JDOBootstrap bootstrap; 
		PersistenceManagerFactory pmf;
		PersistenceManager pm;
		Order o;
		SellableItem si;
		Transaction t;
		Dimension d;
		Object oid;
		
		// initialize everything
		bootstrap = new JDOBootstrap();
		pmf = bootstrap.getPersistenceManagerFactory();
		pm = pmf.getPersistenceManager();
		t = pm.currentTransaction();
		
		// create a new (therefore transient) Order
		o = new Order(Integer.parseInt(args[0]));
		
		
		// persist the Order
		t.begin();
		pm.makePersistent(o);
		t.commit();
		
		// create new (transient) ServiceContract and Product objects
		// adding each one to the order.  Note use of the si reference
		// of type SellableItem (the interface).
		
		t.begin();
		
		d = new Dimension();
		d.width = 10;
		d.height = 15;
		d.depth = 2;
		
		si = new Product(32.99, "JDO Book", 660, d);
		o.getOrderLines().add(new OrderLine(si, 22));
		
		si = new ServiceContract(5.00, "Upgrade Service");
		o.getOrderLines().add(new OrderLine(si, 10));
		
		t.commit();  
		
		// obtain Extent of Order and iterate contents		
		t.begin();
		Extent extOrder = pm.getExtent(Order.class, true);
		Iterator i = extOrder.iterator();
		System.out.println("Listing orders:");
		while (i.hasNext()) {
			System.out.println(i.next());
		}
		System.out.println("Done.");
		extOrder.close(i);
		t.commit();
		
		// close resources		
		pm.close();	
	}
}
