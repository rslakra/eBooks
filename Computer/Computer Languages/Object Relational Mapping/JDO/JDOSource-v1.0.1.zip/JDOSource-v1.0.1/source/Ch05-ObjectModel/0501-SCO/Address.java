package com.ogilviepartners.jdobook.op;

public class Address
{
	private String address;
	
	public Address(String address) {
		this.address = address;
	}
	
	public String toString() {
		return address;
	}
}
