package com.ogilviepartners.jdobook.op.gui;

import javax.swing.table.DefaultTableModel;

public class ReadonlyTableModel extends DefaultTableModel {
	public ReadonlyTableModel(Object[][] a, Object[] b) {
		super(a, b);
	}
	
	public ReadonlyTableModel() {
		
	}
	
	
	
	public boolean isCellEditable(int row, int col) {
		return false;
	}
}
