package com.ogilviepartners.jdobook.op;

public class Customer {

	private BusinessPartner partner;

	public Customer(BusinessPartner partner) {
		this.partner = partner;
	}
}
