package com.ogilviepartners.jdobook.op.gui;

import java.awt.Container;
import javax.swing.*;
import javax.swing.event.*;
import javax.jdo.*;
import java.awt.event.*;
import java.awt.*;

public abstract class GenericViewer extends JFrame implements DocumentListener {
	protected PersistenceManager pm = SingletonPMF.getPMF().getPersistenceManager();
	protected Transaction t = pm.currentTransaction();
	protected Container cp;
	private boolean dataChanged;
	private Object pc;
	protected JPanel p;
	
	protected JToolBar tb;
	ActionImpl actSave;
  ActionImpl actRefresh;
	ActionImpl actCancel;
	ActionImpl actClose;
	ActionImpl actOk;
	
	public GenericViewer() {
	  setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
		this.setTitle("Generic Viewer");
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent we) {
				System.out.println("windowClosing: dataChanged=" + dataChanged);
				if (!dataChanged) closeAction();
			}		
		});
	  cp = getContentPane();
		p = new JPanel();	
		p.setLayout(new GridBagLayout());
		tb = new JToolBar();
		actSave = new ActionImpl("Save", "save");
		actRefresh = new ActionImpl("Refresh", "refresh");
		actCancel = new ActionImpl("Cancel", "cancel");
		actClose = new ActionImpl("Close", "close");
		actOk = new ActionImpl("OK", "ok");
		tb.add(actSave);
		tb.add(actRefresh);
		tb.add(actCancel);
		tb.add(actClose);
		tb.add(actOk);
		tb.addSeparator();
		
		// set GridBatConstraints defaults for toolbar
		
		cp.add(tb, BorderLayout.NORTH);
		cp.add(p,BorderLayout.CENTER);
	}
	
	public void setObjectParameters(Object objectId, boolean newOrCopy, Class persistenceCapableClass) {
		
		pc=null;
		t.begin();
		if (objectId != null) {
			// find it 
			pc = pm.getObjectById(objectId, true);
			
			if (newOrCopy) {
				// copy by making this one transient
				pm.makeTransient(pc);
			}
		}
		else if (newOrCopy) {
			// create a new one
			try {
				pc = persistenceCapableClass.newInstance();
			}
			catch (Exception e) {
				e.printStackTrace();
				System.exit(1);
			}
		}
		else {
			// objetId was null yet newOrCopy was false
			throw new RuntimeException("objetId was null yet newOrCopy was false");
		}
		
		setPersistenceCapable(pc, !JDOHelper.isPersistent(pc));

		
	  pack();
		
	
		dataChanged = newOrCopy;  // new or copy records are inherently dirty, opened items inherently clean
		buttonSensitivity();
		
		t.commit();
		
		
		setVisible(true);

		
}

  protected abstract void setPersistenceCapable(Object pc, boolean enablePKFields);
	protected abstract void collectChanges(boolean includePKFields);
	
	public void okAction() {
		t.begin();
		collectChanges(!JDOHelper.isPersistent(pc));
   	if (!JDOHelper.isPersistent(pc)) {
			// must have been a new or copy
			pm.makePersistent(pc);
		}
		t.commit();
		pm.close();
		setVisible(false);
		dispose();
	}	
	public void saveAction() {
	  t.begin();
		collectChanges(!JDOHelper.isPersistent(pc));
		if (!JDOHelper.isPersistent(pc)) {
			// must have been a new or copy
			pm.makePersistent(pc);
		}
		t.commit();
		setDataChanged(false);
	}
	
	public void closeAction() {
		pm.close();
		setVisible(false);
		dispose();
	}
	
	public void cancelAction() {
		pm.close();
		setVisible(false);
		dispose();
	}
	public void refreshAction() {
		pm.refresh(pc);
	  setPersistenceCapable(pc, !JDOHelper.isPersistent(pc));		
		setDataChanged(false);
	
	}
	
	protected void setDataChanged(boolean changed) {
		if (dataChanged !=changed) {
			dataChanged=changed;
			buttonSensitivity();				
		}
	}
	
	private void buttonSensitivity() {	
		actSave.setEnabled(dataChanged);
  	actRefresh.setEnabled(dataChanged);
	  actCancel.setEnabled(dataChanged);
		actClose.setEnabled(!dataChanged);
		actOk.setEnabled(dataChanged);	
	}
	
	public void changedUpdate(DocumentEvent de) {
		setDataChanged(true);
	}
	
	public void insertUpdate(DocumentEvent de) {
		setDataChanged(true);
	}
	
	public void removeUpdate(DocumentEvent de) {
		setDataChanged(true);
	}
	
	
	
	
	
	
	// inner classes
	
	class ActionImpl extends AbstractAction {
		private String action;
		public void actionPerformed(ActionEvent ae) {
			     if (action.equals("save")) saveAction();
			else if (action.equals("cancel")) cancelAction();
			else if (action.equals("close")) closeAction();
			else if (action.equals("refresh")) refreshAction();			
			else if (action.equals("ok")) okAction();			
			else throw new RuntimeException("Unknown action: " + action);
		}
		public ActionImpl(String label, String action) {
			super(label);
			this.action = action;
		}
	}
	
}

