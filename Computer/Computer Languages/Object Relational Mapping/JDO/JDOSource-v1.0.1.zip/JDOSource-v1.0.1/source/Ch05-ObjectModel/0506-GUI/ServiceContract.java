package com.ogilviepartners.jdobook.op;

/** class that represents a non-physical service contract - these are not products but they are sellable */
public class ServiceContract implements SellableItem {
  /** description of contract */
	protected String description;
	
	/** supposedly unique item id */
	protected String itemId;
	
	/** duration of contract */
	protected int duration;
	
	/** price each */
	protected double price;
	
	/** no-args constructor */
	public ServiceContract () {
	}
	
	/** constructor for specific item ID, description, price and duration */
	public ServiceContract(String itemId, String description, double price, int duration) {
		this.itemId = itemId;
		this.description = description;
		this.price = price;
		this.duration = duration;
	}
	
	/** property get method for description */
	public String getDescription() {
		return description;
	}
	
	/** property set method for description */
	public void setDescription(String description) {
		this.description = description;
	}
	
	/** propery get method for price */
	public double getPrice() {
		return price;
	}
	
	/** property set method for price */
	public void setPrice(double price) {
		this.price = price;
	}
	
	/** property get method for itemId */
	public String getItemId() {
		return itemId;
	}

	/** property set method for itemId */
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}
	
	/** property get method for duration */
	public int getDuration() {
		return duration;
	}
	
	/** property set method for duration */
	public void setDuration(int duration) {
		this.duration = duration;
	}
	
	/** returns the String form of the service contract */
	public String toString() {
		return "ServiceContract (itemId=" + itemId + " description=" + description + " price=" + price + " duration=" + duration + ")";
	}
}

