package com.ogilviepartners.jdobook.op;

public class Individual extends BusinessPartner {

	protected String gender;
	
	public Individual() {
	}
	
	public String getGender() {
		return gender;
	}
	
	public void setGender(String gender) {
		this.gender = gender;
	}

	public String toString() {
		return "Individual (number=" + partnerNumber + " name=" + name + " address=" + address + " gender=" + gender + ")";
	}

}

