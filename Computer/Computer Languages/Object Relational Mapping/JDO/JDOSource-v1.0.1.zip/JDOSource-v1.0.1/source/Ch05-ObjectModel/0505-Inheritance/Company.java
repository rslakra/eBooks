package com.ogilviepartners.jdobook.op;

public class Company extends BusinessPartner {

	protected String vatRegistration;
	protected String companyRegistration;

	public Company() {
	}
	
	public String getCompanyRegistration() {
		return companyRegistration;
	}
	
	public void setCompanyRegistration(String companyRegistration) {
		this.companyRegistration = companyRegistration;
	}

	public String getVatRegistration() {
		return vatRegistration;
	}
	
	public void setVatRegistration(String vatRegistration) {
		this.vatRegistration = vatRegistration;
	}
	
	public String toString() {
		return "Company (number=" + partnerNumber + " name=" + name + " address=" + address + " companyReg=" + companyRegistration + " vatReg=" + vatRegistration + ")";
	}
	
}

