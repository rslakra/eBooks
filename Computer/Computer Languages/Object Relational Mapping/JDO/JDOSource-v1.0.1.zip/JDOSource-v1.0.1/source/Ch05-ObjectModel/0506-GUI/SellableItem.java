package com.ogilviepartners.jdobook.op;

/** interface representing items that are sellable and can therefore be added to an order as part of an order line */
public interface SellableItem
{
  /** property get method for item ID */
	public String getItemId();	
	
	/** property get method for item price */
  public double getPrice();
	
	/** property set method for item price */
	public void setPrice(double price);
	
	/** property get method for description */
	public String getDescription();
	
	/** property set method for description */
	public void setDescription(String description);
}

