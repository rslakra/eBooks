package com.ogilviepartners.jdobook.app;

import javax.jdo.*;
import com.ogilviepartners.jdobook.op.*;
import com.ogilviepartners.jdobook.op.gui.*;
import java.util.Collection;
import java.util.Vector;
import java.util.Iterator;
import java.util.Map;
import java.util.HashMap;
import java.util.StringTokenizer;
import javax.swing.*;
import javax.swing.table.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

public class Explorer extends JFrame
{
	private static String[] arguments;
	//private static DynamicQuery dq;
	
	private Action actNew;
	private Action actOpen;
	private Action actDelete;
	private Action actCopy;
	private Action actExit;
	private Action actAbout;
	
	
	private boolean newPermitted = false;
	private boolean copyPermitted = false;
	private boolean openPermitted = false;
	private boolean deletePermitted = false;
	
	private Map viewerMap = new HashMap();
	
	
	private DefaultTableModel dtm;
	//private String[] entities = { "BusinessPartner", "Individual", "Company", "Charity", "Customer", "Order", "AbstractItem", "Product", "ServiceContract" };
	//private String[] classnames = { "op.BusinessPartner", "op.Individual", "op.Company", "op.Charity", "op.Customer", "op.Order", "op.AbstractItem", "op.Product", "op.ServiceContract" };
		
	private Entity[] entityArray = { 
	                                                           											
																																								 /* new    copy   open   delete query  var filter 										ordering */
		new Entity("Business Partner", "com.ogilviepartners.jdobook.op.BusinessPartner", 										false, true,  true,  true,  false, "", "",    										"" ), 
		new Entity("Individual",       "com.ogilviepartners.jdobook.op.Individual",      										true,  true,  true,  true,  false, "", "",    										"" ), 
		new Entity("Company",          "com.ogilviepartners.jdobook.op.Company",         										true,  true,  true,  true,  false, "", "",    										"" ), 
		new Entity("Charity",          "com.ogilviepartners.jdobook.op.Charity",         										true,  true,  true,  true,  false, "", "",    										"" ), 
		new Entity("Customer",         "com.ogilviepartners.jdobook.op.BusinessPartner", 										false, false, true,  false, true,  "", "customerFlag == true",    "" ), 
		new Entity("Order",            "com.ogilviepartners.jdobook.op.Order",           										false,  false, true,  true,  false, "", "",    										"" ), 
		new Entity("Sellable Item",    "com.ogilviepartners.jdobook.op.Product,com.ogilviepartners.jdobook.op.ServiceContract",   false, true,  true,  true, false, "", "",    										"" ), 
		new Entity("Product",          "com.ogilviepartners.jdobook.op.Product",         										true,  true,  true,  true,  false, "", "",    										"" ), 
		new Entity("Service Contract", "com.ogilviepartners.jdobook.op.ServiceContract", 										true,  true,  true,  true,  false, "", "",    										"" )
		};
	
	// Swing declarations
	
	JList lEntity;
	JSplitPane sp;
	Container cp;
	JTable table;
	
	JTextArea taResult;
	
	JScrollPane spEntity;

	Object[][] data = { {"Row1"}, {"Row2"}, {"Row3"} };
	Object[] columns = { "Description" };
	
	public static void main(String[] args) {
		
		// force PMF initialization to occur, although we don't want to use it yet
		SingletonPMF.getPMF();
				
		Explorer ex = new Explorer();		
		ex.setVisible(true);
	}
	

	
	public Explorer() {
	  super("Order Processing with Java Data Objects (JDO)");
	
		viewerMap.put("com.ogilviepartners.jdobook.op.Individual",      "com.ogilviepartners.jdobook.op.gui.IndividualViewer");
		viewerMap.put("com.ogilviepartners.jdobook.op.Company",         "com.ogilviepartners.jdobook.op.gui.CompanyViewer");
		viewerMap.put("com.ogilviepartners.jdobook.op.Charity",         "com.ogilviepartners.jdobook.op.gui.CharityViewer");
		viewerMap.put("com.ogilviepartners.jdobook.op.Product",         "com.ogilviepartners.jdobook.op.gui.ProductViewer");
		viewerMap.put("com.ogilviepartners.jdobook.op.ServiceContract", "com.ogilviepartners.jdobook.op.gui.ServiceContractViewer");
		viewerMap.put("com.ogilviepartners.jdobook.op.Order",           "com.ogilviepartners.jdobook.op.gui.OrderViewer");		
		
		cp = getContentPane();
		lEntity = new JList(entityArray);
		spEntity = new JScrollPane(lEntity);
		
		dtm = new ReadonlyTableModel();
		table = new JTable(dtm);
		JScrollPane spTable = new JScrollPane(table);
		
		JToolBar toolbar = new JToolBar();
		
		JPanel p2 = new JPanel();
		p2.setLayout(new BorderLayout());
		
		actNew = new ActionImpl("New", "new");
		actOpen = new ActionImpl("Open", "open");
		actCopy = new ActionImpl("Copy", "copy");
		actDelete = new ActionImpl("Delete", "delete");
		actExit = new ActionImpl("Exit", "exit");
		actAbout = new ActionImpl("About", "about");
		
		// start off disabled
		actNew.setEnabled(false);
		actOpen.setEnabled(false);
		actCopy.setEnabled(false);
		actDelete.setEnabled(false);
		
		
		JMenuBar mb = new JMenuBar();
		JMenu mFile = new JMenu("File");
		mFile.add(actNew);
		mFile.add(actCopy);
		mFile.add(actOpen);
		mFile.addSeparator();
		mFile.add(actDelete);
		mFile.addSeparator();
		mFile.add(actExit);
		mb.add(mFile);
	
		JMenu mHelp = new JMenu("Help");
		mHelp.add(actAbout);
		mb.add(mHelp);
		setJMenuBar(mb);
		
		toolbar.add(actNew);
		toolbar.add(actCopy);
		toolbar.add(actOpen);
		toolbar.add(actDelete);
		
		JPanel p3 = new JPanel();
		p3.setLayout(new FlowLayout(FlowLayout.CENTER));
		p3.add(toolbar);
		cp.add(spEntity, BorderLayout.WEST);
		p2.add(spTable, BorderLayout.CENTER);
    p2.add(p3, BorderLayout.SOUTH);
		
		JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, false, spEntity, p2);
		cp.add(split, BorderLayout.CENTER);
		
		table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent lse) {
				if (!lse.getValueIsAdjusting()) {
					System.out.println("setting buttons");
					enableDisableButtons();
				}
			}
		});
		
		pack();

		lEntity.addListSelectionListener(new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent lse) {
				if (!lse.getValueIsAdjusting()) 
					System.out.println("list selection event" + lEntity.getSelectedIndex() + " " + lEntity.getSelectedValue());
					loadData(lEntity.getSelectedIndex());
			}
		});

		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent we) {
				exitAction();
			}
		});
		
	}

  public void enableDisableButtons() {
		actNew.setEnabled(newPermitted);
		actCopy.setEnabled(copyPermitted && table.getSelectedRow() != -1);
		actOpen.setEnabled(openPermitted && table.getSelectedRow() != -1);
		actDelete.setEnabled(deletePermitted && table.getSelectedRow() != -1);	
	}

	public void loadData(int index) {
		// load data via extent.  future enhancement facilitates queryies also

		Query q = null;
		Extent ext = null;
		Iterator i = null;
		PersistenceManager pm = SingletonPMF.getPMF().getPersistenceManager();
		Transaction t = pm.currentTransaction();

		try {
			newPermitted = entityArray[index].newPermitted;
			copyPermitted = entityArray[index].copyPermitted;
			openPermitted = entityArray[index].openPermitted;
			deletePermitted = entityArray[index].deletePermitted;
		  enableDisableButtons();
			
			t.begin();
			
			if (entityArray[index].candidateClassname.indexOf(',') >= 1) {
				// special case
				// merge muyltiple extents
				Collection c = new Vector();
				StringTokenizer st = new StringTokenizer(entityArray[index].candidateClassname,",");
				while (st.hasMoreTokens()) {
					Class cls = Class.forName(st.nextToken());
					ext = pm.getExtent(cls, true);
					Iterator ei = ext.iterator();
					while (ei.hasNext()) c.add(ei.next());
					ext.close(ei);
				}
System.out.println("Getting iterator from collection");
				i = c.iterator();
			}
			else {
					
				Class cls = entityArray[index].candidateClass;
				ext = pm.getExtent(cls, true);				

				Entity entity = entityArray[index];
				
				if (entityArray[index].useQuery) {
					q = pm.newQuery(ext, entity.queryFilter);
					q.declareVariables(entity.queryVariables);
					q.setOrdering(entity.queryOrdering);
					Collection c = (Collection) q.execute();
					i = c.iterator();
				}
				else {
System.out.println("Getting iterator from extent, class=" + ext.getCandidateClass() + " subclasses=" +ext.hasSubclasses());				
					i = ext.iterator();
				}
			}		
			
			Vector data = new Vector();
System.out.println("about to assemble 2-d vector");			
			while(i.hasNext()) {
				Vector row = new Vector();
				Object pc = i.next();
				row.add(new DescribedObjectId(JDOHelper.getObjectId(pc), pc.toString(), pc.getClass().getName(), pc.getClass()));
				data.add(row);
			}

			if (q != null) q.closeAll();
			if (ext != null) ext.closeAll();
		
			Vector cols = new Vector();
			cols.add(entityArray[index].description);
			dtm.setDataVector(data, cols);
			dtm.fireTableDataChanged();
		
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {			
			t.commit();
			pm.close();
		}
	}
	
	public void newAction() {
	
		//String viewerClassname = entityArray[lEntity.getSelectedIndex()].viewerClassname;
		boolean newOrCopy = true;
		Object objectId = null;
		String candidateClassname = entityArray[lEntity.getSelectedIndex()].candidateClassname;
		Class candidateClass = null;
		GenericViewer gv = null;
		try {
			gv = (GenericViewer) Class.forName((String) viewerMap.get(candidateClassname)).newInstance();
			candidateClass = Class.forName(candidateClassname);
		}
		catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		}
		
		gv.setObjectParameters(objectId, newOrCopy, candidateClass);
	}

	public void copyAction() {
		boolean newOrCopy = true;
		DescribedObjectId doi = (DescribedObjectId) ((Vector) dtm.getDataVector().elementAt(table.getSelectedRow())).elementAt(0);
		Object objectId = doi.objectId;
		String candidateClassname = entityArray[lEntity.getSelectedIndex()].candidateClassname;
		Class candidateClass = null;
		GenericViewer gv = null;
		try {
			gv = (GenericViewer) Class.forName((String) viewerMap.get(candidateClassname)).newInstance();
			candidateClass = Class.forName(candidateClassname);
		}
		catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		}
		
		gv.setObjectParameters(objectId, newOrCopy, candidateClass);
	}
	
	public void deleteAction() {
		PersistenceManager pm = SingletonPMF.getPMF().getPersistenceManager();
		Transaction t = pm.currentTransaction();
	
		DescribedObjectId doi = (DescribedObjectId) ((Vector) dtm.getDataVector().elementAt(table.getSelectedRow())).elementAt(0);
		Object objectId = doi.objectId;

		Object pc = pm.getObjectById(objectId, true);
		int result = JOptionPane.showConfirmDialog(this, "Do you really wish to delete the following?\n\n" + pc + "\n", "Confirm Delete", JOptionPane.OK_CANCEL_OPTION);
		if (result==JOptionPane.OK_OPTION) {
			t.begin();
			pm.deletePersistent(pc);
			t.commit();
		}
	}
	
	public void exitAction() {
		setVisible(false);
		dispose();
		System.exit(0);
	}
	
	public void aboutAction() {
		JOptionPane.showMessageDialog(
			this, 
			"Java Data Objects (JDO) Training Course\nCopyright (c) Ogilvie Partners Ltd", 
			"Help About",
			JOptionPane.PLAIN_MESSAGE);
	}
	
	public void openAction() {

		DescribedObjectId doi = (DescribedObjectId) ((Vector) dtm.getDataVector().elementAt(table.getSelectedRow())).elementAt(0);
		//String viewerClassname = entityArray[lEntity.getSelectedIndex()].viewerClassname;
		boolean newOrCopy = false;
		Object objectId = doi.objectId;
		Class candidateClass = doi.candidateClass; 
		
		System.out.println("openAction: class=" + doi.candidateClassname + " viewer=" + viewerMap.get(doi.candidateClassname));
		GenericViewer gv = null;
		try {
			gv = (GenericViewer) Class.forName((String) viewerMap.get(doi.candidateClassname)).newInstance();
		}
		catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		}
		
		gv.setObjectParameters(objectId, newOrCopy, candidateClass);

		
	}

	// inner classes
	
	class DescribedObjectId {
		public Object objectId;
		public String description;
		public Class candidateClass;
		public String candidateClassname;
		
		public DescribedObjectId(Object objectId, String description, String candidateClassname, Class candidateClass) {
			this.objectId = objectId;
			this.description = description;
			this.candidateClassname = candidateClassname;
			this.candidateClass = candidateClass;
		}
		
		public String toString() {
			return description;
		}
	}
		
	class ActionImpl extends AbstractAction {
		private String action;
		public void actionPerformed(ActionEvent ae) {
			     if (action.equals("new")) newAction();
			else if (action.equals("open")) openAction();
			else if (action.equals("delete")) deleteAction();
			else if (action.equals("copy")) copyAction();			
			else if (action.equals("exit")) exitAction();			
			else if (action.equals("about")) aboutAction();
			else throw new RuntimeException("Unknown action: " + action);
		}
		public ActionImpl(String label, String action) {
			super(label);
			this.action = action;
		}
	}
	
	class Entity {
	    public String description;
			public String candidateClassname;
			public boolean newPermitted;
			public boolean copyPermitted;
			public boolean deletePermitted;
			public boolean openPermitted;
			public boolean useQuery;
			public String queryVariables;
			public String queryFilter;
			public String queryOrdering;
			
			public Class candidateClass;
			
			public Entity(String description, String candidateClassname, boolean newPermitted, boolean copyPermitted, boolean openPermitted, boolean deletePermitted, boolean useQuery, String queryVariables, String queryFilter, String queryOrdering) {
			  this.description = description;
			  this.candidateClassname = candidateClassname;
			  this.newPermitted = newPermitted;
			  this.copyPermitted = copyPermitted;
			  this.deletePermitted = deletePermitted;
			  this.openPermitted = openPermitted;			
				this.useQuery = useQuery;
				this.queryVariables = queryVariables;
				this.queryFilter = queryFilter;
				this.queryOrdering = queryOrdering;
			
				if (this.candidateClassname.indexOf(',') == -1) try {
					this.candidateClass = Class.forName(this.candidateClassname);
				}
				catch(Exception e) {
					e.printStackTrace();
					System.exit(1);
				}
			}
			
			public String toString() {
				return description;
			}
	}

}


