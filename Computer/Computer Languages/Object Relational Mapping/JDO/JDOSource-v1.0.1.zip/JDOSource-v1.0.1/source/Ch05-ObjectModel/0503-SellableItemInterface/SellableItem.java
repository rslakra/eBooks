package com.ogilviepartners.jdobook.op;

public interface SellableItem {
    String getDescription();

    double getPrice();
}
