package com.ogilviepartners.jdobook.op.gui;

import javax.jdo.*;
import com.ogilviepartners.jdo.JDOBootstrap;

public class SingletonPMF {

	private static PersistenceManagerFactory pmf;
	
	public static PersistenceManagerFactory getPMF() {
		if (pmf == null) {

			// instantiate the PersistenceManagerFactory
		
			JDOBootstrap bootstrap = new JDOBootstrap();
			bootstrap.listJDOProperties();
	  	bootstrap.listVendorProperties();
			pmf = bootstrap.getPersistenceManagerFactory();
		}
		
		return pmf;
	}
}
