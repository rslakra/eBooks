package com.ogilviepartners.jdobook.op;

/** class representing corporate business partners */
public class Company extends BusinessPartner {

  /** VAT registration number */
	protected String vatRegistration;
	
	/** company registration number */
	protected String companyRegistration;
	
	/** property get method for company registration */
	public String getCompanyRegistration() {
		return companyRegistration;
	}
	
	/** property set method for company registration */
	public void setCompanyRegistration(String companyRegistration) {
		this.companyRegistration = companyRegistration;
	}

  /** property get method for VAT registration */
	public String getVatRegistration() {
		return vatRegistration;
	}
	
	/** property set method for VAT registration */
	public void setVatRegistration(String vatRegistration) {
		this.vatRegistration = vatRegistration;
	}
	
	/** returns String form of the Company */
	public String toString() {
		return "Company (number=" + partnerNumber + " name=" + name + " address=" + address + " companyReg=" + companyRegistration + " vatReg=" + vatRegistration + ")";
	}
	
}

