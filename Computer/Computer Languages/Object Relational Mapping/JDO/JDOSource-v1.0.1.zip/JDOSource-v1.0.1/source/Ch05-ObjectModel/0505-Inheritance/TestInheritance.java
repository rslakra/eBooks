package com.ogilviepartners.jdobook.app;

import javax.jdo.*;
import com.ogilviepartners.jdo.JDOBootstrap;
import com.ogilviepartners.jdobook.op.BusinessPartner;
import com.ogilviepartners.jdobook.op.Individual;
import com.ogilviepartners.jdobook.op.Charity;
import com.ogilviepartners.jdobook.op.Company;
import java.util.Iterator;

public class TestInheritance
{
	public static void main(String[] args) {

	
		// instantiate the PersistenceManagerFactory		
		JDOBootstrap bootstrap = new JDOBootstrap();
		bootstrap.listJDOProperties();
	  	bootstrap.listVendorProperties();
		PersistenceManagerFactory pmf = bootstrap.getPersistenceManagerFactory();
				
		// obtain a PersistenceManager
		PersistenceManager pm = pmf.getPersistenceManager();
		
		// get a reference to the Transaction object		
		Transaction t = pm.currentTransaction();
		
		// create some concrete BusinessPartners
		Individual indv = new Individual();
		indv.setPartnerNumber("1");
		indv.setName("Robin Roos");
		indv.setAddress("Milton Keynes");
		indv.setGender("Male");		
		
		Company comp = new Company();
		comp.setPartnerNumber("2");
		comp.setName("Ogilvie Partners");
		comp.setAddress("London");
		comp.setCompanyRegistration("COMP4377");
		
		Charity chty = new Charity();
		chty.setPartnerNumber("3");
		chty.setName("Ogilvie Partners");
		chty.setAddress("London");
		chty.setCompanyRegistration("UK12345");
		chty.setCharityRegistration("CH98765");
		
		// persist the BusinessPartner		
		t.begin();
		System.out.println("Persisting " + indv);
		pm.makePersistent(indv);
		System.out.println("Persisting " + comp);
		pm.makePersistent(comp);
		System.out.println("Persisting " + chty);
		pm.makePersistent(chty);
		t.commit();
		
		// obtain Extent of BusinessPartner and iterate contents		
		t.begin();
		Extent extPartner = pm.getExtent(BusinessPartner.class, true);
		Iterator i = extPartner.iterator();
		System.out.println("Listing partners:");
		while (i.hasNext()) {
			System.out.println(i.next());
		}
		System.out.println("Done.");
		extPartner.close(i);
		t.commit();
		
		// close resources		
		pm.close();	
	}
}

