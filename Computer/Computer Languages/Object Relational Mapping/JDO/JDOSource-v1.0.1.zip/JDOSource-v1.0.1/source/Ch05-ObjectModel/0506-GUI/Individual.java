package com.ogilviepartners.jdobook.op;

/** class representing an individual person that is a business partner in their own right */
public class Individual extends BusinessPartner {

  /** gender information */
	protected String gender;
	
	/** property get method for gender */
	public String getGender() {
		return gender;
	}
	
	/** property set method for gender */
	public void setGender(String gender) {
		this.gender = gender;
	}

  /** returns the String form of the individual */
	public String toString() {
		return "Individual (number=" + partnerNumber + " name=" + name + " address=" + address + " gender=" + gender + ")";
	}
}

