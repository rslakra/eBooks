package com.ogilviepartners.jdobook.op;

import java.util.Date;

public class ServiceContract implements SellableItem {
	
	public ServiceContract() {
	}
	
	public ServiceContract(double price, String description) {
		this.price = price;
		this.description = description;
	}
	
    public double getPrice(){
            return price;
        }

    public void setPrice(double price){
            this.price = price;
        }

    public String getDescription(){
            return description;
        }

    public void setDescription(String description){
            this.description = description;
        }

    public Date getEndDate(){
            return endDate;
        }

    public void setEndDate(Date endDate){
            this.endDate = endDate;
        }

    public Date getStartDate(){
            return startDate;
        }

    public void setStartDate(Date startDate){
            this.startDate = startDate;
        }

    private double price;
    private String description;
    private Date endDate;
    private Date startDate;
}
