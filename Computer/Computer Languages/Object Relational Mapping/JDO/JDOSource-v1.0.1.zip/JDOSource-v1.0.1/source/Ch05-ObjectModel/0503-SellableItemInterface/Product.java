package com.ogilviepartners.jdobook.op;

public class Product implements SellableItem {
	
	public Product() {
	}
	
	public Product(double price, String description, int weight, Dimension dimensions) {
		this.price = price;
		this.description = description;
		this.weight = weight;
		this.dimensions = dimensions;
	}
	
    public double getPrice(){
            return price;
        }

    public void setPrice(double price){
            this.price = price;
        }

    public String getDescription(){
            return description;
        }

    public void setDescription(String description){
            this.description = description;
        }

    public double getWeight(){
            return weight;
        }

    public void setWeight(double weight){
            this.weight = weight;
        }

    public Dimension getDimensions(){
            return dimensions;
        }

    public void setDimensions(Dimension dimensions){
            this.dimensions = dimensions;
        }

    private double price;
    private String description;
    private double weight;
    private Dimension dimensions;
}
