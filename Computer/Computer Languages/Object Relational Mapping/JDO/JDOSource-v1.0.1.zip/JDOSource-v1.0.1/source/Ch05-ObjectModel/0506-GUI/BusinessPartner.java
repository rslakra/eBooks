package com.ogilviepartners.jdobook.op;

import javax.jdo.InstanceCallbacks;

/** Abstract superclass for hierarchy of business partners */
public abstract class BusinessPartner implements InstanceCallbacks {

  /** name of the partner */
	protected String name;
	
	/** Uniquely identifying String for each partner */
	protected String partnerNumber;
	
	/** Complete address of partner */
	protected String address;
	
	/** is this partner a customer? */
	protected boolean customerFlag;
	
	/** reference to a Customer object, null if this partner is not a Customer 
	 * @label customer*/
	protected Customer customer;
	
	/** returns String representation of a partner */
	public String toString() {
		return "BusinessPartner (number=" + partnerNumber + " name=" + name + " address=" + address + " isCustomer=" + isCustomer() + ")";
	}
	
	/** returns true if this partner has a corresponding Customer object and is therefore a Customer */
	public boolean isCustomer() {
		return (customer != null);
	}
	
	/* property set method for name */
	public void setName(String name) {
		this.name = name;
	}
	
	/* property get method for name */
	public String getName() {
		return name;
	}

  /** property set method for address */
	public void setAddress(String address) {
		this.address = address;
	}
	
	/** property get method for address */
	public String getAddress() {
		return address;
	}

  /** property set method for identifying partner number */
	public void setPartnerNumber(String partnerNumber) {
		this.partnerNumber = partnerNumber;
	}
	
	/** property get method for identifying partner number */
	public String getPartnerNumber() {
		return partnerNumber;
	}
	
	/** returns the corresponding Customer object, and makes one if it does not already exist */
	public Customer getCustomer() {
		if (customer == null) { 
			customer = new Customer(this);
			customerFlag = true;
		}
		return customer;
	}
	
	/** JDO instance callback method */
	public void jdoPostLoad() {
		System.out.println("   jdoPostLoad() called for BusinessPartner " + partnerNumber);
	}
	
	/** JDO instance callback method */
		public void jdoPreStore() {
		System.out.println("   jdoPreStore() called for BusinessPartner " + partnerNumber);
	}
	
	/** JDO instance callback method */
	public void jdoPreClear() {
		System.out.println("   jdoPreClear() called for BusinessPartner " + partnerNumber);
	}
	
	/** JDO instance callback method */
	public void jdoPreDelete() {
		System.out.println("   jdoPreDelete() called for BusinessPartner " + partnerNumber);
	}

}
