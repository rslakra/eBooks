package com.ogilviepartners.jdobook.op;

/** class representing a charitable organization in the business partner hierarchy */
public class Charity extends Company
{
  /** charity registration number */
	protected String charityRegistration;
	
	/** property get method for charity registration */
	public String getCharityRegistration() {
		return charityRegistration;
	}
	
	/** property set method for charity registration */
	public void setCharityRegistration(String charityRegistration) {
		this.charityRegistration = charityRegistration;
	}
	
	/** returns String form of the charity */
	public String toString() {
		return "Charity (number=" + partnerNumber + " name=" + name + " address=" + address + " companyReg=" + companyRegistration + " vatReg=" + vatRegistration + " charityReg=" + charityRegistration + ")";
	}
}

