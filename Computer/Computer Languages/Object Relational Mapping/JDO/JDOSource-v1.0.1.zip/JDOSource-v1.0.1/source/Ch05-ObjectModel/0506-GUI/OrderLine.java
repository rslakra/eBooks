package com.ogilviepartners.jdobook.op;

/** class that represents an individual line of an order */
public class OrderLine {

	/** quantity ordered */
	private int quantity;
	
	 /**
     * @label item 
     */
	private SellableItem item;
	
	/** no-args constructor */
	public OrderLine() {
	}
	
	/** constructor for a specific item and quantity */
	public OrderLine(SellableItem item, int quantity) {
		this.item = item;
		this.quantity = quantity;
	}
	
	/** property set method for quantity */
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	/** property get method for quantity */
	public int getQuantity() {
		return quantity;
	}
	
	/** retrurn the description of the item associated with this order line */
	public String getDescription() {
		return item.getDescription();
	}
	
	/** return the String form of the order line */
	public String toString() {
		return "OrderLine (quantity=" + quantity + ")";
	}
}
