package com.ogilviepartners.jdobook.op;

public class OrderLine {
    /**
     * @directed
     * @label item 
     */
    private SellableItem item;
	private int quantity;

	public OrderLine() {
	}
	
	public OrderLine(SellableItem item, int quantity) {
		this.item = item;
		this.quantity = quantity;
	}
	
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	public int getQuantity() {
		return quantity;
	}
	
	public String getDescription() {
		return item.getDescription();
	}
	
	public String toString() {
		return "OrderLine (description=" + getDescription() + " quantity=" + quantity + ")";
	}
}
