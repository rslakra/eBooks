package com.ogilviepartners.jdobook.op;

public class Dimension
{
	public int height;
	public int width;
	public int depth;
}
