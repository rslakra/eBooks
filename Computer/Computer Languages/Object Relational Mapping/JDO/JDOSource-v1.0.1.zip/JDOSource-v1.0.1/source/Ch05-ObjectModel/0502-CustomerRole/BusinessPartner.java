package com.ogilviepartners.jdobook.op;

public class BusinessPartner {

	protected String name;
	protected String partnerNumber;
	protected String address;
	protected boolean customerFlag;

    /**
     * @label customer 
     * @supplierCardinality 0..1
     */
	protected Customer customer;
    	
	public String toString() {
		return "BusinessPartner (number=" + partnerNumber + " name=" + name + " address=" + address + " customerFlag=" + getCustomerFlag() + ")";
	}

	public boolean getCustomerFlag() {
		return customerFlag;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	public String getAddress() {
		return address;
	}

	public void setPartnerNumber(String partnerNumber) {
		this.partnerNumber = partnerNumber;
	}
	
	public String getPartnerNumber() {
		return partnerNumber;
	}
	
	public Customer getCustomer() {
		return customer;
	}
	
	public void makeCustomer() {
		if (customer == null) customer = new Customer(this);
		if (!customerFlag) customerFlag = true;
	}
}
