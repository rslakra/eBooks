package com.ogilviepartners.jdobook.op;

public class Customer
{
    /**
     * @label businessPartner 
     * @supplierCardinality 1
     */
	private BusinessPartner businessPartner;
	private double creditLimit;

	protected Customer() {
	}
	
	protected Customer(BusinessPartner businessPartner) {
		this.businessPartner = businessPartner;
	}
	
	public BusinessPartner getBusinessPartner() {
		return businessPartner;
	}
	
	public double getCreditLimit() {
		return creditLimit;
	}
	
	public void setCreditLimit(double creditLimit) {
		this.creditLimit = creditLimit;
	}
	
	public String toString() {
		return "Customer (partnerId=" + businessPartner.getPartnerNumber() + " partnerName=" + businessPartner.getName() + ")"; 
  }
}

