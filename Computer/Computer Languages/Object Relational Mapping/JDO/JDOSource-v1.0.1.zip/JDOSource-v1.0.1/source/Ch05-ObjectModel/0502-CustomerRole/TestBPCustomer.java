package com.ogilviepartners.jdobook.app;

import javax.jdo.*;
import com.ogilviepartners.jdo.JDOBootstrap;
import com.ogilviepartners.jdobook.op.BusinessPartner;
import com.ogilviepartners.jdobook.op.Customer;
import java.util.Iterator;

public class TestBPCustomer
{
	public static void main(String[] args) {
	
		JDOBootstrap bootstrap; 
		PersistenceManagerFactory pmf;
		PersistenceManager pm;
		BusinessPartner bp;
		Transaction t;
		Object oid;
		
		// initialize everything
		bootstrap = new JDOBootstrap();
		pmf = bootstrap.getPersistenceManagerFactory();
		pm = pmf.getPersistenceManager();
		t = pm.currentTransaction();
		
		// create a new (therefore transient) BusinessPartner
		bp = new BusinessPartner();
		bp.setName("Ogilvie Partners");
		
		// persist the BusinessPartner and get its Object ID
		t.begin();
		pm.makePersistent(bp);
		oid = pm.getObjectId(bp);
		System.out.println("Is bp a Customer?" + bp.getCustomerFlag());
		t.commit();
		
		// make the BusinessPartner a Customer
		t.begin();
		bp.makeCustomer();
		t.commit();  // no need to �save� bp � that�s part of transparent persistence
		
		bp = null;
		
		// retrieve the BusinessPartner by Object ID and see that it is a Customer
		t.begin();
		bp = (BusinessPartner) pm.getObjectById(oid, true);
		System.out.println("Is bp a Customer?" + bp.getCustomerFlag());
		t.commit();
	}
}
