package com.ogilviepartners.jdobook.op;

/** class that represents a physical product */
public class Product implements SellableItem {
	/** description of product */
	protected String description;
	
	/** supposedly unique item id */
	protected String itemId;
	
	/** colour */
	protected String colour;
	
	/** price each */ 
	protected double price;
	
	/** no-args constructor */
	public Product() {
	}
	
	/** constructor for specific item ID, description, price and colour */
	public Product(String itemId, String description, double price, String colour) {
		this.itemId = itemId;
		this.description = description;
		this.price = price;
		this.colour = colour;
	}
	
	/** property get method for description */
	public String getDescription() {
		return description;
	}
	
	/** property set method for description */
	public void setDescription(String description) {
		this.description = description;
	}
	
	/** property get method for price */
	public double getPrice() {
		return price;
	}
	
	/** property set method for price */
	public void setPrice(double price) {
		this.price = price;
	}
	
	/** property get method for colour */
	public String getColour() {
		return colour;
	}
	
	/** property get method for itemId */
	public String getItemId() {
		return itemId;
	}
	
	/** property set method for itemId */
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}
	
	/** property set method for colour */
	public void setColour(String colour) {
		this.colour = colour;
	}
	
	/** return the String form of the product */
	public String toString() {
		return "Product (itemId=" + itemId + " description=" + description + " price=" + price + " colour=" + colour + ")";
	}
}

