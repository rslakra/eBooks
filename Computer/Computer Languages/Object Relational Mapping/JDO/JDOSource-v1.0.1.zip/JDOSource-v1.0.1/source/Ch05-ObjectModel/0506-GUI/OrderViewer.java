package com.ogilviepartners.jdobook.op.gui;
       
import com.ogilviepartners.jdobook.op.*;
import com.ogilviepartners.jdo.*;

import javax.jdo.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.table.*;
import java.util.Vector;
import java.util.Iterator;

public class OrderViewer extends GenericViewer {
  private Order pc;
	
	private boolean enablePKFields;
	private JTextField tfNumber, tfName, tfCustomer;
	private JLabel lNumber, lDispatched, lCustomer;
	private Action actDispatch, actRecall, actNewLine;
	private JCheckBox tbDispatched;
	private JScrollPane sp;
	private JTable table;
	private DefaultTableModel dtm;
	
	public OrderViewer() {
		// swing initialization

		GridBagConstraints gbc = new GridBagConstraints();
		
		lNumber = new JLabel("Order Number:");
		tfNumber = new JTextField();
		tfNumber.getDocument().addDocumentListener(this);
		lDispatched = new JLabel("Dispatched:");
		tbDispatched = new JCheckBox();
		lCustomer = new JLabel("Customer:");
		tfCustomer = new JTextField();
		
		
		dtm = new DefaultTableModel();
		table = new JTable(dtm);
		sp = new JScrollPane(table);
		//tbDispatched.getDocument().addDocumentListener(this);
		
		actDispatch = new ActionImpl("Dispatch", "dispatch");
		actRecall = new ActionImpl("Recall", "recall");
		actNewLine = new ActionImpl("Add Line", "newline");
		tb.add(actDispatch);
		tb.add(actRecall);
		tb.add(actNewLine);
		
		// set GridBatConstraints defaults for labels
		
		gbc.anchor=GridBagConstraints.EAST;
		gbc.fill=GridBagConstraints.NONE;
		gbc.weightx=0;
		gbc.weighty=0;
		gbc.gridheight=1;
		gbc.gridwidth=1;
		gbc.insets=new Insets(2,2,2,2);
		gbc.ipadx=0;
		gbc.ipady=0;
		
		gbc.gridx=0;		gbc.gridy=0;		p.add(lNumber, gbc);
		gbc.gridx=0;		gbc.gridy=1;		p.add(lDispatched, gbc);
		gbc.gridx=0;		gbc.gridy=2;		p.add(lCustomer, gbc);
		
		// set GridBatConstraints defaults for textfields
		
		gbc.anchor=GridBagConstraints.WEST;
		gbc.fill=GridBagConstraints.BOTH;
		gbc.weightx=1;
		
		gbc.gridx=1;		gbc.gridy=0;		p.add(tfNumber, gbc);
		gbc.gridx=1;		gbc.gridy=1;		p.add(tbDispatched, gbc);
		gbc.gridx=1;		gbc.gridy=2;		p.add(tfCustomer, gbc);

		// set GridBagConstraints defaults for table
		gbc.anchor=GridBagConstraints.EAST;
		gbc.fill=GridBagConstraints.NONE;
		gbc.weightx=1;
		gbc.weighty=1;
		gbc.gridheight=1;
		gbc.gridwidth=2;
		gbc.insets=new Insets(2,2,2,2);
		gbc.ipadx=0;
		gbc.ipady=0;		
		
		gbc.gridx=0;		gbc.gridy=3;		p.add(sp, gbc);
		

	}
	
	protected void setPersistenceCapable(Object newPc, boolean enablePKFields) {
		pc = (Order) newPc;
		this.enablePKFields = enablePKFields;
		display();
	}
	
	public void display() {
		tfNumber.setText("" + pc.getOrderNumber());
		tbDispatched.getModel().setSelected(pc.isDispatched());
		tfCustomer.setText(pc.getCustomer().getBusinessPartner().getName());
		
		Vector cols = new Vector();
		cols.add("Order Line");
		Vector data = new Vector();
		Iterator i = pc.getOrderLines().iterator();
		while (i.hasNext()) {
			Vector row = new Vector();
			row.add(i.next());
			data.add(row);					
		}
		dtm.setDataVector(data, cols);
		
		fieldSensitivity();
	}
	
	protected void fieldSensitivity() {
		tfNumber.setEnabled(enablePKFields);
		tbDispatched.setEnabled(false);
		tfCustomer.setEnabled(false);
		actDispatch.setEnabled(!pc.isDispatched());
		actRecall.setEnabled(pc.isDispatched());
		actNewLine.setEnabled(!pc.isDispatched());
		
	}
	
	protected void collectChanges(boolean includePKFields) {
		// orders must be created through the Customer role.  There are no
		// other fields so there is nothing to do.
		
	}
	
	public void dispatchAction() {
		pm.currentTransaction().begin();
		pc.dispatch();
		pm.currentTransaction().commit();
		//setDataChanged(true);
		display();
		fieldSensitivity();		
	}
	
	public void recallAction() {		
		pm.currentTransaction().begin();
		pc.recall();
		pm.currentTransaction().commit();
		//setDataChanged(true);
		display();
		fieldSensitivity();		
	}
	
	public void newlineAction() {
		// build an array of products and service contracts
		Vector items = new Vector();

		Extent extItem;
		Iterator i;
		extItem = pm.getExtent(Product.class, true);
		i = extItem.iterator();
		while (i.hasNext()) {
			items.add(i.next());
		}
		
		extItem = pm.getExtent(ServiceContract.class, true);
		i = extItem.iterator();
		while (i.hasNext()) {
			items.add(i.next());
		}
		Object[] o = items.toArray();
		
		SellableItem chosenProduct = (SellableItem) JOptionPane.showInputDialog(this, "Please choose a product", "New order line", JOptionPane.QUESTION_MESSAGE, null, o, null);
		String strQuantity = (String) JOptionPane.showInputDialog(this, "Please enter a quantity", "New order line", JOptionPane.QUESTION_MESSAGE, null, null, "1");
		int quantity= 0;
		try {
			quantity = Integer.parseInt(strQuantity);
		}
		catch (NumberFormatException nfe) {
			nfe.printStackTrace();
		}
		if (quantity != 0) {
			pm.currentTransaction().begin();
			pc.getOrderLines().add(new OrderLine(chosenProduct, quantity));
		    pm.currentTransaction().commit();
			//setDataChanged(true);
		    display();
		    System.out.println("product=" + chosenProduct + "\nquantity=" + strQuantity);
			
		}

	
	}
	
		// inner classes
	
	class ActionImpl extends AbstractAction {
		private String action;
		public void actionPerformed(ActionEvent ae) {
			     if (action.equals("dispatch")) dispatchAction();
			else if (action.equals("recall")) recallAction();
			else if (action.equals("newline")) newlineAction();
			else throw new RuntimeException("Unknown action: " + action);
		}
		public ActionImpl(String label, String action) {
			super(label);
			this.action = action;
		}
	}
	
}
