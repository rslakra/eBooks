package com.ogilviepartners.jdobook.op.gui;

import com.ogilviepartners.jdobook.op.*;
import com.ogilviepartners.jdo.*;

import javax.jdo.*;
import javax.swing.*;
import java.awt.*;

public class ServiceContractViewer extends GenericViewer {
  private ServiceContract pc;
	
	private boolean enablePKFields;
	private JTextField tfItemId, tfDescription, tfPrice, tfDuration;
	private JLabel lItemId, lDescription, lPrice, lDuration;
	
	public ServiceContractViewer() {
		// swing initialization

		GridBagConstraints gbc = new GridBagConstraints();
		
		
		lItemId = new JLabel("Item ID:");
		tfItemId = new JTextField();
		tfItemId.getDocument().addDocumentListener(this);
		lDescription = new JLabel("Description:");
		tfDescription = new JTextField();
		tfDescription.getDocument().addDocumentListener(this);
		lPrice = new JLabel("Price:");
		tfPrice = new JTextField();
		tfPrice.getDocument().addDocumentListener(this);
		lDuration = new JLabel("Duration (months):");
		tfDuration = new JTextField();
		tfDuration.getDocument().addDocumentListener(this);
		
		// set GridBatConstraints defaults for labels
		
		gbc.anchor=GridBagConstraints.EAST;
		gbc.fill=GridBagConstraints.NONE;
		gbc.weightx=0;
		gbc.weighty=0;
		gbc.gridheight=1;
		gbc.gridwidth=1;
		gbc.insets=new Insets(2,2,2,2);
		gbc.ipadx=0;
		gbc.ipady=0;
		
		gbc.gridx=0;		gbc.gridy=0;		p.add(lItemId, gbc);
		gbc.gridx=0;		gbc.gridy=1;		p.add(lDescription, gbc);
		gbc.gridx=0;		gbc.gridy=2;		p.add(lPrice, gbc);
		gbc.gridx=0;		gbc.gridy=3;		p.add(lDuration, gbc);
		
		// set GridBatConstraints defaults for textfields
		
		gbc.anchor=GridBagConstraints.WEST;
		gbc.fill=GridBagConstraints.BOTH;
		gbc.weightx=1;
		
		gbc.gridx=1;		gbc.gridy=0;		p.add(tfItemId, gbc);
		gbc.gridx=1;		gbc.gridy=1;		p.add(tfDescription, gbc);
		gbc.gridx=1;		gbc.gridy=2;		p.add(tfPrice, gbc);
		gbc.gridx=1;		gbc.gridy=3;		p.add(tfDuration, gbc);
		
	}
	
	protected void setPersistenceCapable(Object newPc, boolean enablePKFields) {
		pc = (ServiceContract) newPc;
		this.enablePKFields = enablePKFields;
		
		tfItemId.setText(pc.getItemId());
		tfDescription.setText(pc.getDescription());
		tfPrice.setText("" + pc.getPrice());
	  tfDuration.setText("" + pc.getDuration());
		
		fieldSensitivity();
	}
	
	protected void fieldSensitivity() {
		tfItemId.setEnabled(enablePKFields);
		tfDescription.setEnabled(true);
		tfPrice.setEnabled(true);
		tfDuration.setEnabled(true);
	}
	
	protected void collectChanges(boolean includePKFields) {
		if (includePKFields) {
			pc.setItemId(tfItemId.getText());
		}
		pc.setDescription(tfDescription.getText());
		try {
			pc.setPrice(Float.parseFloat(tfPrice.getText()));
			pc.setDuration(Integer.parseInt(tfDuration.getText()));
			
		}
		catch(NumberFormatException nfe) {
			nfe.printStackTrace();
			pc.setPrice(0);
		}

		
	}
	
}
