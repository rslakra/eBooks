package com.ogilviepartners.jdobook.op;

import java.util.HashSet;
import java.util.Set;
//import java.util.Iterator;
import javax.jdo.JDOHelper;
import javax.jdo.JDOUserException;
import javax.jdo.InstanceCallbacks;

/** class that represents an order recorded in the order processing system */
public class Order implements InstanceCallbacks {
  /** identifying order number */
	private int orderNumber;
	
/** set of order lines
     *@link aggregationByValue
     *     @associates <{op.domain.OrderLine}>
     * @label orderLines
     */
	private Set orderLines;
	
	    /**
     * @label customer
     * @supplierCardinality 0..1 
     */
	private Customer customer;
	
	/** flag to indicate whether this order has been dispatched yet */
  private boolean dispatched = false;
	
	/** no-args constructor */
	public Order() {
	}
	
	/** property get method for set of order lines */
	public Set getOrderLines() {
		return orderLines;
	}
	
	/** constructor for a given order number */
	public Order(Customer customer, int orderNumber) {
	  this.customer = customer;
		this.orderNumber = orderNumber;
		orderLines = new HashSet();
	}
	
	/** property get method for order number */
	public int getOrderNumber() {
		return orderNumber;
	}
	
	/** record that this order has been dispatched */
	public void dispatch() {
		dispatched = true;
	}
	
	/** recall this order and make it as if it had not been dispatched */
	public void recall() {
		dispatched = false;
	}
	
	/** property get method for dispatched flag */
	public boolean isDispatched() {
		return dispatched;
	}
	
	/** property get method for customer */
	public Customer getCustomer() {
		return customer;
	}	
		
	/** return the String form of the order */
	public String toString() {
		return "Order (number=" + orderNumber + ")";
	}	
	
	/** JDO callback method - delete cascade/restrict */
	public void jdoPreDelete() {
		System.out.println("   jdoPreDelete called for Order " + orderNumber);
		if (isDispatched()) {
			System.out.println("Order is Dispatched!");
			throw new JDOUserException("cannot delete order " + orderNumber + " as it has been dispatched.");
		}
		
		// deletion will proceed - delete contained instances
		System.out.println("Deleting OrderLines");		
		
		JDOHelper.getPersistenceManager(this).deletePersistentAll(orderLines);
	}
	
	/** JDO callback method */
	public void jdoPostLoad() {}
	
  /** JDO callback method */
	public void jdoPreStore() {}
	
	/** JDO callback method */
	public void jdoPreClear() {}
}

