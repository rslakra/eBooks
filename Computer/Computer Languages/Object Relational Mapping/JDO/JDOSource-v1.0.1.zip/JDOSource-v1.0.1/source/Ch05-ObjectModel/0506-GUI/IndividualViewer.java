package com.ogilviepartners.jdobook.op.gui;

import com.ogilviepartners.jdobook.op.*;
import com.ogilviepartners.jdo.*;

import javax.jdo.*;
import javax.swing.*;
import java.awt.*;

public class IndividualViewer extends BusinessPartnerViewer {
  private Individual pc;
	private boolean enablePKFields;
	JTextField tfGender;
	JLabel lGender;
	
	public IndividualViewer() {
		// swing initialization

		GridBagConstraints gbc = new GridBagConstraints();
		
		
		lGender = new JLabel("Gender");
		tfGender = new JTextField();
		tfGender.getDocument().addDocumentListener(this);
		
		// set GridBatConstraints defaults for labels
		
		gbc.anchor=GridBagConstraints.EAST;
		gbc.fill=GridBagConstraints.NONE;
		gbc.weightx=0;
		gbc.weighty=0;
		gbc.gridheight=1;
		gbc.gridwidth=1;
		gbc.insets=new Insets(2,2,2,2);
		gbc.ipadx=0;
		gbc.ipady=0;
		
		gbc.gridx=0;		gbc.gridy=4;		p.add(lGender, gbc);
		
		// set GridBatConstraints defaults for textfields
		
		gbc.anchor=GridBagConstraints.WEST;
		gbc.fill=GridBagConstraints.BOTH;
		gbc.weightx=1;
		
		gbc.gridx=1;		gbc.gridy=4;		p.add(tfGender, gbc);
		
	}
	
	protected void setPersistenceCapable(Object newPc, boolean enablePKFields) {
		super.setPersistenceCapable(newPc, enablePKFields);
		pc = (Individual) newPc;
		this.enablePKFields = enablePKFields;
		
		tfGender.setText(pc.getGender());
		
		fieldSensitivity();
	}
	
	protected void fieldSensitivity() {
	  super.fieldSensitivity();
		tfGender.setEnabled(true);
	}
	
	protected void collectChanges(boolean includePKFields) {
		super.collectChanges(includePKFields);
		pc.setGender(tfGender.getText());
	}
	
}
