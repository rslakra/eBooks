package com.ogilviepartners.jdobook.op.gui;

import com.ogilviepartners.jdobook.op.*;
import com.ogilviepartners.jdo.*;

import javax.jdo.*;
import javax.swing.*;
import java.awt.*;

public class CompanyViewer extends BusinessPartnerViewer {
  private Company pc;
	private boolean enablePKFields;
	JTextField tfCompanyRegistration, tfVatRegistration;
	JLabel lCompanyRegistration, lVatRegistration;
	
	public CompanyViewer() {
		// swing initialization

		GridBagConstraints gbc = new GridBagConstraints();
		
		
		lCompanyRegistration = new JLabel("Company Reg.:");
		tfCompanyRegistration = new JTextField();
		tfCompanyRegistration.getDocument().addDocumentListener(this);
		lVatRegistration = new JLabel("VAT Reg.:");
		tfVatRegistration = new JTextField();
		tfVatRegistration.getDocument().addDocumentListener(this);
		
		// set GridBatConstraints defaults for labels
		
		gbc.anchor=GridBagConstraints.EAST;
		gbc.fill=GridBagConstraints.NONE;
		gbc.weightx=0;
		gbc.weighty=0;
		gbc.gridheight=1;
		gbc.gridwidth=1;
		gbc.insets=new Insets(2,2,2,2);
		gbc.ipadx=0;
		gbc.ipady=0;
		
		gbc.gridx=0;		gbc.gridy=4;		p.add(lCompanyRegistration, gbc);
		gbc.gridx=0;		gbc.gridy=5;		p.add(lVatRegistration, gbc);
		
		// set GridBatConstraints defaults for textfields
		
		gbc.anchor=GridBagConstraints.WEST;
		gbc.fill=GridBagConstraints.BOTH;
		gbc.weightx=1;
		
		gbc.gridx=1;		gbc.gridy=4;		p.add(tfCompanyRegistration, gbc);
		gbc.gridx=1;		gbc.gridy=5;		p.add(tfVatRegistration, gbc);
	
	}
	
	protected void setPersistenceCapable(Object newPc, boolean enablePKFields) {
		super.setPersistenceCapable(newPc, enablePKFields);
		pc = (Company) newPc;
		this.enablePKFields = enablePKFields;
		
		tfCompanyRegistration.setText(pc.getCompanyRegistration());
		tfVatRegistration.setText(pc.getVatRegistration());
		
		fieldSensitivity();
	}
	
	protected void fieldSensitivity() {
	  super.fieldSensitivity();
		tfCompanyRegistration.setEnabled(true);
		tfVatRegistration.setEnabled(true);
		
	}
	
	protected void collectChanges(boolean includePKFields) {
		super.collectChanges(includePKFields);
		pc.setCompanyRegistration(tfCompanyRegistration.getText());
		pc.setVatRegistration(tfVatRegistration.getText());
		
	}
	
}
