package com.ogilviepartners.jdobook.op.gui;

import com.ogilviepartners.jdobook.op.*;
import com.ogilviepartners.jdo.*;

import javax.jdo.*;
import javax.swing.*;
import java.awt.*;

public class CharityViewer extends CompanyViewer {
  private Charity pc;
	private boolean enablePKFields;
	JTextField tfCharityRegistration;
	JLabel lCharityRegistration;
	
	public CharityViewer() {
		// swing initialization

		GridBagConstraints gbc = new GridBagConstraints();
		
		
		lCharityRegistration = new JLabel("Charity Reg.:");
		tfCharityRegistration = new JTextField();
		tfCharityRegistration.getDocument().addDocumentListener(this);
		
		// set GridBatConstraints defaults for labels
		
		gbc.anchor=GridBagConstraints.EAST;
		gbc.fill=GridBagConstraints.NONE;
		gbc.weightx=0;
		gbc.weighty=0;
		gbc.gridheight=1;
		gbc.gridwidth=1;
		gbc.insets=new Insets(2,2,2,2);
		gbc.ipadx=0;
		gbc.ipady=0;
		
		gbc.gridx=0;		gbc.gridy=6;		p.add(lCharityRegistration, gbc);
		
		// set GridBatConstraints defaults for textfields
		
		gbc.anchor=GridBagConstraints.WEST;
		gbc.fill=GridBagConstraints.BOTH;
		gbc.weightx=1;
		
		gbc.gridx=1;		gbc.gridy=6;		p.add(tfCharityRegistration, gbc);
		
	}
	
	protected void setPersistenceCapable(Object newPc, boolean enablePKFields) {
		super.setPersistenceCapable(newPc, enablePKFields);
		pc = (Charity) newPc;
		this.enablePKFields = enablePKFields;
		
		tfCharityRegistration.setText(pc.getCharityRegistration());
		
		fieldSensitivity();
	}
	
	protected void fieldSensitivity() {
	  super.fieldSensitivity();
		tfCharityRegistration.setEnabled(true);
		
	}
	
	protected void collectChanges(boolean includePKFields) {
		super.collectChanges(includePKFields);
		pc.setCharityRegistration(tfCharityRegistration.getText());
		
	}
	
}
