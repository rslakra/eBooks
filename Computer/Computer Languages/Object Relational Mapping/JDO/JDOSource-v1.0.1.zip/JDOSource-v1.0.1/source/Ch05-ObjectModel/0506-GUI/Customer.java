package com.ogilviepartners.jdobook.op;

import java.util.HashSet;
import java.util.Set;

/** class representing the customer role of a business partner */
public class Customer
{

	/** the orders this customer has placed
     *@link aggregation
     *     @associates <{op.domain.Order}>
     * @label orders
     */

	private Set orders;
	
	/** the business partner to which the customer role applies 
	 * @label businessPartner*/
	private BusinessPartner businessPartner;
	
	/** the credit limit of this customer */
	private double creditLimit;

  /** no-args constructor */
	protected Customer() {
	}
	
	/** constructor for a specific business partner */
	protected Customer(BusinessPartner businessPartner) {
		this.businessPartner = businessPartner;
		orders = new HashSet();
	}
	
	/** property get method for set of orders */
	public Set getOrders() {
		return orders;
	}
	
	/** property set method for set of orders */
	protected void setOrders(Set orders) {
		this.orders = orders;
	}
	
	/** property get method for business partner */
	public BusinessPartner getBusinessPartner() {
		return businessPartner;
	}
	
	/** property get method for credit limit */
	public double getCreditLimit() {
		return creditLimit;
	}
	
	/** property set method for credit limit */
	public void setCreditLimit(double creditLimit) {
		this.creditLimit = creditLimit;
	}
	
	/** create a new order for this customer, with the given order number */
	public Order createOrder(int orderNumber) {
		Order o = new Order(this, orderNumber);
		orders.add(o);
		return o;
	}

  /** remove the specified order from the customers set of orders */
	public void removeOrder(Order o) {
		orders.remove(o);
	}
		
	/** returns the String form of the customer */	
	public String toString() {
		return "Customer (partnerId=" + businessPartner.getPartnerNumber() + " partnerName=" + businessPartner.getName() + ")"; 
  }
}

