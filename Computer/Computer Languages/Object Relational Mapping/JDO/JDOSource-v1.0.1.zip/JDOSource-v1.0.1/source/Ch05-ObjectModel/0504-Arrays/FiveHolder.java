package com.ogilviepartners.jdobook.other;

import javax.jdo.JDOHelper;

public class FiveHolder {
    public FiveHolder(String s1, String s2, String s3, String s4, String s5) {
        content = new String[5];
        content[0] = s1;
        content[1] = s2;
        content[2] = s3;
        content[3] = s4;
        content[4] = s5;
    }

    public void setItem(int index, String s) {
		// instruct JDO that the array is about to be altered
		JDOHelper.makeDirty(this, "content");
        content[index] = s;
    }

    public String toString() {
        return "FiveHolder: 0=" + content[0] + " 1=" + content[1] + " 2=" + content[2] + " 3=" + content[3] + " 4=" + content[4];
    }

    private String[] content;
}
