package com.ogilviepartners.jdobook.app;

import javax.jdo.*;
import com.ogilviepartners.jdo.JDOBootstrap;
import com.ogilviepartners.jdobook.op.BusinessPartner;
import com.ogilviepartners.jdobook.op.Address;
import java.util.Iterator;

public class TestBusinessPartner
{
	public static void main(String[] args) {

		// check the arguments		
		if (args.length != 3) {
			System.out.println("usage: java TestBusinessPartner <partnerNumber> <name> <address>");
			System.exit(1);
		}
		
		// instantiate the PersistenceManagerFactory		
		JDOBootstrap bootstrap = new JDOBootstrap();
		bootstrap.listJDOProperties();
	  	bootstrap.listVendorProperties();
		PersistenceManagerFactory pmf = bootstrap.getPersistenceManagerFactory();
				
		// obtain a PersistenceManager
		PersistenceManager pm = pmf.getPersistenceManager();
		
		// get a reference to the Transaction object		
		Transaction t = pm.currentTransaction();
		
		// create a (transient) BueinssPartner		
		BusinessPartner bp = new BusinessPartner();
		bp.setPartnerNumber(args[0]);
		bp.setName(args[1]);
		bp.setAddress(new Address(args[2]));
		
		// persist the BusinessPartner		
		System.out.println("Persisting " + bp);
		t.begin();
		pm.makePersistent(bp);
		t.commit();
		
		// obtain Extent of Customer and iterate contents		
		t.begin();
		Extent extPartner = pm.getExtent(BusinessPartner.class, false);
		Iterator i = extPartner.iterator();
		System.out.println("Listing partners:");
		while (i.hasNext()) {
			System.out.println(i.next());
		}
		System.out.println("Done.");
		extPartner.close(i);
		t.commit();
		
		// close resources		
		pm.close();	
	}
}

