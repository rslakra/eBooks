package com.ogilviepartners.jdobook.op;

public class Charity extends Company
{
	protected String charityRegistration;
	
	public Charity() {
	}
	
	public String getCharityRegistration() {
		return charityRegistration;
	}
	
	public void setCharityRegistration(String charityRegistration) {
		this.charityRegistration = charityRegistration;
	}
	
	public String toString() {
		return "Charity (number=" + partnerNumber + " name=" + name + " address=" + address + " companyReg=" + companyRegistration + " vatReg=" + vatRegistration + " charityReg=" + charityRegistration + ")";
	}
}

