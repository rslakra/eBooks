package com.ogilviepartners.jdobook.op.gui;

import com.ogilviepartners.jdobook.op.*;
import com.ogilviepartners.jdo.*;

import javax.jdo.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class BusinessPartnerViewer extends GenericViewer {
  private BusinessPartner pc;
	
	private boolean enablePKFields;
	private JTextField tfNumber, tfName;
	private JTextArea tfAddress;
	private JLabel lNumber, lName, lAddress, lCustomer;
	private JCheckBox cbCustomer;
	private Action actNewOrder;
	
	public BusinessPartnerViewer() {
		// swing initialization

	
		GridBagConstraints gbc = new GridBagConstraints();
		
		actNewOrder = new ActionImpl("New Order" , "neworder");
		tb.add(actNewOrder);
		
		lName = new JLabel("Name:");
		tfName = new JTextField();
		tfName.getDocument().addDocumentListener(this);
		lNumber = new JLabel("Partner Number:");
		tfNumber = new JTextField();
		tfNumber.getDocument().addDocumentListener(this);
		lAddress = new JLabel("Address:");
		tfAddress = new JTextArea();
		tfAddress.setBorder(tfName.getBorder());
		tfAddress.getDocument().addDocumentListener(this);
		lCustomer = new JLabel("Customer:");
		cbCustomer = new JCheckBox();
		
		// set GridBatConstraints defaults for labels
		
		gbc.anchor=GridBagConstraints.EAST;
		gbc.fill=GridBagConstraints.NONE;
		gbc.weightx=0;
		gbc.weighty=0;
		gbc.gridheight=1;
		gbc.gridwidth=1;
		gbc.insets=new Insets(2,2,2,2);
		gbc.ipadx=0;
		gbc.ipady=0;
		
		gbc.gridx=0;		gbc.gridy=0;		p.add(lNumber, gbc);
		gbc.gridx=0;		gbc.gridy=1;		p.add(lName, gbc);
		gbc.gridx=0;		gbc.gridy=2;		p.add(lCustomer, gbc);
		gbc.gridx=0;		gbc.gridy=3;		p.add(lAddress, gbc);
		
		// set GridBatConstraints defaults for textfields
		
		gbc.anchor=GridBagConstraints.WEST;
		gbc.fill=GridBagConstraints.BOTH;
		gbc.weightx=1;
		
		gbc.gridx=1;		gbc.gridy=0;		p.add(tfNumber, gbc);
		gbc.gridx=1;		gbc.gridy=1;		p.add(tfName, gbc);
		gbc.gridx=1;		gbc.gridy=2;		p.add(cbCustomer, gbc);
		
		// set GridBatConstraints defaults for textareas
		
		gbc.weighty=1;
		
		gbc.gridx=1;		gbc.gridy=3;		p.add(tfAddress, gbc);
	}
	
	protected void setPersistenceCapable(Object newPc, boolean enablePKFields) {
		pc = (BusinessPartner) newPc;
		this.enablePKFields = enablePKFields;
		
		display();
	}
	
	public void display() {
		tfNumber.setText(pc.getPartnerNumber());
		tfName.setText(pc.getName());
		cbCustomer.getModel().setSelected(pc.isCustomer());
		tfAddress.setText(pc.getAddress());
	
		fieldSensitivity();
	}
	
	protected void fieldSensitivity() {
		tfNumber.setEnabled(enablePKFields);
		tfName.setEnabled(true);
		cbCustomer.setEnabled(false);
		tfAddress.setEnabled(true);
	}
	
	protected void collectChanges(boolean includePKFields) {
		if (includePKFields) {
			pc.setPartnerNumber(tfNumber.getText());
		}
		pc.setName(tfName.getText());
		pc.setAddress(tfAddress.getText());
		
	}
	
	public void neworderAction() {
		String strOrderNumber = (String) JOptionPane.showInputDialog(this, "Please enter new order number", "New order", JOptionPane.QUESTION_MESSAGE, null, null, null);
		int orderNumber= 0;
		try {
			orderNumber = Integer.parseInt(strOrderNumber);
		}
		catch (NumberFormatException nfe) {
			nfe.printStackTrace();
		}
		t.begin();
		pc.getCustomer().createOrder(orderNumber);
		t.commit();
		//setDataChanged(true);
		display();
		//JDOHelper.makeDirty(pc, "customer");
		
	}
	
	// inner classes
	
	class ActionImpl extends AbstractAction {
		private String action;
		public void actionPerformed(ActionEvent ae) {
			     if (action.equals("neworder")) neworderAction();
			else throw new RuntimeException("Unknown action: " + action);
		}
		public ActionImpl(String label, String action) {
			super(label);
			this.action = action;
		}
	}	
}
