package com.ogilviepartners.jdobook.op;

import java.util.HashSet;
import java.util.Set;
import java.util.Iterator;
import javax.jdo.JDOHelper;
import javax.jdo.JDOUserException;
import javax.jdo.InstanceCallbacks;

/** class that represents an order recorded in the order processing system */
public class Order {
	/** identifying order number */
	private int orderNumber;
	
	/** set of order lines */
	private Set orderLines;
	
	/** no-args constructor */
	public Order() {
	}
	
	/** property get method for set of order lines */
	public Set getOrderLines() {
		return orderLines;
	}
	
	/** constructor for a given order number */
	public Order(int orderNumber) {
		this.orderNumber = orderNumber;
		orderLines = new HashSet();
	}
	
	/** property get method for order number */
	public int getOrderNumber() {
		return orderNumber;
	}
	
	
	/** return the String form of the order */
	public String toString() {
		String s = "Order (number=" + orderNumber + " numberOfLines=" + orderLines.size() + ")";
		Iterator i = orderLines.iterator();
		while (i.hasNext()) {
			s += "\n" + i.next();
		}
		return s;
	}		
}

