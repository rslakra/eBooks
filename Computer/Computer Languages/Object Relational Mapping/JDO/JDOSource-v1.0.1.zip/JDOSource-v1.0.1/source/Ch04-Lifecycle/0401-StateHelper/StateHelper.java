package com.ogilviepartners.jdo;

import javax.jdo.JDOHelper;

public class StateHelper
{
	public static String determineState(Object pc) {
		String s = "";
		s += (JDOHelper.isPersistent(pc)    ? "Persistent" : "Transient");
		s += (JDOHelper.isDirty(pc)         ? "-Dirty"     : "-Clean");
		s += (JDOHelper.isNew(pc)           ? "-New"       : "");
		s += (JDOHelper.isDeleted(pc)       ? "-Deleted"   : "");
		if (JDOHelper.isPersistent(pc)) {
			s += (JDOHelper.isTransactional(pc) ? "" : "-Nontransactional");
		}
		else {
			s += (JDOHelper.isTransactional(pc) ? "-Transactional" : "");		
		}
		return s;
	}
}

