package com.ogilviepartners.jdobook.app;

import javax.jdo.*;
import com.ogilviepartners.jdo.JDOBootstrap;
import com.ogilviepartners.jdo.StateHelper;
import com.ogilviepartners.jdobook.op.BusinessPartner;
import java.util.Iterator;

public class TestBusinessPartner
{
	public static void main(String[] args) {

		// check the arguments
		
		if (args.length != 3) {
			System.out.println("usage: java TestBusinessPartner <customerNumber> <name> <address>");
			System.exit(1);
		}
		
		// instantiate the PersistenceManagerFactory
		
		JDOBootstrap bootstrap = new JDOBootstrap();

		bootstrap.listJDOProperties();
	  bootstrap.listVendorProperties();
		PersistenceManagerFactory pmf = bootstrap.getPersistenceManagerFactory();
		
		// obtain a PersistenceManager
		
		PersistenceManager pm = pmf.getPersistenceManager();
		
		// get a reference to the Transaction object
		
		Transaction t = pm.currentTransaction();
		
		// create a (transient) BusinessPartner
		
		System.out.println("Creating new BusinessPartner");
		BusinessPartner bp = new BusinessPartner();
		bp.setPartnerNumber(args[0]);
		bp.setName(args[1]);
		bp.setAddress(args[2]);
		
		System.out.println("   state=" + StateHelper.determineState(bp));
		
		// persist the BusinessPartner
		
		System.out.println("Persisting " + bp);
		t.begin();
		pm.makePersistent(bp);
		System.out.println("   state=" + StateHelper.determineState(bp));
		
		System.out.println("Committing transaction");
		t.commit();		
		System.out.println("   state=" + StateHelper.determineState(bp));
		
		// obtain Extent of BusinessPartner and iterate contents
		
		t.begin();
		Extent extPartner = pm.getExtent(BusinessPartner.class, false);
		Iterator i = extPartner.iterator();
		System.out.println("Listing partners:");
		while (i.hasNext()) {
			Object o = i.next();
			System.out.println(o);
			System.out.println("   state=" + StateHelper.determineState(o));
		}
		System.out.println("Done.");
		t.commit();
		
		// close resources
		
		pm.close();
	
	}


}

