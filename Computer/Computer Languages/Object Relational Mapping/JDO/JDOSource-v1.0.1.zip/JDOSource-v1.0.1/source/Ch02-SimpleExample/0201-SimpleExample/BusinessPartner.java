package com.ogilviepartners.jdobook.op;

/** class that represents a business partner */
public class BusinessPartner {

  	/** name of the partner */
	protected String name;
	
	/** Uniquely identifying String for each partner */
	protected String partnerNumber;
	
	/** Complete address of partner */
	protected String address;
	
	/** returns String representation of a partner */
	public String toString() {
		return "BusinessPartner (number=" + partnerNumber + " name=" + name + " address=" + address + ")";
	}
	
	/* property set method for name */
	public void setName(String name) {
		this.name = name;
	}
	
	/* property get method for name */
	public String getName() {
		return name;
	}

  /** property set method for address */
	public void setAddress(String address) {
		this.address = address;
	}
	
	/** property get method for address */
	public String getAddress() {
		return address;
	}

  	/** property set method for identifying partner number */
	public void setPartnerNumber(String partnerNumber) {
		this.partnerNumber = partnerNumber;
	}
	
	/** property get method for identifying partner number */
	public String getPartnerNumber() {
		return partnerNumber;
	}
}

