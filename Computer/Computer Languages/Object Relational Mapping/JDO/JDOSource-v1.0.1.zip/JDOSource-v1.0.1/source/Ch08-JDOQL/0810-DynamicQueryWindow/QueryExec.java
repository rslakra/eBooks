package com.ogilviepartners.jdobook.app;

import javax.jdo.*;
import java.util.Collection;

class QueryExec
{
	Query q;
	
	public QueryExec(	PersistenceManager pm, 
										Class candidateClass, 
										boolean includeSubclasses, 
										String filterDeclaration, 										
										String variableDeclaration,
										String parameterDeclaration,
										String orderingDeclaration,
										String importDeclaration) {


System.out.println("\nQueryExec\nfilter=" + filterDeclaration + "\nordering=" + orderingDeclaration + "\nvariable=" + variableDeclaration + "\nparameter=" + parameterDeclaration + "\nimport=" + importDeclaration);

		Extent ext = pm.getExtent(candidateClass, includeSubclasses);
			
		q = pm.newQuery(ext, filterDeclaration); 
		
		if (!orderingDeclaration.equals("")) q.setOrdering(orderingDeclaration);
		if (!variableDeclaration.equals("")) q.declareVariables(variableDeclaration);
		if (!parameterDeclaration.equals("")) q.declareParameters(parameterDeclaration);
	}

  public Collection executeWithArray(Object[] params) {
		return (Collection) q.executeWithArray(params);
	}

  public void compile() {
		q.compile();
	}
	
	public void closeAll() {
		q.closeAll();
		q = null;
	}
}

