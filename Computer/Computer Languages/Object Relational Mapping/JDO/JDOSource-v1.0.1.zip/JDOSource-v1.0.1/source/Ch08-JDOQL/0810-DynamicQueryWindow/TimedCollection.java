package com.ogilviepartners.jdobook.app;

import java.util.Collection;

class TimedCollection
{
	private Collection collection;
	private long elapsedTime;
	
	public TimedCollection(Collection collection, long elapsedTime) {
		this.collection = collection;
		this.elapsedTime = elapsedTime;
	}
	
	public Collection getCollection() {
		return collection;
	}
	
	public long getElapsedTime() {
		return elapsedTime;
	}
}

