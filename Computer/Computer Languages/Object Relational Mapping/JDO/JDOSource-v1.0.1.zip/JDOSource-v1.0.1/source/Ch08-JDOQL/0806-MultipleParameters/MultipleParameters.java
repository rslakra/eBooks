package com.ogilviepartners.jdobook.app;

import com.ogilviepartners.jdobook.op.*;
import com.ogilviepartners.jdo.JDOBootstrap;

import java.util.Collection;
import java.util.Iterator;
import javax.jdo.*;

public class MultipleParameters
{
	public static void main() {	
		JDOBootstrap bootstrap = new JDOBootstrap();
		PersistenceManagerFactory pmf = bootstrap.getPersistenceManagerFactory();
		PersistenceManager pm = pmf.getPersistenceManager();
		Transaction t = pm.currentTransaction();
		
		t.begin();
		
		Extent partnerExt = pm.getExtent(BusinessPartner.class, true);
		String filter = "name == searchName && address == searchAddress";
		Query q = pm.newQuery(partnerExt, filter);
		q.declareParameters("String searchName, String searchAddress");
		q.setOrdering("name ascending, partnerId descending");
		Collection c = (Collection) q.execute("Ogilvie Partners", "Milton Keynes");
		
		Iterator i = c.iterator();
		System.out.println("Listing all BusinessPartner Instances:");
		while(i.hasNext()) {
			Object o = i.next();
			System.out.println(o);
		}	
		System.out.println("Done.");
		
		q.close(c);
		t.commit();
	}	
}
