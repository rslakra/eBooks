package com.ogilviepartners.jdobook.app;

import javax.jdo.*;
import com.ogilviepartners.jdo.JDOBootstrap;
//import jdo.StateHelper;

import java.util.Collection;
import java.util.Iterator;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.StringWriter;
import java.io.PrintWriter;

public class DynamicQueryWindow extends JFrame
{
	private static PersistenceManagerFactory pmf;
	private static PersistenceManager pm;
	private static Transaction t;
	private static String[] arguments;
	private static DynamicQuery dq;
	
	// Swing declarations
	
	JTextField tfCandidate;
	JTextField tfVariableDeclaration;
	JTextField tfParameterDeclaration;
	JTextField tfImportDeclaration;
	JTextField tfFilter;
	JTextField tfParameterValues;
	JTextField tfOrdering;
		
	JLabel lCandidate;
	JLabel lVariableDeclaration;
	JLabel lParameterDeclaration;
	JLabel lImportDeclaration;
	JLabel lFilter;
	JLabel lParameterValues;
	JLabel lOrdering;
	JLabel lResults;
	
	JPanel inPanel;
	JPanel btnPanel;
	JPanel resPanel;
	JPanel cPanel;
	
	JButton bNew;
	JButton bPrepare;
	JButton bCompile;
	JButton bExecute;
	
	Container cp;
	
	JTextArea taResult;
	
	JScrollPane sp;
		
	
	public static void main(String[] args) {

		// instantiate the PersistenceManagerFactory
		
		JDOBootstrap bootstrap = new JDOBootstrap();
		bootstrap.listJDOProperties();
	  bootstrap.listVendorProperties();
		pmf = bootstrap.getPersistenceManagerFactory();
		
		// obtain a PersistenceManager
		
		pm = pmf.getPersistenceManager();
		
		// get a reference to the Transaction object
		
		t = pm.currentTransaction();
		

		// construct and execute the Query
	/*	
	String candidateClassName = "op.BusinessPartner";
		String variableDeclaration = "";		
		String parameterDeclaration = "Byte a, Short b, Integer c, Long d, Float e, Double f, Boolean g, Character h, String i";
		String filter = "name.startsWith(\"ro\")";
		String parameterValues = "1,2,3,4,5,6,true,'*',\"robin\"";
		String ordering = "";
	*/	
		
		dq = new DynamicQuery(pm);
		
		// initialization complete
		
		DynamicQueryWindow dqh = new DynamicQueryWindow();
		dqh.setVisible(true);
	}
	
	
	public DynamicQueryWindow() {
		cp = getContentPane();
		
		tfCandidate = new JTextField("com.ogilviepartners.jdobook.op.BusinessPartner");
		tfVariableDeclaration = new JTextField();
		tfParameterDeclaration = new JTextField();
		tfImportDeclaration = new JTextField();
		tfFilter = new JTextField("name.startsWith(\"ro\")");
		tfParameterValues = new JTextField();
		tfOrdering = new JTextField();
		
		
		lCandidate = new JLabel("Candidate Class Name");
		lVariableDeclaration = new JLabel("Variable Declarations");
		lParameterDeclaration = new JLabel("Parameter Declarations");
		lImportDeclaration = new JLabel("Import Declarations");
		
		lFilter = new JLabel("Filter");
		lParameterValues = new JLabel("Parameter Values");
		lOrdering = new JLabel("Ordering");
		lResults = new JLabel("Results");
		cp.setLayout(new BorderLayout());
		inPanel = new JPanel();
		inPanel.setLayout(new GridLayout(12,1));
		inPanel.add(lCandidate);
		inPanel.add(tfCandidate);
		inPanel.add(lVariableDeclaration);
		inPanel.add(tfVariableDeclaration);
		inPanel.add(lParameterDeclaration);
		inPanel.add(tfParameterDeclaration);
		inPanel.add(lImportDeclaration);
		inPanel.add(tfImportDeclaration);
		inPanel.add(lFilter);
		inPanel.add(tfFilter);
		inPanel.add(lOrdering);
		inPanel.add(tfOrdering);
		inPanel.add(lParameterValues);
		inPanel.add(tfParameterValues);
		
		bNew = new JButton("New Query");
		bPrepare = new JButton("Prepare");
		bCompile = new JButton("Compile");
		bExecute = new JButton("Execute");
		btnPanel = new JPanel();
		btnPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
		btnPanel.add(bNew);
		btnPanel.add(bPrepare);
		btnPanel.add(bCompile);
		btnPanel.add(bExecute); 
		
		resPanel = new JPanel();
		resPanel.setLayout(new GridLayout(2,1));
		resPanel.add(btnPanel);
		resPanel.add(lResults);
		
		cPanel = new JPanel();
		cPanel.setLayout(new BorderLayout());
		cPanel.add(resPanel, BorderLayout.NORTH);

		
		cp.add(inPanel,BorderLayout.NORTH);
		
		taResult = new JTextArea();
		sp = new JScrollPane(taResult);
		cPanel.add(sp,BorderLayout.CENTER);
		cp.add(cPanel, BorderLayout.CENTER);
		
		
		tfCandidate.setEnabled(true);
		tfVariableDeclaration.setEnabled(true);
		tfParameterDeclaration.setEnabled(true);
		tfImportDeclaration.setEnabled(true);
		tfFilter.setEnabled(true);
		tfParameterValues.setEnabled(true);
		tfOrdering.setEnabled(true);
		
		bCompile.setEnabled(false);
		bExecute.setEnabled(false);
		
		pack();
			
		
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent we) {
				pm.close();
				System.exit(0);
			}
		});
		
		bExecute.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				executeQuery();
			}
		});
		
		bNew.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				newQuery();
			}
		});
		
		bPrepare.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				prepareQuery();
			}
		});
		
		bCompile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				compileQuery();
			}
		});
		
		
	
	}
	
	public void executeQuery() {
		try {
					taResult.setText("Executing...");
								
					TimedCollection tc = dq.executeQuery(tfParameterValues.getText());

					float duration = (float) tc.getElapsedTime() / 1000F;
					Collection c = tc.getCollection();
					
					taResult.setText("Executing...     " + duration + " seconds elapsed\n\n");
					
					Iterator i = c.iterator();
					while(i.hasNext()) {
						taResult.append(i.next() + "\n");
					}
		}
		catch (Exception e) { 
			reportException(e);
		}
	
	}
	
	public void newQuery() {
		tfCandidate.setEnabled(true);
		tfVariableDeclaration.setEnabled(true);
		tfParameterDeclaration.setEnabled(true);
		tfImportDeclaration.setEnabled(true);
		
		tfFilter.setEnabled(true);
		tfParameterValues.setEnabled(true);
		tfOrdering.setEnabled(true);
		
		bPrepare.setEnabled(true);
		bCompile.setEnabled(false);
		bExecute.setEnabled(false);
		
		dq.closeQuery();
		
		pm.currentTransaction().commit();
  }
	
	public void compileQuery() {
		try {
					taResult.setText("Compiling...");
					
					long elapsedTime = dq.compileQuery();

					float duration = (float) elapsedTime / 1000F;
					
					taResult.setText("Compiling...     " + duration + " seconds elapsed\n\n");
		}
		catch (Exception e) {
			reportException(e);
		}
				
	}
	
	public void prepareQuery() {
	  Transaction t;
		try {
					taResult.setText("Preparing...");
					
					t = pm.currentTransaction();
					
					if (t.isActive()) {
						taResult.append("Warning: transaction already active.  Committing old transaction.");
						t.commit();
					}
					
					t.begin();
								
					long elapsedTime = dq.prepareQuery(					
						tfCandidate.getText(),
						tfVariableDeclaration.getText(),
						tfParameterDeclaration.getText(),
						tfImportDeclaration.getText(),
						tfFilter.getText(),
						tfOrdering.getText(),
						true
						);
					
					float duration = (float) elapsedTime / 1000F;
					
					taResult.setText("Preparing...     " + duration + " seconds elapsed\n\n");
				}
				catch (Exception e) {
					reportException(e);
				}
				
				
		tfCandidate.setEnabled(false);
		tfVariableDeclaration.setEnabled(false);
		tfParameterDeclaration.setEnabled(false);
		tfImportDeclaration.setEnabled(false);
		tfFilter.setEnabled(false);
		tfParameterValues.setEnabled(true);
		tfOrdering.setEnabled(false);
		
		bPrepare.setEnabled(false);
		bCompile.setEnabled(true);
		bExecute.setEnabled(true);				
	}

	public void reportException(Exception e) {
	  StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		e.printStackTrace(pw);
		pw.flush();
		sw.flush();
		taResult.setText(sw.toString());
	}

}


