package com.ogilviepartners.jdobook.app;

import com.ogilviepartners.jdobook.op.*;
import com.ogilviepartners.jdo.JDOBootstrap;

import java.util.Collection;
import java.util.Iterator;
import javax.jdo.*;

public class SingletonNavigation
{
	public static void main() {	
		JDOBootstrap bootstrap = new JDOBootstrap();
		PersistenceManagerFactory pmf = bootstrap.getPersistenceManagerFactory();
		PersistenceManager pm = pmf.getPersistenceManager();
		Transaction t = pm.currentTransaction();
		
		t.begin();
		
		Extent partnerExt = pm.getExtent(BusinessPartner.class, true);
		String filter = "customer.creditLimit > searchCredit";
		Query q = pm.newQuery(partnerExt, filter);
		q.declareParameters("double searchCredit");
		Double credit = new Double(1000);
		Collection c = (Collection) q.execute(credit);
		
		Iterator i = c.iterator();
		System.out.println("Listing all BusinessPartner Instances:");
		while(i.hasNext()) {
			Object o = i.next();
			System.out.println(o);
		}	
		System.out.println("Done.");
		
		q.close(c);
		t.commit();
	}	
}
