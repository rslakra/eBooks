package com.ogilviepartners.jdobook.app;

import javax.jdo.PersistenceManager;
import javax.jdo.Extent;
//import javax.jdo.Query;
import java.util.Collection;
import java.util.Vector;
import java.util.StringTokenizer;

public class DynamicQuery
{
	private PersistenceManager pm;
	private QueryExec qe;
	private boolean compiled;
	private Object[] params;
	private String parameterDeclaration;
	
	public DynamicQuery(PersistenceManager pm) {
		this.pm = pm;
	}

  public TimedCollection executeQuery(String parameterValues) throws Exception {
		
		long startTime=0;
		long endTime=0;
		Collection c;
		
		if (qe == null) {
			throw new Exception("no query available");
		}
		else {
		
			System.out.println("Parsing parameter values");
			
			params = parseParameters(parameterDeclaration, parameterValues);
		
			System.out.println("Executing Dynamic Query - params.length=" + params.length);

			startTime = System.currentTimeMillis();	
			c = qe.executeWithArray(params);
			endTime = System.currentTimeMillis();
		
			System.out.println("Returning resultant Collection");
			
			return new TimedCollection(c, endTime - startTime);
		}
	}
	
	public long compileQuery() throws Exception {
		long startTime=0;
		long endTime=0;
	
		if (qe == null) {
			throw new Exception("no query available");
		}
		else if (compiled) {
			throw new Exception("query already compiled");
		}
		else {
			startTime = System.currentTimeMillis();
			qe.compile();
			compiled = true;
			endTime = System.currentTimeMillis();
			return endTime - startTime;
		}
		
	}
	
	public void closeQuery() {
		if (qe != null) {
			qe.closeAll();
		}
	}

	public long prepareQuery (String candidateClassName,
														String variableDeclaration,
														String parameterDeclaration,
														String importDeclaration,
														String filter,
														String ordering,
														boolean subclasses) throws Exception {
		 
		// let them know what we're doing														
	
	 
	
		System.out.println("Constructing Dynamic Query for:");
		System.out.println("     candidate='" + candidateClassName + "'");
		System.out.println("     variables='" + variableDeclaration + "'");
		System.out.println("     parameters='" + parameterDeclaration + "'");
		System.out.println("     filter='" + filter + "'");
		System.out.println("     ordering='" + ordering + "'");		
		
			// we cannot parse this until we have the values so save for later use
			this.parameterDeclaration = parameterDeclaration;
		
		Class cls = null;
		
		try {
			cls = Class.forName(candidateClassName);
		}
		catch (ClassNotFoundException cnfe) {
			System.out.println(cnfe);
			System.exit(1);
		}
		
		long startTime=0;
		long endTime=0;
			startTime = System.currentTimeMillis();
		
			qe = new QueryExec(pm, cls, subclasses, filter, variableDeclaration, parameterDeclaration, ordering, importDeclaration);
			compiled = false;
			endTime = System.currentTimeMillis();
			return endTime - startTime;
			
	}

private Object[] parseParameters(String decls, String vals) {
		//parse 
		
		StringTokenizer stDecl = new StringTokenizer(decls,",");
		StringTokenizer stVals = new StringTokenizer(vals,",");
		
		int declCount = stDecl.countTokens();
		int valsCount = stVals.countTokens();
		
		if (declCount != valsCount) {
			// mismatch
			throw new RuntimeException("mismatch between number of declared parameters (" + declCount + ") and issued parameters (" + valsCount + ")"); 
		}
		Object[] params = new Object[declCount];
		int paramIndex = 0;
		
		while(stDecl.hasMoreTokens()) {
			String decl = stDecl.nextToken().trim();
			String val = stVals.nextToken().trim();
			
			     if (decl.startsWith("Float "))     params[paramIndex++] = new Float(Float.parseFloat(val));
			else if (decl.startsWith("Integer "))   params[paramIndex++] = new Integer(Integer.parseInt(val));
			else if (decl.startsWith("Double "))    params[paramIndex++] = new Double(Double.parseDouble(val));
			else if (decl.startsWith("Short "))     params[paramIndex++] = new Short(Short.parseShort(val));
			else if (decl.startsWith("Long "))      params[paramIndex++] = new Long(Long.parseLong(val));
			else if (decl.startsWith("Byte "))      params[paramIndex++] = new Byte(Byte.parseByte(val));
			else if (decl.startsWith("Boolean "))   params[paramIndex++] = parseBoolean(val);
			else if (decl.startsWith("Character ")) params[paramIndex++] = parseCharacter(val);
			else if (decl.startsWith("String "))    params[paramIndex++] = parseString(val);			
			else {
				throw new RuntimeException("could not parse " + decl + " - unknown type");
			}
		
		}
		
		// report
		
		for (int i = 0; i < params.length; i++) {
			System.out.println("params[" + i + "] = " + params[i].getClass().getName() + "(" + params[i] + ")");
		}
		
		return params;
		
		
	}
	
	private String parseString(String s) {
		// s is a sting in quotes
		if (s.length() >= 2 && s.charAt(0) == '"' && s.charAt(s.length() - 1) == '"') return s.substring(1, s.length() - 1);
		else throw new RuntimeException("Could not parse String " + s);
		
	}
	
	private Character parseCharacter(String s) {
	  // s is a character in apostropes
		if (s.charAt(0) == '\'' && s.charAt(2) == '\'') return new Character(s.charAt(1));
		else throw new RuntimeException("Could not parse Character " + s);
	}
	
	private Boolean parseBoolean(String s) {
		// s is true or false
		     if (s.equals("true")) return new Boolean(true);
		else if (s.equals("false")) return new Boolean(false);
		else throw new RuntimeException("Could not parse Boolean " + s);
	}
}

