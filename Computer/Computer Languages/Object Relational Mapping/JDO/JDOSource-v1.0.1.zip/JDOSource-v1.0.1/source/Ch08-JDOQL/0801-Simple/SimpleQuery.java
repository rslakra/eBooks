package com.ogilviepartners.jdobook.app;

import com.ogilviepartners.jdobook.op.*;
import com.ogilviepartners.jdo.JDOBootstrap;

import java.util.Collection;
import java.util.Iterator;
import javax.jdo.*;

public class SimpleQuery
{
	public static void main() {	
		JDOBootstrap bootstrap = new JDOBootstrap();
		PersistenceManagerFactory pmf = bootstrap.getPersistenceManagerFactory();
		PersistenceManager pm = pmf.getPersistenceManager();
		Transaction t = pm.currentTransaction();
		
		t.begin();
		
		Extent partnerExt = pm.getExtent(BusinessPartner.class, true);
		Query q = pm.newQuery(partnerExt);
		Collection c = (Collection) q.execute();
		
		Iterator i = c.iterator();
		System.out.println("Listing all BusinessPartner Instances:");
		while(i.hasNext()) {
			Object o = i.next();
			System.out.println(o);
		}	
		System.out.println("Done.");
		
		q.close(c);
		t.commit();
	}	
}
