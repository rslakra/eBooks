package com.ogilviepartners.jdobook.op.pk;

/** concrete key class for application identity of class AbstractItem */
public class BusinessPartnerPK
{
  	/** primary key field partnerNumber */
	public String partnerNumber;
	
	/** equals method */
	public boolean equals(BusinessPartnerPK that) {
		if (that == null) return false;
		if (this == that) return true; // �equality� within the JVM
		if (this.partnerNumber == null) return that.partnerNumber == null;
		return this.partnerNumber.equals(that.partnerNumber);
	}
	
	/** hashCode method */
	public int hashCode() {
		return partnerNumber.hashCode();
	}
	
	/** String constructor - must be interoperable with toString() result */
	public BusinessPartnerPK(String arg) {
		this.partnerNumber = arg;
	}
	
	/** no-args constructor */
	public BusinessPartnerPK() {
	}
	
	/** returns String form of key */
	public String toString() {
		return partnerNumber;
	}
}

