package op.ejb;

import javax.ejb.*;
import op.*;
import op.ex.*;
import op.pk.*;
import javax.jdo.*;
import javax.naming.*;

public class OrderDespatcherBean implements SessionBean
{
	SessionContext sc;
	PersistenceManagerFactory pmf;
	Context env;

	
	public void setSessionContext(SessionContext sc) {
		this.sc = sc;
		try {
			Context ic = new InitialContext();
			env = (Context) ic.lookup("java:comp/env");
			pmf = (PersistenceManagerFactory) env.lookup("jdo/OrderProcessingPMF");		
		}
		catch (Exception e) {
			throw new EJBException(e);
		}
	}
	
	public void ejbCreate() {
	}
	
	public void ejbRemove() {
	}
	
	public void despatchOrder(OrderPK orderKey) {
		PersistenceManager pm = null;
		try {
			pm = pmf.getPersistenceManager();
			Order o = (Order) pm.getObjectById(orderKey, true);
			o.despatch();
		}
		catch (Exception e) {
			throw new EJBException(e);
		}
		finally {
			if (pm != null && !pm.isClosed()) pm.close();
		}
	}
	
	public void cancelOrder(OrderPK orderKey) throws OrderStatusException {
		PersistenceManager pm = null;
		try {
			pm = pmf.getPersistenceManager();			
			Order o = (Order) pm.getObjectById(orderKey, true);
			o.cancel();// verify the exception thrown by this method.			
		}
		catch (Exception e) {
			throw new EJBException(e);
		}
		finally {
			if (pm != null && !pm.isClosed()) pm.close();
		}
	}
	

	public void ejbPassivate() {}
	public void ejbActivate() {}
}

