<%@ page import javax.jdo.* %>
<%@ page import op.Product %>

<%! PersistenceManagerFactory pmf %>

<jsp:useBean id="OrderProcessingPMFHolder" scope="application" class="op.ejb.PMFHolder">
	<% OrderProcessingPMFHolder.setJNDIName("OrderProcessingPMF"); %>
</jsp:useBean>

<HTML><HEAD><TITLE>Business Partners</TITLE></HEAD>
<BODY>
<H1>List of Business Partners</H1>
<TABLE>
<TH>ID</TH><TH>Name</TH><TH>Address</TH><TH>Type</TH>
<% 
PersistenceManager pm = OrderProcessingPMFHolder.getPersistenceManager();
Transaction t = pm.currentTransaction();
t.begin();
Extent e = pm.getExtent(BusinessPartner.class, true);
Iterator i = e.iterator();
while (i.hasNext) {
    BusinessPartner bp = i.next();
%>
<TR>
<TD><%= bp.getPartnerId() %></TD>
<TD><%= bp.getName() %></TD>
<TD><%= bp.getAddress() %></TD>
<TD><%= bp.class.getName() %></TD>
</TR>
<% 
}
e.close(i);
t.commit();
pm.close();
%>
</BODY>

