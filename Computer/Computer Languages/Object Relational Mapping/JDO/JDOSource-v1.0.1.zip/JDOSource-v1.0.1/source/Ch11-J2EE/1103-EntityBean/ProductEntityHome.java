package op.ejb;

import javax.ejb.*;

import op.pk.ItemPK;
import java.util.Collection;
import java.rmi.RemoteException;

public interface ProductEntityHome extends EJBHome {
	// create methods
	public ProductEntity create(String itemId) throws RemoteException, CreateException;
	public ProductEntity create(String itemId, String description, double price, String colour) throws RemoteException, CreateException;
		
	// finder methods	
	public ProductEntity findByPrimaryKey(ItemPK itemKey) throws RemoteException, FinderException;
	public Collection findAll() throws RemoteException, FinderException;	
}
