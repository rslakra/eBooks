package op.ejb;

import java.rmi.RemoteException;
import op.pk.ItemPK;
import javax.ejb.EJBObject;

interface OrderEntry extends EJBObject {
	void addProduct(ItemPK pKey) throws RemoteException;
	void completeOrder() throws RemoteException;
	void discardOrder() throws RemoteException;
}

