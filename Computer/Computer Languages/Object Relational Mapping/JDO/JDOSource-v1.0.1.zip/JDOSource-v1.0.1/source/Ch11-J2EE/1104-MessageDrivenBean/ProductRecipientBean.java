package op.ejb;

import javax.ejb.*;
import javax.jdo.*;
import javax.naming.*;
import javax.jms.*;
import op.*;
import op.pk.*;

public class ProductRecipientBean implements MessageDrivenBean
{
	MessageDrivenContext ctx;
	PersistenceManagerFactory pmf;

	Context env;
	
	public void setMessageDrivenContext(MessageDrivenContext ctx) {
		this.ctx = ctx;
		try {
			Context ic = new InitialContext();
			env = (Context) ic.lookup("java:comp/env");
			pmf = (PersistenceManagerFactory) env.lookup("jdo/OrderProcessingPMF");
		}
		catch (NamingException e) {
			throw new EJBException("JNDI Lookups Failed");
		}
	}
	
	public void ejbRemove() {
	}
	
	public void ejbCreate() {
	}
	
	public void onMessage(Message m) {
		Object content;
		Product product;
		PersistenceManager pm;
		
		try {
			// only ObjectMessage types expected
			if (m instanceof TextMessage) {
				// retieve message contents
				TextMessage tm = (TextMessage) m;
				String s = tm.getText();
				// get pm from pmf - it will be synchronized to the J2EE transaction
				pm = pmf.getPersistenceManager();
				// instantiate and persisty the new product
				product = new Product();
				product.setDescription(s);				
				pm.makePersistent(product);
				// do not commit as J2EE commit will occur on return from onMessage()
			}
			else throw new EJBException("Message was not an instance of TextMessage");			
		}
		catch (Exception e) {
			throw new EJBException(e);
		}
		
	}

}

