package op.ejb;

import javax.jdo.*;
import javax.naming.*;

public class PMFHolder
{
	PersistenceManagerFactory pmf;
	
	public void setJNDIName(String jndiName) {
	  Context ic = new InitialContext();
		Context env = ic.lookup("java:comp/env");
		pmf = (PersistenceManagerFactory) env.lookup(jndiName);
	}
	
	public synchronized PersistenceManager getPersistenceManager() {
		return pmf.getPersistenceManager();
	}
}

