package op.ejb;

import javax.ejb.*;
import op.Product;
import op.pk.ItemPK;
import javax.jdo.PersistenceManager;
import javax.jdo.PersistenceManagerFactory;
import javax.jdo.JDOHelper;
import javax.jdo.Extent;
import java.util.Iterator;
import java.util.Vector;
import java.util.Collection;
import javax.naming.Context;
import javax.naming.InitialContext;

public class ProductEntityBean implements EntityBean
{
	private PersistenceManagerFactory pmf;
	private PersistenceManager pm;
	private Product product;
	private EntityContext ec;
	private Context env;
	
	public ProductEntityBean() {
		System.out.println("ProductBean()");
	}
	
	// business methods

	public String getDescription() {
		System.out.println("getDescription()");	
		return product.getDescription();		
	}
	
	public void setDescription(String description) {
		System.out.println("setDescription()");
		product.setDescription(description);
	}
	
	public double getPrice() {
	  System.out.println("getPrice()");
		return product.getPrice();
		
	}
	
	public void setPrice(double price) {
		System.out.println("setPrice()");
		product.setPrice(price);
	}
	
	public String getColour() {
	  System.out.println("getColour()");
		return product.getColour();
		
	}
	
	public void setColour(String colour) {
	  System.out.println("setColour()");
		product.setColour(colour);		
	}
	
	public String getItemId() {
		System.out.println("getItemId()");
		return product.getItemId();
		
	}

	// create methods
	
	public void ejbPostCreate(String itemId) {
		System.out.println("ejbPostCreate(" + itemId + ")");
	}
	
	public ItemPK ejbCreate(String itemId) {
		System.out.println("ejbCreate(" + itemId + ")");
		// get the PM
		pm = pmf.getPersistenceManager();
		
		// construct transient object and make persistent
		product = new Product(itemId);
		pm.makePersistent(product);
		
		// obtain the key
		ItemPK productKey = (ItemPK) JDOHelper.getObjectId(product); // getTransactionalObjectId() ? 
		
		
		// return the Key
		return productKey;
	}
	
	public void ejbPostCreate(String itemId, String description, double price, String colour) {
		System.out.println("ejbPostCreate(four arguments)");
	}
	
	public ItemPK ejbCreate(String itemId, String description, double price, String colour) {
		System.out.println("ejbCreate(four arguments)");
		// get the PM
		pm = pmf.getPersistenceManager();
		
		// construct transient object and make persistent
		product = new Product(itemId, description, price, colour);
		pm.makePersistent(product);
		
		// obtain the key
		ItemPK productKey = (ItemPK) JDOHelper.getObjectId(product); // getTransactionalObjectId() ? 
		
		// return the Key
		return productKey;
		
	}
		
	
	// entity methods
	
	public void ejbLoad() {
		System.out.println("ejbLoad()");
	  // get the PM
		pm = pmf.getPersistenceManager();
		
		// construct key and obtain persistent object
		ItemPK productKey = (ItemPK) ec.getPrimaryKey();
		product = (Product) pm.getObjectById(productKey, true);
	}
	
	public void ejbStore() {
		System.out.println("ejbStore()");
		// close the PM
		pm.close();	

	}
	
	public void ejbPassivate() {
		System.out.println("ejbPassivate()");
		// nullify reference to persistent instance
		product = null;
		
		// close the PM
		pm.close();
	}
	
	public void ejbActivate() {
		System.out.println("ejbActivate()");
	  // get the PM
		pm = pmf.getPersistenceManager();
		
		// construct key and obtain persistent object
		ItemPK productKey = (ItemPK) ec.getPrimaryKey();
		product = (Product) pm.getObjectById(productKey, true);
	
	}
	
	public void ejbRemove() {
		System.out.println("ejbRemove()");
		// delete the persistent instance
		pm.deletePersistent(product);
		
	}
	
	public void setEntityContext(EntityContext ec) {

		System.out.println("setEntityContext()");
		this.ec = ec;
		try {
			InitialContext ic = new InitialContext();
			env = (Context) ic.lookup("java:comp/env");
			pmf = (PersistenceManagerFactory) env.lookup("jdo/OrderProcessingPMF"); 
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public void unsetEntityContext() {
		System.out.println("unsetEntityContext()");
		pmf = null;
	}
	
	public Collection ejbFindAll() {
		System.out.println("ejbFindAll()");
		// find all products and return a collection of primary keys
		Vector v = new Vector();
		
		Extent e = pm.getExtent(Product.class, false); // no direct inheritance support
		Iterator i = e.iterator();
		while (i.hasNext()){
			v.add(JDOHelper.getObjectId(i.next()));
		}
		
		return v;
	}
	
	public ItemPK ejbFindByPrimaryKey(ItemPK itemKey) throws FinderException {
		System.out.println("ejbFindByPrimaryKey()");
		
		
		try {
			pm = pmf.getPersistenceManager();
			Object o = pm.getObjectById(itemKey, true);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new FinderException("failed to locate object through JDO with itemId=" + itemKey.itemId);
		}
		finally {
			pm.close();
		}
		
		return itemKey;
		
	}
	
}

