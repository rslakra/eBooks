package op.ejb;

import javax.ejb.*;

import java.rmi.RemoteException;
import javax.ejb.EJBHome;
import javax.ejb.CreateException;
import op.pk.BusinessPartnerPK;

interface OrderEntryHome extends EJBHome{
    void create(BusinessPartnerPK bpKey) throws RemoteException, CreateException;
}

