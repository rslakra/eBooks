package op.ejb;

import javax.ejb.*;
import java.rmi.RemoteException;

public interface ProductEntity extends EJBObject
{	
	public String getDescription() throws RemoteException;
	public void setDescription(String description) throws RemoteException;
	
	public double getPrice() throws RemoteException;
	public void setPrice(double price) throws RemoteException;
	
	public String getColour() throws RemoteException;
	public void setColour(String colour) throws RemoteException;
	
	public String getItemId() throws RemoteException;
}

