package op.ejb;

import javax.ejb.*;
import javax.jdo.*;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.transaction.UserTransaction;
import op.*;
import op.pk.*;

public class OrderEntryBean implements SessionBean
{
	PersistenceManagerFactory pmf;
	PersistenceManager pm;
	Context env;
	Order o;
	UserTransaction ut;
	SessionContext sc;
	
	public void setSessionContext(SessionContext sc) {
		this.sc = sc;
		try{
			Context ic = new InitialContext();
			env = (Context) ic.lookup("java:comp/env");
			pmf = (PersistenceManagerFactory) env.lookup("jdo/OrderProcessingPMF");		
			ut = sc.getUserTransaction();
		}
		catch (Exception e) {
			throw new EJBException(e);
		}
	}
	
	public BusinessPartnerPK ejbCreate(BusinessPartnerPK bpKey, int newOrderNumber) {		
		try {
			ut.begin();
			pm = pmf.getPersistenceManager();
			BusinessPartner bp = (BusinessPartner) pm.getObjectById(bpKey, false);
			o = bp.getCustomer().createOrder(newOrderNumber);
			pm.makePersistent(o);		
		}
		catch (Exception e) {
			throw new EJBException(e);
		}

	  return (BusinessPartnerPK) pm.getObjectId(o);
	}
	
	public void ejbPostCreate(OrderPK k) {
	}
	
	public void addProduct(ItemPK k, int quantity) {
		//if (!ut.isActive()) throw new EJBException("addProduct called when BMT not active");
		
		try {
			Product p = (Product) pm.getObjectById(k, true);
			o.addItem(p, quantity);
		}
   	catch (Exception e) {
			throw new EJBException(e);
		}	
	}
	
	public void completeOrder() {
		try {
			ut.commit();
		}
		catch (Exception e) {
			throw new EJBException(e);
		}
	}
	
	public void discardOrder() {
		try {
			ut.rollback();
		}
		catch (Exception e) {
			throw new EJBException(e);
		}
	}
	
	
	public void ejbRemove() {
	}
	
	public void ejbActivate() {}
	public void ejbPassivate() {}
}

