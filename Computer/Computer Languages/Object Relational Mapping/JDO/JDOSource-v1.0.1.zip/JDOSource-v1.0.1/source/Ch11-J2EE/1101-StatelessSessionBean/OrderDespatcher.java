package op.ejb;

import javax.ejb.*;
import op.pk.*;
import op.ex.*;
import java.rmi.RemoteException;

interface OrderDespatcher extends EJBObject {
	void despatchOrder(OrderPK orderKey) throws RemoteException;
  void cancelOrder(OrderPK orderKey) throws OrderStatusException, RemoteException;
}

