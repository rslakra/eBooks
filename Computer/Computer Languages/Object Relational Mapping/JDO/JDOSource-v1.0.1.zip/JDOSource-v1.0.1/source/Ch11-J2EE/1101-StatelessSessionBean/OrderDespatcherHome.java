package op.ejb;

import javax.ejb.*;

interface OrderDespatcherHome extends EJBHome {
	OrderDespatcher create();
}

