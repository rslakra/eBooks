import javax.servlet.*;

public class BusinessPartnerServlet extends HttpServlet
{
	PersistenceManagerFactory pmf;
	Context env;
	
	public void init(ServletConfig config) {
		super.init(config);
		Context ic = new InitialContext();
		env = (Context) ic.lookup("java:comp/env");
		pmf = env.lookup("OrderProcessingPMF");		
	}
	
	public void doGet(HttpRequest request, HttpResponse response) {
		processRequest(request, response);
	}
	
	public void doPost(HttpRequest request, HttpResponse response) {
		processRequest(request, response);
	}
	
	private void processRequest(HttpRequest request, HttpResponse response) {
		// get the persistence manager and begin transaction
		PersistenceManager pm = pmf.getPersistenceManager();
		Transaction t = pm.currentTransaction();
		t.begin();
		// get the extent of BusinessPartner including subclasses
		Extent e = pm.getExtent(BusinessPartner.class, true);
		Iterator i = e.iterator();
		// commence output
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		// page header
		out.println("<HTML><HEAD><TITLE>Business Partners</TITLE></HEAD>">
		out.println("<BODY>");
		out.println("<H1>List of Business Partners</H1>");
		// start of table
		out.println("<TABLE><TH>ID</TH><TH>Name</TH><TH>Address</TH><TH>Type</TH>");
		
		while(i.hasNext()) {
			BusinessPartner bp = (BusinessPartner) i.next();
			out.println("<TR>");
			out.println("<TD>" + bp.getPartnerId() + "</TD>");
			out.println("<TD>" + bp.getName() + "</TD>");
			out.println("<TD>" + bp.getAddress() + "</TD>");
			out.println("<TD>" + bp.class.getName() + "</TD>");
			out.println("</TR>");			
		}
		
		//end of table
		out.println("</TABLE>");
		//end of document
		out.println("</BODY></HTML>");
		
		// output complete
		out.flush();
		e.close(i);
		t.commit();
		pm.close();
	}
}

