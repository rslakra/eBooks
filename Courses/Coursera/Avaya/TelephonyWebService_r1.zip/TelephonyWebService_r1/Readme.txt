READ ME FILE
-------------

Pre-requistes for using the contents of this zip file:

1. 'TelephonyWebService.pdf' requires Adobe Acrobat Reader 6.0 or higher for viewing.

2. 'TelephonyWebService' folder contains a Dialog Designer project and requires Avaya Dialog Designer version 4.0.7 or a more recent version installed.
 
Copy the 'TelephonyWebService' folder to the Dialog Designer workspace directory.
For Example: D:\Eclipse\workspace
Open the Dialog Designer application and click on 'Import' under the 'File' menu to include the project into the workspace.
------------------------

The following changes need to be done before running the application.

------Setting the WSDL URL and authentication details in all the wsop files-------
The wsop files are located under TelephonyWebService/connectivity/wsoperations folder.

1. Double click on the wsop file to open the Web Service Operation Editor.
2. In the Web Service Information section, change the WSDL URL to point to the AES Telephony Web service.
3. In the Authentication section, change the User Name and Password fields as per the AES CT user settings.
4. Save the wsop file to apply the changes.

-------Setting the Grammar Compatibility-------
1. Right click on project and select the properties menu. 
2. In the properties window select Dialog Designer menu, and then select the speech tab. 
3. In the speech tab window, the Grammar Compatibility drop down list enumerates the supported Grammar formats.
4. Select the Grammar format supported by the speech Recognizer. If the application is being tested on desktop, select Grammar format as SRGS .

-------Setting the runtime-Platform--------
1. Right click on project and select properties.
2. Select Dialog Designer menu, and then select the Web Descriptor tab. 
3. In the Web Descriptor tab select the runtime-Platform option under Parameters section.
4. Click on edit button to edit the runtime-Platform value as per the setup available for running the application.

-------Jar file requirements-------
Ensure that the following jar files are present in the build path.
axis.jar
jaxrpc.jar
-------------Adding Jar files to the build path------------------
1. Right click project and select properties. 
2. In properties window, select Java Build Path, and add the required jar files.
       