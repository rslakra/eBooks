/**
 * Result.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package connectivity.ws.beans;

public class Result  implements java.io.Serializable {
    private int result_code;

    private java.lang.String result_data;

    private java.lang.String message_text;

    public Result() {
    }

    public Result(
           int result_code,
           java.lang.String result_data,
           java.lang.String message_text) {
           this.result_code = result_code;
           this.result_data = result_data;
           this.message_text = message_text;
    }


    /**
     * Gets the result_code value for this Result.
     * 
     * @return result_code
     */
    public int getResult_code() {
        return result_code;
    }


    /**
     * Sets the result_code value for this Result.
     * 
     * @param result_code
     */
    public void setResult_code(int result_code) {
        this.result_code = result_code;
    }


    /**
     * Gets the result_data value for this Result.
     * 
     * @return result_data
     */
    public java.lang.String getResult_data() {
        return result_data;
    }


    /**
     * Sets the result_data value for this Result.
     * 
     * @param result_data
     */
    public void setResult_data(java.lang.String result_data) {
        this.result_data = result_data;
    }


    /**
     * Gets the message_text value for this Result.
     * 
     * @return message_text
     */
    public java.lang.String getMessage_text() {
        return message_text;
    }


    /**
     * Sets the message_text value for this Result.
     * 
     * @param message_text
     */
    public void setMessage_text(java.lang.String message_text) {
        this.message_text = message_text;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Result)) return false;
        Result other = (Result) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.result_code == other.getResult_code() &&
            ((this.result_data==null && other.getResult_data()==null) || 
             (this.result_data!=null &&
              this.result_data.equals(other.getResult_data()))) &&
            ((this.message_text==null && other.getMessage_text()==null) || 
             (this.message_text!=null &&
              this.message_text.equals(other.getMessage_text())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getResult_code();
        if (getResult_data() != null) {
            _hashCode += getResult_data().hashCode();
        }
        if (getMessage_text() != null) {
            _hashCode += getMessage_text().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Result.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xml.avaya.com/ws/SystemManagementService/2005/04/04", "Result"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("result_code");
        elemField.setXmlName(new javax.xml.namespace.QName("", "result_code"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("result_data");
        elemField.setXmlName(new javax.xml.namespace.QName("", "result_data"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("message_text");
        elemField.setXmlName(new javax.xml.namespace.QName("", "message_text"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
