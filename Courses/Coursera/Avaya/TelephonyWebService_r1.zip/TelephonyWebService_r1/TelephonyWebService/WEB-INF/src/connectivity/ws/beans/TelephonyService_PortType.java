/**
 * TelephonyService_PortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package connectivity.ws.beans;

public interface TelephonyService_PortType extends java.rmi.Remote {
    public connectivity.ws.beans.Empty release(java.lang.String nothing) throws java.rmi.RemoteException, connectivity.ws.beans.InvalidSessionException;
    public connectivity.ws.beans.Empty attach(java.lang.String nothing) throws java.rmi.RemoteException, connectivity.ws.beans.InvalidSessionException, connectivity.ws.beans.InvalidCredentialsException, connectivity.ws.beans.SwitchNotReachableException;
    public void makeCall(java.lang.String originatingExtension, java.lang.String destinationNumber) throws java.rmi.RemoteException, connectivity.ws.beans.InvalidSessionException, connectivity.ws.beans.InvalidCredentialsException, connectivity.ws.beans.SwitchNotReachableException, connectivity.ws.beans.InvalidPartyException, connectivity.ws.beans.ActiveCallExistsException;
    public void disconnectActiveCall(java.lang.String extension) throws java.rmi.RemoteException, connectivity.ws.beans.InvalidSessionException, connectivity.ws.beans.InvalidCredentialsException, connectivity.ws.beans.SwitchNotReachableException, connectivity.ws.beans.InvalidPartyException, connectivity.ws.beans.NoActiveCallException;
    public void singleStepTransferCall(java.lang.String originatingExtension, java.lang.String destinationNumber) throws java.rmi.RemoteException, connectivity.ws.beans.InvalidSessionException, connectivity.ws.beans.InvalidCredentialsException, connectivity.ws.beans.SwitchNotReachableException, connectivity.ws.beans.InvalidPartyException, connectivity.ws.beans.NoActiveCallException;
    public void singleStepConferenceCall(java.lang.String originatingExtension, java.lang.String destinationNumber) throws java.rmi.RemoteException, connectivity.ws.beans.InvalidSessionException, connectivity.ws.beans.InvalidCredentialsException, connectivity.ws.beans.SwitchNotReachableException, connectivity.ws.beans.InvalidPartyException, connectivity.ws.beans.NoActiveCallException;
    public void answerAlertingCall(java.lang.String extension) throws java.rmi.RemoteException, connectivity.ws.beans.NoAlertingCallException, connectivity.ws.beans.InvalidSessionException, connectivity.ws.beans.InvalidCredentialsException, connectivity.ws.beans.SwitchNotReachableException, connectivity.ws.beans.InvalidPartyException, connectivity.ws.beans.ActiveCallExistsException;
}
