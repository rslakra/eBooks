/**
 * TelephonyServiceSoapBindingStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package connectivity.ws.beans;

public class TelephonyServiceSoapBindingStub extends org.apache.axis.client.Stub implements connectivity.ws.beans.TelephonyService_PortType {
    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[7];
        _initOperationDesc1();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("release");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://TelephonyService.ws.avaya.com", "release"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://TelephonyService.ws.avaya.com", "empty"));
        oper.setReturnClass(connectivity.ws.beans.Empty.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://TelephonyService.ws.avaya.com", "releaseResponse"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "InvalidSessionException"),
                      "connectivity.ws.beans.InvalidSessionException",
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "InvalidSessionException"), 
                      true
                     ));
        _operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("attach");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://TelephonyService.ws.avaya.com", "attach"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://TelephonyService.ws.avaya.com", "empty"));
        oper.setReturnClass(connectivity.ws.beans.Empty.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://TelephonyService.ws.avaya.com", "attachResponse"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "InvalidSessionException"),
                      "connectivity.ws.beans.InvalidSessionException",
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "InvalidSessionException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "InvalidCredentialsException"),
                      "connectivity.ws.beans.InvalidCredentialsException",
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "InvalidCredentialsException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "SwitchNotReachableException"),
                      "connectivity.ws.beans.SwitchNotReachableException",
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "SwitchNotReachableException"), 
                      true
                     ));
        _operations[1] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("makeCall");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "originatingExtension"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "destinationNumber"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "InvalidSessionException"),
                      "connectivity.ws.beans.InvalidSessionException",
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "InvalidSessionException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "InvalidCredentialsException"),
                      "connectivity.ws.beans.InvalidCredentialsException",
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "InvalidCredentialsException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "SwitchNotReachableException"),
                      "connectivity.ws.beans.SwitchNotReachableException",
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "SwitchNotReachableException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "InvalidPartyException"),
                      "connectivity.ws.beans.InvalidPartyException",
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "InvalidPartyException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "ActiveCallExistsException"),
                      "connectivity.ws.beans.ActiveCallExistsException",
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "ActiveCallExistsException"), 
                      true
                     ));
        _operations[2] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("disconnectActiveCall");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "extension"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "InvalidSessionException"),
                      "connectivity.ws.beans.InvalidSessionException",
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "InvalidSessionException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "InvalidCredentialsException"),
                      "connectivity.ws.beans.InvalidCredentialsException",
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "InvalidCredentialsException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "SwitchNotReachableException"),
                      "connectivity.ws.beans.SwitchNotReachableException",
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "SwitchNotReachableException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "InvalidPartyException"),
                      "connectivity.ws.beans.InvalidPartyException",
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "InvalidPartyException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "NoActiveCallException"),
                      "connectivity.ws.beans.NoActiveCallException",
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "NoActiveCallException"), 
                      true
                     ));
        _operations[3] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("singleStepTransferCall");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "originatingExtension"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "destinationNumber"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "InvalidSessionException"),
                      "connectivity.ws.beans.InvalidSessionException",
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "InvalidSessionException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "InvalidCredentialsException"),
                      "connectivity.ws.beans.InvalidCredentialsException",
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "InvalidCredentialsException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "SwitchNotReachableException"),
                      "connectivity.ws.beans.SwitchNotReachableException",
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "SwitchNotReachableException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "InvalidPartyException"),
                      "connectivity.ws.beans.InvalidPartyException",
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "InvalidPartyException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "NoActiveCallException"),
                      "connectivity.ws.beans.NoActiveCallException",
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "NoActiveCallException"), 
                      true
                     ));
        _operations[4] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("singleStepConferenceCall");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "originatingExtension"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "destinationNumber"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "InvalidSessionException"),
                      "connectivity.ws.beans.InvalidSessionException",
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "InvalidSessionException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "InvalidCredentialsException"),
                      "connectivity.ws.beans.InvalidCredentialsException",
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "InvalidCredentialsException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "SwitchNotReachableException"),
                      "connectivity.ws.beans.SwitchNotReachableException",
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "SwitchNotReachableException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "InvalidPartyException"),
                      "connectivity.ws.beans.InvalidPartyException",
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "InvalidPartyException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "NoActiveCallException"),
                      "connectivity.ws.beans.NoActiveCallException",
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "NoActiveCallException"), 
                      true
                     ));
        _operations[5] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("answerAlertingCall");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "extension"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "NoAlertingCallException"),
                      "connectivity.ws.beans.NoAlertingCallException",
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "NoAlertingCallException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "InvalidSessionException"),
                      "connectivity.ws.beans.InvalidSessionException",
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "InvalidSessionException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "InvalidCredentialsException"),
                      "connectivity.ws.beans.InvalidCredentialsException",
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "InvalidCredentialsException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "SwitchNotReachableException"),
                      "connectivity.ws.beans.SwitchNotReachableException",
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "SwitchNotReachableException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "InvalidPartyException"),
                      "connectivity.ws.beans.InvalidPartyException",
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "InvalidPartyException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "ActiveCallExistsException"),
                      "connectivity.ws.beans.ActiveCallExistsException",
                      new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "ActiveCallExistsException"), 
                      true
                     ));
        _operations[6] = oper;

    }

    public TelephonyServiceSoapBindingStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public TelephonyServiceSoapBindingStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

    public TelephonyServiceSoapBindingStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.2");
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "ActiveCallExistsException");
            cachedSerQNames.add(qName);
            cls = connectivity.ws.beans.ActiveCallExistsException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "BasicTelephonyException");
            cachedSerQNames.add(qName);
            cls = connectivity.ws.beans.BasicTelephonyException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "InvalidCredentialsException");
            cachedSerQNames.add(qName);
            cls = connectivity.ws.beans.InvalidCredentialsException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "InvalidPartyException");
            cachedSerQNames.add(qName);
            cls = connectivity.ws.beans.InvalidPartyException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "InvalidSessionException");
            cachedSerQNames.add(qName);
            cls = connectivity.ws.beans.InvalidSessionException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "NoActiveCallException");
            cachedSerQNames.add(qName);
            cls = connectivity.ws.beans.NoActiveCallException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "NoAlertingCallException");
            cachedSerQNames.add(qName);
            cls = connectivity.ws.beans.NoAlertingCallException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://basictelephony.api.avaya.com", "SwitchNotReachableException");
            cachedSerQNames.add(qName);
            cls = connectivity.ws.beans.SwitchNotReachableException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }

    protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setEncodingStyle(null);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        java.lang.Object x = cachedSerFactories.get(i);
                        if (x instanceof Class) {
                            java.lang.Class sf = (java.lang.Class)
                                 cachedSerFactories.get(i);
                            java.lang.Class df = (java.lang.Class)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                        else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
                            org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
                                 cachedSerFactories.get(i);
                            org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                    }
                }
            }
            return _call;
        }
        catch (java.lang.Throwable _t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
        }
    }

    public connectivity.ws.beans.Empty release(java.lang.String nothing) throws java.rmi.RemoteException, connectivity.ws.beans.InvalidSessionException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://TelephonyService.ws.avaya.com", "release"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {nothing});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (connectivity.ws.beans.Empty) _resp;
            } catch (java.lang.Exception _exception) {
                return (connectivity.ws.beans.Empty) org.apache.axis.utils.JavaUtils.convert(_resp, connectivity.ws.beans.Empty.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof connectivity.ws.beans.InvalidSessionException) {
              throw (connectivity.ws.beans.InvalidSessionException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public connectivity.ws.beans.Empty attach(java.lang.String nothing) throws java.rmi.RemoteException, connectivity.ws.beans.InvalidSessionException, connectivity.ws.beans.InvalidCredentialsException, connectivity.ws.beans.SwitchNotReachableException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[1]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://TelephonyService.ws.avaya.com", "attach"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {nothing});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (connectivity.ws.beans.Empty) _resp;
            } catch (java.lang.Exception _exception) {
                return (connectivity.ws.beans.Empty) org.apache.axis.utils.JavaUtils.convert(_resp, connectivity.ws.beans.Empty.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof connectivity.ws.beans.InvalidSessionException) {
              throw (connectivity.ws.beans.InvalidSessionException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof connectivity.ws.beans.InvalidCredentialsException) {
              throw (connectivity.ws.beans.InvalidCredentialsException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof connectivity.ws.beans.SwitchNotReachableException) {
              throw (connectivity.ws.beans.SwitchNotReachableException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public void makeCall(java.lang.String originatingExtension, java.lang.String destinationNumber) throws java.rmi.RemoteException, connectivity.ws.beans.InvalidSessionException, connectivity.ws.beans.InvalidCredentialsException, connectivity.ws.beans.SwitchNotReachableException, connectivity.ws.beans.InvalidPartyException, connectivity.ws.beans.ActiveCallExistsException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[2]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://TelephonyService.ws.avaya.com", "makeCall"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {originatingExtension, destinationNumber});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof connectivity.ws.beans.InvalidSessionException) {
              throw (connectivity.ws.beans.InvalidSessionException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof connectivity.ws.beans.InvalidCredentialsException) {
              throw (connectivity.ws.beans.InvalidCredentialsException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof connectivity.ws.beans.SwitchNotReachableException) {
              throw (connectivity.ws.beans.SwitchNotReachableException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof connectivity.ws.beans.InvalidPartyException) {
              throw (connectivity.ws.beans.InvalidPartyException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof connectivity.ws.beans.ActiveCallExistsException) {
              throw (connectivity.ws.beans.ActiveCallExistsException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public void disconnectActiveCall(java.lang.String extension) throws java.rmi.RemoteException, connectivity.ws.beans.InvalidSessionException, connectivity.ws.beans.InvalidCredentialsException, connectivity.ws.beans.SwitchNotReachableException, connectivity.ws.beans.InvalidPartyException, connectivity.ws.beans.NoActiveCallException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[3]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://TelephonyService.ws.avaya.com", "disconnectActiveCall"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {extension});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof connectivity.ws.beans.InvalidSessionException) {
              throw (connectivity.ws.beans.InvalidSessionException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof connectivity.ws.beans.InvalidCredentialsException) {
              throw (connectivity.ws.beans.InvalidCredentialsException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof connectivity.ws.beans.SwitchNotReachableException) {
              throw (connectivity.ws.beans.SwitchNotReachableException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof connectivity.ws.beans.InvalidPartyException) {
              throw (connectivity.ws.beans.InvalidPartyException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof connectivity.ws.beans.NoActiveCallException) {
              throw (connectivity.ws.beans.NoActiveCallException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public void singleStepTransferCall(java.lang.String originatingExtension, java.lang.String destinationNumber) throws java.rmi.RemoteException, connectivity.ws.beans.InvalidSessionException, connectivity.ws.beans.InvalidCredentialsException, connectivity.ws.beans.SwitchNotReachableException, connectivity.ws.beans.InvalidPartyException, connectivity.ws.beans.NoActiveCallException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[4]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://TelephonyService.ws.avaya.com", "singleStepTransferCall"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {originatingExtension, destinationNumber});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof connectivity.ws.beans.InvalidSessionException) {
              throw (connectivity.ws.beans.InvalidSessionException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof connectivity.ws.beans.InvalidCredentialsException) {
              throw (connectivity.ws.beans.InvalidCredentialsException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof connectivity.ws.beans.SwitchNotReachableException) {
              throw (connectivity.ws.beans.SwitchNotReachableException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof connectivity.ws.beans.InvalidPartyException) {
              throw (connectivity.ws.beans.InvalidPartyException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof connectivity.ws.beans.NoActiveCallException) {
              throw (connectivity.ws.beans.NoActiveCallException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public void singleStepConferenceCall(java.lang.String originatingExtension, java.lang.String destinationNumber) throws java.rmi.RemoteException, connectivity.ws.beans.InvalidSessionException, connectivity.ws.beans.InvalidCredentialsException, connectivity.ws.beans.SwitchNotReachableException, connectivity.ws.beans.InvalidPartyException, connectivity.ws.beans.NoActiveCallException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[5]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://TelephonyService.ws.avaya.com", "singleStepConferenceCall"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {originatingExtension, destinationNumber});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof connectivity.ws.beans.InvalidSessionException) {
              throw (connectivity.ws.beans.InvalidSessionException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof connectivity.ws.beans.InvalidCredentialsException) {
              throw (connectivity.ws.beans.InvalidCredentialsException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof connectivity.ws.beans.SwitchNotReachableException) {
              throw (connectivity.ws.beans.SwitchNotReachableException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof connectivity.ws.beans.InvalidPartyException) {
              throw (connectivity.ws.beans.InvalidPartyException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof connectivity.ws.beans.NoActiveCallException) {
              throw (connectivity.ws.beans.NoActiveCallException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public void answerAlertingCall(java.lang.String extension) throws java.rmi.RemoteException, connectivity.ws.beans.NoAlertingCallException, connectivity.ws.beans.InvalidSessionException, connectivity.ws.beans.InvalidCredentialsException, connectivity.ws.beans.SwitchNotReachableException, connectivity.ws.beans.InvalidPartyException, connectivity.ws.beans.ActiveCallExistsException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[6]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://TelephonyService.ws.avaya.com", "answerAlertingCall"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {extension});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof connectivity.ws.beans.NoAlertingCallException) {
              throw (connectivity.ws.beans.NoAlertingCallException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof connectivity.ws.beans.InvalidSessionException) {
              throw (connectivity.ws.beans.InvalidSessionException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof connectivity.ws.beans.InvalidCredentialsException) {
              throw (connectivity.ws.beans.InvalidCredentialsException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof connectivity.ws.beans.SwitchNotReachableException) {
              throw (connectivity.ws.beans.SwitchNotReachableException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof connectivity.ws.beans.InvalidPartyException) {
              throw (connectivity.ws.beans.InvalidPartyException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof connectivity.ws.beans.ActiveCallExistsException) {
              throw (connectivity.ws.beans.ActiveCallExistsException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

}
