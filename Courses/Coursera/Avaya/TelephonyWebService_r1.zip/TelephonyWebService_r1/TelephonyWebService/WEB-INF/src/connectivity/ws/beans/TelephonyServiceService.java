/**
 * TelephonyServiceService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package connectivity.ws.beans;

public interface TelephonyServiceService extends javax.xml.rpc.Service {
    public java.lang.String getTelephonyServiceAddress();

    public connectivity.ws.beans.TelephonyService_PortType getTelephonyService() throws javax.xml.rpc.ServiceException;

    public connectivity.ws.beans.TelephonyService_PortType getTelephonyService(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
