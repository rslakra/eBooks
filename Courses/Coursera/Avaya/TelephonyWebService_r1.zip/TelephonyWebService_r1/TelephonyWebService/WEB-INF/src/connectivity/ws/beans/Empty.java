package connectivity.ws.beans;

public class Empty {

}
