/**
 * TelephonyServiceServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package connectivity.ws.beans;

public class TelephonyServiceServiceLocator extends org.apache.axis.client.Service implements connectivity.ws.beans.TelephonyServiceService {

    public TelephonyServiceServiceLocator() {
    }


    public TelephonyServiceServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public TelephonyServiceServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for TelephonyService
    private java.lang.String TelephonyService_address = "http://192.168.146.136:8080/axis/services/TelephonyService";

    public java.lang.String getTelephonyServiceAddress() {
        return TelephonyService_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String TelephonyServiceWSDDServiceName = "TelephonyService";

    public java.lang.String getTelephonyServiceWSDDServiceName() {
        return TelephonyServiceWSDDServiceName;
    }

    public void setTelephonyServiceWSDDServiceName(java.lang.String name) {
        TelephonyServiceWSDDServiceName = name;
    }

    public connectivity.ws.beans.TelephonyService_PortType getTelephonyService() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(TelephonyService_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getTelephonyService(endpoint);
    }

    public connectivity.ws.beans.TelephonyService_PortType getTelephonyService(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            connectivity.ws.beans.TelephonyServiceSoapBindingStub _stub = new connectivity.ws.beans.TelephonyServiceSoapBindingStub(portAddress, this);
            _stub.setPortName(getTelephonyServiceWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setTelephonyServiceEndpointAddress(java.lang.String address) {
        TelephonyService_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (connectivity.ws.beans.TelephonyService_PortType.class.isAssignableFrom(serviceEndpointInterface)) {
                connectivity.ws.beans.TelephonyServiceSoapBindingStub _stub = new connectivity.ws.beans.TelephonyServiceSoapBindingStub(new java.net.URL(TelephonyService_address), this);
                _stub.setPortName(getTelephonyServiceWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("TelephonyService".equals(inputPortName)) {
            return getTelephonyService();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://xml.avaya.com/ws/TelephonyService/2005/04/04", "TelephonyServiceService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://xml.avaya.com/ws/TelephonyService/2005/04/04", "TelephonyService"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("TelephonyService".equals(portName)) {
            setTelephonyServiceEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
