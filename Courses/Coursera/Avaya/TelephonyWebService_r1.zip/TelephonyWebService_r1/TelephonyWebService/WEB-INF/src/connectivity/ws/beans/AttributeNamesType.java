/**
 * AttributeNamesType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package connectivity.ws.beans;

public class AttributeNamesType  implements java.io.Serializable {
    private java.lang.String[] attributeNames;

    public AttributeNamesType() {
    }

    public AttributeNamesType(
           java.lang.String[] attributeNames) {
           this.attributeNames = attributeNames;
    }


    /**
     * Gets the attributeNames value for this AttributeNamesType.
     * 
     * @return attributeNames
     */
    public java.lang.String[] getAttributeNames() {
        return attributeNames;
    }


    /**
     * Sets the attributeNames value for this AttributeNamesType.
     * 
     * @param attributeNames
     */
    public void setAttributeNames(java.lang.String[] attributeNames) {
        this.attributeNames = attributeNames;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AttributeNamesType)) return false;
        AttributeNamesType other = (AttributeNamesType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.attributeNames==null && other.getAttributeNames()==null) || 
             (this.attributeNames!=null &&
              java.util.Arrays.equals(this.attributeNames, other.getAttributeNames())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAttributeNames() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAttributeNames());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAttributeNames(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AttributeNamesType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:userspace.ws.avaya.com", "AttributeNamesType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attributeNames");
        elemField.setXmlName(new javax.xml.namespace.QName("", "attributeNames"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "attributeName"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
