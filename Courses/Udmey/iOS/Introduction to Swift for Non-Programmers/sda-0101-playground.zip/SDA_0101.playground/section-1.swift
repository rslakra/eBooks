// playground 0101
// You can download this playground at
// http://swiftdeveloper.academy

// variables + constants

let numberOfWheels = 4
let location = "Atlanta"

location = "Springfield"

