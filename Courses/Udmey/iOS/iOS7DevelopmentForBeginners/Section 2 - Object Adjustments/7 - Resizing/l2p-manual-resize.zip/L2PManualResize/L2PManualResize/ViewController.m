//
//  ViewController.m
//  L2PManualResize
//
//  Created by Vector Prime on 7/15/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize bigButton;
- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration
{
  if ( toInterfaceOrientation == UIInterfaceOrientationLandscapeLeft || toInterfaceOrientation == UIInterfaceOrientationLandscapeRight)
  {
    self.bigButton.frame = CGRectMake(20, 10, 440, 280);
  }
  else
  {
    self.bigButton.frame = CGRectMake(10, 10, 280, 440);
  }
}

@end
