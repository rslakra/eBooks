//
//  ViewController.h
//  L2PAutoResizing
//
//  Created by Vector Prime on 7/14/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
