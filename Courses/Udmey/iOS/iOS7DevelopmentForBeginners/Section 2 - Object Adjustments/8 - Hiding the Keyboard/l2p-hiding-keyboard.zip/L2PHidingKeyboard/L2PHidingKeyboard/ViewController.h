//
//  ViewController.h
//  L2PHidingKeyboard
//
//  Created by Vector Prime on 7/15/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (strong, nonatomic) IBOutlet UILabel *lblResult;

- (IBAction)sendMessage:(id)sender;

@property (strong, nonatomic) IBOutlet UITextField *userText;


- (IBAction)endTyping:(id)sender;



@end
