//
//  ViewController.m
//  L2PHidingKeyboard
//
//  Created by Vector Prime on 7/15/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize lblResult,userText;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)sendMessage:(id)sender {
  lblResult.text = userText.text;
}

- (IBAction)endTyping:(id)sender {
  [sender resignFirstResponder];
}
@end
