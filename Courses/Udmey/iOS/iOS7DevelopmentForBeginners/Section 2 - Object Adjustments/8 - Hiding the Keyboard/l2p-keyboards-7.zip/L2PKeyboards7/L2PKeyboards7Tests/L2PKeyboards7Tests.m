//
//  L2PKeyboards7Tests.m
//  L2PKeyboards7Tests
//
//  Created by Vector Prime on 7/15/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface L2PKeyboards7Tests : XCTestCase

@end

@implementation L2PKeyboards7Tests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
