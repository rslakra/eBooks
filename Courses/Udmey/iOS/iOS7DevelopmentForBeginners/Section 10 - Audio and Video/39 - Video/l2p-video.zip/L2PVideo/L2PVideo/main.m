//
//  main.m
//  L2PVideo
//
//  Created by Vector Prime on 7/25/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
  }
}
