//
//  ViewController.h
//  L2PVideo
//
//  Created by Vector Prime on 7/25/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>

@interface ViewController : UIViewController
- (IBAction)btnPlay:(id)sender;


@end
