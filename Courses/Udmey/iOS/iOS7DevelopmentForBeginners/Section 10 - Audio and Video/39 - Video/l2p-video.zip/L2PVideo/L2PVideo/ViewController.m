//
//  ViewController.m
//  L2PVideo
//
//  Created by Vector Prime on 7/25/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnPlay:(id)sender {
  NSString *pathToMovie = [[NSBundle mainBundle] pathForResource:@"Test Video" ofType:@"mp4"];
  NSURL *mURL = [NSURL fileURLWithPath:pathToMovie];
  MPMoviePlayerController *moviePlayer = [[MPMoviePlayerController alloc] initWithContentURL:mURL];
  
  [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(movieComplete:) name:MPMoviePlayerPlaybackDidFinishNotification object:moviePlayer];
  [self.view addSubview: moviePlayer.view];
  moviePlayer.fullscreen = YES;
  [moviePlayer play];
}

-(void) movieComplete:(NSNotification *)notification
{
  MPMoviePlayerController *moviePlayerController = [notification object];
  [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerPlaybackDidFinishNotification object: moviePlayerController];
  
  [moviePlayerController.view removeFromSuperview];
  moviePlayerController = nil;
}
@end
