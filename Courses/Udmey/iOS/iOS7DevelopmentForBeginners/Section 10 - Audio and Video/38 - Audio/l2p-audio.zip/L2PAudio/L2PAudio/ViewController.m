//
//  ViewController.m
//  L2PAudio
//
//  Created by Vector Prime on 7/25/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize audioPlayer1;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnPlay:(id)sender {
  NSURL *urlAudio = [NSURL fileURLWithPath:[NSString stringWithFormat: @"%@/Dubstep Free Beat.mp3", [[NSBundle mainBundle] resourcePath]]];
  
  NSError *audioError;
  
  audioPlayer1 = [[AVAudioPlayer alloc] initWithContentsOfURL: urlAudio error:&audioError];
  audioPlayer1.numberOfLoops =-1;
  if(audioPlayer1 == nil)
  {
    NSLog([ audioError description]);
  }
  else
  {
    [audioPlayer1 play];
  }
}

- (IBAction)btnPause:(id)sender {
  [audioPlayer1 pause];
}

- (IBAction)btnStop:(id)sender {
  [audioPlayer1 stop];
}
@end
