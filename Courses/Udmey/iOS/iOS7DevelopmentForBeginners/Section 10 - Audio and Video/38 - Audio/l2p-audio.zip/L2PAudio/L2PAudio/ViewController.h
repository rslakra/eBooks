//
//  ViewController.h
//  L2PAudio
//
//  Created by Vector Prime on 7/25/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

@interface ViewController : UIViewController
- (IBAction)btnPlay:(id)sender;
- (IBAction)btnPause:(id)sender;
- (IBAction)btnStop:(id)sender;

@property AVAudioPlayer *audioPlayer1;
@end
