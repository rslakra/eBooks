//
//  L2PConditionalResourceLoadingTests.m
//  L2PConditionalResourceLoadingTests
//
//  Created by Vector Prime on 8/10/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface L2PConditionalResourceLoadingTests : XCTestCase

@end

@implementation L2PConditionalResourceLoadingTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
