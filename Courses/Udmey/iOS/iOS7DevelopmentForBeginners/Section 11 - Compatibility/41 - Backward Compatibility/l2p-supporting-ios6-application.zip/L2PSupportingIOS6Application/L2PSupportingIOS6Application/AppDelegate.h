//
//  AppDelegate.h
//  L2PSupportingIOS6Application
//
//  Created by Vector Prime on 8/10/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
