//
//  ViewController2.h
//  L2PPassingData
//
//  Created by Vector Prime on 7/22/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController2 : UIViewController

@property (strong, nonatomic) IBOutlet UILabel *lblResult;
@property int passedResult;
@end
