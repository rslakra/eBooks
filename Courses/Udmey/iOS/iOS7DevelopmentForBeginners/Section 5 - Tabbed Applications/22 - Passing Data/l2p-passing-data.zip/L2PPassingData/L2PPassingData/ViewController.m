//
//  ViewController.m
//  L2PPassingData
//
//  Created by Vector Prime on 7/22/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import "ViewController.h"
#import "ViewController2.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize number1,number2;

-(void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
  int addedValues = [number1.text integerValue] + [number2.text integerValue];
 
  if([[segue identifier] isEqualToString: @"mySegue"])
  {
    ViewController2 *viewController2 = [segue destinationViewController];
    
    viewController2.passedResult = addedValues;
  }
}
- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
  
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
