//
//  L2PTabbedApplicationTemplateTests.m
//  L2PTabbedApplicationTemplateTests
//
//  Created by Vector Prime on 7/20/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface L2PTabbedApplicationTemplateTests : XCTestCase

@end

@implementation L2PTabbedApplicationTemplateTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
