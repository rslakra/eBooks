//
//  ViewController.m
//  L2PCustomPicker
//
//  Created by Vector Prime on 7/19/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize pickerVideoGameSystem,lblDisplayPickerChoice,videoGameSystemNames;

- (void)viewDidLoad
{
    [super viewDidLoad];
  videoGameSystemNames =  @[@"SNES", @"Nintendo 64", @"Playstation 1", @"Playstation 2", @"XBox 360", @"Xbox", @"Atari"];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark -
#pragma mark PickerView DataSource

-(NSInteger) numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
  return 1; 
}

-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
  return [videoGameSystemNames count];
}

-(NSString * )pickerView:(UIPickerView*)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
  return [videoGameSystemNames objectAtIndex:row];
}

#pragma mark -
#pragma mark PickerView Delegate

-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
  lblDisplayPickerChoice.text = [videoGameSystemNames objectAtIndex:row];
}

@end

