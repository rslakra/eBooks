//
//  ViewController.h
//  L2PCustomPicker
//
//  Created by Vector Prime on 7/19/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <
UIPickerViewDataSource,UIPickerViewDelegate>
@property (strong, nonatomic) IBOutlet UIPickerView *pickerVideoGameSystem;

@property (strong, nonatomic) IBOutlet UILabel *lblDisplayPickerChoice;

@property (strong,nonatomic) NSArray *videoGameSystemNames;

@end
