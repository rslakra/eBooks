//
//  ViewController.m
//  L2PDatePickerExample
//
//  Created by Vector Prime on 7/16/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize myDatePicker,lblUserDate;
- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)readDate {
  
  NSLocale *usaLocale = [[NSLocale alloc]initWithLocaleIdentifier:@"en_US"];
  
  NSDate *userDate = [myDatePicker date];
  
  NSString *outputString = [[NSString alloc]initWithFormat:@"%@", [userDate descriptionWithLocale:(usaLocale)]];
  
  lblUserDate.text = outputString;
}
@end
