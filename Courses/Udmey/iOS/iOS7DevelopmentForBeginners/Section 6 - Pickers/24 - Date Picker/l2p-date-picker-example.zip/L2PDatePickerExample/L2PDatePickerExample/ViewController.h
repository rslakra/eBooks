//
//  ViewController.h
//  L2PDatePickerExample
//
//  Created by Vector Prime on 7/16/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (strong, nonatomic) IBOutlet UIDatePicker *myDatePicker;
@property (strong, nonatomic) IBOutlet UILabel *lblUserDate;

- (IBAction)readDate;


@end
