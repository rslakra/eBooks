//
//  ViewController.m
//  L2PArchiving
//
//  Created by Vector Prime on 7/23/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize txtFirstName,txtLastName,txtAddress,filePath;
- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnArchive:(id)sender {
 
  NSMutableArray *userInfo = [[NSMutableArray alloc] init];
  [userInfo addObject:txtFirstName.text];
  [userInfo addObject:txtLastName.text];
  [userInfo addObject:txtAddress.text];
  
  [NSKeyedArchiver archiveRootObject:userInfo toFile: filePath];
  
}

- (IBAction)btnLoad:(id)sender {
  
  NSFileManager *fileManager;
  NSString *dir;
  NSArray *dirPaths;
  NSMutableArray *userData;
  
  fileManager = [NSFileManager defaultManager];
  dirPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
  
  dir = [dirPaths objectAtIndex:0];
  filePath = [[NSString alloc] initWithString: [dir stringByAppendingPathComponent:@"userInfo.dat"]];
  
  if([fileManager fileExistsAtPath:filePath])
  {
    userData = [NSKeyedUnarchiver unarchiveObjectWithFile:filePath];
    txtFirstName.text = [userData objectAtIndex:0];
    txtLastName.text = [userData objectAtIndex:1];
    txtAddress.text = [userData objectAtIndex:2];
  }
  
}
@end
