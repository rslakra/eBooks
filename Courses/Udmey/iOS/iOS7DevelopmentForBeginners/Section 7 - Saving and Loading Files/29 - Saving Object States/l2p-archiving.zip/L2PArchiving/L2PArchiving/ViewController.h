//
//  ViewController.h
//  L2PArchiving
//
//  Created by Vector Prime on 7/23/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (strong, nonatomic) IBOutlet UITextField *txtFirstName;
@property (strong, nonatomic) IBOutlet UITextField *txtLastName;
@property (strong, nonatomic) IBOutlet UITextField *txtAddress;
@property NSString * filePath;

- (IBAction)btnArchive:(id)sender;

- (IBAction)btnLoad:(id)sender;

@end
