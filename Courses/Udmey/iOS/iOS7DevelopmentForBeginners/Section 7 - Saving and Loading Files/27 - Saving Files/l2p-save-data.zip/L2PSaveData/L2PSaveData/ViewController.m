//
//  ViewController.m
//  L2PSaveData
//
//  Created by Vector Prime on 7/22/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize saveUserData;
- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnSave:(id)sender {
  NSFileManager *filemanager1;
  NSData *inputDataBuffer;
  NSString *dataFile;
  NSString *dir;
  NSArray *dirPaths;
  
  filemanager1 = [NSFileManager defaultManager];
  dirPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
  
  dir = [dirPaths objectAtIndex:0];
  dataFile = [dir stringByAppendingPathComponent:@"testData.dat"];
  
  inputDataBuffer = [saveUserData.text dataUsingEncoding:NSASCIIStringEncoding];
  
  [filemanager1 createFileAtPath:dataFile contents:inputDataBuffer attributes:nil];
  
}
@end
