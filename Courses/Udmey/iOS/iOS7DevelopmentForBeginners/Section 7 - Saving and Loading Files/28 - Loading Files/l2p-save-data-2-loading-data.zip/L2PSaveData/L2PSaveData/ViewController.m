//
//  ViewController.m
//  L2PSaveData
//
//  Created by Vector Prime on 7/22/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize saveUserData;
@synthesize lblSavedContent;
- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnSave:(id)sender {
  NSFileManager *filemanager1;
  NSData *inputDataBuffer;
  NSString *dataFile;
  NSString *dir;
  NSArray *dirPaths;
  
  filemanager1 = [NSFileManager defaultManager];
  dirPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
  
  dir = [dirPaths objectAtIndex:0];
  dataFile = [dir stringByAppendingPathComponent:@"testData.dat"];
  
  inputDataBuffer = [saveUserData.text dataUsingEncoding:NSASCIIStringEncoding];
  
  [filemanager1 createFileAtPath:dataFile contents:inputDataBuffer attributes:nil];
  
}


- (IBAction)btnLoad:(id)sender {
  NSFileManager *fileManager2;
  NSData *loadDataBuffer;
  NSString *fileName;
  NSString *dir2;
  NSArray *dirPaths2;
  
  fileManager2 = [NSFileManager defaultManager];
  dirPaths2 = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
  dir2 = [dirPaths2 objectAtIndex:0];
  fileName = [dir2 stringByAppendingPathComponent:@"testData.dat" ];
  
  if([fileManager2 fileExistsAtPath:fileName])
  {
    loadDataBuffer= [fileManager2 contentsAtPath:fileName];
    NSString *fileContentsString = [[NSString alloc]initWithData:loadDataBuffer encoding:NSASCIIStringEncoding];
    
    lblSavedContent.text = fileContentsString;
  }
}
@end
