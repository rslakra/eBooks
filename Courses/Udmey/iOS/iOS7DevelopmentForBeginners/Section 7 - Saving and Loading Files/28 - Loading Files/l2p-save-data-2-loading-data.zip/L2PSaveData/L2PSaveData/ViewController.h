//
//  ViewController.h
//  L2PSaveData
//
//  Created by Vector Prime on 7/22/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
//Saving
@property (strong, nonatomic) IBOutlet UITextField *saveUserData;
- (IBAction)btnSave:(id)sender;

//Loading

@property (strong, nonatomic) IBOutlet UILabel *lblSavedContent;
- (IBAction)btnLoad:(id)sender;

@end
