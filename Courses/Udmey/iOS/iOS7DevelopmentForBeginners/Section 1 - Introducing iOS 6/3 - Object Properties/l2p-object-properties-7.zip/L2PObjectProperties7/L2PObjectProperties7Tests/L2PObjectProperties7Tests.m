//
//  L2PObjectProperties7Tests.m
//  L2PObjectProperties7Tests
//
//  Created by Vector Prime on 7/13/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface L2PObjectProperties7Tests : XCTestCase

@end

@implementation L2PObjectProperties7Tests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
