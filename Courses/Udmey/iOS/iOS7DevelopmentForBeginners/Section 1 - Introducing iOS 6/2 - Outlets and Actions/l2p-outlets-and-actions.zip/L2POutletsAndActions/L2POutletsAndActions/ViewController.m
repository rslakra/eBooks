//
//  ViewController.m
//  L2POutletsAndActions
//
//  Created by Vector Prime on 7/13/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize tf1,tf2,tf3,lblResult;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)buttonOneCallBack
{
  lblResult.text = tf1.text;
}
-(IBAction)buttonTwoCallBack
{
  lblResult.text = tf2.text;
}
-(IBAction)buttonThreeCallBack
{
  lblResult.text = tf3.text;
}

@end
