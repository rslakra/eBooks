//
//  ViewController.h
//  L2POutletsAndActions
//
//  Created by Vector Prime on 7/13/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property(strong,nonatomic) IBOutlet UITextField *tf1;
@property(strong,nonatomic) IBOutlet UITextField *tf2;
@property(strong,nonatomic) IBOutlet UITextField *tf3;

@property(strong,nonatomic) IBOutlet UILabel *lblResult;

-(IBAction)buttonOneCallBack;
-(IBAction)buttonTwoCallBack;
-(IBAction)buttonThreeCallBack;

@end
