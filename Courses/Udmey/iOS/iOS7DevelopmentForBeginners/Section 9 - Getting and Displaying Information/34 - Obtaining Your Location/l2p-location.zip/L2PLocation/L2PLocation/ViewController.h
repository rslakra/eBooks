//
//  ViewController.h
//  L2PLocation
//
//  Created by Vector Prime on 7/27/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface ViewController : UIViewController <CLLocationManagerDelegate>
@property (strong, nonatomic) IBOutlet UILabel *lblLong;
@property (strong, nonatomic) IBOutlet UILabel *lblLat;
- (IBAction)btnLocate:(id)sender;
@property (strong,nonatomic) CLLocationManager *locationManager;


@end
