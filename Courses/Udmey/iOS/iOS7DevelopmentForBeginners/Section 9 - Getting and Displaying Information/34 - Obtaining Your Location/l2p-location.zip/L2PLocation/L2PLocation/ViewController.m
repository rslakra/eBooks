//
//  ViewController.m
//  L2PLocation
//
//  Created by Vector Prime on 7/27/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize lblLat,lblLong, locationManager;
- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
  locationManager = [[CLLocationManager alloc] init];
  locationManager.delegate = self;
  locationManager.distanceFilter = kCLDistanceFilterNone;
  locationManager.desiredAccuracy = kCLLocationAccuracyBest;
 
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnLocate:(id)sender {
   [locationManager startUpdatingLocation];
}

-(void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations{
  CLLocation *location =[locations lastObject];
  lblLong.text = [[NSString alloc] initWithFormat:@"%f", location.coordinate.longitude];
  lblLat.text = [[NSString alloc] initWithFormat:@"%f", location.coordinate.latitude];
}
@end

