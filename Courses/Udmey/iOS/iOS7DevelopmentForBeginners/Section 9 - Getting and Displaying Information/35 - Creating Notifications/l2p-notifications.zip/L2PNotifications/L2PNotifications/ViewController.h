//
//  ViewController.h
//  L2PNotifications
//
//  Created by Vector Prime on 7/27/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
