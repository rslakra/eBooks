//
//  ViewController.m
//  L2PWebview
//
//  Created by Vector Prime on 7/27/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize txtAddress, webView;
- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnGo:(id)sender {
  NSString *userURL = [[NSString alloc]initWithFormat: @"http://%@", txtAddress.text ];
  NSURL *url = [NSURL URLWithString:userURL];
  NSURLRequest *userRequest = [NSURLRequest requestWithURL:url];
  [webView loadRequest:userRequest];
}
@end
