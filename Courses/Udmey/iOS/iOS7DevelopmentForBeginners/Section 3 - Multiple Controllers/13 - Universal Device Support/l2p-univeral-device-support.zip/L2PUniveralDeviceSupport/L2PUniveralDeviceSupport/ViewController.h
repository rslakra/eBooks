//
//  ViewController.h
//  L2PUniveralDeviceSupport
//
//  Created by Vector Prime on 7/17/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (strong, nonatomic) IBOutlet UITextField *txtRoomWidth;

@property (strong, nonatomic) IBOutlet UITextField *txtRoomLength;

@property (strong, nonatomic) IBOutlet UILabel *lblResult;

- (IBAction)calcRoomSize:(id)sender;

@end
