//
//  ViewController.h
//  L2PStoryboardPart3
//
//  Created by Vector Prime on 7/17/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (strong, nonatomic) IBOutlet UITextField *textNum1;

@property (strong, nonatomic) IBOutlet UITextField *textNum2;


@end
