//
//  AppDelegate.h
//  L2PStoryboarding2
//
//  Created by Vector Prime on 7/19/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
