//
//  AppDelegate.h
//  L2PTableviewApplicationiOS7
//
//  Created by Vector Prime on 7/20/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
