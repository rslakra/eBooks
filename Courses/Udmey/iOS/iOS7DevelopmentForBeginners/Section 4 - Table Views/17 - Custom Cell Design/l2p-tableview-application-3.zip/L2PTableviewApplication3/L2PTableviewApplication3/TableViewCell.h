//
//  TableViewCell.h
//  L2PTableviewApplication3
//
//  Created by Vector Prime on 7/20/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *lblCarMake;
@property (strong, nonatomic) IBOutlet UILabel *lblCarModel;

@end
