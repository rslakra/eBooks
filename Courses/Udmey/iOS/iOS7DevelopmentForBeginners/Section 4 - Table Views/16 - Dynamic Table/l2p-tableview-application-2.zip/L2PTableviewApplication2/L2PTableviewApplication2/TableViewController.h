//
//  TableViewController.h
//  L2PTableviewApplication2
//
//  Created by Vector Prime on 7/20/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewController : UITableViewController
@property (strong,nonatomic) NSArray *carMakes;
@end
