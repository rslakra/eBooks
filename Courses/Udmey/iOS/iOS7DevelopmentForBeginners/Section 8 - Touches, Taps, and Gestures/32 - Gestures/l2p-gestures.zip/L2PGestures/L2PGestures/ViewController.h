//
//  ViewController.h
//  L2PGestures
//
//  Created by Vector Prime on 7/24/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (strong, nonatomic) IBOutlet UILabel *lblEvent;
- (IBAction)tapGestureDidOccur:(id)sender;
- (IBAction)swipeGestureDidOccur:(id)sender;
- (IBAction)longPressDidOccur:(id)sender;

@end
