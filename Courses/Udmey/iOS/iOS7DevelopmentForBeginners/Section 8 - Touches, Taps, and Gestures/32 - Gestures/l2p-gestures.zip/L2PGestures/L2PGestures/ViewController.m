//
//  ViewController.m
//  L2PGestures
//
//  Created by Vector Prime on 7/24/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize lblEvent;
- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)tapGestureDidOccur:(id)sender {
  lblEvent.text = @"Tap Gestured Occurred";
  NSLog(@"%@", [sender description]);
}

- (IBAction)swipeGestureDidOccur:(id)sender {
  lblEvent.text = @"Swipe Gestured Occurred";
  NSLog(@"%@", [sender description]);
}

- (IBAction)longPressDidOccur:(id)sender {
  lblEvent.text = @"Long Press Gestured Occurred";
  NSLog(@"%@", [sender description]);
}
@end
