//
//  ViewController.h
//  L2PDetectingGestures
//
//  Created by Vector Prime on 7/24/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (strong, nonatomic) IBOutlet UILabel *lblEvent;
@property (strong, nonatomic) IBOutlet UILabel *lblXPos;
@property (strong, nonatomic) IBOutlet UILabel *lblYPos;

@end
