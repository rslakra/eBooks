//
//  ViewController.m
//  L2PDetectingGestures
//
//  Created by Vector Prime on 7/24/13.
//  Copyright (c) 2013 Learn2Program. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize lblEvent,lblXPos,lblYPos;

-(void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
  lblEvent.text =@"touchesBegan";
  UITouch *touch = [touches anyObject];
  CGPoint point =[touch locationInView:self.view];
  CGFloat xPos = point.x;
  CGFloat yPos = point.y;
  lblXPos.text = [[NSString alloc] initWithFormat:@"%f" , xPos];
  lblYPos.text = [[NSString alloc] initWithFormat:@"%f" , yPos];
}

-(void) touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
  lblEvent.text = @"touchesMoved";
  NSLog(@"touchesMoved");
  UITouch *touch = [touches anyObject];
  CGPoint point =[touch locationInView:self.view];
  CGFloat xPos = point.x;
  CGFloat yPos = point.y;
  lblXPos.text = [[NSString alloc] initWithFormat:@"%f" , xPos];
  lblYPos.text = [[NSString alloc] initWithFormat:@"%f" , yPos];
}

-(void) touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
  lblEvent.text =@"touchesEnded";

}
- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
