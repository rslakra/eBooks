/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bonbhel.oracle.webServiceClientSecureSSL.facade;

import com.bonbhel.oracle.webServiceClientSecureSSL.Seller;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author bonbhejf
 */
@Stateless
public class SellerFacade extends AbstractFacade<Seller> {
    @PersistenceContext(unitName = "WebServiceClientSecureSSLPU")
    private EntityManager em;

    protected EntityManager getEntityManager() {
        return em;
    }

    public SellerFacade() {
        super(Seller.class);
    }
    
}
