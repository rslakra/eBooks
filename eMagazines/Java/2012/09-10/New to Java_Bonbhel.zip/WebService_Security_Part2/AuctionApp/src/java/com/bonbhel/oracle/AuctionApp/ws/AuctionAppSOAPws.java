/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bonbhel.oracle.AuctionApp.ws;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author bonbhejf
 */
@WebService(serviceName = "AuctionAppSOAPws")
public class AuctionAppSOAPws {

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "extrapolateAmountBid")
    public Double extrapolateAmountBid(@WebParam(name = "amountBid") 
            double amountBid, @WebParam(name = "factor") int factor) {
        //TODO write your implementation code here:
        
        double k = 0;
        if (factor == 0){
            k = amountBid;
        }
        else{
            k = amountBid * factor;
        }
        return k;
    }
}
