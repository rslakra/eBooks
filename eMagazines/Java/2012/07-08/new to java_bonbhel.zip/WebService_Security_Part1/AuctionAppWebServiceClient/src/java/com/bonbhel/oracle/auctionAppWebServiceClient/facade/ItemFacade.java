/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bonbhel.oracle.auctionAppWebServiceClient.facade;

import com.bonbhel.oracle.auctionAppWebServiceClient.Item;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author bonbhejf
 */
@Stateless
public class ItemFacade extends AbstractFacade<Item> {
    @PersistenceContext(unitName = "AuctionAppWebServiceClientPU")
    private EntityManager em;

    protected EntityManager getEntityManager() {
        return em;
    }

    public ItemFacade() {
        super(Item.class);
    }
    
}
