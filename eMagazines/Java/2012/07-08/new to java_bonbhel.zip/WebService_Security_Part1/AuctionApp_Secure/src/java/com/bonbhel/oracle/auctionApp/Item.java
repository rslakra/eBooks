/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.bonbhel.oracle.auctionApp;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

/**
 *
 * @author bonbhejf
 */
@Entity
public class Item implements Serializable {
    @OneToMany(mappedBy = "item")
    private List<Bid> bids;
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    protected String title;
    protected String description;
    protected double initialPrice;
    @ManyToOne
    protected Seller seller;

    public List<Bid> getBids() {
        return bids;
    }

    public void setBids(List<Bid> bids) {
        this.bids = bids;
    }

    /**
     * Get the value of seller
     *
     * @return the value of seller
     */
    public Seller getSeller() {
        return seller;
    }

    /**
     * Set the value of seller
     *
     * @param seller new value of seller
     */
    public void setSeller(Seller seller) {
        this.seller = seller;
    }


    /**
     * Get the value of initialPrice
     *
     * @return the value of initialPrice
     */
    public double getInitialPrice() {
        return initialPrice;
    }

    /**
     * Set the value of initialPrice
     *
     * @param initialPrice new value of initialPrice
     */
    public void setInitialPrice(double initialPrice) {
        this.initialPrice = initialPrice;
    }

    /**
     * Get the value of description
     *
     * @return the value of description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Set the value of description
     *
     * @param description new value of description
     */
    public void setDescription(String description) {
        this.description = description;
    }


    /**
     * Get the value of title
     *
     * @return the value of title
     */
    public String getTitle() {
        return title;
    }

    /**
     * Set the value of title
     *
     * @param title new value of title
     */
    public void setTitle(String title) {
        this.title = title;
    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Item)) {
            return false;
        }
        Item other = (Item) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.bonbhel.oracle.auctionApp.Item[id=" + id + "]";
    }

}
