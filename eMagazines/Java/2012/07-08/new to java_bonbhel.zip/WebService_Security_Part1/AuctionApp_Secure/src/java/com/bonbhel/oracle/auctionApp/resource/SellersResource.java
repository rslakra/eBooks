/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.bonbhel.oracle.auctionApp.resource;

import com.bonbhel.oracle.auctionApp.Seller;
import java.util.Collection;
import javax.ws.rs.Path;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.persistence.EntityManager;
import com.bonbhel.oracle.auctionApp.Item;
import com.bonbhel.oracle.auctionApp.converter.SellersConverter;
import com.bonbhel.oracle.auctionApp.converter.SellerConverter;
import javax.persistence.PersistenceContext;
import javax.ejb.Stateless;

/**
 *
 * @author bonbhejf
 */

@Path("/sellers/")
@Stateless
public class SellersResource {
    @javax.ejb.EJB
    private SellerResource sellerResource;
    @Context
    protected UriInfo uriInfo;
    @PersistenceContext(unitName = "AuctionAppPU")
    protected EntityManager em;
  
    /** Creates a new instance of SellersResource */
    public SellersResource() {
    }

    /**
     * Get method for retrieving a collection of Seller instance in XML format.
     *
     * @return an instance of SellersConverter
     */
    @GET
    @Produces({"application/json"})
    public SellersConverter get(@QueryParam("start")
                                @DefaultValue("0")
    int start, @QueryParam("max")
               @DefaultValue("10")
    int max, @QueryParam("expandLevel")
             @DefaultValue("1")
    int expandLevel, @QueryParam("query")
                     @DefaultValue("SELECT e FROM Seller e")
    String query) {
        return new SellersConverter(getEntities(start, max, query), uriInfo.getAbsolutePath(), expandLevel);
    }

    /**
     * Post method for creating an instance of Seller using XML as the input format.
     *
     * @param data an SellerConverter entity that is deserialized from an XML stream
     * @return an instance of SellerConverter
     */
    @POST
    @Consumes({"application/xml", "application/json"})
    public Response post(SellerConverter data) {
        Seller entity = data.resolveEntity(em);
        createEntity(data.resolveEntity(em));
        return Response.created(uriInfo.getAbsolutePath().resolve(entity.getId() + "/")).build();
    }

    /**
     * Returns a dynamic instance of SellerResource used for entity navigation.
     *
     * @return an instance of SellerResource
     */
    @Path("{id}/")
    public SellerResource getSellerResource(@PathParam("id")
    Long id) {
        sellerResource.setId(id);
        sellerResource.setEm(em);
        return sellerResource;
    }

    /**
     * Returns all the entities associated with this resource.
     *
     * @return a collection of Seller instances
     */
    protected Collection<Seller> getEntities(int start, int max, String query) {
        return em.createQuery(query).setFirstResult(start).setMaxResults(max).getResultList();
    }

    /**
     * Persist the given entity.
     *
     * @param entity the entity to persist
     */
    protected void createEntity(Seller entity) {
        entity.setId(null);
        em.persist(entity);
        for (Item value : entity.getItems()) {
            Seller oldEntity = value.getSeller();
            value.setSeller(entity);
            if (oldEntity != null) {
                oldEntity.getItems().remove(value);
            }
        }
    }
}
