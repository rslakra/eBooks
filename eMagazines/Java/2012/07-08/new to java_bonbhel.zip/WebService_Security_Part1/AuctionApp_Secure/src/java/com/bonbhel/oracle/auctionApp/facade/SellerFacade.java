/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.bonbhel.oracle.auctionApp.facade;

import com.bonbhel.oracle.auctionApp.Seller;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author bonbhejf
 */
@Stateless
public class SellerFacade extends AbstractFacade<Seller> {
    @PersistenceContext(unitName = "AuctionAppPU")
    private EntityManager em;

    protected EntityManager getEntityManager() {
        return em;
    }

    public SellerFacade() {
        super(Seller.class);
    }

}
