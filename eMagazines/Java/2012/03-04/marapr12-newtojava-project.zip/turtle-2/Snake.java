import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Snake here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Snake extends Actor
{
    /**
     * Act: move around (keyboard controlled) and eat pizza
     * if we find any.
     */
    public void act() 
    {
        moveAndTurn();
        eat();
    }
    
    /**
     * Move forward and turn if the control keys are pressed.
     */
    public void moveAndTurn()
    {
        move(4);
        turn(Greenfoot.getRandomNumber(40)-20);
    }
    
    /**
     * Look for pizza and eat it if we see some.
     */
    public void eat()
    {
        Actor turtle = getOneIntersectingObject(Turtle.class);
        if(turtle != null) {
            getWorld().removeObject(turtle);
        }
    }
}
