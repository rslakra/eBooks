Freeware. 

Build upon free tools and resources off Internet by Anunad and Raviratlami.

Feel free to use and distribute. Enjoy!

IMPORTANT : 

Go to the directory where you have installed this program and click open any of the file. It will open your default Browser. Now, to get the meaning of any english word, click the very first character on the list given on browser window, and start typing the word in the input window. Meaning window will dynamically change as and when you input characters.

Remember: 

If you type in the word whose FIRST character is other than the one you have clicked in the list in your browser, there will be error and no meaning will get displayed. So please remember to click the proper character first before inputting your query.